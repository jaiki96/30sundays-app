---
name: wishlist-phases
description: "Five-phase wishlist rollout agreed 2026-10-19, one branch and PR per phase off kashyap/main; decisions on destination folders, hotels by name, no regions tab, hints not pre-ticks"
metadata:
  node_type: memory
  type: project
  originSessionId: ba4c5fb8-9d50-43aa-9021-3a0c0601e04c
  modified: 2026-10-19T13:35:11.639Z
---

Wishlist rollout agreed with the user on 2026-10-19. CLAUDE.md was changed the same day to "work on main, commit there", so phases are committed straight onto local `main` (fast-forwarded to `kashyap/main` first), not on side branches. Pushing still needs an explicit ask.

Decisions (user's answers):
- Single wishlist, one destination (the /saved screen), tabs and filters inside it.
- Every save is filed under its destination automatically (the screen that owns the heart knows it). Saved screen opens on the last-viewed destination, chips switch folders.
- Tabs inside a destination: Trips, Stays, Things to do, Food, Shops. Regions are a FILTER, not a tab. Map toggle for located things.
- Hotels saved by NAME (hotel data is regenerated per trip dates, ids are positional).
- In Build and itinerary customise flows: only a "Saved" mark plus a "N saved for X. See them" line that opens the wishlist in add mode with "Add to trip". Never pre-tick.
- Partner saves: ignored at first, then brought back on 2026-10-19 (boards are shared; demo co-planner "Aanya Rao" on the Bali board). Lab flows (/discover, /wf) do get hearts and hints (Phase 5).
- Restaurants and shops: build the screens in parallel (Phase 3). Pools are not a saveable thing.

Phases: 1 one store + rebuilt Saved screen + universal toast + Account badge; 2 hearts on hotels, activities, ready-made trip cards; 3 food + shops; 4 hints in Build and itinerary customise; 5 variant flows.

Phase 1 committed on main 2026-10-19 ("One wishlist, filed by destination"). Store API: useWishlist().isSaved/toggle(kind, dest, id, meta); kinds trip, region, activity, hotel, restaurant, shop; ids: city name, `city::name`, version id, hotel name. useSaves is a thin adapter. Toast is global (WishlistToast in App). Phase 4 hints use an in-screen picker sheet, not navigation, so Build state is not lost.

Parked work: `git stash` entry "WIP travellers + journal screens (feat/building-addons-community)" holds uncommitted travellers/journal work. Restore it onto `feat/building-addons-community` when the user returns to that.

**Why:** Kashyap's main already had three unconnected save stores and a shared SaveHeart (commit 61e555e); the user wanted one list, and the destination-folder answer was left to me to propose.
**How to apply:** Follow the phase order, never pre-tick, keep hotels keyed by name + destination, and check [[design-rules]] for colour and copy. See [[sunday-community]] for the parallel feature on the same repo.

Trip boards (2026-10-19, after the user shared District and Tanishq references):
- /saved is now a list of destination boards; /saved/board/:dest is a board (map first, list in a sheet over it, District style); old screen kept at /saved/classic.
- TWO designs: the ONE-PERSON board ships first (first 3-4 months) and owns /saved; the GROUP board (people, love it too, loved-by-everyone rail, invite) lives at /saved/group. Same component with a `group` flag.
- Demo saves seeded in every destination (Bali, Thailand, Vietnam, Maldives, Sri Lanka, New Zealand) so all boards show.
- ONE board per destination, NO custom named lists: the user said customers never visit a destination twice.
- Board has: people on it + Invite sheet, "Love it too" per save, "Loved by everyone" rail, a note per save, "Plan <dest> from these saves" (opens /build?dest=X&from=wishlist; the route step opens the saved sheet, still no pre-ticks).
- Removing is instant with an Undo toast (no confirm sheet). Toast says "saved to your <dest> board" with "View board".
- Deferred ("later"): add-more search, sort, list menu/share, price alerts, first-save explainer.
