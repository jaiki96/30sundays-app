---
name: feedback-minimal-preview-eval
description: This repo is a prototype; skip heavy preview_eval verification loops
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 095e6a5c-79f2-4d46-a134-413d092530f3
---

This repo (30sundays-app) is a throwaway prototype, not production. Do NOT run long chains of `preview_eval` clicks/queries to verify changes.

**Why:** The user found the repeated eval-driven click-throughs noisy and unnecessary for a prototype.

**How to apply:** After a code change, rely on `npx vite build` passing for correctness, and take at most ONE `preview_screenshot` when a visual result genuinely needs confirming. Don't script multi-step DOM interaction via eval to "prove" flows work. If something needs interactive testing, ask the user to click through it themselves.
