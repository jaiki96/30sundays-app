---
name: booked-home-lab
description: The default home is now the Perfect match design for new/lead, and the boarding pass trip block for booked customers; picked 30 Sep 2026
metadata:
  type: project
---

The app's default home is the Perfect match design (home 6 in the lab). Same
component serves "/" and /home-lab/6, so the lab and the real home never drift.

- New and lead: the clip with one fixed line, then Plan my trip (or the resume
  card for a lead), then Our Curations, Why we're the perfect match, Sunday School.
- Booked customer: the clip STAYS and shows their own destination, with "Your
  trip to <country>" on it. The boarding pass sits over the bottom third of the
  clip, then the Sunday Lounge card. Everything from Our Curations down is the
  same page for everyone. The plainer no-clip version is kept only for
  comparison at /home-lab/booked-flat; do not ship that one.

The pass carries: lead traveller first name, nights, 30 Sundays, IND India to
the destination country code, depart and return as dd mmm yy, the countdown and
barcode on the stub, and a small "Trip details" link. No cities, no route.
The Lounge card is entry option 21, the drawn immigration stamp, with no FAQ
count, fixed to 70% of the pass height.

The old home is kept reachable at /home-v5 while it is still under review.
The floating trip card is hidden for customers on the home: the trip block
replaces it, and the two showed different destinations and countdowns.

**Why:** the customer home used to be identical to a new visitor's, selling a
trip they had already paid for. A bottom-right floating icon was rejected
because it fights the bottom nav.

**How to apply:** the booked trip shown is Thailand trip-1, because the Lounge
story is built on the Thailand room. The five booked tops stay at
/home-lab/booked/1-5 as a picker. See [[home-lab-worktree]].
