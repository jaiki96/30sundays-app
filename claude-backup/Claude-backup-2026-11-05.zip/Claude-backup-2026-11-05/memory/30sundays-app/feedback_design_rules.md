---
name: feedback-design-rules
description: "The user's compiled design rules for the 30 Sundays app. Read before designing or changing any UI in this repo."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a9396f51-2760-4e40-95dc-857d9f666ab4
  modified: 2026-10-30T06:26:02.652Z
---

The user's design system, compiled from their own corrections. **Why:** they correct the same
classes of mistake repeatedly, and each correction is a rule, not a one-off. **How to apply:**
check a design against every section below before building it, not after they point it out.

Related: [[feedback-industry-best-practices]], [[feedback-check-existing-components]],
[[feedback-no-em-dashes]], [[feedback-concise-responses]].

## 1. Colour

The brand board: sunsetFuchsia `#FD014F`, tropicalForest `#254342`, lagoonBliss `#00A898`,
goldenHour `#FDA201`, coastalMist `#EAE6E3`.

- **Every colour means one thing.** Green is type. Lagoon is proof (verified, trip stamps).
  Golden is attention (new, unanswered, live). Fuchsia is the one primary action.
- **Fuchsia is never decoration.** Not on unread counts, not on "Read more", not on secondary
  links. One primary action per screen; on a trip screen that is Pay now.
- **Never use an accent randomly.** If a colour is doing a job it already does elsewhere, it
  is fine. If it is there to be pretty, take it out.
- **Default to white.** Do not wrap body text in a tinted panel to group it.
- **A tinted block is a doorway, not a field.** Use it for one entrance, then go back to white.
- **Raised surfaces stay in the family.** A card on a gold ground is gold lifted towards white
  (`#FFFDF7`), never plain white.
- **No solid pill badges.** Coloured text carries it. A pill around something that is true of
  everything is decorating the default.
- **One neutral for repeated decoration.** Avatars use a single warm neutral, not rotating
  accents. Rotating three accents spends all three on decoration.
- **A section's colour must survive the tap.** The entry point and the screen it opens share
  a ground, or the two do not read as the same place.

## 2. Numbers and labels

- **Never a bare number.** Say what it counts. "3 answers", not "3". "3 unread messages",
  not "3".
- **Never show zero.** "0 answers" tells somebody the thing is dead. Hide the count, or say
  what is needed instead ("Needs an answer"). Answer counts appear at 2 or more.
- **Count what changes behaviour.** New messages, not lifetime totals. A running total is a
  vanity number: it changes nothing anyone does next and crowds the number that does.
- **Lead with the figure that exists on day one.** Past travellers exist from the first hour;
  this month's cohort has to fill up first.
- **Fall back before a number goes thin.** Under a threshold, swap the number for a promise
  that is true whatever the count says.

## 3. Layout and structure

- **Different kinds of thing must look different.** A greeting, a live room and a rule book
  should not all arrive as the same white card.
- **Separate on one axis at a time**: weight, ground, shape, or fewer blocks. Not all four.
- **Fixed heights in any repeated row or rail.** Ragged bottoms are what make a rail look
  unfinished.
- **Every repeated element gets one slot per fact.** The count sits in the same place on every
  card, never floated to wherever the text ended.
- **Rail geometry**: cards at ~84% of screen width so the next peeks 40-50px, 16px left edge,
  12px gutters, scroll-snap on. A snap target must exist for the last item or the rail cannot
  rest there.
- **Truncate in CSS, not with a guessed character budget.** A budget is wrong on every width
  it was not measured at.
- **Cap long text at 5 lines with Read more**, measured so the link only appears when the text
  actually overflows.
- **No fixed bottom bar restating counts already on the screen.** One floating action instead.
- **One primary action per screen, in the thumb zone.** Top corners are the dearest real
  estate; the bottom right is the cheapest.
- **Which action gets the thumb changes over time.** Early, it is the one the product needs
  (creation). Later, it is the one people repeat. Name the metric that flips it.
- **Never two entry points to one destination visible at once.** Hand over by scroll position:
  the in-page card on arrival, the header icon once it scrolls away.
- **Controls sit with what they act on.** A search box belongs inside the section it searches,
  under its heading, not floating above an unrelated block.
- **Full bleed means both axes.** A band butts against its dividers with no white strips.
- **A card that is itself the tap target contains no button.** A named link is enough.
- **Wishlist lives on the item, never behind a link.** Anywhere saved things can be chosen
  (activities, hotels, cities), the item itself carries its heart and saved items sort first
  in their row. Never a "2 saved, see them" line that opens a separate sheet: it breaks the
  flow. Rejected 2026-10-29 with "why are you making me say design principles again".
- **Actions on repeated items get cut hard.** Question: all five. Reply: like, reply, report.
  Icons without labels. The rare ones go to the top or into a menu.

## 4. Copy

- **Never all caps.** No uppercase kickers, labels, or badges unless they ask for it by name.
  Proper case everywhere. Small size and weight carry a kicker on their own.
- **Never em dashes.** Anywhere, ever. Hyphens, commas, parentheses, separate sentences.
- **No couple or family framing.** Travellers, people, everyone. The product is going wider
  than honeymoons. Never "you two", "you both", "meet", "couples". Since 2026-10-19 this is
  app-wide with no exceptions (not even quoted brand copy). New brand focus: "the full picture
  of your holiday". The guide series is called "Sunday guide", not "Couple's guide".
- **Counts, not labels, for who went.** "2 adults, 1 child" as numbers and icons. Never
  "Family of four" or "Solo".
- **Proper first and last names.** Never "The Deshpandes", never "Lakshmi & Ravi".
- **Names, not cities.** Where somebody lives says nothing about whether their answer is worth
  reading.
- **A headline is a fact or a promise, never an instruction.** "19 travellers are going" beats
  "Ask travellers who have been".
- **A CTA names its destination.** "Visit Lounge", not "Open".
- **Short date forms in bylines.** "Jun '26", not "June 2026".
- **Do not say verified when everything is verified.** It says nothing and costs a line.
- **Do not repeat what the surrounding screen already says.**
- **Subheads under every row are what make a screen read as prose.** Titles only, usually.
- **No subtitle by default, on sections too.** A section gets a title only. Add a line
  under it only when the title cannot be understood without it. The user rejected
  "Our travellers / What they booked, filmed and said" and three more subtitles on
  2026-10-16 with "why are we using sub title always?".
- **Simple words in headings.** Plain nouns people already use ("Reviews", "Recent
  bookings") beat clever phrases ("In their words", "On their trips"). Rejected on
  2026-10-16 as not simple.
- **No pronouns in headings.** Not "Our travellers", not "Their reviews". Say the
  noun: "Real travellers", "Reviews". The word "travellers" is fine to use.
- **Say the plain consequence, not a label for it.** "Can't be changed", not "Fixed".
  "Not rated yet" / "No tours today", not a clever chip. The user's mental model is
  concise, simple, explicit words (2026-10-29).
- **Status text is never a pill.** A pill reads as tappable. A missing rating is plain
  grey text, not a chip (2026-10-29).
- **Score is not rating.** "Day score" = How this day feels (pace, crowds, time). Rating =
  % of travellers who enjoyed it. Keep the two apart in copy and in empty states.
- **Tips and notes use the honest-bit family, lightly.** Cream paper, a small handwritten
  (Caveat) title like "30 Sundays tip" or "The honest bit", one regular-weight line, then
  "Read more". No bold body text, no plain system-font label: the user called a bold
  one-line "Ubud tip" boring (2026-10-30).
- **Plain copy needs a lively frame.** After the travellers block went to plain
  headings on flat cream, the user called the work "lifeless" (2026-10-16). Plain
  words are right, but the energy then has to come from the design: a section's
  own ground, the brand's display type, motion, imagery. Never ship a plain-copy
  block on a plain ground with nothing else carrying it.

## 5. Cold start

The product launches with an empty room. Every design has to survive that.

- **Never lead with something that needs a full room.** No quoted questions in an entry point,
  no cohort counts as the headline.
- **A failed search is the best moment to ask.** Pre-fill the question with what they searched
  for; never make them retype it.
- **Ask people to answer.** Supply is passive otherwise. One unanswered question, the composer
  one tap away, dismissible for good.
- **Show the day-one state next to the busy state** when presenting options. A line that only
  works when busy is not an option.

## 6. How to present work to this user

- **Always give variations, and say what each one costs**, not only what it is good for.
  Usually 5 to 7.
- **Borrow patterns already in this prototype before inventing one.** The hotel listing's
  collapsed summary bar and Change day plan's chips plus sliders button are both house patterns.
- **Show variations in place**, at real width, with real content, and with the neighbouring
  sections around them.
- **Variation screens get their own route.** Never overwrite a live screen.
- **State a recommendation with the reasoning.** They ask for a view, not a menu.
- **Do not agree blindly.** When they propose something, think it through and push back with
  reasons if it is wrong. They have said so explicitly.
- **Name the trade-off you are leaving on the table**, so they can overrule it.
- **References are a direction, not a spec.** When they share screenshots to riff on,
  take the idea behind each one and do something new with it. Five near-copies of the
  references were rejected on 2026-10-16 with "do not copy exactly, be creative".
- **No dark themes or dark bands.** A deep forest band was rejected the same day. Keep
  sections light; get contrast from type, accent colour and motion instead.
