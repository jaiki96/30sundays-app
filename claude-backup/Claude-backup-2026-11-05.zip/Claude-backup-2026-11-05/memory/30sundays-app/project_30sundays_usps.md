---
name: project-30sundays-usps
description: The three USPs 30 Sundays markets, as the brand words them; the couple exception was revoked on 2026-10-19
metadata:
  node_type: memory
  type: project
---

The three USPs, given by the user on 2026-09-17 as an image of the live marketing block. Use this
wording, not invented alternatives:

1. **Made for Couples** - Vacations curated solely with couples in mind.
2. **Price Transparency** - The only travel company that splits flights, hotels and activities.
3. **No Tourist Traps** - Only hotels rated 8 and above, and hand picked activities.

**Why:** these are the claims the business actually makes. USP two is also the honest version of
price anchoring: show the split of a real trip, never an invented "internet price" to beat.

**How to apply:**
- REVOKED 2026-10-19: "Made for Couples" is no longer an exception. The user asked for neutral
  wording across the whole app, no exceptions, because the brand focus is now "the full picture
  of your holiday". Do not use USP one as worded; see [[feedback-design-rules]].
- Show the three as a thin bar over the hero clip, not as a list further down. The user asked for
  this explicitly: on the footage they read as context for what you are looking at. A separate
  card list below repeats what the hero already says.
- A price split card proving USP two was built and then cut: the user did not want it on the home.

Related: [[feedback-design-rules]], [[project-home-lab-worktree]].
