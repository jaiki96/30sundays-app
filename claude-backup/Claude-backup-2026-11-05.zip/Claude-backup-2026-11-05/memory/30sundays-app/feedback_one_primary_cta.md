---
name: feedback-one-primary-cta
description: "HARD RULE, user is fed up: one filled dark-pink button per screen, ever. Suggestions and add-ons stay subtle. Check every board before publishing."
metadata:
  type: feedback
---

**One filled dark-pink (#E31B53) button per screen. Never more.** On the itinerary that one is already Save Itinerary (or Pay now on a trip). Anything else on the page, including add-on cards, suggestion rows, quick actions and rail cards, gets a quiet button: white, 1px #D5D7DA border, navy text, small pink icon at most. Added state: lagoon check plus plain text, never a pink fill or a pink outline repeated per card.

Suggestions, recommendations and "popular" rows must be **subtle**: they help the journey continue, they must not shout over the plan. No pink text links repeated on every row either (Undo, Add, See): use navy or grey text.

**Why:** the user said on 2026-11-03 "I am fed up with your behaviour of not saving my previous instructions in memory and still giving multiple primary CTA on the page in dark pink color, and not making it subtle." The rule already sat in [[feedback-design-rules]] (section 1, "Fuchsia is the one primary action") and I broke it anyway: Quick actions rounds 1-3 put a filled pink "Add" on every card.

**How to apply:** before publishing any board or screen, count the filled pink buttons visible in that screenshot, including the app's own bottom bar. If the count is above one, fix it before publishing. A sheet over the page may have its own one primary (the page behind is dimmed). Also re-read [[feedback-design-rules]] before any new design round, not after.
