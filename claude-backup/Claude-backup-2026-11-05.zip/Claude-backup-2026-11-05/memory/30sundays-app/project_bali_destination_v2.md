---
name: bali-destination-v2
description: "Bali destination pages /destination-v2 (Figma), /destination-v3 (brief) and /destination-v4 (Figma plus gaps, the one going forward) on branch feat/bali-destination-v2 (worktree bali-dest, port 5212)"
metadata:
  node_type: memory
  type: project
  originSessionId: 5a14c7b4-cf1a-4c6b-a7c9-f326eddd0f81
  modified: 2026-10-19T14:27:52.150Z
---

Started 2026-10-19. The user asked to implement the Figma destination design
(file 5RtSvviuO53NEHrDeNKKBw "30 Sundays", Prototype page, frame 81:5093) on a
separate url first, then merge onto /destination/:name once approved.

- Branch `feat/bali-destination-v2` off `kashyap/main`, worktree
  `.claude/worktrees/bali-dest`, preview config "bali-dest" on port 5212.
- Scope chosen by the user: Bali only.
- Figma: the connected account (jaiki96@gmail.com) is view-only and the owner
  turned export off. The user said to do the best possible from the prototype.
  Art was captured with headless Chrome (puppeteer-core from the main repo's
  node_modules) at about 3.85x, overlays painted out, saved in `public/bali-v2`.
- "Couple's guide" became "Sunday guide" (user's pick).

**Why:** this is the review copy; nothing is merged onto the live destination
page without approval (CLAUDE.md).

**How to apply:** keep later Bali page work on this branch. Open questions at
hand-off: design trip prices (₹32K) sit below the app's Bali "from" price
(₹48,998); Kuta and Nusa Dua have no region page; Shopping tab dropped for lack
of content. Related: [[feedback-design-rules]], [[project-30sundays-usps]].

**v3 (same day):** /destination-v3/Bali rebuilt to the user's written brief
(information before action, sticky Plan my trip, 12-month best-time strip that
opens the plan calendar on the tapped month via `?month=0-11`, compare table).
Decisions the user gave: one price, chosen as the app's ₹48,998 ("₹49K") with
real app itineraries as packages; sample booking counts from 10,000; sample
review summary, liked/didn't-like chips and one 4 star review (marked Sample,
user will supply real Google reviews); price by month shown only as season;
flight inclusion left out; Sunday School videos and an AI expert both kept;
pins only show the selection, cards do the picking.

**v4 (2026-10-30), the version going forward:** /destination-v4/Bali keeps the
Figma look and order and adds what was missing. Decisions the user gave, item
by item: vibe tiles under the hero (not on it); intro paragraph; price line
says nights and hotel level ("4 star stays", my pick); best-time strip reuses
the wizard's sky and season chips and words, never negative; Moods became
highlight cards; map stays, hearts on area and activity cards; "Getting there"
is text-only rows with an "as of" month (user: easy to update); packages use
the region page's BookedCard; Sunday School is the live EduMultiCarousel;
Ask the expert removed (no feature yet); Sunday guide removed; reviews title
"What travellers said"; compare table; FAQ. **No swing and no Handara gate
anywhere on the page** (30 Sundays tells travellers to skip both). Ship order:
tall picture first, then the test link, then replace /destination/Bali on
approval and retire v2, v3 and the tops.

**v7, all destinations (2026-11-01), the working prototype:** the canvas v7 design
(Claude Design artifact SctsmESadMfyEg22XszkFf, board Full7) built for all seven
destinations at /destination-v7 (index) and /destination-v7/:name. Worktree
`.claude/worktrees/dest-v7`, branch `feat/destination-v7` off 441253e plus the
activities worktree's uncommitted files (so the deploy kept what was live). Files:
src/pages/DestinationV7.jsx, src/data/destV7Data.js (facts as of Nov 2026, samples),
one-pager public/destination-v7.html. Deployed with `vercel deploy dist --prod --yes
--project 30sundays-activities` (copy vercel.json into dist first). Uncommitted.
Preview config "dest-v7", port 5216. The old /destination/:name page is untouched.

**v8 (2026-11-02):** canvas boards Full8 + Bar8. Built into /destination-v7 locally
(not deployed): six itinerary rows placed beside their sections (most loved, an
activity, a place, real travellers, relaxed, under a budget; picked per country in
destV7Data `itineraryRows`), and the itinerary page's SectionNav (variant "soft").
Sample Bali trips ids 110-115 (`sample: true`, Gili Islands and ATV ride) were added
to allItineraries at the user's request; bookedTrips skips samples. Wording stays
"Indian travellers", not couples (user agreed).

**v9 LIVE (2026-11-02):** commit d37c3d1 pushed to origin main (jaiki96/30sundays-app);
Vercel project 30sundays-app builds from main (30sundays-app.vercel.app). /destination/:name
now renders DestinationV7 for all seven countries (earlier layouts stay on /wf/:name and
/old-bali-page). v9 = trip row titles "title + See all" (Most loved trips, Trips with
[activity], Trips with [place], Recently booked trips, Relaxed trips, Trips under X);
activity/place sit at the end of the title and open a sheet of choices; Best time is a
season accordion with season-tinted headers and one weather tag (majority sky). The
activities worktree's uncommitted honest-bit work was NOT included in the commit.

**2026-11-02, v10 order LIVE (commit 7b8b50e on origin main):** photos, title/intro, plane-window vibes (a tap on blind or view opens the gallery; drag moves the blind), Recently booked itineraries, Places + Trips with city, Best time, wishlist card (DestWishlistBand, "Start your X wishlist" when empty, ?wish=empty to force), then Most loved, Things to do, Trips with activity, Getting there, Sunday School, Compare, Questions, Reviews. Flights/visa box at the top removed. This push also took the other session's 4 wishlist commits (dcfb646..bf5d97a) live, with the user's OK. Open: the Glimpses teaser may show a swing photo.

**2026-11-03, LIVE afb9cf5:** blinds follow the row (open share = window width in view, rest at top, new view after a full shut, zzz only by hand); Places and Things to do lead with the centered card in a looping row (three copies, useLoop), spotlight A (two lagoon hairlines + faint tint) joins it to "Trips with X" below (dropdown rows for places/activity gone; no trips = no section); Things to do cards 160x284 (near 9:16); the vibes windows row loops too (views kept per vibe). Canvas boards Link11a-d, Blind11a-b.

**2026-11-03, LIVE fa4017b:** scroll-closing of blinds REMOVED (user: "not looking good"); blinds rest at top, move only by hand, hand position and view shared per vibe across loop copies. Trip card on destination pages = canvas Card12b: no pace tag, no divider, photo 124, route then one line price + "N nights" at right (216px tall). Home cards unchanged.
