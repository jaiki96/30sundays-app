---
name: No em dashes
description: User dislikes em dashes (—) anywhere — in code, copy, chat strings, or commit messages
type: feedback
originSessionId: 5a14c7b4-cf1a-4c6b-a7c9-f326eddd0f81
---
Never use em dashes (—) in any output.

**Why:** Stated as a hard preference during the chat-screen build on 2026-05-13.

**How to apply:** In UI copy, code comments, commit messages, and conversational replies, use regular hyphens (-), commas, parentheses, or periods instead. Search-and-replace any em dashes I find in files I'm already editing.
