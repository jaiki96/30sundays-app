---
name: home-lab-worktree
description: Home lab now lives in the MAIN repo (6 homes + labs at /home-lab, port 5201); the old worktree copy on 5203 is stale and its section-join work was rescued on 30 Sep 2026
metadata:
  type: project
---

The home revamps live at /home-lab in the MAIN checkout, served by the
"30sundays-app" launch config on port 5201. Six homes now: Crew layout, Six
chapters, Pinned clip, Fill in the blank, Poster stack, Perfect match. Plus the
cards, cta, plans, states, lines and booked labs.

The separate worktree at .claude/worktrees/home-lab (port 5203, branch
feat/home-lab) is now STALE. Do not build there and do not send the user its
links.

**Why:** on 30 Sep 2026 the user asked why the section joins looked broken. The
polish work (the smootherstep bridge that fades the page ground into Sunday
School's yellow, the video mask fade, the GlassEdge rewrite, the six hero line
animations, the Perfect match home) had been done in the worktree but never
committed, so the merge into feat/lounge-and-home carried only the older
committed state. It was rescued by copying the uncommitted files across.

**How to apply:** commit home lab work promptly, and prefer the main checkout.
If anything else is ever missing, check `git status` inside the worktree before
assuming it was never built. See [[booked-home-lab]].
