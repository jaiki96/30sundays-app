---
name: feedback_check_existing_components
description: "before adding UI to a section, check what that area is already reserved for"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 095e6a5c-79f2-4d46-a134-413d092530f3
---

Before adding a new UI block, check the existing components and what each screen
area is already reserved for. Don't drop new content into space another feature
owns (e.g. the hotel card area is reserved for hotel upgrades / "Change" room,
not for special inclusions).

**Why:** The user rejected a "What's included at your hotels" accordion placed in
the hotels area because that space already belongs to hotel upgrades.

**How to apply:** Scan sibling components and their placement first. Put new
content where it belongs (its own CTA + drawer), not on top of an existing feature.
Related: [[feedback_industry_best_practices]].
