---
name: Concise responses, short sentences
description: Standing rule - answer in short bullet points, sentences under 15 words, every response
type: feedback
originSessionId: fc25bcab-debc-4dd5-b811-2f49041fd297
modified: 2026-08-18T19:58:24.790Z
---
Answer in short bullet points. Max 15 words per sentence. Applies to every
response, not just when asked.

**Why:** User asked twice, and the second time made it a standing condition to
check before replying. Long prose answers were not being read.

**How to apply:** Lead with the answer. Bullets by default, prose only when a
bullet cannot carry it. No preamble, no trailing summary, no restating the
question. Cut caveats unless they change what the user does next. Combine with
[[feedback_plain_plans]] and [[feedback_no_em_dashes]].
