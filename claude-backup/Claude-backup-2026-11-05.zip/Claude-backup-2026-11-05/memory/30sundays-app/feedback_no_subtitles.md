---
name: no-subtitles-under-titles
description: Never put a subtitle line under a section or page title unless the user asks for one explicitly
metadata:
  node_type: memory
  type: feedback
  originSessionId: 5a14c7b4-cf1a-4c6b-a7c9-f326eddd0f81
  modified: 2026-10-30T10:41:50.254Z
---

Section and page titles stand alone. No "sub" line under them, anywhere in the app or on canvases, unless the user asks for one on that screen.

**Why:** On 2026-10-30, reviewing the Bali destination canvas, the user said subtitles make the page "very text heavy and bulky" and asked for this to be remembered as a standing rule.

**How to apply:** Write the title so it carries the meaning. If a hint is truly needed (for example "tap a month"), put it in the content, as a small caption on the element, not under the heading. Strip `sub` props from section headers before showing a page. See also [[concise-responses]] and [[design-rules]].
