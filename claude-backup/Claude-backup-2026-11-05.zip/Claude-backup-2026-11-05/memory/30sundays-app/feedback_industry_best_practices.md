# Industry best practices for UI/UX decisions

When designing or building UI, always apply established industry best practices and patterns rather than ad-hoc solutions. Look to top apps in the relevant space (travel, fintech, social, etc.) for proven patterns. Examples:

- For metric tiles showing multiple related values (e.g. activity time + travel time totaling tour duration), keep each metric visually distinct (its own icon + value + label) so the user can parse each piece, with a combined total shown contextually. Don't collapse distinct metrics into a single ambiguous string like "6.5h + 6h" that loses meaning.
- For primary CTAs, the disabled state should look like the primary CTA at reduced opacity, not a ghosted neutral pill. (Apple HIG, Material 3.)
- Apple HIG minimum readable type: caption 11pt / footnote 13pt / body 17pt. Don't drop below these for important info.
- For overlaid text on imagery, always include a gradient/scrim for legibility.

Apply this proactively. If a quick implementation produces something that doesn't match how a polished app would handle the case, redo it.
