---
name: project-versioned-deals
description: Mobile versioned-deal architecture mirroring the back-office deal/version model
metadata: 
  node_type: memory
  type: project
  originSessionId: 095e6a5c-79f2-4d46-a134-413d092530f3
---

The mobile app mirrors the back-office deal model: a deal holds versions. Implemented 2026-06-10.

**Model** (`src/data/deals.js`, `DealsProvider` context + localStorage key `30s_deals_v1`):
- Version statuses: `draft` (editable) → `quote` (locked, priced, PDF) → `expired` (quote older than `QUOTE_VALID_DAYS` = 7).
- Versions mint only on two events: customer Saves a catalog itinerary (v1 draft), or edits a locked quote (fork → new draft). NOT per-edit.
- `computePrice` = base itinerary price + sum of selected day-plan deltas.

**Flow** (`ItineraryDetail` reads `?dealId&versionId`):
- Catalog (no params): "Save to My Plans" creates a draft, navigates into deal context.
- Draft: editable, indicative price, sticky pink banner + "Request live pricing".
- Quote: locked, edits disabled (day-change pills hidden via `dayHasOptions` gate, "Change Hotel" hidden), "Edit" forks a new draft.
- My Plans (`Plan.jsx` success) shows a "Saved plans" deal hub with version rows + status badges.

**Key product decisions:** pricing is instant-simulated (the back-office "Pricing requested" pending state is collapsed); customer never sees raw version numbers as the primary label (Draft/Quote/Expired badges).

**Known gaps:** flights/hotels are NOT yet snapshotted per-version (only `selectedDayOptions` + `travelDates` are). Expiry logic exists but needs a backdated `pricedAt` to demo. Relates to [[project-day-swap]] if that memory exists.
