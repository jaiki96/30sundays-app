---
name: feedback_plain_plans
description: keep plans short and plain; never mention files or code (user is non-technical)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 095e6a5c-79f2-4d46-a134-413d092530f3
---

When presenting plans, keep them short and in plain language. Never mention file
names, code, or file-level changes. Describe what changes for the user and how it
behaves, not how it is built.

**Why:** The user is non-technical and found file-level plan detail noise.
**How to apply:** In plan files and plan summaries, lead with behaviour and
rationale. Omit paths, function names, and implementation steps. Also recorded in
the project CLAUDE.md. Relates to [[feedback_concise_responses]].
