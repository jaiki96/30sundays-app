---
name: feedback-local-first
description: Show changes on the local preview first; deploy to Vercel or push to GitHub only after the user approves
metadata:
  node_type: memory
  type: feedback
  originSessionId: 095e6a5c-79f2-4d46-a134-413d092530f3
  modified: 2026-10-29T13:15:48.501Z
---

Show new work on the local preview (localhost) first. Deploy to Vercel or push to
GitHub only after the user has looked and approved it.

**Why:** On 2026-10-29 the user said "first give on local only, after approval only take
everything live", after several rounds where each change was deployed straight away.

**How to apply:** After a change, give localhost links and stop. Do not run `vercel deploy`
or `git push` until the user says it is approved or asks to make it live. Earlier
standing approvals ("make it live") applied to that change only. Related: [[feedback-design-rules]].

**Reuse Vercel projects.** Never create a new Vercel project per feature; deploy to an
existing one (the user said so 2026-10-29 after `30sundays-activities` was created).
Current activities work lives on `30sundays-activities` (prj_4rNp9TVLG610Jf3AV9rJsGV5BlGU,
team_IgH1rnXrxoV2fw72CkbBGvi3); ask which existing project to use if unclear.
