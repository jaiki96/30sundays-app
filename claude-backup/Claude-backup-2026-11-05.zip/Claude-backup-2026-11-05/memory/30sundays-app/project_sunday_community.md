---
name: sunday-community
description: The community feature is called Sunday Community (was Lounge, then Circle); lives at /community; entry designs 29-45; nested replies 3 deep
metadata:
  type: project
---

The feature is called **Sunday Community**. It was Sunday Lounge, then briefly
Sunday Circle on 5 Oct 2026, then Sunday Community the same day. Addresses went
/lounge* then /circle* then /community*; both older spellings still redirect.
The demo index of every screen moved from /community to /community-demo. The rename sweep was done on
5 Oct 2026: all user-facing copy, every entry design, and the web addresses,
which moved from /lounge* to /circle*. The old addresses redirect, so links
already shared keep working.

NOT renamed, on purpose: real hotel and airport lounge copy in the hotel,
resort and upgrade data; internal file, component and stylesheet names;
analytics event keys such as community_lounge_entry_tapped.

Still outstanding: the illustration public/lounge-entrance.webp has
"SUNDAY LOUNGE" painted into its signboard. Entry design 28 uses it and keeps
the label "Lounge entrance" because it literally depicts an airport lounge.
It needs the picture redrawn to say Circle.

Entry designs 29-40 at /community-entries are the Sunday Circle set:
29 voices, 30 many stamps, 31 guest book, 32 manifest, 33 contact sheet,
34 postcards, 35 wall of names, 36 constellation, 37 the arc, 38 subject tiles,
39 drawn together, 40 subject cards.

A first attempt at 29-38 was rejected: "you have used only circles and didnt
innovate". Eight were deleted. The lesson is that rearranging avatar chips is
not a design; each one now uses a different material (handwriting, print,
photography, paper, type, orbit, illustration, colour blocks).

36-40 were built from community-app references the user supplied and are the
first to use real traveller photographs instead of initials. Photos only read
at 34px and above, because the library holds landscape holiday shots of couples,
not portraits. Below that size use initials.

**Why:** the user said every design up to 28 reads as a lounge or an object and
never as a group of people. Three signals are BANNED at launch because there is
no content yet, and may return in 3 to 4 months: real questions in a
traveller's words, reply or answer counts as a community signal, and recency
like "answered 11 minutes ago". So the people set leans only on who is already
there, which is true on day one.

**Home page, as of 5 Oct 2026:** the Community is NOT a card on the home. It is
one line under the boarding pass plus a hyperlinked action, because two cards
of the same size stacked read as two boxes put together. Five wordings at
/home-lab/line, variation 1 live. Five ways to show the Google rating and the
traveller count at /home-lab/proof, none chosen yet.

Handwriting (Caveat) is now reserved for teaching sections such as Sunday
School and Know before you go. Home page headings use the default face.

Replies nest three levels deep, with an indent, a vertical rail and a reply
count on each comment. Deeper replies attach to the grandparent rather than
indenting further.

**Superseded:** design 36, the constellation, is the Circle entry point on both
the trip details screen (full, 150px orbit) and the home page (compact, inside
the 106px card). The 30 Sundays logo mark holds the centre and every orbit
position is a real traveller photograph, no placeholder circles. The
immigration stamp is no longer used as an entry point.

**How to apply:** avatars are initials on warm neutral, not photos. The count
is always "have travelled with us", never how many are going. The home entry
point is allowed to look different from the trip screen one, and only "named
three" is short enough for the home card's 106px. See [[booked-home-lab]].
