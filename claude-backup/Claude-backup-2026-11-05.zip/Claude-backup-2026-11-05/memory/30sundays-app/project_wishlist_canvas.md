---
name: wishlist-canvas
description: "Wishlist iterations design canvas (2026-11-02): 4 rows, 25 boards, hotels/change day/entry point/coverage; user's answers and my picks"
metadata:
  node_type: memory
  type: project
  originSessionId: ba4c5fb8-9d50-43aa-9021-3a0c0601e04c
  modified: 2026-11-02T10:39:58.645Z
---

Design canvas "Wishlist iterations": https://claude.ai/artifact/PGxUef1m1ESdQuFL7ecxyr (created 2026-11-02). Before this, wishlist work went straight into the prototype; there was no canvas.

Rows (boards drawn in markup, generator `scratchpad/wl/gen.py` in session ba4c5fb8, photos uploaded as blobs):
1. Hotels list: today + H1 pink shelf, H2 pink band on card, H3 round stamp, H4 spotlight + compare, H5 pinned polaroids. My pick H1.
2. Change day screen: today + D1 tick chips, D2 tick cards, D3 checklist box, D4 tab, D5 must-include + match meter + "no plan has both" hint. My pick D1 + D5 hint.
3. Entry point: E1-E3 home (destination chips + collage, ring + unsaved picks, empty state), E4-E5 Bali page (band, quick shortlist); sheets S1 list, S2 swipe. My pick E1, E4, S1.
4. Itinerary coverage: C1 ring line, C2 counts by kind, C3 photos + 10-step bar, C4 toast after generating; sheets C5 grouped, C6 in/not in. My pick C2, C4, C5.

User answers: "day side" = the Change day screen (saves on top, plans holding ticked saves first). Coverage sheet gets an Add for missing items but "very small or subtle" (grey underlined text links).

Demo numbers used: 10 Bali saves (5 cities, 2 stays, 3 things to do: Campuhan ridge walk, Kintamani volcano hike, Surf lesson); Swing & Sanur covers 4 = 40%.

User's choices (2026-11-02), now row 5 on the canvas and built on localhost (not committed):
- H1 without the heart graphic: pink shelf in the hotel list.
- D2 reworked: today's day cards kept; one sideways row "Include activities from your wishlist" (small icon + name) on Change day; ticking filters plans. "Add" from the coverage sheet opens that day with the save pre-ticked.
- E1 on home under Why we're the perfect match; E4 on the destination page under Vibes; both have empty states (?wish=empty shows them).
- The deck "Choose what you like": mixed regions/stays/things to do/food, buttons "Not for me" and "Wishlist", swipe hint on first open, no progress counts, hearts never in a circle.
- C1 line + C5 sheet on the itinerary; missing items get small grey underlined Add / Swap in.
- Demo seed adds Bali saves Kintamani volcano hike and Surf lesson (key 30s_wishlist_acts_v1).

**Why:** user approves direction from boards before prototype code (same as [[project-annie-assistant]]).
**How to apply:** when the user picks boards, build them in the prototype on their own routes first; see [[wishlist-phases]].

Glimpses round (2026-11-02, localhost only, not committed): the swipe deck is now full screen (`src/components/wishlist/Glimpses.jsx`), 4 swipe variants ?v=1 Reel, 2 Stack, 3 Reveal, 4 Collect; 4 teasers on the home/destination card ?t=1 Fan, 2 Demo, 3 Strip, 4 Hero. Cards show kind, vibe tag, city, rating; photos drift (stand-in for video), stays held still; tap opens the activity page or hotel page in a drawer. Canvas row 6 holds screenshots. My pick: T2 + V1.
