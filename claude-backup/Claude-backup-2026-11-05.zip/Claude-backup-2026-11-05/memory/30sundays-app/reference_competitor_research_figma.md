---
name: competitor-research-figma
description: "The \"Research - 30 Sundays (Copy)\" Figma file (49 competitor apps, Scapia, our own app audit) is fully evaluated in the competitor-patterns skill; use the skill, not the Figma file"
metadata:
  node_type: memory
  type: reference
  originSessionId: 5a14c7b4-cf1a-4c6b-a7c9-f326eddd0f81
  modified: 2026-10-30T11:56:05.789Z
---

Figma file: https://www.figma.com/design/haAwWioQ8bxCJWkYNEcLaV/Research---30-Sundays--Copy-
(file key `haAwWioQ8bxCJWkYNEcLaV`). The team's competitor research board: 1,118 screens from 49
Indian consumer apps in 10 categories, Scapia Hotels, Facebook groups, a splash and onboarding
study, and an audit of the current 30 Sundays app with the designers' notes.

Evaluated screen by screen on 2026-10-30. The results live in the user-level skill
`~/.claude/skills/competitor-patterns/` (SKILL.md is the index; `references/PATTERNS.md` is the
lookup by component kind; `references/30sundays-audit.md` covers our own app). Use the skill for
design work instead of re-reading Figma.

Figma MCP on this account is on the Starter plan and runs out of calls fast. If the file must be
read again, open it in Chrome and run JavaScript against the page's `figma` global (no limit);
the skill's SKILL.md says how. Screens 141:8 and 141:79 show a real customer's details: never
quote them.

Related: [[project-30sundays-brand-system]], [[feedback-design-rules]],
[[project-bali-destination-v2]].
