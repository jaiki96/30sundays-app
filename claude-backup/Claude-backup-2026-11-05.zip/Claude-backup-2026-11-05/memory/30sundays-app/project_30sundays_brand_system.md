---
name: project-30sundays-brand-system
description: The real 30 Sundays brand system, measured off 30sundays.club: cream ground, navy headings, handwriting display face, fuchsia. Use it before inventing any palette or type choice.
metadata:
  node_type: memory
  type: reference
---

Measured from the live marketing site https://30sundays.club on 2026-09-17 (computed styles,
not guessed):

- **Display face:** `PF Reminder Pro`, a handwriting face. Hero at 42px, every section heading
  at 32px. We have no web licence for it, so the app lab uses **Caveat** (Google) as the closest
  stand in. One line swap in the lab's shared file if the real webfont is ever hosted.
- **Heading colour:** navy `#181E4C`. Not the app's near black `#181D27`.
- **Body faces:** Montserrat and Poppins. The app uses Figtree; keep Figtree for body in the app.
- **Warm grounds:** `#FFF6E6` (main cream), `#FFF7EB`, `#FDF8F5`. Cards are pure white on top.
  There is no pure white page ground anywhere on the site.
- **Fuchsia:** `#FD014F` on the site. The app's `C.p600` is `#E31B53`. Do not mix the two on one
  screen; inside the app, stay on `C.p600`.
- **Hero pattern:** full bleed video of a couple, handwriting headline centred in white over it,
  rounded bottom corners, a proof row under it (Google 4.6/5, "Run by IIT-IIM, Apple team"), a
  sticky fuchsia pill CTA, and palm frond illustrations peeking in from the page edges.
- **Section headings on the site:** "Why we're the perfect match", "30 Sundays curated
  destinations", "Torn Between Two Destinations?", "Real couples, real itineraries",
  "Our Traveller Moments", "Testimonials".

**Why:** the app looked bland next to Crew because it was pure white with one sans at one weight.
The brand already had the warmth; it just was not in the app.

**How to apply:** when a screen needs to feel like 30 Sundays rather than a generic app, reach for
cream ground plus white cards, navy handwriting headings, and one fuchsia action. Grade
destination photos to a single warm family: six stock photos at six colour temperatures side by
side is what reads as cheap.

**In the app lab (2026-09-17), the site's cues became:**
- Ground `#FFFBF2`, a tone lighter than the site's `#FFF6E6`, at the user's request.
- Palm fronds drawn as inline SVG (`PalmFrond`), clipped by a section so only a corner shows.
  Drawn rather than shipped as art, so it costs nothing and takes any size or tint.
- A lagoon band `#EAF7F5` with a wave edge top and bottom (`Wave`), wrapping Traveller moments
  and the reviews. It breaks a long scroll after Sunday School, the way water does on the site.
- The clip dissolves into the ground with a gradient. No rounded corner on the video: the user
  rejected that explicitly.

Related: [[project-30sundays-usps]], [[feedback-design-rules]], [[project-home-lab-worktree]].
