# 30 Sundays app prototype: how to find your way around

A clickable mock-up of the 30 Sundays mobile app. Everything in it is sample data. Nothing is really booked, paid or sent.

## Open it

- Link: **https://30sundays-app-two.vercel.app**
- On a phone, it fills the screen like a real app.
- On a computer, it shows inside a phone outline. Scroll and click as if it were a phone.

## The four tabs at the bottom

| Tab | What you see |
|---|---|
| **Explore** | The home page. Destinations, trips other travellers booked, short videos, reviews. |
| **My Plans** | Trips being planned with our team, and their versions. |
| **My Trips** | Trips already booked: upcoming, happening now, and finished. |
| **Account** | Profile, wallet, gift cards, saved items, support. |

## The pink beaker button: be a different customer

The round pink button with a beaker, floating on the screen, is for demos only. Tap it to choose who you are:

- **New User**: has never used the app. Plans and trips ask you to sign in.
- **Lead**: has asked us to plan a trip. My Plans shows their plans.
- **Customer**: has booked. My Trips shows a trip happening now plus upcoming ones.
- **Trip Done**: back from a trip. Home asks for a review.

Drag the button aside if it covers something.

**Refreshing the page sets you back to New User.** Switch customers, then move around using the tabs, not the browser's reload.

## Signing in (it's pretend)

- Type any phone number of the right length (10 digits for India).
- Tap "Send OTP", then type **any 4 digits except 0000**.
- Gift card and registry codes: use **1234**.

## Six things to try

1. **Look at a destination.** On Explore, tap a destination such as Bali. Scroll through areas, activities and ready-made trips. "Plan my Bali trip" stays at the bottom.
2. **Plan a trip from scratch.** Tap "Plan my trip". Steps: destination, travellers, travel dates, cities, activities. Then "Create my itinerary". New users sign in here (pretend). You land on your new trip.
   - Only Bali, Vietnam and Thailand use this planner. Other countries open a short request form instead.
   - The planner only takes pairs of adults for now. Children, solo or odd groups see a "sorry" message.
3. **Change a trip.** Open a ready-made trip from a destination page. Tap "Customise" to change cities, dates, hotels or day plans. "Save Itinerary" turns it into a quote.
4. **Look at a trip someone else booked.** On Explore, tap a card under "Real itineraries". It's read-only. "Recreate this trip" starts your own copy.
5. **See plans in progress.** Beaker, pick Lead, then tap **My Plans**. Each plan shows Draft, Quote or Expired, plus its versions. "Compare" puts two versions side by side.
6. **See booked trips.** Beaker, pick Customer, then tap **My Trips**. Open a trip for its day-by-day plan, documents, hotels and "Pay now".

## Account tab

- Wallet, Gift cards (you can try buying one), Gift registry, Refer & Earn.
- Saved & Wishlist: everything you tapped the heart on.
- Travellers & documents, Contact Support, Suggest a feature, Report a problem.
- Logout takes you back to New User.

## Design experiments (not part of the main app)

These are alternative designs, kept on their own links for review. Add them to the end of the main link.

- `/home-lab`: new home page designs, numbered 1 to 5.
- `/v1`, `/v3`, `/v4`, `/v5`, `/v6`: older home pages.
- Any link ending in `-lab`: tests of one screen part, such as `/hotel-lab` or `/rating-lab`.

## Good to know

- Names, prices, reviews and photos are samples.
- Some videos are placeholders.
- A few buttons lead nowhere yet, or show a "demo" message. Examples: Terms & Conditions, "Rate your trip", "Itinerary PDF", "Call consultant". That's expected in a prototype.
- A trip you build as a New User won't show in My Plans until you switch to Lead.
- If you get lost, tap **Explore** to go back home.
