# Trailix — agent guardrails

## Google Places API — hard rules

**This is the most expensive third-party dependency in the app. Do not soften any of these rules without product sign-off.**

1. **Enrich is admin-only EXCEPT for hotels** (hotels exception added 2026-06-26 with product cost sign-off). `/api/places/enrich` and `/api/places/bulk-enrich` are gated by `isAdmin(session.roleId)` for activities / restaurants / shopping. For `entityType === "hotel"` they are allowed for editors with `hasPermission(roleId, "hotels", "write")` — product wanted editors to run the full hotel Places workflow (attach Place, enrich, photos) without bouncing through an admin, and accepted the cost. `/api/places/lookup-by-id` (cache-first Place preview, used by the hotel add-wizard) is likewise open to hotels/activities editors. Do NOT widen the enrich exception to other entity types, or add a new role tier, without another cost review.
   **Remap and search-candidates are editor-accessible** (lowered 2026-05-23): they use `hasPermission(roleId, "activities", "write")`. Rationale: the cache-first path is usually free, and product wanted editors to fix mis-mapped places without bouncing through an admin. The `recompute-matrix` follow-up (Routes API, billable per pair) stays `isAdmin`.

2. **No automation.** Never call `searchPlace`, `fetchAndStorePlacesPhoto`, or the enrich routes from:
   - cron jobs / scheduled tasks
   - sync workers (`SyncRun` jobs)
   - Prisma middleware or hooks
   - background queues
   - entity create / update handlers
   - any non-admin user-facing surface
   The only legitimate triggers are an admin clicking the per-entity button or admin-only bulk endpoint.

3. **Re-enrich is admin-only via `force=true`** (re-loosened 2026-05-26 after the 2026-05-23 lockout broke the Remap→refresh workflow). Once `placesEnrichedAt` is set, `/api/places/enrich` refuses with 409 unless the caller is admin AND passes `force=true`. The admin UI confirms before sending force. Bulk is still enrich-missing-only — never sends force. To switch to a different Place, prefer `/api/places/remap` (cache-first, usually free) over re-enrich.

4. **3 photos per place, no exceptions.** `MAX_PHOTOS_PER_PLACE` in `lib/places.ts`. Each photo is a separate billable call (~$7 / 1k). Don't raise without weighing the cost.

5. **Cache is permanent.** `PlacesCache` rows keyed by `googlePlaceId` are intentionally never expired. This is a deliberate product decision that diverges from Google's TOS retention guidance — do not add a TTL or cleanup job. Photos referenced from `Media.placesPhotoName` are also kept indefinitely.

6. **Cache-first.** Both routes look up `PlacesCache` by `googlePlaceId` and reuse `photos[]` (S3 URLs) before refetching from Google. Per-photo dedup against existing `Media.placesPhotoName` for the entity. If you add a new code path that fetches photos, route it through the cache.

7. **Field mask is intentionally maximal.** Atmosphere/Enterprise fields are billed per request, but product chose to keep all fields. Do not slim the mask without a product decision — this is a known trade-off, not an oversight.

## Timed un-blacklist (2026-08-18)

Taking a hotel or a room OFF the blacklist asks a question: for good, or for a fixed
window of **24 / 48 / 72 hours** (24 the default)? A window flips the flag off now and a
cron (`.github/workflows/blacklist-override.yml`, every 15 min) puts it back when the
time is up. The rules live in `lib/hotel/blacklist-override.ts` with tests beside it.

Decisions, all signed off — do not soften without asking:

- **Both copies of the flag move.** Trailix owns `Hotel.isBlacklisted`; the booking
  system reads the catalog's `blacklist` column. Flipping only the catalog would leave
  the hotel still blocked inside Trailix, and the next hotel save would push the block
  straight back out. Room flags exist only in Trailix, so a room window mirrors nothing.
- **The clock starts at the click**, never at the trip dates.
- **One window per hotel or room.** No stacking, no extending. A second request is a 409.
- **A person outranks the timer.** If the flag is no longer `false` when the window
  closes, the restore is SKIPPED and the hotel's History says why. Blacklisting by hand
  mid-window, or a CSV upload carrying the flag, closes the window as `superseded`.
- **Reason and deal reference are optional, and audit-only.** During the window the
  hotel is on sale for EVERY deal — `dealId` is never enforced.
- **No ops email when the blacklist returns.** Blacklisting by hand still emails ops.
- **Every event lands in the hotel's History**, including room windows, so the whole
  story sits on one screen.

Nothing is deleted: each window keeps its own row (`BlacklistOverride`) with the value
the flag held before, who asked, and how it ended.

## Room mapping — hand work is final (2026-08-24)

A hotel's Room mapping screen has a **Checked by hand** tick. Ticking it stamps
`Hotel.roomMappingReviewedAt`; the nightly auditor (`lib/rooms/audit.ts`) then skips every
supplier name that was already mapped at that moment. Names mapped AFTER the tick are still
judged, so new supplier names keep getting checked; ticking again re-stamps to now.

Alongside it, and independent of the tick: **the auditor no longer judges a hand mapping at
all**. It used to flag one it disliked (`SupplierRoomMapping.flaggedAt`) for a human to keep or
remap. Flags raised before 2026-08-24 stay on screen until someone clears them — the flag-action
route and the queue badge exist only for that backlog.

What did NOT change: the daily mapper (`scripts/room-ai-mapping-cron.ts`) still maps NEW
unmapped names by logic then AI, and a name nothing fits still lands in the review queue.

Both rules only narrow what the AI looks at, so they can only lower spend. Do not widen them
back without product sign-off.

### Three more things that make a room a different room (2026-08-28)

Product found three wrong auto-mappings by hand, all the same shape: the supplier name carries
something distinguishing and the room does not, and the mapper shrugged it off. All three now
fail `pricedMismatch`, so neither logic nor AI can map them, and the AI prompt states them too.

- **A numbered floor.** "2nd Floor Deluxe Double" is not "Deluxe Double". `groundfloor` /
  `highfloor` were already priced; a NUMBER is now priced as well.
- **A stated headcount of three or more.** "Bungalow for 4 People" is not the "Standard
  Bungalow". Who the RATE covers ("breakfast for 2 adults") is still ignored, and a bare
  "Triple" / "Quadruple" is still ignored — that is the 20-hotel pilot's call and it holds.
- **The supplier's own product name.** "Aura Delight with Sea View" is not the plain "Double Room
  with Sea View": Aura Delight may be a category we do not stock. Any word the checker does not
  recognise, that is not the hotel's own brand and not on the noise lists, counts as the supplier
  naming a product. `pricedMismatch` therefore takes the HOTEL NAME now, so "Hadana Suite" at the
  Hadana hotel is not read as a product called Hadana. Pass it wherever you call the gate.

The noise lists (`AMENITY_NOISE`, plus `NOISE` and `PROMO_STOPWORDS`) are what keeps the third
rule honest, and they were tuned against all 8,479 live Vietnam mappings: without them "Deluxe
Double Room with afternoon tea daily" reads as a room called "afternoon". Measured cost of the
three rules together: they hold back 4% of mappings that are live today. That is the intended
direction — product would rather under-map than sell the wrong room — but add to the noise lists
rather than loosening the rules when a new inclusion word shows up.

The rooms bundle cache key went v1 -> v2 because the bundle gained `hotelName`.

### The nightly mapper skips room-less hotels, and stops on a clock (2026-08-28)

Two limits were doing the wrong job, both found by product asking why names were still unmapped.

- **A hotel with no saved room is no longer queued.** Both passes returned immediately anyway, but
  the hotel still cost four queries and, worse, a place in the run. 867 room-less hotels were in
  the loop and 81 sat inside the 500 the run would reach.
- **The 500-hotel cap is now a 35-minute clock.** A fixed count, over a ranking that barely moves,
  re-visited the same top 500 every night and never reached the other 2,072 hotels that had real
  work — 56,363 supplier names no pass had ever looked at. The clock does what the count was for
  (finish before the auditor at 02:45 IST) without freezing the tail out: an already-judged hotel
  costs nothing on the next visit, so each run gets further down the list than the last.
- **The order comes from the NAMES, not the hotels** (`lib/rooms/mapping-order.ts`). Hotels used
  to be ranked by sold + quoted, which put a name that appeared today at a quiet hotel behind
  hundreds of busy hotels holding nothing new. A hotel's place is now decided by the newest name
  it is still holding (`reviewSince`, falling back to `createdAt`), with lookup demand breaking
  ties. A hotel with nothing new is still walked, LAST, because the logic pass is free and an
  alias added by hand today can promote a name the AI gave up on months ago.

The layers must stay in this order or the script is killed before it writes its summary:
`script 35m < timeout 38m < command_timeout 40m < job 45m < audit 02:45`.

The nightly job KEEPS UP; it is not how you clear a backlog. At four hotels in flight it covers
roughly 100 hotels a night, so a 64,000-name backlog wants a one-off supervised run instead.

### Only 98% and up goes live, and a below-bar pick keeps NO room (2026-08-28)

`AUTO_MAP_MIN` is **0.95** (0.85 from 2026-06-26, briefly 0.98 on the morning of 2026-08-28).

The 0.98 was a blunt stand-in for one specific complaint: the band under it kept crossing twin or
single with double or king. That is now a RULE rather than a confidence guess, so the bar came
back down the same day:

- **Twin and single (separate or small beds) may never be answered with double, king or queen
  (one large bed), or the other way round.** `single` counts as a bed again, reversing the
  20-hotel pilot's call — TBO does write "Single room - De Luxe" for single OCCUPANCY, and reading
  it as a bed does lose a few correct mappings, but product chose that side outright: selling a
  king to someone who asked for a single is the dearer mistake.
- **`bedCoinFlip`**: the room commits to a bed, the name says nothing, and another room at the
  hotel is the same product with the other kind of bed. No confidence number can catch that one,
  because the model is right that it is that room — it just cannot know which of the two.
- Supplier abbreviations (`DBL`, `TWN`, `SGL`, `KNG`, `QN`) and "TWO BEDS" are read as beds, or
  the coin-flip check fires on names that were never in doubt.

Measured against all 8,479 live Vietnam mappings: the bed rule refuses 83 and the coin-flip check
holds 59, so 1.7% of what is live today. Do not raise the bar again in place of a rule.

**A row you do not want served must have NO `hotelRoomId`.** `/api/public/rooms/lookup` returns
any row that carries a room and is not REJECTED (`lib/rooms/lookup.ts`). Status is NOT the gate;
the room is. Two branches got this wrong and both were selling answers nobody had approved:

- the below-bar pick, pre-filled as a "suggestion for one-click confirm";
- worse, the pick the priced-attribute guard had just REFUSED, pre-filled so a human could force
  it in one click. 4,477 rows the guard called a different product were answering the booking
  tool, against 1.97 million requests.

Both now write `hotelRoomId: null` and keep the AI's pick in the reason, which is all a person
needs in order to see it.

Taking a mapping back also means **stripping the supplier spelling from the room's aliases**. The
AI pass appends it when it maps (the learning loop), and the free logic pass re-maps from that
alias the very next night.

### A bedroom count is part of the signature, and the signature is STORED (2026-09-14)

`roomSignature()` dropped number words as bed noise, so "One-Bedroom Villa" and "Three-Bedroom
Villa" folded onto one key. That key is also the unique key of the review queue
(`@@unique([supplier, hotelId, signature])`), so both supplier names landed on ONE row, and
mapping that row mapped both. It was live: **429 mappings were answering two or more bedroom
counts with a single room, against 3.9 million lookups.** Fraser Suites Hanoi served one-, two-
and three-bedroom Deluxe as "3 Bedroom Deluxe"; Regent Phu Quoc served one- and two-bedroom Sky
Pool Villa as the two-bedroom. A count qualifying "bedroom" is now folded into one token
(`2bedroom`) instead of dropped. Standalone bed counts ("Deluxe Two Beds") are unaffected.

**`SupplierRoomMapping.signature` is a STORED column.** Changing `roomSignature()` makes every
stored signature built from a name carrying a count stale, and a lookup that misses its row loses
the mapping — 41,024 of them. The code change and `scripts/backfill-room-signatures.ts` have to
land in the same window. The same applies to any future change to that function.

Two things the migration got wrong first, both worth remembering:

- **The room's aliases cannot be the evidence for which child was right.** The AI appends each
  spelling it maps onto the room's aliases, so a fused row's room already carries both counts.
  Reading them let every child keep the mapping and left the fault where it was. The test is the
  room's OWN NAME, and on the COUNT alone, since that is all the split turns on.
- **A human decision outranks the AI's when two rows merge.** A CONFIRMED row and an AUTO_MAPPED
  row that now key the same cannot both survive; the confirmed one wins however much busier the
  other is.

Returned children must end up with **no `hotelRoomId`**, a reasoning that does NOT start with
"AI" (or `skipAiEvaluated` retires them unjudged), and their spelling stripped off the room's
aliases — otherwise the free logic pass re-maps them the next night and the fix undoes itself.

**Ask who owns a signature before EVERY write, the merge included.** The rename path asked; the
merge path deleted the row it was dropping and moved the keeper onto the target, assuming the
dropped row was what held it. A split earlier in the same hotel can have CREATED a row on that
signature instead, and the in-memory view only calls something a clash when it already knows about
it. The collision fails inside the hotel's transaction and rolls the WHOLE hotel back: 66 hotels
and 1,652 rows were left unmigrated by the first live pass. A conflict is now reported and stepped
over, never written through.

The migration is re-runnable and keeps a `PROGRESS` file, so a second pass retries only what
failed. Its `BACKUP` is appended, never truncated — an earlier version truncated its own backup on
restart and left nothing to roll back to.

### A count mismatch is backlog, not only a fused row (2026-09-14)

The split above only fires on a row holding TWO counts at once. A row that only ever held ONE
count, and was simply pointed at the wrong room back before `pricedMismatch()` judged bedrooms,
looks settled to it. **855 such name/room pairs on 306 rows were live** — 102 quoted, 30 sold —
including a hotel answering 2-, 3- and 4-bedroom villa requests with one 3-bedroom villa.

Every one of them is refused by today's gate, so this was backlog and not an open hole: 762 were
the AI, 66 were the free logic pass re-reading an alias the AI had appended, 27 were confirmed by
hand. All 306 were taken back (`tmp/clear-bedroom-mismatches.ts`), 957 aliases stripped.

- **A row serves every spelling it holds with one room**, so one disagreeing spelling makes the
  whole row unsafe. Take the row back, not the spelling.
- **`tmp/audit-bedroom-counts.ts` reads the text on both sides and never looks at the stored
  signature**, on purpose: it still catches a drift between `roomSignature()` and the column.
- Finishing a merge the conflict guard skipped must apply the SAME count test. 15 of 67 stranded
  rows were a 1-bedroom name sitting on a two- or three-bedroom room; moving those across would
  have put back the exact fault the migration removed (`tmp/heal-stale-signatures.ts`).

### Three rules, checked together or not at all (2026-09-15)

`scripts/check-room-invariants.ts` is the contract. Run it after anything that writes to
`SupplierRoomMapping`, and nightly. It exits non-zero.

1. **A row is filed under its own name.** The lookup computes `roomSignature(name)` and reads the
   row holding it, so a row filed anywhere else answers nothing.
2. **Every spelling on a row belongs to that row.** A stray is answered by some other row, or by
   none, while its quotes are still attributed here — `room-quotes.ts` matches on spellings.
3. **A served room does not contradict the name on bedroom count.**

All three were found separately, hours apart, because nobody had written down what "correct" meant.
Fixing them one at a time let each repair break the next: a pass that folded unreachable duplicate
rows into live ones carried their mixed spellings across, which put back count contradictions that
had been cleared an hour earlier. Measure all three, fix once, measure again.

**`pricedMismatch()` is deliberately NOT one of them.** It decides whether a MACHINE may make a new
mapping, and it is meant to be shy — it objects to 35,256 live rows, 1,542 of which have sold.
Treating "do not guess this" as "this is wrong" would unmap most of the catalogue. Bedroom count is
in because it is a flat contradiction and not a judgement.

**Re-run the migration until it reports nothing.** Its split steps over a row whose target signature
another row already holds, which is right inside a transaction and means the row keeps its strays
forever. Two passes left the identical 14 rows and 14 conflicts; those needed the spellings MOVED
(`tmp/move-stray-spellings.ts`), not split.

**Then check nothing undoes it overnight.** A room that still carries a spelling you just took off
it gets re-mapped by the free logic pass before morning (`tmp/check-alias-reversal.ts`). Of 2,196
names an alias would re-map, 2 contradicted the room, and both aliases were stripped.

### `skipAiEvaluated` must never be a bare NOT (2026-08-28)

`NOT: { reasoning: { startsWith: "AI" } }` compiles to `NOT (reasoning LIKE 'AI%')`, and
`NULL LIKE anything` is NULL, not false — so every row that had never been judged at all was
excluded by the clause written to find it. That was 39,335 names, the entire never-touched
backlog, invisible to the nightly AI pass for as long as the flag has existed. Use
`UNJUDGED_BY_AI` (an explicit two-branch OR) in `lib/rooms/ai-apply.ts`, and remember the same
trap for any other nullable-column exclusion.

### The mapper must never hardcode a model (2026-08-28)

`aiMatchRooms` used to fall back to `DEFAULT_ROOM_AI_MODEL` ("gemini-3-flash-preview") whenever a
caller left the model unset, and handed that name to `aiText`. Once `roomMatch` was switched to
OpenAI on 2026-08-24 every nightly call asked OpenAI for a Gemini model and came back 404, so the
mapper auto-mapped 4 names in a month. Leave `model` unset and let Settings choose the provider
AND its model; pass one only when a caller genuinely wants to pin it.

The second half of the same bug: a failed call wrote `reasoning` as `AI: AI failed: …`, and the
cron's `skipAiEvaluated` skips anything whose reasoning starts with "AI". One bad night therefore
retired a name from the AI pass for good. A decision the model never gave now carries
`notJudged`, and `aiMapHotelQueue` writes it as `not judged: …` so it is picked up again on the
next run. Never write an "AI"-prefixed reason for a name the model did not actually judge.

## Regions: one list, and the booking side gets told (2026-08-27)

The hotel Region dropdown used to read ONLY the catalog's city table
(`itinerary_databases.city_airport_mapping`), so a region added on the Regions screen never
appeared in the hotel form. `lib/hotel/regions.ts` now merges both sources: the catalog list
(cached a day, cross-database) and Trailix's own `Region` rows (read fresh every time, so a
region added a minute ago is usable). Catalog spelling wins where the two overlap.

`hasList` (region required?) comes from whether the destination HAS a catalog list, not from
the list being non-empty — a failed catalog read must not quietly make the field optional.

**Trailix writes one row to the booking side.** `lib/hotel/legacy-region.ts` inserts a missing
region into `city_airport_mapping` when a hotel is saved into it, because the booking system
reads its region list from that table and cannot find a hotel filed under a region it does not
know. Rules, signed off (jd, 2026-08-27):

- INSERT only, `ON CONFLICT (city) DO NOTHING`. Never update, never delete, never touch a
  region Trailix did not add. `city` is that table's primary key.
- Fired from the hotel create and hotel edit routes only. Never from a cron, an import or a
  region being created on the Regions screen — a region reaches the booking side when a hotel
  actually sits in it.
- `airport_codes` is copied from the NEAREST region the catalog already lists, measured from
  the hotel's coordinates, within 300 km. Every existing row has codes and they drive the
  booking side's flight suggestions, so a blank is worse than a near-neighbour's. Beyond
  300 km, or with no coordinates, the row goes in with no codes and the person is told to have
  ops fill them.
- Every insert lands in `HotelPushLog` (source `region-add`) and in the hotel's History, saying
  which region the codes came from and how far away it was.

## Prioritise room mapping by QUOTES, not API calls (2026-08-31)

`SupplierRoomMapping.lookupCount` is labelled "API calls" and it counts exactly that: calls to
`/api/public/rooms/lookup`. The sales tool calls it whenever anyone opens an itinerary, so it
measures ATTENTION, not demand. Ranking work by it was sending people at hotels nobody sells.

Measured on the day: of the top 300 waiting names by API calls, 66 were at hotels with no quote
and no sale ever, and 211 at hotels quoted fewer than ten times. The top-500 lists produced by
"most API calls" and "most quoted" shared SIX names.

- The flat review list (`/room-mapping/all`) defaults to **Most quoted hotel**; "Most API calls"
  is still there, renamed so it is obvious what it counts.
- The fix-first list on `/api-usage` ranks by `compareFixFirst` (quoted + sold, then the size of
  the pile). Do not re-sort it by `requests`.
- The number it orders by is `SupplierRoomMapping.quotedCount` / `soldCount`, per SPELLING, built
  by `lib/metrics/room-quotes.ts` (below). `UsageMetric` is per HOTEL and stays that way.

### Per-room-name quote counts come from the itineraries (2026-08-31)

`RoomQuote` + `SupplierRoomMapping.quotedCount`/`soldCount`, built by `lib/metrics/room-quotes.ts`
and run nightly as the `roomquotes` target of `scripts/recompute-metrics.ts` (`all` includes it).

Each hotel-day in `itinerary_versioning.itinerary_table` records the room string the sales tool put
in front of the customer. That string is our own saved room name where the rooms lookup answered,
and **the SUPPLIER's own name where it did not** — which is what makes a per-supplier-name count
possible. Keyed by `roomSignature()`, so it lines up with `SupplierRoomMapping.signature` and can
also count a spelling Trailix does not stock at all (`RoomQuote.matched = false`: quoted, and we
have no idea what it is).

Rules:
- It counts the SAME deals the per-hotel numbers count, via `loadDealVersions` exported from
  `lib/metrics/hotel-usage.ts`. If those two ever diverge the screens stop being comparable.
- One deal naming a room on three nights is ONE quote for that room, not three.
- The meal plan the sales tool appends (`(Breakfast Included)`) is stripped; anything else in
  brackets is kept, because suppliers put real room wording there.
- `RoomQuote` is rebuilt whole each run, so a name that stops being quoted stops being counted.
  The counts are denormalised onto the mapping rows because there is no key to join on.
- **Match on the SPELLINGS (`rawName` + `rawNames`), never on `SupplierRoomMapping.signature`.**
  A parked row's signature is `name:<normalized>`, so matching on it files every name a person took
  off a room as one Trailix has never seen. That mistake hid 871 names and 6,828 quotes on the
  first run, plus 156 that were mapped and pinned — exactly the names that most need a count.
- Product's hunch that the unplaceable names were contracted room categories was checked and does
  NOT hold: those 2,067 hotels have 17 distinct room names in `hotels_main_contracted` between
  them, and zero matched. The contract sheet is not where these names come from.
- The nightly `run-metrics.sh` has a `timeout 30m`. This pass walks the itineraries a second time,
  so watch that headroom before adding a third.

The hotels list (`/hotels`) defaults to **Most sold** for the same reason. Its usage-ranked path
now selects ids for the ranking and hydrates only the fifty on the page; it used to hydrate all
2,000 ranked rows, each with a room count and an image lookup, which is too heavy for a default.

## The hotel reference id (2026-09-17)

Hotels are moving from "the TBO code is the id" to a supplier-agnostic key the
catalog calls `internal_hotel_id`. Both are live at once, and both must keep
working until the old booking service is retired.

**Never build the mapping from a copy of the catalog.** On 2026-09-17 the
staging copy and the live catalog disagreed about the same hotel's reference id:
TBO 1023365 was 43457 in the copy and 43454 live, and the drift grows with the
id. A backfill from a copy would stamp most of the catalog with another hotel's
reference id, and the new service would then serve that hotel's rooms and photos
under it. Read `LEGACY_POSTGRES_URL`, the catalog the app itself connects to, and
take no file or export as input.

**`idType` defaults to `tbo` and there is no fallback.** The old service sends no
parameter, so the default is what keeps it working; a typo'd value is a 400, not
a silent default. Never "try one key then the other": the two number spaces
overlap for real (the catalog holds a row whose reference id equals another row's
TBO code), and guessing is how a caller ends up looking at another property.
Every hotel payload carries `tboHotelCode` and `internalHotelId` as ordinary
fields — those are what to join on, never `id`, which is whichever key the caller
asked by.

**A hotel with no TBO code is keyed by its reference id.** Those are the 112,200
rows the booking side loaded on 2026-09-16; every read path filtered them out for
a week because a null id took the hotels page down. They have an identity now.
Go through `trailixHotelId()` and never `tbo_hotel_code` directly: an EMPTY
STRING passes `IS NOT NULL` and is exactly the shape that broke the page.

**Never supply `internal_hotel_id` on an INSERT.** It is
`GENERATED ALWAYS AS IDENTITY`: Postgres assigns it and REFUSES a supplied value
with `cannot insert a non-DEFAULT value into column "internal_hotel_id"`. That
error took manual hotel creation down on 2026-09-17, when this repo briefly tried
to allocate the id itself with highest+1 under a lock. It does not need to, and
should not: an identity column is atomic and race-free by construction, which is
stronger than any lock we can hold. Leave the column out and read the assigned
value back from `RETURNING`. Anything shown in a form beforehand is a guess.

**Sold/quoted read BOTH keys, TBO first.** The itinerary data carries the
reference id alongside the TBO code (jd, 2026-09-17). The TBO code wins whenever
it names a hotel we hold, so the reference id can only bring a hotel into the
counts, never move one between hotels. Several spellings of the field are
accepted because an unrecognised one is silently a hotel that scores zero;
`travClan` is deliberately NOT one of them, since that is the supplier's code and
not the catalog key.

**TravClan room names arrive under supplier `TRAVCLAN`** (jd, 2026-09-17) and
queue for review like any other. The nightly AI mapper still covers TBO only:
pointing it at a second queue is real spend on an unsized backlog, so it stays a
deliberate choice. Pass `supplier` to `aiMapHotelQueue` when that is decided.

**A hotel added by hand is keyed `M` + its reference id** (jd, 2026-09-21).
The booking app will not list a hotel whose `tbo_code` is empty, so a hand-made
hotel saved with an empty code is invisible to them; the booking team was
patching all 25 of ours by hand, days later, which broke every link to those
hotels because the list read their new code while Trailix held the bare number.
So Trailix writes the M code itself at creation, in the same transaction as the
insert, and keys the hotel by it like every other hotel. The reference id is
still the sequential number the catalog assigns and is still what the new
booking service asks by; `M242325` is a separate column their app requires, not
a second id.

**Superseded (kept because the reasoning still applies elsewhere): a hotel added
by hand takes the next reference id, not a made-up code** (jd, 2026-09-17). Manual hotels used to get `MBL001431` style ids in the TBO column
with `tbo_code_valid=false`, because that column was the catalog's only identity.
Now they take the catalog's next `internal_hotel_id` and their TBO column is left
NULL, which is the truth about them. The catalog assigns the id;
what the wizard shows beforehand is a preview and nothing keys on it. That a person created the hotel is recorded ONLY on our
side, as `Hotel.isManuallyAdded` — the booking catalog gets no new column for it.

**Duplicate hotels are flagged, never merged** (product, jd 2026-09-17). The same
property is listed once per supplier, so 10,786 groups look like duplicates and
5,131 of those pair a TBO hotel with a TravClan-only one. Nothing is merged,
hidden, or taken off sale. `HotelDuplicateFlag` is a derived cache feeding a
banner and a list filter; it is rebuilt whole and safe to truncate.

## Public API — list/detail parity

Every public list endpoint (`/api/public/<resource>`) must expose the same scalar fields as its matching detail endpoint (`/api/public/<resource>/{id}`). The only allowed delta is heavy nested arrays (`rooms`, `activities`, `offerings`, `documents`, `usedInTours`) which stay detail-only because they balloon list payloads.

To enforce this:
1. **Single source of truth per resource.** Keep one `<RESOURCE>_SCALAR_SELECT` and one `serialize<Resource>Scalars` in `lib/public-<resource>-shape.ts`. Both list and detail spread from these. Adding a column means editing one place.
2. **No ad-hoc `LIST_SELECT` next to a different `DETAIL_SELECT`.** That's how drift happens.
3. **Run `scripts/check-list-detail-parity.ts` after touching any public route.** It fetches one row from each list and the matching detail and asserts every detail key is present in the list (minus the nested-only allowlist).

If you genuinely need a list field detail doesn't have (e.g. `images_urls` on hotels), it's fine — parity only checks list-superset-of-detail-scalars, not the other direction.

## API docs — always update in the same change

The public API reference is `app/(app)/api-docs/page.tsx` (rendered at `/api-docs`). It is hand-maintained, not generated.

**Whenever any API is added, changed, or removed, update the docs in the same commit/PR — no exceptions.** This applies to every public-facing surface, not just `/api/public/*`: a new route, a new/renamed/removed query param, a changed response shape or field meaning, a new error/status, a changed default or cap, a changed auth scope. If you touch the contract, you touch `api-docs/page.tsx` in the same change.

For each affected endpoint keep these in sync: the `summary`, the `query` param list (name + desc), the `scope`, and the `sample` response JSON. Treat a contract change with no accompanying docs edit as an incomplete change — call it out and fix it before opening the PR.

## Other

- DB schema is pushed via `prisma db push --accept-data-loss --skip-generate` in CI (`.github/workflows/deploy.yml`). There is no `prisma/migrations/` directory — schema is the source of truth.
- Trailix moved from EC2-local Postgres to AWS RDS on 2026-04-24. The local PG on EC2 is kept as a rollback. Be careful with destructive schema changes.

## Catalog sync removed 2026-05-26

Trailix is now the **single source of truth** for Tours, Activities, Restaurants, Shopping Places, Hotels. No external CATALOG sync runs anywhere — the entry scripts, the GHA workflow, the SyncButton component and the `/api/sync/{tours,activities,day-combos}` routes have all been moved under `tmp/_disabled-sync-2026-05-26/`. Do not re-enable without product sign-off.

What is still allowed to read from the external source DB:
- `scripts/recompute-metrics.ts {activity|hotel|maldives|all}` — read-only aggregation of live booking outcomes into `UsageMetric`. Runs nightly via cron. Never writes catalog data.
- `/api/sync/runs` — read-only history endpoint for the legacy SyncRun table. No new rows are created by app code.

If you ever need to import a single missing tour / activity / hotel manually, do it through Prisma directly (or temporarily un-archive the relevant `lib/sync/*` module under `tmp/`). Never reintroduce a periodic sync.
