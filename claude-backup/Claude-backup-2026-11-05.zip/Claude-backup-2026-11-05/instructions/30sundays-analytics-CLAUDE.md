# About 30 Sundays

30 Sundays (legal entity: Brance Technologies Private Limited) is a seed-stage B2C couples travel startup based in Gurgaon, backed by InfoEdge, Eximius, and First Cheque. We sell curated international holiday packages, primarily honeymoons and couples trips, to destinations including Bali, Thailand, Vietnam, Maldives, Sri Lanka, New Zealand, and Mauritius. Average package value is ₹1–3 lakh. Customer acquisition is primarily through Instagram and Facebook ads, with sales handled by an in-house team. Bookings flow from inquiry → consultation → itinerary customization → payment → travel → post-trip. The data in our systems reflects this funnel and the operations supporting it.

# Data sources

We have five primary data sources:

- **PostgreSQL** — primary transactional database (DB name: `sundays_dev` — legacy naming, this is actually our canonical analytics/production DB, not a dev environment). Bookings, payments, customers, itineraries, sales pipeline, internal tools data.
- **MongoDB** — customer-facing app backend (Android + iOS). Database `30_sundays_production`. Hosts: app clickstream (`app_clickup_logs`), customer master for the app (`customers`), AI-chat conversations (`conversations`), per-customer deal state surfaced in the app (`customer_deals_infos`), referral program (`customers.referral_code`, `referral_points`, `referral_points_ledgers`), trip participants, and periodic-refresh travel-product caches (`daywise_activities_*`, `*_historic_data`). NOT authoritative for ops deals — `deals_table` in Mongo is a partial random mirror. Full catalog in `notes/catalog_mongodb.md`.
- **BigQuery** — GCP project `couple-trails`, region `asia-south2` (Delhi). Hosts an ETL/mirror layer of Postgres + Freshworks + call/feedback/marketing data. **The Looker Studio revenue dashboards read from here, not from Postgres directly.** Access via service account key at `/Users/jaiki96/Documents/Claude-code/30sundays-analytics/secrets/bigquery-key.json` (service account: `claude-readonly-analytics@couple-trails.iam.gserviceaccount.com`).
- **Metabase** — our BI layer. Connected to both Postgres and MongoDB. Team-facing Metabase dashboards live here. (Note: the Looker Studio revenue dashboards are a separate BI surface on top of BigQuery.)
- **App Store Connect (Apple) — Analytics + Sales APIs.** iOS-only store-side acquisition funnel for the app "30 Sundays: Holiday planning" (App ID `6749570798`, bundle `com.thirtysundays.app`, Vendor `93580185`). Two API paths, both behind one ES256 JWT (`secrets/AuthKey_U5GU965695.p8`): (a) **Sales & Trends Reports API** — instant daily download counts (Units excl. updates), fills `public.appstore_metrics_daily.total_downloads`, no batch wait; backfilled May 2026 = 1,236 downloads, 26 days, mean 47.5/day, peak 67. (b) **Analytics Reports API** — async batch feed (ongoing ~48h to first data, snapshot a few hours) for impressions, product page views, and the first-time-vs-redownload split. Same report's Detailed tier is re-grouped by Source Type into `public.appstore_source_daily` (organic = App Store Search + Browse; link = App / Web / External Referrer). All metrics: daily granularity, iOS only, **no per-user identity** — funnel only, deliberately excludes consent-gated usage/sessions/retention reports. **Apple does NOT expose actual search-term strings in any public API** — only visible in the App Store Connect web dashboard. Refreshed by `scripts/refresh_appstore_metrics.py` (scheduled daily 08:12 IST). Full reference: `notes/appstore_analytics.md`. (Google Play / Android funnel is planned, not yet built — see `notes/store_api_integration.md`.)

Read access for analytics is via dedicated read-only credentials. Write access (creating Metabase cards/dashboards) is via Metabase API key scoped to the "Claude Sandbox" collection.

**BigQuery is DEPRECATED (JD, 2026-08-31). Postgres is the only source.** The company has moved off
BigQuery entirely. Do not write new queries against `couple-trails.*`, and treat any existing BQ number
as suspect: the `Freshworks_Leads_Pipeline.Converted_Deals` mirror stopped updating at `booking_date =
2026-08-17`, which silently truncated every dashboard reading it by ~40% for August 2026. For bookings,
use `deals_table.is_converted` dated by `COALESCE(NULLIF(btrim(lm.booking_date),'')::date,
dt.sold_ts::date)` — `lm.booking_date` alone is broken from 2026-06 (July 2026 has zero rows). See
`notes/gotchas.md` #99–#100. Remaining BQ dependency to migrate: `scripts/refresh_sales_app_funnel.py`
(Callyzer call records → `public.sales_app_funnel_daily`, feeds only dormant draft card 1254).

_Superseded, kept for context:_ **Source-of-truth precedence: Postgres always, unless BigQuery is explicitly requested.** Default to querying Postgres (`sundays_dev`) for **everything, including revenue / bookings / margins** (JD, 2026-07-14). Reach for BigQuery only when the user explicitly asks for it, when the data genuinely isn't in Postgres, or when the explicit task is to reconcile against a Looker dashboard exactly (BQ `Freshworks_Leads_Pipeline.Converted_Deals` has the pricing/TCS/test-exclusion logic pre-computed). Accept the known PG-vs-BQ residual (~3 bookings/month low + `leads_master_updated` ETL defects, documented below) rather than defaulting to BQ to close it.

# Key tables and collections

**Operational core (`itinerary_versioning` schema — the live ops DB, misleadingly named):**
- `itinerary_versioning.deals_table` — the canonical bookings/deals table
- `itinerary_versioning.customers_table` — customer records
- `itinerary_versioning.deal_travellers` — travellers per deal
- `itinerary_versioning.deal_installments` — payment installments
- `itinerary_versioning.invoices` and `invoice_items` — invoicing
- `itinerary_versioning.vouchers` and `voucher_items` — post-booking vouchers

**Product catalog (`itinerary_databases` schema):**
- `itinerary_databases.<destination>_activities` and `<destination>_rules` — per-destination product catalog (bali, thailand, vietnam, maldives, sri_lanka, new_zealand, europe, georgia, azerbaijan, kazakhstan)

**CRM / top-of-funnel (`freshworks_leads_pipeline` schema):**
- `freshworks_leads_pipeline.leads_master_updated` — CRM leads
- `freshworks_leads_pipeline.deal_stage_update_logging` — deal stage transitions
- `freshworks_leads_pipeline.sales_task_logger` — sales activity log

**BigQuery (`couple-trails`, region `asia-south2`):**
- `Freshworks_Leads_Pipeline.Converted_Deals` — **the canonical bookings table that feeds the Looker Studio revenue dashboards.** Pre-joined and enriched, with pricing broken out by hotel / activity / flight / add-on and margins pre-computed.
- Other datasets (not yet explored, presumably BQ mirrors / ETL outputs): `itinerary_versioning`, `itinerary_generator`, `marketing_db`, `AppContent`, `Callyzer_call_records`, `Customer_Requirements_Analysis_DB`, `OnTripAssistances_DB_30Sundays`, `auto_Itinerary`, `feedback_db`, `30_Sundays_Logging`.

**Postgres gotcha:**
- `converted_deals_data.booked_deals` exists but `techlogin_readonly` has no SELECT privilege. Ask DBA for a GRANT if needed — though it may be redundant with BigQuery's `Converted_Deals`.

# Business rules and definitions

**Timezone — everything must be reported in IST**
- **Postgres:** `timestamp without time zone` columns store **IST wall-clock as naive values**. psycopg2 returns them as naive Python datetimes — attach IST tzinfo before comparing to any other source.
- **MongoDB:** BSON Date is **true UTC**. Pass `tz_aware=True` to `MongoClient`; in aggregations bucket by IST via `$dateToString(timezone="Asia/Kolkata")`. Without `tz_aware=True` pymongo returns naive UTC datetimes that look identical to PG's naive IST in Python.
- **BigQuery:** Looker `booking_date` etc. are `DATE` (no time) — safe.
- **The trap:** Python lets you compare naive UTC (Mongo) with naive IST (PG) directly without error — the result is silently wrong by 5:30 hours. Always lift both sources to **aware** datetimes before any `<`, `>`, `-`, or `MIN/MAX` comparison. See `notes/gotchas.md` #36 for the canonical rule and `queries/lead_to_booked.py` for the fix template.
- All outputs (CSVs, slides, dashboard numbers) must be presented in IST.

**App DAU / GA4 reconciliation (established 2026-04-20)**
- **Mongo `app_clickup_logs` = canonical** for anything customer-joined (segmentation, cohort, trip-state DAU). `user_id` maps 1:1 to PG `customer_id`.
- **GA4 = reference** for engagement-filtered "Active users" consumed by business stakeholders. Don't try to make Mongo equal GA4 — they measure different things.
- Apply these GA4-parity filters to Mongo when producing a DAU number meant to line up with GA4:
  1. Exclude `user_id = "unknown"` (pre-auth bucket).
  2. Exclude web traffic: `device_info.platform ~ /chrome|firefox|safari.*web/i`.
  3. Exclude sellers / internal: phone `8750465800` + any `user_id` emitting `seller_shadow_login` in the window.
  4. (Optional, if matching GA4 "Active" definition exactly) require ≥2 events/day AND timestamp span ≥10s.
- Expected post-filter drift vs. GA4: ±10%. Alert at ±15%.
- User-segment DAU card uses Mongo auth `user_id` joined to PG `itinerary_versioning.deals_table + itinerary_table` on `customer_id`. Precedence: OnTrip > PreTrip > PostTrip > Leads > Cancelled > New > Unknown. Full methodology: `notes/user_segment_dau_methodology.md`. Reconciliation rationale: `notes/gotchas.md` #33.
- App analytics code refs (app repo `/Users/jaiki96/Documents/Claude-code/30-sundays-app`):
  - Firebase + backend adapters both init at launch: `lib/core/analytics/analytics_service.dart:26-61`
  - Seller / internal override (skips BOTH pipelines when strictly applied): `lib/features/authentication/notifier/auth_notifier.dart:152`
  - `setUserId` only fires post-OTP-verify: `auth_notifier.dart:214`

**Revenue reporting**
- Revenue amounts in the Looker Studio revenue dashboards are in **lakhs** (value ÷ 100,000).
- Currency: INR unless otherwise noted.

**Booking definition (canonical — matches the Looker Studio revenue dashboards)**
- A deal counts as a booking only if `hotel_selling_price_post_discount IS NOT NULL OR activities_selling_price_post_discount IS NOT NULL`. Flight-only or un-priced deals are excluded.
- Date field: `booking_date` on `Converted_Deals` (BQ) / `leads_master_updated.booking_date` (Postgres). **Do not use `deals_table.sold_ts`** — it diverges for back-entered deals.
- Postgres booking-count convention (agreed 2026-04-17): filter on `freshworks_leads_pipeline.leads_master_updated.booking_date` only. Do NOT COALESCE to `sold_ts` — the COALESCE over-counts historical back-entered deals that BQ correctly dates to prior years. Expect a residual of ~3 bookings/month below BQ total due to Postgres `leads_master_updated` data-quality issues (see "Booking count reconciliation" and "Known Postgres ETL defects" below).
- Test deals are excluded: deal name or customer name matching `ILIKE '%test%'`.
- CRM source-of-truth stage for "booked": `Ops Pipeline - Booking Confirmed` in `freshworks_leads_pipeline.deal_stage_update_logging`.
- _Derived from Looker Studio SQL on 2026-04-17. Validate with team before treating as canonical._

**TCS (Tax Collected at Source) rules used in net-booking-value calculations**
- Maldives: 0%
- Bookings before 2026-04-01: 5%
- Bookings on/after 2026-04-01: 2%
- (Mauritius had special handling historically; currently commented out in the dashboard SQL.)
- _Source: derived from existing dashboard SQL. Confirm with finance/CRM owner before locking in._

**Booking count reconciliation — Postgres vs BQ/Looker (discovered 2026-04-17)**

When reproducing the Looker "Destination Overall" numbers from Postgres, a naive query against `deals_table + itinerary_table` undercounts/misclassifies for four independent reasons. All four must be handled for near-reconciliation. Canonical reconciled query: `queries/bookings_by_destination_reconciled.sql`.

1. **`pricing_be` JSON has two schemas.** Most destinations use a flat schema with top-level `hotels`, `activities`, `flights`, `addOns` numeric keys. `destination = 'maldives_sis'` uses a nested schema instead: `{ prices: [[{price, costPrice, mealName,…}, …]], costPrice: [[…]], … }` with no top-level `hotels`/`activities`. A filter like `(pricing_be->>'hotels')::numeric > 0 OR (pricing_be->>'activities')::numeric > 0` silently drops every Maldives booking (−43 in March 2026). Extract Maldives pricing from the nested `prices` array.

2. **`itinerary_table.destination` is per-version, not canonical.** It reflects the selected itinerary's destination and can diverge from the CRM canonical destination. In March 2026, 4 deals whose itinerary destination was `bali` (e.g. "Nishant Singapore booking", "Deepak Europe Opportunity") had CRM main destination different or missing. For display-destination bucketing, prefer `freshworks_leads_pipeline.leads_master_updated."Main Destination"` (note: column is quoted, with a space, proper-cased), falling back to a normalized itinerary destination.

3. **Version-of-pricing selection matters.** `deals_table.ops_converted_version_id` is not always the version where hotel/activity selling prices are populated. Seen case: deal `402007325189` has `ops_converted_version_id = _11` with `pricing_be.hotels = 0, activities = 0, total = 138960` (flight+tax only), while version `_10` has `hotels = 37591`. BQ's `hotel_selling_price_post_discount` is populated (from the priced version), so BQ counts the deal; a naive PG filter on the ops version rejects it. Use the version with highest `(hotels + activities)` per deal, not ops_converted_version_id.

4. **BQ `booking_date` is sourced from CRM, not from the ops DB.** BQ `Converted_Deals.booking_date` is a direct mirror of `freshworks_leads_pipeline.leads_master_updated.booking_date` — same column name in the CRM table. For current-flow deals this matches `deals_table.sold_ts::date` (IST), but for back-entered / historical deals the CRM `booking_date` can be months or even over a year earlier than `sold_ts` (e.g. deal `402008737770`: BQ booking_date = 2025-02-09, PG sold_ts = 2026-03-11). Always filter on `leads_master_updated.booking_date` (not `sold_ts`) when reconciling against Looker revenue dashboards.

March 2026 reconciliation after all four fixes (using `leads_master_updated.booking_date`): Bali 173 (BQ 174), Thailand 139 (139), Vietnam 132 (133), Maldives 43 (43), Sri Lanka 18 (18), NZ 9 (9), Georgia 0 (1). **Totals: Postgres 514 vs BQ 517 — residual of 3.**

**Known Postgres ETL defects in `freshworks_leads_pipeline.leads_master_updated` (flag to data eng):**
- **Missing rows.** Some converted deals never land in `leads_master_updated` at all (March 2026: `402008737770`, `402008832061`, `402008737815`). BQ has them with historical `booking_date` in 2025; Postgres has no `lm` row.
- **`booking_date` overwritten on re-sync.** Same column name mirrors differently between systems. E.g. deal `402007340341`: BQ `booking_date = 2025-12-15` (snapshotted at conversion), Postgres `lm.booking_date = 2026-03-11` (overwritten by a later CRM update). BQ preserves the original; Postgres does not.
- **`booking_date` NULL for some current deals.** 4 March-2026 deals have `lm.booking_date IS NULL` in Postgres while BQ has it populated (= `sold_ts` date). E.g. `402008865910`, `402008854979`, `402008371865`, `402008739319`.

**Consequence:** Postgres totals will sit a few bookings below BQ each month until the ETL is fixed. Do not patch around this in SQL — accept the residual and report BQ as the canonical number when precision matters.

**Cancellations**
- Postgres `deals_table.is_cancelled` appears to undercount vs. the CRM stage log (observed undercount in March 2026 sample: 1 in DB vs 4 in CRM). Pattern not confirmed across other months. Use CRM stage log as canonical until investigated.
- Canonical cancellations: CRM `stage_updated_to = 'Ops Pipeline - Trip Cancelled'` in `freshworks_leads_pipeline.deal_stage_update_logging`.
- _Ops Pipeline stage names: derived from existing dashboard SQL. Confirm with finance/CRM owner before locking in._

# Naming gotchas

- `freshworks_lead_pipeline` (singular) is empty and deprecated. Always query `freshworks_leads_pipeline` (plural).
- The Postgres user is `techlogin_readonly`, not `claude_readonly`. We reused an existing read-only user.
- The database is named `sundays_dev` but is the canonical analytics DB (legacy naming, not actually a dev environment).
- `itinerary_versioning` is misleadingly named. It is actually the live production operational schema (deals, customers, payments, invoices, vouchers, KYC, call logs).
- **No Postgres schema is "dead."** Earlier notes wrongly labeled `itinerary_generator` / `itinerary_copilot` / `itinerary_test_db` as legacy/dead. They are valid, just sparsely populated in places. Query them when the data you need lives there — e.g. `itinerary_generator.add_ons` is the live 66-row package add-ons catalog.
- BigQuery datasets are in **`asia-south2` (Delhi)**, not `asia-south1` (Mumbai). Only `temp_migration` lives in Mumbai.
- `deals_table.is_cancelled` is unreliable (undercounts vs CRM stage log in March 2026 sample). Use CRM stage log for cancellations until investigated.
- `deals_table.type` is observed as null in current samples — do not filter on it without checking.
- `deals_table.ops_sold_ts` and `ops_sold_by` are often null / sparsely populated. `sold_ts` is the reliable timestamp on the ops DB side.
- Destination naming differs by source:
  - Postgres `itinerary_table.destination`: lowercase, with variants (e.g. `bali`, `maldives_sis`)
  - CRM `main_destination` (Freshworks) and BigQuery: proper-cased, cleaned (e.g. `Bali`, `Maldives`)
  - In `freshworks_leads_pipeline.leads_master_updated` the column is quoted: `"Main Destination"` (space, title case)
  - Proper-cased (CRM / BQ) values are the display standard.
- `itinerary_versioning.itinerary_table.pricing_be` has two JSON schemas. Most destinations use flat keys (`hotels`, `activities`, `flights`, `addOns`, `total`, …). `destination='maldives_sis'` uses a nested `{prices:[[{price,costPrice,…}]], costPrice:[[…]]}` schema with no top-level `hotels`/`activities`. See Booking Rules for reconciliation details.
- `deals_table.ops_converted_version_id` does not always point to the version with the canonical selling prices. Some deals have `pricing_be.hotels = 0, activities = 0` on the ops_converted version while an earlier version holds the real prices. For pricing-sensitive queries, pick the version with max `(hotels + activities)` per deal rather than trusting ops_converted_version_id.
- `converted_deals_data` Postgres schema has tables but no SELECT permission granted to `techlogin_readonly`.
- `leads_master_updated.ad_id` is **not** what the Looker "Campaign Performance" dashboard treats as the ad id. The dashboard regex-parses `campaign_id` / `adset_id` from `ad_name` (`Campn: ...-<id> Adset:` and `Adset: ...-<id>$`). Filtering `WHERE ad_id = '<meta_id>'` will silently miss most matches. See `notes/gotchas.md` #11b and `notes/campaigns.md` "Reproducing the Looker Campaign Performance dashboard" for the canonical query.
- For Meta ad spend / lead joins, the only **live** table is `Freshworks_Leads_Pipeline.Meta_Campaign_Analytics_RAW`. `Meta_Ad_Analytics_Grouped_AdLevel` (latest 2025-07-17), `Meta_Campaign_Analytics_RAW_New` (2025-07-20), and `Meta_Campaign_Analytics_DB` (empty) are stale. `marketing_db.campaign_ad_table*` is Drive-backed and the BQ service account has no Drive access.

# Metabase conventions

_TODO: fill in._

# Data catalog

Detailed per-table reference lives in `notes/`. Read before writing new queries:

- **`notes/gotchas.md`** — 27 cross-system traps (serviceable_lead filter, CRM stage drift, pricing_be schema split, PG/BQ/Mongo divergences, dirty task_status CRM IDs, empty shell tables, schema quirks). Consult first when a number disagrees with a dashboard.
- **`notes/catalog_postgres.md`** — 10 Tier-1 PG tables (deals, itineraries, customers, leads, CRM stage log, tasks, payment links, ozonetel calls) with columns, distributions, joins, per-table gotchas.
- **`notes/catalog_bigquery.md`** — 10 Tier-1 BQ tables (Converted_Deals, Leads_Master_Updated, task loggers, Daily_Booking_Report, Meta campaign analytics, Callyzer calls, feedback, ad spend) plus PG→BQ parity map.
- **`notes/catalog_mongodb.md`** — 7 Tier-1 Mongo collections (app_clickup_logs, customers, conversations, trip_participants, customer_deals_infos, referral_points, referral_points_ledgers) plus a skip-list for the other 43.
- **`notes/README.md`** — how to use the catalog + when to re-profile.
- **`notes/analysis_checklist.md`** — MANDATORY pre-delivery sanity checks (definitions, reconciliation, impossible events, extreme-value tracing, selection bias, identity across login, ordering). Run before presenting any number.

# Operating instructions for Claude

- Always show me SQL or aggregation pipelines before executing writes or creating Metabase cards
- Never run DROP, DELETE, UPDATE, or INSERT on any database without explicit confirmation
- Save all Metabase cards to the "Claude Sandbox" collection unless I say otherwise
- When in doubt about a column's meaning, ask me rather than guess
- **Build up `notes/` after every interaction.** Whenever I share context — a business rule, a column meaning, a team decision, a correction to a prior assumption, a new gotcha discovered while answering a question, a confirmed hypothesis — persist it immediately into the right file:
  - New cross-system trap or corrected behavior → `notes/gotchas.md`
  - New table/column meaning, distribution, or purpose → the relevant `notes/catalog_*.md`
  - New high-level business / stakeholder / pipeline context → `CLAUDE.md` itself
  - Ad-hoc but reusable SQL → `queries/`
  Goal: each conversation leaves the knowledge base strictly richer than it found it, so future-me doesn't re-ask questions you've already answered. When unsure where something belongs, ask before writing.
- Default to Postgres for **everything, including revenue / bookings / margins** (JD, 2026-07-14). Only use BigQuery `Freshworks_Leads_Pipeline.Converted_Deals` when explicitly asked, or when the task is specifically to reconcile against a Looker revenue dashboard (that table has pricing filters, test exclusions, TCS, GST back-calc baked in). When you do use PG for bookings, follow the canonical booking definition and reconciliation notes below.
- Postgres is canonical for everything by default, and specifically for row-level state: specific deal details, customer records, raw itineraries, call logs, installment-level payment data.
- When reconciling numbers with an existing dashboard, find the LookML / SQL behind it before guessing at filter logic.
- Use the design system colors from this file when creating charts:
  - Primary `#FD014F`
  - Blue `#1F78FF`
  - Success `#4EAC7E`
  - Warning `#FDA201`
  - Orange `#FF5400`
  - Purple `#712BDA`
