## graphify

This project has a graphify knowledge graph at graphify-out/.

Rules:
- Before answering architecture or codebase questions, read graphify-out/GRAPH_REPORT.md for god nodes and community structure
- If graphify-out/wiki/index.md exists, navigate it instead of reading raw files
- For cross-module "how does X relate to Y" questions, prefer `graphify query "<question>"`, `graphify path "<A>" "<B>"`, or `graphify explain "<concept>"` over grep — these traverse the graph's EXTRACTED + INFERRED edges instead of scanning files
- After modifying code files in this session, run `graphify update .` to keep the graph current (AST-only, no API cost)

# Claude Code / AI instructions — thirty_sundays_mobile

This file is for **Claude Code** (and any tool that reads `CLAUDE.md`).
Cursor-specific rule slices live in **`.cursor/rules/*.mdc`**; keep them in sync when conventions change.

---

## 0. Commands

**Use `fvm flutter`, not bare `flutter`** — the Flutter version is pinned in `.fvmrc` (3.41.5) and every build script goes through `fvm`.

```bash
fvm flutter run --flavor development --dart-define-from-file=.env.dev
fvm dart run build_runner build --delete-conflicting-outputs   # ONLY after editing a file that feeds codegen — see below
fvm flutter analyze                                            # completion gate — read warnings + infos, not just errors
fvm flutter test                                               # test/{common,core,features}
```

Flavors are `development` / `staging` / `production` (Android applicationId suffix `.dev` / `.stg` / none), paired with
`--dart-define-from-file=.env.dev` (dev + staging) or `.env.prod` (production).

| Script | What it does |
|---|---|
| `bash staging-release.sh` | Builds staging aab / ipa / web into `staging-artifacts/`. Build only, no upload. |
| `./staging-deploy.sh` | Builds staging **and** uploads via fastlane (`skip_build:true` lanes). Both platforms share one build number **and one changelog** (`deploy-changelogs/staging.txt`). |
| `./shorebird-release.sh` | Despite the name, runs plain `fvm flutter build` for production into `release-artifacts/` — the `shorebird release` lines are commented out. |
| `./shorebird-patch.sh <release-version> [track]` | The only script that actually calls Shorebird: pushes a Dart-only patch (default track `staging`). |

---

## 1. Tech stack (from `pubspec.yaml`)

- **Dart**: `>=3.10.0 <4.0.0` · **Flutter** (Material 3)
- **State**: Riverpod 3 (`hooks_riverpod`) · **Hooks**: `flutter_hooks`
- **Navigation**: `go_router` + `go_router_builder` (typed `GoRouteData`, generated `app_router.g.dart`)
- **HTTP**: `dio` · **Serialization**: `json_annotation` / `json_serializable` (`*.g.dart` generated — edit sources only)
- **UI**: `cached_network_image` / `ImageCarouselWidget`, `flutter_svg`, `phosphor_flutter`
- **Maps / location**: `google_maps_flutter`, `geolocator`, `geocoding`
- **Firebase**: Core, Analytics, Crashlytics, Remote Config (respect mobile-only packages on web)
- **Logging / debug**: `talker`, `talker_flutter`, `talker_dio_logger`
- **Storage**: `hive_ce_flutter` · **Markdown**: `markdown_widget` / `AppMarkdownWidget` where rich text is required
- **Video**: `media_kit` / `VideoView` (`lib/common/widgets/media_player/video/video_view.dart`; pub dep; Android libs prefetched by `scripts/prefetch-media-kit-libs.sh`)
- **Local path packages**: `packages/modelith/` (model codegen — see §2), `packages/particle_veil/`
- **Fonts**: **Poppins** from assets; `AppTextTheme.fontFamily` is the source of truth

Do **not** add new dependencies unless the user explicitly asks.

**Run `build_runner` only when the edit feeds code generation** — an annotated source whose output is a `*.g.dart` (`@Model` from modelith, `@JsonSerializable`, retrofit `@RestApi()`, `GoRouteData` routes). Adding, removing or renaming a field on such a class needs it; changing only a method body or a comment on that same class does not, and edits to views, widgets, notifiers, services or anything else with no generated counterpart never do. It is a full-project pass — do not run it "just in case". Before reaching for it, name the generated file the edit would change; if you cannot name one, do not run it.

---

## 2. Project architecture (`lib/`)

| Area | Purpose |
|------|---------|
| `lib/core/router/` | `app_router.dart`, paths, **`AppRouter`** API (`lib/core/router/app_router_service.dart`) |
| `lib/core/theme/` | `app_theme.dart`, `app_text_theme.dart` |
| `lib/common/` | Shared widgets, utils, extensions, services, cross-cutting views |
| `lib/features/<feature>/` | Vertical slice: `model/`, `notifier/`, `repository/`, `service/`, `ui/views/`, `ui/widgets/` |
| `lib/data/<domain>/` | retrofit `@RestApi()` clients (`auth`, `explore`, `seller`, `trips`, `user`) |
| `lib/core/network/` | `ApiService` (base URL + legacy endpoint constants), `httpClient` provider |

### Architectural Principles

DRY (Don't Repeat Yourself) – eliminate duplicated logic by extracting shared utilities and modules.

Separation of Concerns – each module should handle one distinct responsibility.

Single Responsibility Principle (SRP) – every class/module/function/file should have exactly one reason to change.

Clear Abstractions & Contracts – expose intent through small, stable interfaces and hide implementation details.

Low Coupling, High Cohesion – keep modules self-contained, minimize cross-dependencies.

Scalability & Statelessness – design components to scale horizontally and prefer stateless services when possible.

Observability & Testability – build in logging, metrics, tracing, and ensure components can be unit/integration tested.

KISS (Keep It Simple, Sir) - keep solutions as simple as possible.

YAGNI (You're Not Gonna Need It) – avoid speculative complexity or over-engineering.


### Naming

- Screens: `*_view.dart` under `ui/views/`
- Feature widgets: `ui/widgets/` (often subfolders)
- Extract non-trivial UI (~40+ lines or reusable) into **real files** under `ui/widgets/`, matching sibling structure

### Code Guidelines

- Add newlines between statements for better readability but club similar statements together and add new line for separate logic.
- **Follow all linter rules in `analysis_options.yaml`** — written code must pass `flutter analyze` with no new lints. In particular honor **`omit_obvious_local_variable_types: true`**: drop the type annotation on a local `var`/`final` when the initializer makes the type obvious (literals, constructors, casts, `?? const <T>[]`), e.g. write `final images = activity.imageUrls ?? const <String>[];` not `final List<String> images = ...`. This rule is local-only — keep explicit types on fields, parameters, and public APIs (`type_annotate_public_apis` is on).
- **Avoid type annotations wherever they aren't required** — the same instinct as `omit_obvious_local_variable_types`, applied past locals:
  - Drop redundant generics the context already types: `children: [...]` not `children: <Widget>[...]`, `.map((e) => ...)` not `.map<Foo>((e) => ...)`.
  - Drop types on closure/callback parameters — `(card, position) => …`, `(_, _) => …`, not `(ExploreDestinationCardModel card, int position) => …`.
  - Keep them where inference would be wrong or the type is the API contract: field and return types, public parameters, empty literals (`const <String>[]`), and casts.
- **Always** prefer flutter_hook usage instead of stateful widgets
- **Prefer private widget classes over build methods.** Do not split a widget's UI into `Widget _buildX(...)` helper methods that return widgets. Extract each piece into its own widget class — a file-local `_Name` (`StatelessWidget` / `HookWidget` / `ConsumerWidget`) for private pieces, or a real file under `ui/widgets/` when reusable. Widget classes get their own `Element` (rebuild isolation), support `const`, and appear in the DevTools tree — build methods get none of that.
- **Read MediaQuery through its aspect getters, never `MediaQuery.of(context)`.** Use `MediaQuery.sizeOf`, `paddingOf`, `viewInsetsOf`, `viewPaddingOf`, `textScalerOf`, `disableAnimationsOf`, … — each rebuilds the widget only when that aspect changes, while `MediaQuery.of` subscribes it to *every* field (keyboard insets, text scale, brightness, …) and rebuilds it on any of them. Do not grab the whole `MediaQueryData` just because it is convenient to read several fields from it.
  - The one legitimate use is copying the data to override part of it (`MediaQuery(data: MediaQuery.of(context).copyWith(...))`). Put that in a **small dedicated widget** so only it takes the all-fields dependency — never in a large screen/page `build` (see `_BottomPadding` in `day_details_view.dart`).
- **Keep code comment-light** — do **not** add a comment narrating each change/edit. Comment only genuinely non-obvious logic (surprising decisions, workarounds, subtle invariants); well-named code should speak for itself. Keep real markers like `// TODO`.
- Think about the requested changes and **brainstorm** them. **Find edge-cases** that I might have missed and also any improvements or issues with the new change. **Do not blindly implement the changed**. Think like a senior developer from Meta.

### Code placement / layering (no top-level functions)

- **Do not define top-level (global) functions or variables** for logic. Group behaviour into a class/type so it has a clear home and is discoverable. Pick the home by what the code *does*:
  - **Pure logic / filtering / derivation** (no state, no `ref`, no `BuildContext`) → **service class with `static` methods** (private const ctor, e.g. `HotelUpgradeService._()`). Lives under `lib/features/<feature>/service/`.
  - **Derived / computed state** that composes providers → a **computed `Provider`** (`.family` when parameterised). It only wires inputs together and delegates the pure work to a service. Key a family on an `Equatable` args object; never on a raw `List`/`Map` unless its elements have value equality.
  - **State handling / mutations** (persisted or session state) → **`Notifier` / `AsyncNotifier`** (never statics — statics block DI/testing).
  - **Behaviour / predicate that belongs to a model** (e.g. "are these the same hotel") → **`extension` on that model**, not a feature service. Keeps it reusable and correctly scoped.
  - **UI formatting / helpers** → **`extension` on `BuildContext` or the value type**, or reuse **`AppUiHelpers`** — do **not** create a catch-all `*Utils` dump. Anything needing `BuildContext`/theme is presentation, not a service.
- Value/data types → `model/` (`*_model.dart` for serialized models). A pure value type used by a service may live beside it in `model/`.

### New routes / screens (checklist)

1. Add or extend typed **`GoRouteData`** in `lib/core/router/`
2. Register the route in the router configuration
3. Navigate with **`AppRouter.push` / `AppRouter.go`** (or `pushUri` when intentional) for GoRouter-defined routes, and use **`AppRouter`** for **all** pops (`AppRouter.pop` / `AppRouter.maybePop`) — including imperatively-pushed sheets/dialogs. Use `Navigator.push` **only** for non-GoRouter routes (e.g. `showModalBottomSheet` / `ModalSheetRoute` content). Avoid ad-hoc `Navigator.pop`.
4. Wire call sites (button/card taps) when the user asked for navigation
5. When creating new paths always add to **`AppRoutePaths`** and also update **`pathToIdMapping`**.
6. **Any new `$extra` type must be registered in `AppExtraCodec`** (`lib/core/router/app_extra_codec.dart`) — add a branch to **both** the encoder and the decoder, and a round-trip case to `test/core/router/app_extra_codec_test.dart`. go_router serializes the whole route stack on every navigation, so an unregistered `extra` is silently dropped and the route rebuilds with nothing on a restored stack (hot reload, Android process death). The payload type therefore needs `toJson`/`fromJson` (`@Model()` via modelith), and the route's `$extra` field stays **nullable** with a `redirect` to `AppRoutePaths.dashboard` when it is null.

### Networking & data

- **dio** for HTTP
- Run **`build_runner`** when adding or changing serialized types (`*.g.dart` is generated — edit the source `*.dart` only)
- When creating models follow the file naming - [name]_model.dart (note the model suffix). **Where it goes depends on who owns it:**
  - **Request / response DTO of an API** → **`lib/data/<domain>/models/`**, beside the api that returns it (see *API setup* below). A DTO belongs to the endpoint, not to whichever screen happens to render it first — never put it in a feature slice, even when the work started as "a new feature folder".
  - **Feature-local value type** (view model, notifier state, service args, derived state — never crosses the wire) → **`lib/features/<feature>/model/`**.
- **Always use the `modelith` package for models** (`@Model()` + `with _$Name`), never a hand-rolled `Equatable` + `@JsonSerializable` pair. `@Model` generates `==` / `hashCode` / `toString`, `copyWith`, and the json codec into one `*.g.dart`.
  - **New models**: always `modelith`.
  - **Existing `Equatable` / `@JsonSerializable` models**: convert to `modelith` **when you refactor, edit, or add/change a field** on them. Do not convert models you are only reading from — leave the rest of the codebase alone.
  - **Turn off what the model does not need**: `@Model(serializable: false)` for pure in-memory value types (derived state, view models, service args), `copyWith: false` when nothing calls `copyWith`. Do not generate unused surface.
  - Field-level options go on **`@ModelField`** (`name`, `includeIfNull`, `fromJson`/`toJson`, `readValue`, …) — not `@JsonKey`. Class-level json options (`includeIfNull`, `fieldRename`, `converters`, …) are named arguments on `@Model` itself.
  - A `modelith` class needs `part '<file>.g.dart';` plus, when `serializable` is on, the two hand-written json lines (`factory X.fromJson` / `Map<String, dynamic> toJson()`). Missing the `part` directive fails silently as a build warning.
  - **Member order**: constructor → **fields** → `fromJson` / `toJson` → everything else (getters, helper methods). The json pair always sits **below the fields**, so the shape of the model reads first and the codec boilerplate stays out of the way.

#### API setup (retrofit — the pattern for all new endpoints)

A new endpoint is **four** edits, in this order. Do not skip step 1 by inventing a new folder.

1. **Api class** → `lib/data/<domain>/<domain>_api.dart`, a `@RestApi()` abstract class holding the path in its `@GET` / `@POST` annotation. `<domain>` is the **backend path segment** (`/trips/...` → `lib/data/trips/`, `TripsApi`), not the feature name. Extend the existing api for that domain when one is there — one api class per domain, never a second api for the same prefix.
2. **DTOs** → `lib/data/<domain>/models/`, `modelith` `@Model`, one type per file.
3. **Register** in `lib/core/di/locator.dart`: `getIt.registerLazySingleton<XApi>(() => XApi(getIt<Dio>()));`
4. **Call it** from the notifier / provider as `getIt<XApi>()` — retrofit apis have **no repository layer**. Do not add a repository, and do not add the path to `ApiEndpoints`; both are the legacy path below.

Also:

- `ResponseEnvelopeInterceptor` already unwraps the backend's `{message, data}` envelope, so a retrofit method returns the **inner payload** type. Never model the envelope.
- Path params use `@Path('name')`, query params `@Query('wire_name')` (keep the wire casing, e.g. `hotel_id`). An empty POST body takes no `@Body()`.
- **Legacy (do not use for new work):** older features declare the path in **`ApiService.endpoints`** and call it through the `httpClient` provider from `lib/features/<feature>/repository/`. Touch that only when editing one of those existing repositories.

---

## 3. Design tokens and UI rules

### Colors

- Use **`AppColors`** (`lib/common/utils/app_colors.dart`) everywhere in UI code
- No scattered `Color(0xFF...)` — add or reuse a **named** token on `AppColors` when a design introduces a new stable color
- **Reuse only a near-identical token.** Before adding a token, look for an existing one that is visually indistinguishable from the design's color — a few units per RGB channel at most. A token that is merely "also grey" or "also green" is not a match: reusing a much lighter grey for a locked field in edit profile visibly broke the design. When nothing is that close, add a new named token.
- **Name tokens by color, not by widget/feature.** Use general color names like the existing ones (`mintDark`, `burntOrange`, `spaceCadet`) — never usage-scoped names like `pdfGreen` or `discardOrange`. Exception: brand colors keep their brand name (e.g. `bookingComBlue`).
- **No comments on color tokens** — the name + hex is enough.
- **A zero-alpha gradient stop takes the hue of the stop next to it — not the hue the CSS writes.** Browsers blend gradient stops in *premultiplied* alpha, so in CSS a zero-alpha stop's hue is irrelevant: `rgba(255,255,255,0)`, `rgba(0,0,0,0)` and `transparent` all render as "fade the neighbouring color out". Flutter blends *unpremultiplied*, so the stop's hue bleeds into the ramp: `AppColors.transparent` / `black@0` muddies it grey, and `white@0` washes the tint out early (about twice as fast as the browser, even over a white background). To match the design:
  - `linear-gradient(<c>, rgba(255,255,255,0))` → `colors: [c, c.withValues(alpha: 0)]` — same for `transparent` / `rgba(0,0,0,0)` and for `radial-gradient` stops.
  - A zero-alpha stop *between* two colors (`red, transparent, blue`) becomes two stops at the same position: `red@0` and `blue@0`.
  - Map each hue to an `AppColors` token (a near-identical existing one, or a new one, per *Reuse only a near-identical token*) and keep the design's alpha verbatim — do not round the alpha and do not add a token just to hold a faded shade.
  - `AppColors.transparent` is only for a genuinely hue-less slot (an untinted background, a cleared `Border`/overlay), never as a gradient stop.

### Typography

- Use **`AppTextTheme`**, **`context.textTheme`**, and **`AppTextSizes`** (`lib/core/theme/app_text_theme.dart`)
- **Font sizes come only from `context.textTheme`.** Pick the role (or `context.textTheme` getter such as `titleMedium18`) whose size is closest to the design's and override just weight/color with `copyWith`. Never set `fontSize:` yourself — not even with an `AppTextSizes` token — and never add a size to match one design value.
- **Always use `AppFontWeight`** (`lib/core/theme/app_text_theme.dart`) for `fontWeight:` — never a raw `FontWeight.wNNN` / `FontWeight.bold`. e.g. `fontWeight: AppFontWeight.semiBold`, not `fontWeight: FontWeight.w600`. If the weight you need is missing, add a named `static const FontWeight` to `AppFontWeight` first, then use it.

### Responsive layout

- **Do NOT use `flutter_screenutil` in new code.** The `.sp` / `.r` / `.h` / `.w` extensions are deprecated for new work — size with plain **logical-pixel** values instead (e.g. `EdgeInsets.symmetric(horizontal: 16)`, `SizedBox(height: 240)`, `BorderRadius.circular(12)`).
  - For font sizes use **`TextTheme`** roles / **`AppTextSizes`** tokens — never raw `.sp`.
- `flutter_screenutil` usage in **existing** files is being phased out: **don't add new `.sp/.r/.h/.w` usages**, even when editing a file that already has them (no need to rip it out of unrelated surrounding code in the same change).
- Respect documented exceptions (e.g. map markers using logical px — see `AppTextSizes` comments)

### 4px grid (critical)

**Every dimension you write must be a multiple of 4** — padding, margins, `spacing:`, `VerticalSpacer`/`HorizontalSpacer` values, icon `size:`, `BorderRadius`, and fixed widths/heights. This applies to all new UI, and *especially* when implementing from a design reference (HTML, Figma, screenshot, CSS): the source's off-grid values (`13`, `11`, `9`, `6`) get **snapped, not copied**.

Rounding direction when a design value is off-grid:

| Kind | Direction | Example |
|------|-----------|---------|
| Padding, margin, `spacing:`, gaps | **up** to the next multiple of 4 | `5 → 8`, `9 → 12`, `13 → 16` |
| Icon `size:`, fixed box width/height | **nearest**, ties go up | `11 → 12`, `13 → 12`, `14 → 16`, `18 → 20` |
| `BorderRadius` | **up** to the next multiple of 4 | `6 → 8`, `9 → 12`, `13 → 16` |

Do **not** round these:

- **Hairlines and borders** — `0.5` / `1` / `1.5` px dividers, `Border.all(width:)`, `Divider`/`VerticalDivider` `thickness`, and any 1px slot reserved to keep columns aligned. These are strokes, not spacing.
- **Font sizes** — always come from `TextTheme` roles / `AppTextSizes`. Never add a raw `fontSize:` just to put type on the grid.
- Documented per-widget exceptions (e.g. map markers).

**Flag, don't silently deviate:** rounding up a *nested* radius can make it meet or exceed its parent's (outer `11` + padding `3` + inner `9` all round to `12/4/12`, so the inner corners overshoot the track). Correct nesting is `inner = outer − padding`. When the grid and correct nesting disagree, say so and ask rather than picking one.

### Widget reuse (critical)

Weak phrases like “reuse as much as possible” are insufficient. **Mandatory workflow:**

1. Search **`lib/common/widgets/`** and **`lib/features/<feature>/ui/widgets/`** first
2. If almost correct, **extend** the existing widget via **parameters** — do **not** fork a second widget
3. If the user `@`-mentions a widget file, that widget is the **base implementation** — parameterize for differences (full width vs fixed width, optional sections, etc.)
4. For larger tasks, state **which existing widgets** you reuse and **what new parameters** you add
5. Use `VerticalSpacer` and `Horizontal` spacer instead of SizedBox when required.

### Spacing between children (critical)

Do **not** interleave spacer widgets with a `for` loop / `if (i > 0)` just to gap children. Follow this priority order:

1. **`spacing:` property first** — `Row`, `Column`, `Wrap`, `Flex`, `Table` (and similar) support a `spacing:` argument. Use it for uniform gaps between children: `Column(spacing: 12, children: [...])`.
2. **If the widget has no `spacing:`** (e.g. `ListView`, `CustomScrollView` slivers, custom builders) use **`AppUiHelpers.generateSeparated`** or **`IterableExt.generateSeparatedWidget`** (`lib/common/extensions/iterable_extensions.dart`) to build the separated child list.
3. **Only if neither fits** (non-uniform gaps, conditional separators, gap depends on the item) fall back to an explicit `for` loop with `VerticalSpacer`/`HorizontalSpacer`, or a `VerticalSpacer/HorizontalSpacer/Spacer` widget for depending on the requirement.

### Building lists from a collection

- **Always prefer prototype/iterable methods** (`.map`, `.where`, `.expand`, `.whereType`, etc.) over a collection-`for` when turning a collection into a list of widgets/values. e.g. `children: items.map((item) => ItemTile(item: item)).toList()` — not `children: [for (final item in items) ItemTile(item: item)]`.
- **Never use `forEach`** — use `.map`/`for-in` as appropriate (`forEach` can't be used in an expression and reads worse).
- Collection-`for`/`if` spreads (`...<Widget>[]`) are still fine for **conditional** children and mixed static+dynamic child lists where `.map` doesn't cleanly apply.

### Extensions reuse

1. **Always** make use of existing extensions like instead of checking String? for null and empty use the existing extension method called "isBlank" and "isNotBlank" etc.

### Design handoff (Figma, screenshots, React, CSS)

**When I ask you to implement a design from another codebase or an HTML file, follow it exactly.** Every visible property must match, not just the layout:

- Font size (closest `context.textTheme` role, see *Typography*), font weight, and text color of every label, title, hint and placeholder.
- Colors of every fill, border, divider, icon and disabled state (see *Colors*).
- Component states — focus, pressed, disabled, selected. If the design's field does not change on focus, ours must not either; do not carry over the house style of a similar widget.
- Heights of controls, radii, border widths, icon sizes and the gaps between elements.

The only allowed deviations: spacing and sizes snap to the **4px grid** (below), and the font stays Poppins.
Read the values from the rendered design (computed styles in a browser) when you can run it, not only from source — global CSS (line-height, placeholder color, font) changes what the source shows.

1. Map colors and type to **`AppColors` / `TextTheme`** before coding
2. Do not paste hex/rgba from CSS/React into widgets — use a near-identical `AppColors` token or add one
3. Snap every px value to the **4px grid** (see above) — never copy the design's raw `13px` / `9px` / `6px`
4. For “pixel perfect” requests, list assumptions or confirm token mapping **before** huge diffs
5. Images: follow existing patterns (`cached_network_image`, common placeholders).
  - Always prefer ImageCarouselWidget for displaying images and VideoView for playing video urls.

### Implementing from HTML provided in comments

When I paste HTML code in comments as a design reference, follow these rules:

1. **Break down into smaller widgets** — extract sections into real widget files under `ui/widgets/`, do not build one monolithic widget.
2. **Match colors from `AppColors`.** If a color is missing, add a named token to the class and use it. If a similar color already exists, use that instead of introducing a new one.
3. **Prefer `.bold`** for phosphor icons.
4. **Snap all px values per the 4px grid rules above** — the HTML's `padding: 11px 13px`, `border-radius: 9px` are intent, not exact values. Type comes from `TextTheme` / `AppTextSizes`, never a raw `fontSize:`.
5. **Do not make assumptions.** If something is confusing or unclear, ask me before implementing.

### Loading skeletons

A screen or section that loads shows a **skeleton**, not a spinner.

- **Never skeletonize the real widgets.** Do not wrap content in `Skeletonizer(enabled: loading, child: RealWidget(fakeData))`. Write a **separate skeleton widget** (`XSkeleton`, under `ui/widgets/`) built from `Bone`s (`Bone`, `Bone.text`, `Bone.circle`) inside `Skeletonizer.zone`. It only has to **resemble** the real layout, not copy it: match the big shapes and reuse the real widget's size constants (e.g. `ExploreSeasonDestinationCard.width`, `DayGalleryGridDelegate`).
- **Swap with `FadeStateSwitcher`** (`lib/common/widgets/fade_state_switcher.dart`): `FadeStateSwitcher(child: loading ? const XSkeleton() : content)`. The content is in place at full opacity from its first frame and the skeleton **fades out on top of it**; it is never a cross-fade.
- **Full-screen skeleton**: build the page in a `Stack` and lay the skeleton over it with `IgnorePointer(ignoring: !loading, child: FadeStateSwitcher(child: loading ? skeleton : null))`. References: `ExploreHomeGate` (explore home) and `DayMediaGalleryView.showForRequest`.
  - Draw the skeleton on the page's own background, so nothing shows through until it lifts.
  - **Hold it at `context.screenHeight`.** While it fades out, it is laid out with no height to fill, and an `Expanded` inside it throws.
  - Keep a back button in it **real**, so the user can leave a slow load.
- **Widget tests:** the shimmer never settles, so `pumpAndSettle` times out while a skeleton is up. Pump fixed durations until it is gone, then settle.

### Text fields: tap outside closes the keyboard

Every text field you add closes the keyboard on a **tap** outside it, and only a tap: a scroll or swipe that starts outside leaves the keyboard open.

- `onTapOutside` alone is wrong. It fires on pointer **down**, so it also fires on the first touch of every scroll. Record the down position in `onTapOutside`, and in `onTapUpOutside` unfocus only when the finger lifted within `kTouchSlop` of it.
- Give the field its own `FocusNode` and unfocus **that** node, only if it still has focus. Never `FocusScope.of(context).unfocus()`: tapping from one field into another would drop the field that just took focus.
- Reference: `ProfileTextField` (`lib/features/manage_account/ui/widgets/profile/profile_text_field.dart`).

### Common building blocks (discover in repo)

Examples: `BottomNavBarContainer`, `AppMarkdownWidget`, `AppButton`, `PrimaryTextField` — **search** before creating parallels.

---

## 4. Agent workflow / pain points

- **NEVER assume unstated requirements — ASK.** If a detail isn't specified (pricing basis, comparison baseline, fallback behaviour, edge-case handling, defaults, etc.), stop and ask me before implementing. Do **not** invent a plausible-sounding default and build on it. A wrong guess wastes a whole implementation cycle. Only proceed without asking when I explicitly stated it or it is unambiguous from the code.
- **Default**: smallest correct change; no unrelated refactors
- **Bugs**: need expected vs actual + repro steps; never invent a story from “not working”
- **“Obvious” requirements** (markdown, no loading spinner, listener must fire, etc.) must be stated explicitly — the model will not infer them reliably
- **Large tasks**: short plan first (files, reused widgets, routes) to avoid forgotten router entries and duplicate components
- **React → Flutter**: behavior/layout reference only; **tokens and project widgets win**

### Hot reload after every edit

- **After every change — and after `build_runner` when the change needed it — hot reload the already-running debug build, if there is one. Never hot restart.** The app stays open on the simulator; a restart throws away the screen and state the developer is on.
- Run **`fvm dart run scripts/hot_reload.dart`**. It finds the IDE-run app's Dart Development Service and calls the flutter tool's `reloadSources` (the IDE runs `flutter run --machine`, so there is no terminal to press `r` in). It prints `"type": "Success"` when it works.
- The app runs from the **main checkout**. Edits made only in a worktree never reach it, so a reload after them changes nothing — say so instead of reporting the change as live.
- **If the reload is rejected, do nothing** — no restart, no retry, no workaround (e.g. `-32603` after adding a field to a `const` class).
- No app running (no `dart development-service` process): say so and skip.
- flutter_hooks effects added to an already-mounted widget keep the old closure after a reload — close and reopen the screen to see them.

### Verifying third-party package APIs

- **Read the resolved source before calling a non-obvious package API.** Ground truth is `~/.pub-cache/hosted/pub.dev/<package>-<version>/lib/` for the version `pubspec.lock` actually resolved — not recall, and not a doc page that may describe a different version. Grep it for **`@internal`**, **`@Deprecated`**, and **`@visibleForTesting`** on the member you are about to use. Package APIs move between minor versions (e.g. riverpod's `AsyncValue.copyWithPrevious` became `@internal` in 3.x).
- **`flutter analyze` / `dart analyze` is the completion gate — read warnings and infos, not just errors.** The `mcp__dart__analyze_files` MCP tool reports *errors only*: it answers "No errors" on code that `dart analyze` flags as `invalid_use_of_internal_member`. Never treat that tool's all-clear as verification on its own.
- For library docs, API syntax, and version migrations, use the **Context7 MCP** first. If it is unavailable, say so before answering instead of falling back to a remembered API shape.

---

## 5. Related files

- Cursor rules: **`.cursor/rules/thirty-sundays-*.mdc`**
- Human/agent index: **`AGENTS.md`**

