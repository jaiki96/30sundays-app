# CLAUDE.md — Couple Trails Itinerary Builder

Behavioral guidelines to reduce common LLM coding mistakes. Merge with project-specific instructions as needed.

**Tradeoff:** These guidelines bias toward caution over speed. For trivial tasks, use judgment.

## 1. Think Before Coding

**Don't assume. Don't hide confusion. Surface tradeoffs.**

Before implementing:
- State your assumptions explicitly. If uncertain, ask.
- If multiple interpretations exist, present them - don't pick silently.
- If a simpler approach exists, say so. Push back when warranted.
- If something is unclear, stop. Name what's confusing. Ask.

## 2. Simplicity First

**Minimum code that solves the problem. Nothing speculative.**

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" that wasn't requested.
- No error handling for impossible scenarios.
- If you write 200 lines and it could be 50, rewrite it.

Ask yourself: "Would a senior engineer say this is overcomplicated?" If yes, simplify.

## 3. Surgical Changes

**Touch only what you must. Clean up only your own mess.**

When editing existing code:
- Don't "improve" adjacent code, comments, or formatting.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- If you notice unrelated dead code, mention it - don't delete it.

When your changes create orphans:
- Remove imports/variables/functions that YOUR changes made unused.
- Don't remove pre-existing dead code unless asked.

The test: Every changed line should trace directly to the user's request.

## 4. Goal-Driven Execution

**Define success criteria. Loop until verified.**

Transform tasks into verifiable goals:
- "Add validation" → "Write tests for invalid inputs, then make them pass"
- "Fix the bug" → "Write a test that reproduces it, then make it pass"
- "Refactor X" → "Ensure tests pass before and after"

For multi-step tasks, state a brief plan:
```
1. [Step] → verify: [check]
2. [Step] → verify: [check]
3. [Step] → verify: [check]
```

Strong success criteria let you loop independently. Weak criteria ("make it work") require constant clarification.

## Project Overview
Travel itinerary SaaS platform for **30 Sundays**. Monorepo with a React+Vite frontend, Node/Express backend, and Python microservices for PDF generation, hotel pricing, and supplier email automation.

## Repo Structure
```
itenarary_creator/
  frontend/          React 18 + Vite + Tailwind + Ant Design
  backend/           Node 20 + Express + Mongoose (MongoDB) + PostgreSQL (Aurora) + Redis
  payment-backend/   Payment processing + payment PDF generation
  webhooks/          CRM webhook handlers (Freshsales)
excel_pdf_generator/ Python FastAPI — PDF/Excel generation (port 5000)
hotels_prices/       Python FastAPI — hotel data aggregation (port 5050)
supplier_email/      Python FastAPI — deal automation (port 5005)
data_migration_scripts/ Node — PostgreSQL <-> BigQuery sync
```

## Tech Stack
- **Frontend:** React 18, Vite 6, Tailwind CSS, Ant Design, react-icons, @ant-design/icons, Lucide icons, react-select, @floating-ui/react, Tippy.js, dnd-kit, dayjs, axios, Sentry, LogRocket
- **Backend:** Express 4, Mongoose (MongoDB primary), PostgreSQL (Aurora), Redis (ioredis), PM2, Puppeteer, pdf-lib, Firebase Admin, OpenAI, AWS SDK, Freshsales CRM
- **Python services:** FastAPI, uvicorn, pandas, gspread, boto3, pdfkit
- **Monitoring:** Sentry, New Relic, LogRocket, HyperDX, Microsoft Clarity, BigQuery analytics

## Coding Conventions

### Naming
- **Files:** `camelCase.js` for backend (`*.controller.js`, `*.service.js`, `*.routes.js`, `*.model.js`), `PascalCase.jsx` for React components
- **Variables/functions:** camelCase
- **DB fields (MongoDB):** snake_case (`deal_id`, `customer_id`, `modified_at`)
- **Path aliases:** `@/` maps to frontend `src/`

### Backend Pattern (vertical slice)
```
routes/*.routes.js -> controllers/*.controller.js -> services/*.service.js -> models/*.model.js
```
- CommonJS `require()` throughout backend
- Express Router per domain: `router.route("/path").post(handler)`

### Frontend Pattern
- Functional components + hooks only
- State via React Context API — NOT Redux (AppContext, DataContext, CurrencyContext, ItineraryComposerContext, GoogleFlightSelectionContext)
- Feature-based folder structure under `src/components/`
- ES6 imports with `@/` alias
- Toast notifications via react-toastify (also antd message/notification in some files)
- UI component libraries are mixed: antd, react-icons, @ant-design/icons, lucide-react, react-select, @floating-ui/react, Tippy.js, and custom SVG Icons.jsx (178KB)
- Custom reusable UI components live in `src/components/ui/` (53 files): Button, Modal/DialogBox, Tooltip, Popover, Input, Select, CustomSelect, CopyInput, StatusPillButton variants, etc.
- ModalContext exists (`src/contexts/ModalContext.jsx`) for global modal management but is underutilized
- CustomToast component exists (`src/components/ui/CustomToast.jsx`) but only used in ~20 files vs 112 files using raw toast()

### Code Quality
- ESLint (flat config) + Prettier
- Husky pre-commit/pre-push hooks enforce formatting
- No TypeScript — plain JS throughout

## Key Rules
- **Never remove existing code comments** — preserve inline, block, section header, and JSDoc comments when editing files
- **No unnecessary abstractions** — this is a fast-moving product; keep changes direct and minimal
- **Large controller files are normal** — `itinerary.controller.js` is 132KB+; don't try to refactor/split unless asked
- **Spelling:** The codebase uses `itenarary` (not `itinerary`) in folder/file names and route paths — match existing spelling in code, don't "fix" it
- **Always use themed UI components** — Never use native HTML elements (`<button>`, `<input>`, `<select>`, etc.) in frontend code. Always use the custom components from `src/components/ui/`: `Button`/`PillButton`/`IconButton` for buttons, `Input` for inputs, `Select`/`CustomSelect` for dropdowns, `Tooltip` for tooltips, `Modal`/`DialogBox` for modals. Colors must use design tokens (`var(--...)`), never hardcoded hex/rgb. Toasts must use `showToast` from `@/lib/toast`.
- **Always use mapped Tailwind typography classes** — Never use raw Tailwind font-size utilities (`text-xs`, `text-sm`, `text-base`, `text-lg`, `text-xl`, `text-2xl`, etc.) or arbitrary sizes (`text-[14px]`). Use the design-token typography classes defined in `src/index.css`. These classes bundle font-family, font-size, font-weight, and line-height from design tokens. Do not use inline `var(--type-*)` styles either — always prefer the mapped Tailwind utility class.
  - **Headings** (semibold): `text-h1` (32px), `text-h2` (24px), `text-h3` (20px), `text-h4` (16px), `text-h5` (14px)
  - **Body** (regular/medium): `text-b1` (24px), `text-b2` (20px), `text-b3` (16px), `text-b4` (14px), `text-b5` (12px) — add `-medium` suffix for weight 500 (e.g., `text-b4-medium`)
  - **Captions**: `text-c1` (16px), `text-c2` (14px), `text-c3` (12px)
  - **Labels** (medium weight): `text-l1` (16px), `text-l2` (14px), `text-l3` (12px)
  - **Tables**: `text-tbl-header` (12px), `text-tbl-body-hd` (14px bold), `text-tbl-body` (14px)
  - **Raw Tailwind → Token mapping**: `text-4xl`→`text-h1`, `text-3xl`→`text-h2`, `text-2xl`→`text-h2`/`text-b1`, `text-xl`→`text-h3`/`text-b2`, `text-lg`→`text-h4`/`text-b3`, `text-base`→`text-b3`, `text-sm`→`text-b4`, `text-xs`→`text-b5`

## Databases
- **MongoDB (Mongoose):** Primary data store — itineraries, customers, deals, flights, activities, referrals
- **PostgreSQL (Aurora):** Transactional data
- **Redis:** Caching, session locking (distributed locks via `requireLock` middleware)
- **BigQuery:** Analytics warehouse, version history, data sync from PG

## Deployment
- **CI/CD:** Jenkinsfile.development — builds and deploys to EC2 (ap-south-1)
- **Process manager:** PM2 for both frontend (preview on 4173) and backend (dev on 3001)
- **Python services:** Dockerized with uvicorn, SSL support
- **Health checks:** Curl-based in Jenkins pipeline

## Key Integrations
- Freshsales CRM (leads, deals, webhooks)
- Firebase Auth + Analytics
- AWS S3, Secrets Manager
- Google BigQuery, Sheets (gspread), Cloud Storage
- OpenAI APIs
- Payment gateway APIs

## Common Commands
```bash
# Frontend
cd itenarary_creator/frontend && npm run dev     # Vite dev server
cd itenarary_creator/frontend && npm run build   # Production build

# Backend
cd itenarary_creator/backend && npm start        # Nodemon dev
cd itenarary_creator/backend && npm run prod     # PM2 production

# Lint
cd itenarary_creator/backend && npm run lint
```
