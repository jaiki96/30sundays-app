# CLAUDE.md — Couple Trails Itinerary Builder

Behavioral guidelines to reduce common LLM coding mistakes. Merge with project-specific instructions as needed.

**Tradeoff:** These guidelines bias toward caution over speed. For trivial tasks, use judgment.

## 0. Module Rewrite Prompts (READ FIRST — every dev, every rewrite)

Whenever a module is being rewritten — frontend or backend — the dev (human or LLM) must follow the matching prompt below verbatim. Same architecture, same conventions, across the codebase. No exceptions.

### 0.1 Frontend Module Rewrite Prompt

Rewrite `<MODULE FILE>` from scratch — a clean, modular re-implementation. Do not relocate or copy the existing code; read it only to understand what it does (the behavior: what renders, what shows/disables when, what each action/handler does), then re-derive and write it fresh. Copy the idea, never the code. Reuse only the existing services (API calls) and contexts — nothing else.

**Process**

- Leave the original file 100% untouched as a parity reference. Create the new files alongside it (same folder, clear new names). Swap the render site(s) to the new component last (find all usages first).
- First read the whole module and give a short behavioral spec + proposed file/hook/component structure. Then build it all in one pass. Verify with ESLint + `npm run build` before finishing. UI must stay visually identical (improve only where sensible).

**Coding style (follow exactly)**

- **Minimal state** — keep `useState` count as low as possible; derive values instead of storing them. Before adding state, ask "can this be computed from what I already have?"
- **Two-tier utils** — separate files for business/domain logic (rules, calculations, validation — pure: no React, no toasts, no API calls) vs generic helpers (date/number/string formatting, etc.). Put every tunable hardcoded value (thresholds, limits, durations, rates, allowed lists) in a dedicated `*Constants.js` — no magic numbers in logic files.
- **Hooks for separation of concerns** — split logic into focused hooks, typically: a **data** hook (fetch + read-only server state), a **state/editor** hook (working state + derived values + local mutations), and an **actions** hook (server interactions + side-effecting orchestration). Each hook calls the contexts/services it needs directly (no prop-drilling). Pass one hook's returned object into the next rather than threading many args.
- **Short, readable parent** — the main component just calls the hooks and composes presentational children; it should read top-to-bottom at a glance. No nested ternaries in JSX.
- **Pure components, minimal meaningful props** — never dump 15–20 props onto a child; pass cohesive slices, and bundle related callbacks into a single `actions` object. Make components as reusable/pure as possible.
- **Function decomposition** — a function should read at a glance, like a component. Big functions become a short orchestrator that calls named step-helpers (`// Step 1:`, `// Step 2:`). Extract reusable logic into services; keep non-reusable logic inline under numbered step comments — don't over-fragment into one-off helpers. No giant (500-line) functions.
- **Single-line comments** above every function/section saying what it does/returns. Code must be readable by any developer, junior or senior.
- **Themed UI only** — use the project's `ui/` components (`Button`/`PillButton`/`IconButton`, `Input`, `Select`, `Tooltip`, `Modal`, etc.) and design tokens (`var(--...)`), never raw native HTML controls or hardcoded colors. Use the mapped typography classes (`text-h4`, `text-b4`, …), never raw `text-sm`/`text-xs`/arbitrary sizes.
- Fix obvious dead code and bugs you find while rewriting (call them out), but keep behavior identical. When logic exists on both frontend and backend, treat the **backend as the source of truth**.
- **Target shape:** `<Name>Content.jsx` (short parent) + `hooks/` (the focused hooks) + `utils/` (constants / domain-logic / generic-helper files, split by concern) + `components/` (one pure component per UI section — enough to map code to on-screen UI, not so many it fragments).

### 0.2 Backend Module Rewrite Prompt

Rewrite `<MODULE FILE>` from scratch — a clean, modular re-implementation. Do not relocate or copy the existing code; read it only to understand what it does (the behavior: what each endpoint accepts, what it validates, what services it orchestrates, what it returns, what side effects it has), then re-derive and write it fresh. Copy the idea, never the code. Reuse only the existing models, external integrations (Mongo, Postgres, Redis, S3, Freshsales, etc.), and shared utilities — nothing else.

**Process**

- Leave the original file 100% untouched as a parity reference. Create the new files alongside it (same folder, clear new names). Swap the route mounts to the new controller/service last (find all usages first).
- First read the whole module (routes + controller + service + models) and give a short behavioral spec — endpoint list, payload shape, validation rules, response shape, side effects, DB writes, external calls — plus the proposed file/function structure. Then build it all in one pass. Verify with ESLint and a hand-trace of every endpoint (request → controller → service → response) before finishing. **API contract (URL, method, request body, response body, status codes) must stay identical.**

**Coding style (follow exactly)**

- **Controller owns ALL input validation** — every payload field is type-checked, required-checked, range-checked, shape-checked at the controller level. Services trust their inputs and do **zero** re-validation. If the controller passes it through, it's valid.
- **Controller is dumb and readable** — every handler is just: (1) pull/validate inputs from `req`, (2) call a service function, (3) `try/catch` + send response. No business logic, no calculations, no DB queries, no transformations in the controller body. A handler should fit on one screen at a glance.
- **Service does the work** — one named function per use case (`createX`, `updateX`, `fetchXById`, `sendXEmail`). If a function is long, break it into smaller named functions in the same service file using a short orchestrator + `// Step 1:`, `// Step 2:` helpers. No 500-line functions, no nested `if/else` towers, no logic dumped at the top of a request flow.
- **Two-tier helpers** — separate files for **business logic helpers** (domain rules, calculations, pricing math, eligibility checks — pure: no `req`/`res`, no DB writes, no logging) vs **generic code helpers** (date/number/string formatting, parsers, ID generators). Both live as `<topic>.utils.js` — add to the existing file for that topic rather than spawning new files per function. Put every tunable hardcoded value (thresholds, limits, timeouts, status enums, role lists, retry counts) in a dedicated `*.constants.js` — no magic numbers/strings in service files.
- **Reuse existing utils first** — grep `utils/`, `services/`, and existing `*.utils.js` files before writing a new helper. Don't reinvent `parseJSON`, currency conversion, role checks, lock acquisition, etc.
- **Simple function names** — say what they do in plain English: `getDealById`, `sendBookingConfirmation`, `calculateMarkup`. Never `doExecuteFinalizedOperation`, `ProcessorFactory`, `handleEnrichmentPipelineStep`. A junior dev should understand the name on first read.
- **Single-line (or two-line max) comments** above every function/section saying what it does and what it returns. No multi-paragraph docstrings, no JSDoc blocks unless the project already uses them in that area.
- **Models stay untouched** unless the schema needs to change — if a field is missing/wrong, call it out and ask, don't silently mutate the schema.
- **Errors flow up** — services throw with clear messages; controllers catch, log, return the right HTTP status with a clean error body. No `try/catch` buried inside service functions unless you're recovering from a known failure (e.g. fallback API, optional email send).
- Fix obvious dead code and bugs you find while rewriting (call them out), but keep behavior identical. **Backend is the source of truth for billing, availability, and persistence** — preserve the existing contract exactly.
- **Target shape:** `<name>.routes.js` (thin router) + `<name>.controller.js` (validation + delegation only) + `<name>.service.js` (business logic, broken into named functions) + `<name>.utils.js` / `<name>.helpers.js` (business + generic helpers split by topic) + `<name>.constants.js` (all magic values).

Drop in any module path (frontend or backend) and the rewrite must produce the same architecture and conventions described above.

## 1. Think Before Coding

**Don't assume. Don't hide confusion. Surface tradeoffs.**

Before implementing:

- State your assumptions explicitly. If uncertain, ask.
- If multiple interpretations exist, present them - don't pick silently.
- If a simpler approach exists, say so. Push back when warranted.
- If something is unclear, stop. Name what's confusing. Ask.

## 2. Simplicity First

**Minimum code that solves the problem. Nothing speculative.**

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" that wasn't requested.
- No error handling for impossible scenarios.
- If you write 200 lines and it could be 50, rewrite it.

Ask yourself: "Would a senior engineer say this is overcomplicated?" If yes, simplify.

## 3. Surgical Changes

**Touch only what you must. Clean up only your own mess.**

When editing existing code:

- Don't "improve" adjacent code, comments, or formatting.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- If you notice unrelated dead code, mention it - don't delete it.

When your changes create orphans:

- Remove imports/variables/functions that YOUR changes made unused.
- Don't remove pre-existing dead code unless asked.

The test: Every changed line should trace directly to the user's request.

## 4. Goal-Driven Execution

**Define success criteria. Loop until verified.**

Transform tasks into verifiable goals:

- "Add validation" → "Write tests for invalid inputs, then make them pass"
- "Fix the bug" → "Write a test that reproduces it, then make it pass"
- "Refactor X" → "Ensure tests pass before and after"

For multi-step tasks, state a brief plan:

```
1. [Step] → verify: [check]
2. [Step] → verify: [check]
3. [Step] → verify: [check]
```

Strong success criteria let you loop independently. Weak criteria ("make it work") require constant clarification.

## Codebase Exploration

**Use `/graphify` first when exploring frontend or backend structure.** It generates a visual knowledge graph of the codebase, saving tokens vs. reading files one by one. Trigger it via the Skill tool with `skill: "graphify"` before doing structural analysis.

## Project Overview

Travel itinerary SaaS platform for **30 Sundays**. Monorepo with a React+Vite frontend, Node/Express backend, and Python microservices for PDF generation, hotel pricing, and supplier email automation.

## Repo Structure

```
itenarary_creator/
  frontend/          React 18 + Vite + Tailwind + Ant Design
  backend/           Node 20 + Express + Mongoose (MongoDB) + PostgreSQL (Aurora) + Redis
  payment-backend/   Payment processing + payment PDF generation
  webhooks/          CRM webhook handlers (Freshsales)
excel_pdf_generator/ Python FastAPI — PDF/Excel generation (port 5000)
hotels_prices/       Python FastAPI — hotel data aggregation (port 5050)
supplier_email/      Python FastAPI — deal automation (port 5005)
data_migration_scripts/ Node — PostgreSQL <-> BigQuery sync
```

## Tech Stack

- **Frontend:** React 18, Vite 6, Tailwind CSS, Ant Design, react-icons, @ant-design/icons, Lucide icons, react-select, @floating-ui/react, Tippy.js, dnd-kit, dayjs, axios, Sentry, LogRocket
- **Backend:** Express 4, Mongoose (MongoDB primary), PostgreSQL (Aurora), Redis (ioredis), PM2, Puppeteer, pdf-lib, Firebase Admin, OpenAI, AWS SDK, Freshsales CRM
- **Python services:** FastAPI, uvicorn, pandas, gspread, boto3, pdfkit
- **Monitoring:** Sentry, New Relic, LogRocket, HyperDX, Microsoft Clarity, BigQuery analytics

## Coding Conventions

### Naming

- **Files:** `camelCase.js` for backend (`*.controller.js`, `*.service.js`, `*.routes.js`, `*.model.js`), `PascalCase.jsx` for React components
- **Variables/functions:** camelCase
- **DB fields (MongoDB):** snake_case (`deal_id`, `customer_id`, `modified_at`)
- **Path aliases:** `@/` maps to frontend `src/`

### Backend Pattern (vertical slice)

```
routes/*.routes.js -> controllers/*.controller.js -> services/*.service.js -> models/*.model.js
```

- CommonJS `require()` throughout backend
- Express Router per domain: `router.route("/path").post(handler)`

### Frontend Pattern

- Functional components + hooks only
- State via React Context API — NOT Redux (AppContext, DataContext, CurrencyContext, ItineraryComposerContext, GoogleFlightSelectionContext)
- **All React contexts live in `src/contexts/`** — when adding a new context (provider + `useXContext` hook), create the file in `src/contexts/` and import it via `@/contexts/<Name>`. Do not colocate context files next to the feature that consumes them, even if a single feature is the only consumer.
- **All hardcoded values (constants, thresholds, timeouts, magic numbers, category lists, etc.) live in `src/constants.js`** — when introducing a literal that has semantic meaning (a duration, a limit, a list of allowed categories, a fallback default), export it from `@/constants` and import where used. Service files, components, and utils should pull from `@/constants` rather than redeclare the value locally. The only literals that may stay inline are values that have no meaning outside their immediate expression (e.g. `flex: 1`, `idx + 1`, tailwind class names).
- Feature-based folder structure under `src/components/`
- ES6 imports with `@/` alias
- Toast notifications via react-toastify (also antd message/notification in some files)
- UI component libraries are mixed: antd, react-icons, @ant-design/icons, lucide-react, react-select, @floating-ui/react, Tippy.js, and custom SVG Icons.jsx (178KB)
- Custom reusable UI components live in `src/components/ui/` (53 files): Button, Modal/DialogBox, Tooltip, Popover, Input, Select, CustomSelect, CopyInput, StatusPillButton variants, etc.
- ModalContext exists (`src/contexts/ModalContext.jsx`) for global modal management but is underutilized
- CustomToast component exists (`src/components/ui/CustomToast.jsx`) but only used in ~20 files vs 112 files using raw toast()

### Code Quality

- ESLint (flat config) + Prettier
- Husky pre-commit/pre-push hooks enforce formatting
- No TypeScript — plain JS throughout

### Import / require ordering (applies to every source file, frontend and backend)

Every file's import block is **grouped by what the module IS, with a `// Comment` header per group, groups in a fixed order, and — inside a group — statements sorted by statement length, shortest first.** The point is that the block becomes scannable: you learn what a file plugs into by reading down the headers, and you never have to hunt for whether a hook or a util is already imported.

**Three rules, in priority order:**

1. **Group order is fixed** (lists below). A group is emitted only if it has at least one import. One blank line between groups, none inside a group.
2. **Group header is exactly the group's name as a single-line `//` comment**, directly above the group's first statement. Never merge two names into one header (`// Constants + utils`, `// React + third-party`, `// Utils + components` are all wrong — split them into their own groups). Never add a parenthetical to the header (`// Hooks (shared, payment-prefixed)` → `// Hooks`); if that context is worth keeping, it becomes a normal comment on the import it describes.
3. **Inside a group, sort by the length of the import statement, ascending** — shortest line at the top, growing as you go down. Measure the whole statement with whitespace collapsed, so a multi-line destructured import counts its full length and therefore sinks to the bottom of its group. Ties keep their existing relative order. Comment lines above an import are **not** counted in its length.

#### Frontend group order (ESM, `.js` / `.jsx`)

| # | Header | What goes in it |
|---|---|---|
| 1 | `// React` | `react`, `react-dom` |
| 2 | `// Third-party` | every other bare npm specifier — `antd`, `dayjs`, `lucide-react`, `react-icons/*`, `@ant-design/icons`, `react-select`, `@floating-ui/react`, … |
| 3 | `// Contexts` | `@/contexts/*` |
| 4 | `// Hooks` | `@/hooks/*` |
| 5 | `// Services` | `@/services/*` |
| 6 | `// Constants` | `@/constants`, `@/constants/*` |
| 7 | `// Utils` | `@/utils/*`, `@/lib/*` (incl. `@/lib/toast`) |
| 8 | `// Components` | `@/components/*` |
| 9 | `// Local` | anything relative (`../…`, `./…`) |

The order reads outward-in: the framework, then vendor code, then the app-wide things this file plugs into (state → behaviour → I/O → pure data → helpers), then what it renders, then its own module's files.

**Relative imports always go in `// Local`, whatever they are** — a component, a util, a config builder. A relative path's most useful signal is "this belongs to the module I'm in", which beats guessing its kind (and settles the genuinely ambiguous ones like `./Sections`).

```jsx
/* eslint-disable react/prop-types */

// React
import { useId, useRef, useState } from "react";

// Third-party
import dayjs from "dayjs";
import { DatePicker } from "antd";
import { RxCross1 } from "react-icons/rx";
import { AlertTriangle } from "lucide-react";

// Hooks
import useDialogKeys from "@/hooks/useDialogKeys";

// Constants
import { MAX_BANK_PROOFS, BANK_PROOF_UPLOAD_FOLDER } from "@/constants/paymentsV2.constants";

// Utils
import { getTodayIST } from "@/utils/calendarDate";
import { detectAmountAnomaly, isBlockingAnomaly } from "@/utils/amountAnomalyUtils";

// Components
import Input from "@/components/ui/Input";
import ScreenshotsField from "@/components/requests/ScreenshotsField";
import { IconButton, PillButton, TextButton } from "@/components/ui/buttons";

// Local
import LeanCard from "./LeanCard";
import AmountAnomalyWarning from "../ui/AmountAnomalyWarning";
```

#### Backend group order (CommonJS `require`)

Backend groups follow the app's own dependency stack, so reading down a require block tells you how deep the file reaches.

| # | Header | What goes in it |
|---|---|---|
| 1 | `// Node builtins` | `fs`, `path`, `crypto`, `os`, `https`, `async_hooks`, `node:*`, … |
| 2 | `// Third-party` | npm packages — `express`, `axios`, `pg`, `dotenv`, `puppeteer`, `firebase-admin`, `@aws-sdk/*`, … |
| 3 | `// Config` | `config/*` (`db`, `env`, `flags`, `tables`, `cors`, `credentialsLoader`) |
| 4 | `// Constants` | `constants/*.constants` |
| 5 | `// Logger` | `logger/*` |
| 6 | `// Utils` | `utils/*`, any `*.utils` / `errors` |
| 7 | `// Entities` | `entities/*.entity` |
| 8 | `// Repositories` | `repository/*.repo` |
| 9 | `// Integrations` | `gateways/*`, `client/*`, `channels/*`, `storage/*`, `alerts/*` — anything that talks to a system we don't own |
| 10 | `// Services` | `services/*.service` |
| 11 | `// Jobs` | `jobs/*`, `jobs/handlers/*.job` |
| 12 | `// Middleware` | `middleware/*.middleware` |
| 13 | `// Controllers` | `controllers/*.controller` |
| 14 | `// Routes` | `routes/*.routes` |
| 15 | `// Local` | a same-module relative that fits none of the above (e.g. `./render`, `./puppeteerConfig` inside `services/pdf/`) |

Classify by **folder first, filename suffix second** — a same-folder `require("./ledger.service")` is a Service, `require("./base.channel")` is an Integration.

```js
// Third-party
const express = require("express");

// Config
const { pool } = require("../config/db");
const { AUTO_GENERATE_INSTRUMENT } = require("../config/flags");

// Constants
const { JOB_TYPE } = require("../constants/events.constants");
const {
  PAYMENT_SOURCE_TYPE,
  INSTALLMENT_STATUS,
  BANK_REQUEST_STATUS,
} = require("../constants/payment.constants");

// Utils
const money = require("../utils/money.utils");
const { withRetry } = require("../utils/retry.utils");

// Repositories
const dealRepo = require("../repository/deal.repo");
const paymentRepo = require("../repository/payment.repo");

// Integrations
const { getAdapter } = require("../gateways");

// Services
const ledgerService = require("./ledger.service");
```

#### Carve-outs (do NOT sort these)

- **Side-effect imports are fences, not entries.** A bare `require("./logger/instrument")` / `require("./logger-override")` / `import "./x.css"` runs code the moment it loads, so its position is behaviour. Leave every bare import exactly where it is, and sort only the assigned statements between them. `logger/instrument.js` must stay **line 1** of `server.js` — see the payments-v2 note in Modules.
- **Test files are exempt.** `vi.mock` / `vi.hoisted` / `Module.prototype.require` stubs deliberately sit *between* imports, Vitest hoists `vi.mock`, and the mock-then-import reading order is what makes a suite legible. Regrouping there risks breaking suites for no readability gain.
- **File-header comments and `/* eslint-disable */` stay above the first group**, untouched.
- **A comment that explains a specific import moves with that import** — never delete it, and never let it become a group header (per rule 2, and per the never-remove-comments rule below). Only a bare group label is rewritten.
- **A moved `require` must still sit above its first USE — the temporal dead zone (TDZ), not cycles, is the hazard that actually bites.** A `const`/`let` read before its declaration line throws `ReferenceError: Cannot access 'X' before initialization` — it does NOT read as `undefined` the way `var` would. At module scope that kills the process during `require`, so the service simply does not boot. This has already happened here (2026-08-24): sorting moved `const { RUNTIME, TLS } = require("./config/env")` to the bottom of `payment-backend-v2/server.js` while `RUNTIME` was read at line 84, and the service died on startup. **Both gates stayed green** — `npm run lint` passed and all 1203 tests passed, because nothing in the suite requires `server.js`, so a boot-time crash there is structurally invisible to it. `no-use-before-define` (`{ functions: false, classes: false, variables: true }`) in `payment-backend-v2/eslint.config.mjs` now catches this in that package; **no other package has that guard**, so elsewhere you must check by eye that nothing above the new position reads the binding — or actually start the thing.
- **CommonJS cycles:** reordering `require`s can change how a circular dependency resolves. If a file is part of a cycle, run the suite before and after. Note that a green suite is NOT sufficient evidence for either this or the TDZ case above — entry points like `server.js` are typically not covered by any test.

## Key Rules

- **Never use string/number literals directly in logic — always define a constant and import it.** Any value with semantic meaning (a status string, an enum value, a threshold, a category name, a trip type, a role name, etc.) must be declared in a constants file (`src/constants.js` on frontend, the relevant `*.constants.js` or domain utils file on backend) and imported where used. Never write `=== "roundtrip"`, `=== "sales agent"`, `type: "multicity"` etc. inline — always `=== TRIP_TYPES.ROUNDTRIP`, `=== ROLES.SALES_AGENT`, etc. The only inline literals that are acceptable are values with no semantic meaning outside their immediate expression (array indices like `idx + 1`, CSS values like `flex: 1`, Tailwind class names).
- **Never remove existing code comments** — preserve inline, block, section header, and JSDoc comments when editing files
**`.gitkeep` only in otherwise-empty directories — keep it in sync.** A `.gitkeep` exists solely to track an empty directory in git; it's noise once the directory has real files. So: whenever a directory gains its first real file, remove that directory's `.gitkeep`. Conversely, whenever you remove a directory's last real file (or otherwise create/leave an intentionally-empty directory that must stay in git), add a `.gitkeep` to it. Rule of thumb after any add/remove: a directory should contain a `.gitkeep` **if and only if** it would otherwise be empty.
- **No unnecessary abstractions** — this is a fast-moving product; keep changes direct and minimal
- **Large controller files are normal** — `itinerary.controller.js` is 132KB+; don't try to refactor/split unless asked
- **Spelling:** The codebase uses `itenarary` (not `itinerary`) in folder/file names and route paths — match existing spelling in code, don't "fix" it
- **Never auto-run destructive, DB-mutating, or commit/push commands** — for anything that writes to a database, deletes/overwrites data, commits, or pushes, do a dry-run (or print the query/plan) and hand the exact write command back to the developer to run themselves. Commit/push only when explicitly asked. Don't assume approval in one step extends to the next.
- **Shared service functions keep defensive guards (clarifies §0.2).** §0.2's "services do zero re-validation" applies to a service function with a single controller entry point. A service function called from _multiple_ entry points (other services, jobs, scripts, webhooks) must still guard its primitive inputs — wrap each use-case in a thin service fn, and keep the guards on the shared low-level helper.
- **UI styling defaults live in the base component config, not scattered overrides** — border-radius, default sizes, variant colors, etc. belong in the `ui/` component's own config so every call-site inherits them. Don't re-specify the same style override at each usage.
- **Lead with a recommendation, then show options.** When there's a design/implementation choice, don't pick silently and don't dump a flat list — state the option you'd pick and why, then list the alternatives with their tradeoffs so a non-expert can decide.
- **Before changing any API, payload, or shared function, trace every caller/twin and report them.** When you modify an API (request/response shape, endpoint behavior), a payload builder (added/removed/renamed fields), _or any function whose logic is duplicated elsewhere_, first find **all** the places that build/consume that payload or replicate that logic — and list them back to the user as the possible places that also need changing before you edit. The duplication cuts three ways: (1) the same logic living in **both frontend and backend**, (2) **two copies within the frontend**, or (3) **two copies within the backend**. Common examples: flight payload builders exist in both `frontend/src/utils/flightUtils.js` and `backend/utils/flight.utils.js` / `backend/services/itinerary/pricing.helper.js`; and the final-price builder itself is duplicated inside the frontend (live `getFinalPrice` path) vs backend (`getFinalPrice2` path). These twins silently drift — a real bug (2026-07: multi-city PR #1053 rewrote the frontend and backend flight payload builders in the same PR but to _different_ shapes; the mismatch went unnoticed because the backend twin — `getFinalPrice2` → `search_specific_flight` — is dead code that never runs). So: never edit one copy of a paired function/builder without checking its twins and surfacing them, and flag when a twin you find is dead/unwired (it changes the risk).
- **Always use themed UI components** — Never use native HTML elements (`<button>`, `<input>`, `<select>`, etc.) in frontend code. Always use the custom components from `src/components/ui/`: `Button`/`PillButton`/`IconButton` for buttons, `Input` for inputs, `Select`/`CustomSelect` for dropdowns, `Tooltip` for tooltips, `Modal`/`DialogBox` for modals. Colors must use design tokens (`var(--...)`), never hardcoded hex/rgb. Toasts must use `showToast` from `@/lib/toast`.
- **All new modals must follow the standard modal structure** — Key rules:
  - Overlay: `fixed inset-0 bg-black/30 flex items-center justify-center z-50` (do NOT use `DialogBox`)
  - Container: `bg-white rounded-3xl overflow-hidden text-navy-black flex flex-col`
  - Header: `flex items-start justify-between p-6 pb-4 border-b` — title uses `text-h4`, close button uses `IconButton variant="gray" icon={<RxCross1 size={15} />}`
  - Body: `flex-1 p-6` with content inside
  - Footer: `min-h-16 flex flex-wrap items-center gap-3 px-4 py-2 border border-t-1 border-navy-divider` — Cancel is a `<div className="text-pink-main cursor-pointer">` (hidden while submitting), submit is `<PillButton variant="solid">`, both wrapped in `<ButtonGroup align="right" gap="md" className="ml-auto">`
  - Enter-to-submit: add a `useEffect` with `window.addEventListener("keydown", ...)` — do NOT rely on `onKeyDown` on the input alone
- **Always use mapped Tailwind typography classes** — Never use raw Tailwind font-size utilities (`text-xs`, `text-sm`, `text-base`, `text-lg`, `text-xl`, `text-2xl`, etc.) or arbitrary sizes (`text-[14px]`). Use the design-token typography classes defined in `src/index.css`. These classes bundle font-family, font-size, font-weight, and line-height from design tokens. Do not use inline `var(--type-*)` styles either — always prefer the mapped Tailwind utility class.
  - **Headings** (semibold): `text-h1` (32px), `text-h2` (24px), `text-h3` (20px), `text-h4` (16px), `text-h5` (14px)
  - **Body** (regular/medium): `text-b1` (24px), `text-b2` (20px), `text-b3` (16px), `text-b4` (14px), `text-b5` (12px) — add `-medium` suffix for weight 500 (e.g., `text-b4-medium`)
  - **Captions**: `text-c1` (16px), `text-c2` (14px), `text-c3` (12px)
  - **Labels** (medium weight): `text-l1` (16px), `text-l2` (14px), `text-l3` (12px)
  - **Tables**: `text-tbl-header` (12px), `text-tbl-body-hd` (14px bold), `text-tbl-body` (14px)
  - **Raw Tailwind → Token mapping**: `text-4xl`→`text-h1`, `text-3xl`→`text-h2`, `text-2xl`→`text-h2`/`text-b1`, `text-xl`→`text-h3`/`text-b2`, `text-lg`→`text-h4`/`text-b3`, `text-base`→`text-b3`, `text-sm`→`text-b4`, `text-xs`→`text-b5`
- **Calendar dates must use `@/utils/calendarDate` helpers, not raw `new Date()`** — Backend calendar dates (`start_date`, `end_date`, `checkin`, `checkout`, flight dates, `installment_date`, etc.) represent a day on the calendar, NOT an instant. `new Date("2026-09-16")` is parsed as **UTC midnight**, so any timezone-sensitive method (`toLocaleDateString`, `getDate`, `toISOString().slice(0,10)`) can return the previous day depending on the viewer's timezone or the hour of night in IST — silently shifting the displayed day by one.
  - **For display:** use `formatCalendarDate(dateStr, { withYear, weekday })` from `@/utils/calendarDate` — never `new Date(str).toLocaleDateString(...)`.
  - **For YYYY-MM-DD serialization back to backend:** use `toCalendarDateString(date)` — never `date.toISOString().slice(0,10)` (it can shift the day).
  - **For day arithmetic:** use `addCalendarDays(input, n)` — never `d.setDate(d.getDate() + n)` on a UTC-parsed Date.
  - **For parsing:** use `parseCalendarDate(input)` to get a local-midnight `Date`.
  - **Exception — real instants** (`created_at`, `ts`, `updated_at`, log timestamps, lock acquisitions): keep `new Date().toISOString()` / `toLocaleString` — those genuinely should shift with the viewer's timezone.
- **Flights: use `meta.tripType`, not length-based or positional checks.** A flight is `[meta, leg1, ..., legN]`. Read trip type from `meta.tripType` (`"oneway"` | `"roundtrip"` | `"multicity"`) via the shape helpers (`flightShape.utils` on backend, `flight.helpers` on frontend) — never `flight.length > 2`, `legs.length === 2`, or positional `flight[1]`/`flight[2]`. Every site that constructs flight meta must set `tripType`. Do NOT write `returnFlight` — it is a legacy field; new code must never set it.

## Mobile Responsive Design Philosophy

The product was originally desktop-only. When adapting any screen for mobile, follow these principles — they reflect decisions already baked into the responsive pages (itinerary table, edit page, versions tab, document modals, all Trip Details sub-sections).

### Layout

- **Stack vertically when space is tight, but use the full horizontal width that's available.** Prefer `justify-between` over centering — items spread across the row, not clustered in the middle.
- **Label/value rhythm**: identity/label on the LEFT, metadata/value on the RIGHT. Examples: `[Day] · [N]`, `[Logo + airline name] · [flight numbers + carrier]`, `[Location] · [N Nights]`, `[per-pax info] · [total]`.
- **Page padding** shrinks on mobile: `px-4 sm:px-6` (vs `px-6` on desktop-only pages).

### Cards & separation

- **Shadows, not gray backgrounds, not dividers.** Each item in a vertical list becomes its own white card on mobile with `bg-white rounded-xl border border-navy-divider shadow-[0_2px_10px_0_rgba(24,30,76,0.08)]`, separated by `gap-3`. On `md+` the cards collapse back to a shared container with `divide-y`. Example wrapper pattern:
  ```jsx
  // Container
  className =
    "flex flex-col gap-3 p-3 md:gap-0 md:p-0 md:divide-y md:divide-navy-divider";
  // Each item
  className =
    "bg-white rounded-xl border border-navy-divider shadow-[0_2px_10px_0_rgba(24,30,76,0.08)] md:bg-transparent md:rounded-none md:border-0 md:shadow-none overflow-hidden";
  ```
- **Outer section wrappers** that hold a list of items (AddOns/Hotels/etc.) become transparent on mobile (`max-md:bg-transparent max-md:border-0 max-md:shadow-none`) so the inner item cards don't double-up visual treatment.

### Actions

- **Action icons (Edit / Delete / Expand / Download) live in a footer strip at the bottom of each card** with a `border-t` separator and `justify-end`. Consistent across Flight, Hotel, Activity, AddOns, Documents. Pattern:
  ```jsx
  <div className="flex items-center justify-end gap-1.5 md:gap-2 px-4 md:px-5 py-2 border-t border-navy-divider">
    {/* IconButtons */}
  </div>
  ```
- **PillButtons with `display: inline-flex` inline style**: Tailwind's `hidden` can't beat inline styles, so wrap in `<div className="hidden md:block">` / `<div className="md:hidden">` instead of putting the breakpoint class on the button itself.
- **Header CTAs on mobile**: hide the text label inside the button (`<span className="hidden md:inline">…</span>`) so the button collapses to icon-only on mobile while desktop keeps the full label. For circle/bordered icon-only mobile, use `IconButton variant="gray" size="sm"` wrapped per the rule above. Do NOT use borderless `TextButton` for these (we tried — users prefer the bordered look).
- **The rail is the CRM's rail, to the pixel — change one, change both.** As of 2026-09-10 `Navbar`'s sidebar and the CRM's `app/Sidebar.tsx` are dimensionally identical by decision: 240/64px, a 48px brand block at `px-4` with a 28px mark, `px-3 py-2` nav with `gap-1`, rows at `px-3 py-2.5` with an 18px icon and a 12px gap, an 8px radius, a 1px border in **both** row states, and a 30px square collapse toggle around a 16px chevron. The collapse control shifts between the brand row (open) and the nav's first row (icon column) — that shift is deliberate and is what product asked for. **The trap when touching any of it: both apps scale the root font-size to 85% below 1400px, and every seller laptop is 1366px.** So a `rem` on one side against a `px` on the other is 15% out exactly where it is used — that is why `--rail-brand-height` and `--rail-row-radius` are px here, and why the nav icons are sized by a CSS class (`w-[1.125rem]`) rather than the `size` prop: an SVG `width`/`height` attribute does not scale, and a CSS width does.
- **A `calc()` in an arbitrary Tailwind value needs `_` where CSS needs a space.** CSS requires whitespace around `+` and `-`; a class name cannot contain one; `_` is Tailwind's escape for it. So `left-[calc(var(--a)_+_var(--b))]` — and **never** `left-[calc(var(--a)+var(--b))]`, which makes Tailwind emit **no rule at all**, not a broken one. The element silently keeps whatever that property was, nothing appears in `dist/assets/*.css`, and there is no warning anywhere. Cost an hour on the phone panel's left edge (2026-09-10); the check is `grep` the built CSS for the property.
- **Primary "create" actions** that don't fit in the mobile header become a circular FAB at `fixed bottom-[88px] right-6 z-[1002]`. **The 88px used to clear the Ozonetel call button, and as of 2026-09-10 there is nothing there to clear** — that button is a row in the sidebar rail now (`Navbar`, above the account), and the phone panel opens beside the rail on the left. The offset is kept on the existing FABs rather than moved, because several pages share it and a new gap under one of them is worse than a consistent one; a NEW FAB with nothing beneath it may sit at `bottom-6`.

### Navigation

- **Hamburger + 30Sundays logo** sit in a sticky top strip on mobile (`md:hidden sticky top-0 z-30 bg-white border-b border-navy-divider h-14`). Drawer slides in as the **full 240px sidebar with its labels** over a `bg-black/30` backdrop. Auto-close on link tap. No expand-toggle on mobile — there is nothing to expand. **It forced the icon-only 64px state until 2026-09-10**, which showed a drawer the user had just pulled open as nine unlabelled glyphs with no way to identify them: a tooltip needs a hover, and there is no hover on a phone. `railCollapsed = isMobile ? false : collapsed` in `Navbar` is the whole of it — never `isMobile ? true`.
- **Page title + subtitle** can ride right-aligned in that same strip (matched by route prefix in `Navbar.jsx`'s `mobilePageHeader`) to reclaim a whole header row for the page content.

### Section headers (every "X Details", "Hotels", "Flights", etc.)

- Header wraps cleanly so action buttons can drop to a new row instead of overflowing:
  ```jsx
  <div className="flex flex-wrap items-center justify-between gap-2">
    <div className="flex items-center gap-2 min-w-0">
      <Icon className="w-6 h-6 shrink-0" />
      <h2 className="text-h3 text-navy-black">{title}</h2>
    </div>
    <div className="flex flex-wrap items-center gap-2 ml-auto">
      {/* actions */}
    </div>
  </div>
  ```

### Specific patterns

- **Day badges** (Activity day, Hotel nights, Version number): on desktop a small vertical box on the left; on mobile a **full-width horizontal bar with two halves split by `justify-between`** — label LEFT, value RIGHT.
  ```jsx
  <div className="w-full md:w-[70px] md:h-[70px] rounded-xl border border-navy-divider overflow-hidden flex md:flex-col">
    <div className="flex-1 ... bg-navy-black">Day</div>
    <div className="flex-1 ... bg-white">{n}</div>
  </div>
  ```
- **Copy-icon-after-text**: when an action follows a wrappable text (activity name, hotel name), render it as `inline-flex align-middle ml-1` inside a regular div (NOT inside a flex container), so the icon wraps with the last word of the text instead of getting its own line.
- **Price-section split** on mobile: smaller info (per-pax breakdown) LEFT, primary value (total, provider) RIGHT, with a `border-t` above to read as a card footer. Total price size: `text-h4` on mobile, `text-h3` on desktop (matches across Hotel / Flight / AddOns).
- **Info-dense tables** (itinerary list, etc.) convert to **stacked cards** on mobile with the most important info up top and actions in the footer. Never settle for horizontal scroll if a reflow is possible.
- **Modals**: full-screen sheet on mobile (`w-full h-full rounded-none`), centered fixed-size card on desktop (`md:w-[840px] md:h-[640px] md:rounded-3xl`). Two-pane modals stack their panes vertically on mobile (`flex-col md:flex-row`, `border-r` becomes `border-b`).

### Typography

- **Match font sizes across analogous elements**. Hotel total = Flight total = AddOn total = `text-h4` on mobile (`md:text-h3` on desktop).
- **Don't shrink to unreadability.** CSS `zoom` was tried as a band-aid; it's only acceptable as a temporary measure for sections that haven't been given a real responsive pass (currently HotelQuotesSection). Always prefer true reflow.
- **Day-badge / "Modified by NAME" type metadata**: keep mobile-side rows at `text-b4-medium` or larger so they remain scannable; don't drop to `text-b5` just because there's vertical room.

### When to render a separate mobile markup vs reflow

- **Reflow** (preferred) when the same children can flow into a different shape via `flex-col md:flex-row`, `md:contents`, `flex-wrap`, `order-*`, etc. — one tree, two layouts.
- **Render twice (`md:hidden` / `hidden md:flex`)** when desktop has compound chips (e.g. "Modified by NAME · DATE") that need to split into separate rows on mobile, or when a button has both a text version (desktop) and an icon-only version (mobile) and trying to share would conflict with PillButton's inline styles. Duplicate the small JSX subtree; don't try to be too clever.

### Repeating form line-items (search modals, wizard steps) → card per row

Whenever a screen renders a **list of editable rows** with a shared column-header row (Flight/Hotel search modals, the itinerary-composer Flights/Hotels steps), the column headers stack into a useless block on mobile and the inputs lose their labels. Two canonical treatments — pick based on whether the fields are antd `Form.List`-bound:

- **Controlled-state rows (NOT antd Form.Item-bound)** — e.g. `FlightSearchModal/FlightSearchLineItem.jsx` (the reference implementation). Render twice: a `md:hidden` **card per row** + a `hidden md:block` antd `Row/Col`. The mobile card is `bg-white rounded-xl border border-navy-divider shadow-[0_2px_10px_0_rgba(24,30,76,0.08)]` with a navy header strip (`bg-navy-bg border-b rounded-t-xl` — section label + status + optional drag grip), a `flex flex-col gap-3 px-4 py-3` body where **every field is full-width with its own label**, and a `border-t justify-end` footer for the action icons. Desktop keeps labels on the first row only (`labelsVisible = index === 0`). Duplicating the field markup is safe here because the inputs are driven by `handleChange`, not a form field registry.
- **antd `Form.List`-bound rows** — e.g. the composer `Steps/Flights/Flights.jsx` and `Steps/Hotels/Hotels.jsx`. **Do NOT duplicate the markup** — two `<Form.Item name=...>` with the same name double-register the field and corrupt values. Instead use ONE tree:
  1. Hide the standalone column-header `<Row>` on mobile (`className="!hidden md:!flex"`).
  2. Each field `<Col>` is already `xs={24}` (full-width stacked) — add a `<Text strong className="md:hidden …">Label</Text>` above (or inline before) each field so it's labelled on mobile.
  3. Wrap each repeating `<Row>` (one per flight/hotel) in a card shell that only paints on mobile: `className="max-md:bg-white max-md:rounded-xl max-md:border max-md:border-navy-divider max-md:shadow-[0_2px_10px_0_rgba(24,30,76,0.08)] max-md:!mx-0 max-md:p-3"` (the `!mx-0` neutralises antd's gutter negative margin) so rows read as separated cards on mobile and collapse to plain rows on desktop.
  4. **Give each card a header strip** (mobile only) like the search modals' "Flight N" / "Hotel N" bar: a first `<Col xs={24} className="md:hidden !p-0">` whose inner div bleeds to the card edges — `className="-mx-3 -mt-3 mb-3 px-4 py-2 bg-navy-bg border-b border-navy-divider rounded-t-xl"` (the `!p-0` on the Col + `!mx-0` on the Row let `-mx-3`/`-mt-3` cancel the card's `p-3` exactly so the strip reaches the border).
  5. **The action column (Settings / Duplicate / Delete / flags) must become a footer strip at the bottom of the card on mobile — never left inline** — same rule as the rest of the app: `className="… max-md:justify-end max-md:border-t max-md:border-navy-divider max-md:pt-2 max-md:mt-1"` on that `<Col>`.
     Centered checkbox columns (`Booked by Guest`, `Finalize Later`) should go left-aligned with an inline label on mobile (`max-md:!text-left flex items-center gap-2 md:block` + a `md:hidden` label beside the `Checkbox`).

### Antd-specific workarounds

- **`Modal` with fixed `width`**: antd applies width via inline style, so `width={700}` ignores Tailwind breakpoints. Override with `className="max-md:!max-w-[calc(100vw-20px)]"` (the `!` is required to beat the inline style).
- **`Steps` connector lines**: the horizontal connector between steps is rendered as `::after` of `.ant-steps-item-title`. Hiding the title with `display: none` removes the connector. Use `text-transparent + w-0` to invisibly collapse the title text while keeping the element in layout, so connectors still render.
- **`Row/Col` forms**: `xs={12}` makes a 2-column layout even on phones — change to `xs={24} md={12}` so columns stack on mobile and stay side-by-side on desktop.

### Buttons & icons (refinements)

- **Toggle buttons need variant feedback**: when a toggle's text label collapses on mobile (`<span className="hidden sm:inline">…</span>`), change the _variant_ too (`outline-gray` ↔ `outline-pink`) so the active state stays visible. Pair with a `Tooltip` so hover/long-press still describes the action.
- **Distinct icons for distinct CTAs**: a bare `+` is ambiguous when two "Add X" buttons sit near each other. Pair `UserPlus` with Add Traveller, `FilePlus` with Add Document, `Trash2` with Show/Hide Deleted, etc. Pick semantically distinct icons.
- **Collapse N CTAs into a mobile dropdown**: when 3+ inline "Add via X" pills overflow on mobile, render a single PillButton on mobile that opens an antd `Dropdown` of choices, and keep the inline pills on desktop (`md:hidden` / `hidden md:flex`).

### Layout micro-patterns

- **Always-top-right absolute button**: when a button must stay in the corner regardless of how content wraps, position it `absolute top-2 right-3`. Add `pr-N` on the parent (so wrapped text never sits underneath) and `min-h-[N]` so the parent doesn't collapse to text-line height when content fits one row.
- **Currency / whitespace-nowrap**: `₹ 1,94,484.51` breaks at the space inside flex containers. Wrap prices in `<span className="whitespace-nowrap">` to prevent the symbol jumping to a new line. Same applies to phone numbers and any "symbol + value" pair.
- **Hidden dividers on wrap**: vertical pipes (`|`) and `· ` connectors look orphaned when items wrap. Mark them `hidden md:inline` so they only render at `md+`.
- **Inline-trailing icons in text** (e.g. copy after a name): render the `IconButton` inside a plain text container (not a flex container) with `align-middle` so its own `display: inline-flex` lets it flow inline with the text and wrap with the last word.

### Sticky strip and viewport height

- **Mobile navbar strip is 47.6px** — `min-h-14` (3.5rem) plus a 1px border, at the 85% root font size `index.css` applies below 1400px, so it is **not** 56px. When a page uses `min-h-screen` inside an `h-screen` overflow container, the strip eats viewport height and the bottom of the page (pagination, footer actions) ends up below the fold. Use `min-h-[calc(100dvh-3.5rem)] md:min-h-screen` for a flexible page, or `h-[calc(100dvh-3.5rem)] md:h-screen` when the page must fit exactly without scrolling (footer pinned). Subtract `3.5rem`, not a px figure — it stays correct through the font scaling.
- **`LockModal` and similar**: when placed inside a tab content area shorter than the viewport, pass `fullPage` so it uses `fixed inset-0` (viewport-relative) instead of `absolute inset-0` (parent-relative). Without it the modal centers within the small tab area, not the screen.

### Modal conventions (canonical recipe)

- Overlay: `fixed inset-0 bg-black/30 flex items-center justify-center z-50 p-2.5 md:p-0` — 10px breathing room on mobile.
- Modal: `w-full h-full md:w-[X] md:h-[Y] rounded-2xl md:rounded-3xl bg-white overflow-hidden flex flex-col` — full-screen sheet with rounded corners on mobile, centered fixed card on desktop.
- Header: `flex items-start justify-between gap-3 p-4 md:p-6 md:pb-4 border-b shrink-0` — left side `flex-1 min-w-0`, right side (close button) `shrink-0` so it never wraps off.
- **The close (✕) button must ALWAYS sit at the modal's top-right — it must never drift down.** This breaks the moment a header is allowed to stack (`flex-col md:flex-row`) with the close button living inside the actions group: on mobile the actions row drops below the title and the ✕ ends up bottom-right. So when a header stacks on mobile (or the header holds other action buttons that wrap), **pull the close button out of the header flow and pin it to the modal container**: make the modal panel `relative` and render the close as `<IconButton className="absolute top-3 right-3 z-10" …/>`, then add `pr-12 md:pr-16` to the header so its text never sits under the button. (antd `Modal`'s built-in `closeIcon` is already absolute-positioned top-right, so this only applies to hand-rolled div modals.)
- Heading inside: `text-h5 md:text-h4` (step down one level).
- Body: `flex-1 min-h-0 overflow-y-auto md:overflow-hidden` and tighten padding on mobile.
- Two-pane modals (left panel + right content): outer body `flex flex-col md:flex-row`; left panel gets `w-full md:w-[420px] max-h-[40vh] md:max-h-none` with `border-b md:border-b-0 md:border-r`; right panel `flex-1 min-h-0`.

### Toast/notification positioning

- Default `react-toastify` `position="bottom-right"` overlaps mobile FABs. Override with `className="max-md:!top-2 max-md:!bottom-auto max-md:!left-2 max-md:!right-2 max-md:!w-auto"` so mobile toasts pin to the top with edge margins. Keep desktop bottom-right.

### Pagination

- Numbered page buttons (especially 4-digit pages like "1018") overflow on mobile. Hide the numbered list below `sm` and show a simple `Page X of Y` text indicator between prev/next arrows. Container height also shrinks (`h-12 sm:h-[70px]`).

### Heading hierarchy step-down (rule of thumb)

- `text-h1` → `text-h2 md:text-h1`
- `text-h2` → `text-h3 md:text-h2`
- `text-h3` → `text-h4 md:text-h3`
- `text-h4` → `text-h5 md:text-h4`
- Apply across modal titles, section headings, and total-price values. Consistency makes the whole product feel "designed for mobile" rather than scaled down.

### Data tables → mobile cards (admin / config / list screens)

This is the single most-used mobile transform in the app. **Never leave a wide multi-column table to horizontal-scroll on mobile if a card reflow is possible.** Applied across UserManagement, RoleManagement, all Seller Configurations tabs (Lead Allocator, Schedule, AD ID Override, Category Division), all OPS Owner Assignment tabs (OPS Allocator, Call Time Slots), ActivitiesModal, AddOnsModal, ActivityJobs.

- **Keep the existing table; don't rewrite it.** Wrap the `<Table>` (antd or custom) in `<div className="hidden md:block">` and add a sibling `<div className="md:hidden space-y-2">` that maps the same `data`/rows into cards. Reuse the existing handlers/column-render data — don't invent new fields or state.
- **Card shell:** `bg-white rounded-xl border border-navy-divider shadow-sm p-3`.
- **Card anatomy:** most-important field as heading (`font-medium text-navy-black` or `text-h5`); a status/type chip top-right (`inline-flex items-center px-2 py-0.5 rounded-full text-b5 font-medium` with `bg-pink-bg text-pink-main`, or green/red for active/inactive); a compact `grid grid-cols-2 gap-x-3 gap-y-1 text-b5 text-secondary` for the remaining `Label: value` pairs (only render rows that have a value — keeps sparse cards short); a footer `flex items-center justify-end gap-2 pt-2 border-t border-navy-divider` holding the row's action `IconButton`s. Gate the footer behind the same permission flag the desktop actions use.
- **Action icon sizing (canonical):** Edit `<Edit2 className="w-3.5 h-3.5" />` (gray), Delete `<DeleteOutlined style={{ fontSize: 14 }} />` (red), Save `<Check className="w-3.5 h-3.5" />`, Cancel `<X className="w-3.5 h-3.5" />`, all `IconButton size="sm"`. Matches the flight-search row actions.
- **Excel download/upload buttons stay visible on mobile too** — shorten labels ("Download Users Excel" → "Download Excel") and add a leading `Download`/`Upload` lucide icon at `size={14}`, `size="sm"` so they stay compact, but don't hide them behind a `md:` breakpoint.
- **Clear-filters is desktop-only when filters live in the desktop table's column headers** — there's no filter surface on the mobile cards, so the button would do nothing. Hide it.

### Editable cards (inline-edit tables)

When a table row supports inline editing, the mobile card must branch on edit state — **do not reuse the display layout for inputs.**

- `{isRowEditing ? (<stacked edit form>) : (<display card>)}`. The display layout (heading-left / chip-right via `flex-1 min-w-0` + `shrink-0`) **collapses inputs** — long values wrap char-by-char and a native `<input type="time">` shrinks to just its clock icon.
- Edit form: render each editable field as a labelled, full-width `EditableCell` stacked vertically (or in a `grid grid-cols-2 gap-3` with each cell `min-w-0` for paired short fields like time-start/time-end or numeric capacities). Keep the same fields read-only that the desktop `renderCell`'s `isEditing` condition excludes (e.g. Seller / Total / CRM_ID / AD_ID).
- Inline add-row forms built as a `<tr>` (or a fixed-width flex row) overflow on mobile. Give the component a `mobile` prop that returns a stacked `<div>` card with labelled inputs + Save/Cancel `IconButton`s instead of the table row. For add-a-value inputs, make the text input `flex-1 min-w-0` and the container `w-full md:max-w-md` so it doesn't push the buttons off-screen.

### Horizontal tab / sub-nav strips

For top-of-page nav strips (Users & Permissions, Database) and in-page tab pills (Seller Configurations, OPS Owner Assignment): **keep them horizontal on mobile — do not collapse to a hamburger/accordion.** Make the strip itself scroll.

- Strip: `flex … overflow-x-auto overflow-y-hidden scrollbar-hide shrink-0` so it scrolls within its own container without nudging the page's horizontal scroll (the page wrapper stays `overflow-hidden` / `overflow-x-hidden`).
- Each tab/pill: `whitespace-nowrap shrink-0`, smaller font + padding on mobile (`text-b5 md:text-b4-medium`, `px-3 md:px-5 py-3 md:py-4`); icons `text-b4 md:text-b3`. Section title in the strip: `text-h5 md:text-h4`, `whitespace-nowrap shrink-0`.

### Single-item "journey tab" strip

When a multi-tab journey strip (flight sectors, hotel destinations) has only one tab, it otherwise renders as a stubby pill on the left with dead white space. Stretch it full-width with centered text: wrapper `flex-1 min-w-0`, tab `w-full`, and `justify-center` on the tab's content row (multi-tab keeps the scrollable `min-w-max` / `shrink-0` layout).

### Custom div-overlay modals need visible separation

Many modals in this app are hand-rolled `absolute/fixed inset-0` overlays (not antd `Modal`). The default faint overlay (`bg-navy-divider/60`) makes a white panel "merge" into a white page. Fix: overlay `bg-black/40`, panel `border border-navy-divider shadow-[0_20px_60px_-10px_rgba(24,30,76,0.35)]`. Use this same panel shadow recipe for any new custom modal.

### Icon-only Select trigger on mobile

To collapse a labelled `Select` (antd-backed) to a 40×40 icon button on mobile (e.g. Location/Type filters in ActivitiesModal): wrap in a `relative w-10 h-10` box, hide the selection display + arrow + clear via arbitrary selectors (`[&_.ant-select-selection-overflow]:!hidden [&_.ant-select-selection-item]:!hidden [&_.ant-select-selection-placeholder]:!hidden [&_.ant-select-arrow]:!hidden [&_.ant-select-clear]:!hidden`), force the selector round (`[&_.ant-select-selector]:!rounded-full [&_.ant-select-selector]:!justify-center`), and overlay the icon with `<div className="absolute inset-0 flex items-center justify-center pointer-events-none z-[1]">` (the flex-center wrapper beats the lucide MapPin/Tag visual-center offset; `pointer-events-none` lets taps fall through to the Select). Set `popupMatchSelectWidth={false}` + `dropdownStyle={{ minWidth: 240 }}` so options stay full-width. Signal an active filter by **tinting the icon** (`text-pink-main`), not a floating dot.

### Search-input expand-on-focus

In a toolbar where a search field shares a row with filter icons / buttons (ItineraryTable, ActivitiesModal): put the row in `flex flex-wrap` and the search wrapper in `flex-1 min-w-0 focus-within:basis-full md:focus-within:basis-auto transition-[flex-basis] duration-200`. Focusing the input expands it to the full row, pushing siblings to the next line; desktop stays inline.

### Status-pill row that must stay on one line

To fit N filter/status pills (All / Planning / Booked / Completed) on a single mobile row, wrap each pill in a `flex-1` div and stretch the inner button: container `[&>div]:flex-1 md:[&>div]:flex-initial [&>div>button]:w-full md:[&>div>button]:w-auto`. (PillButton's outer `<button>` accepts width classes even though its inline `display` doesn't yield to `hidden`.)

### Uniform button grid

A wrapping row of auto-width pills looks ragged. For a tidy grid (e.g. Update-from-Sheet destination buttons): `grid grid-cols-2 gap-2 md:flex md:flex-wrap md:gap-3`, each pill `!w-full md:!w-auto min-w-0 justify-center md:justify-start`, leading icon `shrink-0` (and shrink it — e.g. `size={14}`), label wrapped in `<span className="truncate">` so long names ellipsize instead of overflowing.

### Hardcoded SVG icons

The custom `Icons.jsx` SVGs are often hardcoded to 24×24 with no props. When you need one smaller in a compact context, add `({ size = 24, className })` (defaulting to the current size so existing call-sites are untouched) rather than wrapping/scaling.

### The PillButton `hidden` gotcha (reiterated — bites often)

`PillButton` sets `display: inline-flex` via inline style, which **beats Tailwind's `hidden`**. `className="hidden md:inline-flex"` on a PillButton does nothing. Always wrap it: `<div className="hidden md:block"><PillButton …/></div>`. Plain `<div>` wrappers and `IconButton` are unaffected.

### antd Card body padding on mobile

`<Card>` defaults to generous body padding. Tighten on mobile with `className="max-md:[&_.ant-card-body]:!p-3"`.

### iOS Safari / WebKit — scroll rules learned the hard way

Full investigation record in `itenarary_creator/docs/ios-scroll-fix.md` (root causes, the disproved theories, and the on-device tooling). **Read it before touching anything that scrolls on mobile.** The four rules that matter:

- **An always-mounted overlay must be hidden with `visibility: hidden` or unmounted — never with `opacity: 0` / `pointer-events: none` alone.** On iOS, WebKit routes pan gestures in the UI process over the view/layer tree, and UIKit's hit-testing does **NOT** consult CSS `pointer-events` or `opacity`. An invisible-but-present overlay therefore silently eats every drag that starts over it, wherever it sits. This cost days: `OzonetelWidget`'s closed call popup (`z-[1001]`, holds an `<iframe>`) killed scrolling inside every modal beneath it, for admin/ops roles only, and **Chrome could never reproduce it** because Chrome honours `pointer-events` when hit-testing. `<iframe>` is the worst offender (each one gets its own scroll view in the UI process), but the rule applies to any hidden overlay. If a widget must stay mounted to preserve state, add `visibility: isOpen ? "visible" : "hidden"` and put `visibility 0s linear <duration>` in the transition so the fade-out still plays on close.
- **A full-height page shell must be desktop-only.** Never `style={{ height: "100vh" }}` + `overflow-hidden` with a `flex-1 overflow-auto` pane inside — on mobile that shell sits *below* the 47.6px navbar strip (`min-h-14` at the 85% root font size below 1400px, so **not** 56px), making the page taller than the screen: the document becomes a second scroller fighting the inner pane, and because the viewport resizes as Safari's URL bar animates, the shell changes height mid-gesture and iOS drops the scroll. Correct shape — desktop scrolls a pane, mobile scrolls the document:
  ```jsx
  <div className="flex flex-col w-full md:h-[100dvh] md:overflow-hidden">
    <div className="flex-1 md:overflow-auto">…</div>
  </div>
  ```
  This is what the five page shells (Accounts, Databases, Operations, Requests, Users & Permissions), `RequestsList` and `ItineraryView` all use. A nested `overflow-auto` pane on mobile is both unnecessary and harmful.
- **`html, body` must stay `height: auto; min-height: 100%`** — the override in `index.css`. antd's `reset.css` ships `html, body { height: 100% }`, and **iOS derives the document's scrollable range from the root's declared height**, so a hard `height` makes anything taller than one viewport unreachable (this is why the login page would not scroll at all). The override wins only because `antd-*.css` is a manual chunk linked *before* `index-*.css` — re-verify that if `vite.config.js` chunking changes.
- **Never target a bare Tailwind utility class from an injected `<style>` string.** `hotelSearchStyles.js` styled `.overflow-y-auto` directly, so mounting hotel search leaked `-webkit-overflow-scrolling: touch` to **every** scroll container in the app — which on iOS hands the gesture to the document when momentum ends. Scope the selector, or put the rule in `index.css` where its blast radius is visible.

**Use `dvh`, never `vh`.** `100vh` on iOS is the viewport with the URL bar *hidden*, so a `100vh` panel is always taller than what you can actually see and its bottom sits under the browser chrome; `dvh` tracks the visible viewport and is identical to `vh` on desktop. `h-screen` and `min-h-screen` already resolve to `100dvh` — that mapping lives in `tailwind.config.js` (`theme.extend.height.screen` / `minHeight.screen`), so use the utility and it is handled. For an arbitrary value write `h-[90dvh]`, not `h-[90vh]`. `vw` is unaffected and stays as-is — only the vertical axis has a moving toolbar.

**Testing:** Chromium (puppeteer) cannot reproduce iOS hit-testing bugs at all, and **WebDriver's synthetic touch drags do not scroll anything in Safari** — a "drag didn't scroll" result there is a false negative, not a finding. Conclude from measured geometry (`clientHeight`/`scrollHeight`/computed styles), the CGEvent drag harness described in the doc, or a real device.

## Auditing Test Cases (testcases.json)

When verifying or adding entries in `test_cases_docs/dashboard/data/testcases.json`, do **not** stop at "this function does what its own code says." That misses the most expensive class of bugs in this codebase: **frontend↔backend semantic divergence on shared logic.**

Real example (2026-04-29): Activity rule engine exists on both sides — `frontend/src/utils/activityFilterRules.js` and `backend/utils/activity.utils.js` + `backend/services/activity.service.js`. Each side passed its own unit tests. But the frontend honored `rule.repeat` (Annually/Weekly), the backend did not. Result: a UI hides an activity in 2027 for an annual blackout, while backend pricing/availability ignores the rule entirely. The original audit verified each function against itself and missed it. We also found two more divergences (frontend can't split comma-separated `applicable_on_value`, frontend doesn't handle `unit_of_value === "Fixed"` surcharges).

### Required workflow when auditing rule/pricing/validation logic

1. **Identify shared-logic surfaces first.** If similar logic exists on both sides (filtering, pricing, validation, date math, normalization), treat them as a pair. Common pairs in this repo: activity filter rules, currency conversion, surcharge math, blackout checks, hotel-type compatibility, traveller validation.
2. **Diff semantics, not just lines.** For each rule field (`repeat`, `unit_of_value`, `applicable_on_value`, etc.), confirm both sides read it and behave the same way. A field that only one side checks is a gap, even if the code "works" in isolation.
3. **For every `pass` entry, ask "pass on both sides?"** If the test case describes user-facing behavior that depends on shared logic, the verification note must cite both the frontend and backend file:line. A note that only references one side is incomplete.
4. **File divergences as `[GAP]` entries.** Use the existing convention: `tags: ["GAP"]`, `baselineStatus: "gap"`, `currentStatus: "gap"`, description prefixed with `` `[GAP]` ``. Cite both file:line and explain the user-visible effect (UI mismatch, wrong price, silent ignore, etc.).
5. **When fixing a divergence, append a new history entry** to the related existing test case rather than overwriting prior `notes` — history is the audit trail.

Bias toward the backend as source of truth for billing, availability, and persistence; frontend-only enforcement is itself a gap unless the spec explicitly says otherwise.

## Databases

- **MongoDB (Mongoose):** Primary data store — itineraries, customers, deals, flights, activities, referrals
- **PostgreSQL (Aurora):** Transactional data
- **Redis:** Caching, session locking (distributed locks via `requireLock` middleware)
- **BigQuery:** Analytics warehouse, version history, data sync from PG

### Database query policy (STRICT — never violate)

- **NEVER run `INSERT` / `UPDATE` / `DELETE` (or any write/DDL) queries yourself** against any database — not even on `*_copy` / test tables. The `.env` credentials point at a real, possibly shared instance.
- **Avoid running `SELECT` queries too** in most cases — don't connect to the DB to explore data. Prefer reading the schema/usage from code (models, controllers, migrations) instead.
- **Always hand the query to the user and ask them to run it themselves.** Write the exact SQL (or script) in your response, explain what it does, and let the user execute it. Do not execute it via `node -e`, `psql`, the app's pool, or any other means.
- The only acceptable exception is when the user _explicitly_ says "run it yourself" for that specific query.

### Flight data shape in PostgreSQL (`itinerary_versioning.itinerary_table.flight_details`)

`flight_details` is a JSONB column. **Two storage formats exist** — both are valid and must be handled:

```
// Old (legacy) format — array of arrays
flight_details = [ flight, flight, ... ]

// New (current) format — object with numeric string keys
flight_details = { "0": flight, "1": flight, ... }
```

Always iterate with `Object.values(flight_details)` — works for both formats. The frontend and backend controllers both do this before passing downstream.

Each flight is always a positional array:

```
flight  = [ meta, leg, leg, ... ]          // meta at index 0, then one entry per leg
meta    = { tboPrice, totalPrice, supply_cost_inr, provider, google,
            tripType,       // "oneway"|"roundtrip"|"multicity" — source of truth
            returnFlight?,  // boolean — legacy only; DO NOT write on new saves
            ... }
leg     = [ airline, departure, arrival, total_flight_time, layover, sector, luggageArr, extraInfo? ]
          // positional array, NOT a keyed object
luggageArr = [ cabin_adult, checkin_adult, cabin_child, checkin_child ]
```

**Three data eras in the DB:**

- Case 1 — neither `tripType` nor `returnFlight` (pre-Jan 2026): infer from leg count — 1 leg → oneway, 2 → roundtrip, 3+ → multicity
- Case 2 — `returnFlight` present, no `tripType` (Jan–Jun 2026): derive — `true` → roundtrip, `false` + 1 leg → oneway, `false` + 2+ legs → multicity
- Case 3 — `tripType` present (post-Jun 2026 backfill + new saves): use `tripType` directly, ignore `returnFlight`

**Reading trip type:** always call `getTripType(meta)` / `getTripTypeFromFlight(flight)` from `flightShape.utils` (backend) or `flight.helpers` (frontend) — these handle all three eras.

## Modules

### Requests

In-app request tracking: any sales/ops/manager raises a structured request to add hotels/activities/etc to the itinerary builder. Replaces the old Google Form. Full module doc at `itenarary_creator/docs/requests-system.md`.

- **Backend:** `controllers/requests.controller.js`, `routes/requests.routes.js`, `services/requestNotification.service.js`. Mounted at `/api/requests`.
- **Frontend:** `frontend/src/components/requests/` (form + list + detail-modal + parent-tabs).
- **Storage:** PG only — `itinerary_generator.requests` keyed by firebase uid; raised-by/resolved-by display fields are joined live from `user_data_cleaned_1` (no denormalisation).
- **Hierarchy:** sales agent / ops exec see only their own; team lead sees own + their team; managers see their own department; admin/super_admin see everything. Status→`resolved` and `DELETE` are super_admin-only.
- **Email notifications:** on create, sends an HTML email via the existing `info@branceit.com` Gmail OAuth helper (`sendOnboardingEmail` in `utils.js`). Routing: agent/exec → team_lead+manager+super_admins; team_lead → manager+super_admins; manager+ → super_admins only. Suppression list in env: `REQUESTS_EMAIL_EXCLUSION_LIST` (comma-separated emails, leave empty to disable). Fire-and-forget — never blocks API response.
- **Roles use spaces** (`"sales agent"`, `"sales team lead"`, `"sales manager"`, `"ops executive"`, `"ops manager"`); only `super_admin` and `admin` use underscores.

### Payments v2 — job queue & outage resilience

The `jobs` table in `payment-backend-v2` is a transactional outbox drained by a sweeper in every PM2 process. Full design record — including every rejected option and the mid-build corrections — at `itenarary_creator/docs/payments-v2-job-resilience.md`; the user-facing summary is the `#ops-resilience` section of `payment-backend-v2/docs/index.html`. **Read the doc before changing anything in `jobs/`, `alerts/`, or `claimNext`** — most of what looks removable there is load-bearing, and the doc says why.

The five rules that are easiest to break by accident:

- **A blocked job DEFERS, it never throws.** Five throws inside ~8 minutes make a job `dead` forever, and for the three *sending* jobs (`whatsapp`, `send_request`, `decision_notify`) that is unrecoverable — re-running one is a second message to a real customer. `job.repo.defer` un-spends the claim's attempt, so a deferred job waits indefinitely. Every attempt-count and retry decision in this module splits along idempotent-vs-sending.
- **The kill-switch guard lives in `worker.runOnce`, once**, keyed off `DEPENDENCY_FOR_JOB_TYPE` — not in the handlers. A new job type either appears in that map or is deliberately absent (`link_create`/`link_cancel` already defer on `payment_sources.is_available`; a second gate would be two switches that can disagree). A test asserts every `JOB_TYPE` is accounted for.
- **`jobs.priority` is a materialized copy of `JOB_PRIORITY`, not a second source of truth.** `insert` derives it and ignores any caller value; `requeue` **recomputes** it. Do not remove that recompute — it is the only path where a dead row's priority is read again, and the row it matters for is a dead `link_cancel`, which means a gateway link is still live against an attempt we call cancelled.
- **Alert/counter state must live in Postgres, never in memory.** PM2 runs `-i max`, so four processes run the same check on the same tick; the atomic `UPDATE … RETURNING` on `alerted_at` is what makes that one WhatsApp instead of four.
- **`PAYMENT_ERROR_ALERT_WATCHERS` gates two features** (held/unmatched alerts *and* the queue-health alert). Blank means nobody is told a service is down.

Sentry was removed 2026-08-20 by directive. Telemetry is HyperDX via `logger/instrument.js`, which must stay line 1 of `server.js` and reads `HYPERDX_ENABLED` straight from `process.env` rather than `config/flags.js` — deliberately, so nothing loads unpatched ahead of it.

### Graceful restart (both `backend` and `payment-backend-v2`)

Both services drain in-flight requests on SIGINT/SIGTERM instead of dying instantly, and signal PM2 when a new worker can
actually serve. Full record — every bug found, every number and why, and the things we deliberately did NOT do — at
`itenarary_creator/docs/graceful-restart.md`. **Read it before touching either `server.js` shutdown block, the
`SHUTDOWN_*` / `BOOT_*` constants, or either `ecosystem.config.js`.**

The rules that are easiest to break by accident:

- **NOTHING outside `server.js` may register a `process.on("SIGINT"/"SIGTERM")` handler.** Node runs signal listeners in
  REGISTRATION order and `process.exit()` never returns, so a listener in a module that loads earlier silently deletes
  the whole graceful shutdown. `controllers/sse.controller.js` did exactly this until 2026-09-04 — lint was clean and
  every test passed, because nothing can load `server.js` in a test. A test in each package now scans the sources for it.
  Teardown belongs in `server.js`'s `shutdown()`, not in the module that owns the resource.
- **`SHUTDOWN_FORCE_EXIT_MS` and `SHUTDOWN_PM2_KILL_TIMEOUT_MS` are DERIVED from the step constants — never hand-tune
  them.** Change a step (drain, job wait, teardown) and the ceilings follow, `ecosystem.config.js` included. Declaration
  order is load-bearing: a new step goes ABOVE the derived block, or the derived `const` reads it before initialization
  and the service does not boot (the TDZ failure from 2026-08-24, which both gates missed).
- **`wait_ready: true` and `process.send("ready")` are a PAIR, and the signal must come from the LISTEN CALLBACK.**
  The flag without the signal is worse than neither — PM2 waits out the full `listen_timeout` on every worker of every
  reload. And because `server.listen()` is async, signalling after the listen *call* claims we can serve while the bind
  is still outstanding: PM2 retires the old worker on that signal, so a bind that then fails (EADDRINUSE, EACCES) has
  already killed its own predecessor. A test in each package asserts both the pairing and the placement.
- **Nothing may be `await`ed ahead of `server.close()`.** It is the call that refuses new connections, and it resolves
  only once every in-flight request is done — so `await something(); await drainServer();` is time the worker spends
  still accepting traffic after it was told to die. Kick the drain, do the rest concurrently, await it last. Both
  services had this backwards for their stream teardown; v2's was also uncapped, so a wedged pg LISTEN socket meant the
  drain never started at all (`docs/graceful-restart.md` §3.8).
- **Cap every teardown that awaits a socket.** An unresponsive Redis or Postgres connection does not *reject* — it
  never answers. `SHUTDOWN_SSE_CLEANUP_MS` / `SHUTDOWN_STREAM_STOP_MS` exist for that, and losing such a teardown costs
  nothing because the exit closes the socket regardless.
- **PM2 settings live in `ecosystem.config.js`, not in the `prod`/`dev` npm scripts.** As a CLI flag, `kill_timeout` is
  lost by any `pm2 start server.js` typed by hand or any `pm2 resurrect` from an older dump — and at PM2's 1600ms default
  the entire drain is dead code, silently.
- **Deploy with `pm2 reload`, never `restart`** — reload retires workers one at a time; restart kills them all at once.
- **A changed `ecosystem.config.js` only takes effect if you pass PM2 the FILE**: `pm2 reload ecosystem.config.js
  --only <app>`, then `pm2 save`. `pm2 restart/reload <name>` replays the STORED config and silently keeps the old
  values — no error, `kill_timeout` just stays at PM2's 1600ms default and the drain is dead code again. `--only` is
  mandatory: each file declares two apps, and without it PM2 starts the other one too. Verify with `pm2 jlist`
  (`pm2 describe` does not print `kill_timeout`).

### HDFC SmartGateway — the second online gateway

`payment-backend-v2` runs Razorpay and HDFC SmartGateway (Juspay) side by side; agents pick, and a rollout dial decides
what a new plan DEFAULTS to. Full record — including what HDFC's real payloads settled and the decisions that reverse
the original plan — at `itenarary_creator/docs/hdfc-smartgateway-integration.md`. **Read §14–§22 before touching
`gateways/hdfc/`, `verify_first`, `rollout_percent` or the browser-return route.**

Not live: migrations `0029`–`0031` are written and **unrun**, so the source is still `inactive` and nothing routes
through it.

The rules that are easiest to break by accident:

- **HDFC's money fields are the MIRROR IMAGE of Razorpay's.** Razorpay reports a `fee` it DEDUCTS, so its net is
  `charged − fee`. HDFC reports no merchant fee at all; its `surcharge_amount`/`tax_amount` are a convenience fee
  ADDED to what the payer owes, and `net_amount` is net of OFFERS, not of MDR. Book `order.amount` — the base — and
  nothing else. `txn_amount` and `effective_amount` are payer-side totals and are the traps.
- **The match key is OUR `order_id` (`SUN…`), not HDFC's `ordeh_…`.** Both of HDFC's outbound endpoints
  (`GET /orders/{order_id}`, `POST /merchants/{mid}/order/{order_id}/cancel`) are keyed on the id WE supply, so
  storing theirs would 404 every cancel and every status probe. The webhook matches on `content.order.order_id`.
- **`metadata.expiryInMins` must be sent on EVERY session.** SmartGateway's default order expiry is **15 minutes**
  (measured), and we WhatsApp links that are paid days later. There is also no expiry webhook and no expired order
  status, so a lapsed link reads `active` for ever — the migration-0016 bug, accepted knowingly and made small by a
  long expiry.
- **`return_url` must point at our own `/api/payments/return/hdfc`, never the marketing site.** HDFC POSTs its
  response there and the site answers **405** to a POST, so every payer landed on a raw error page seconds after being
  charged. It is also FROZEN onto each order at creation — changing the env fixes the next link, never an existing one.
- **HDFC does not sign the webhook body.** Basic auth authenticates the SENDER, not the PAYLOAD, so `verify_first`
  (dual inquiry — confirm the payment against the Order Status API before crediting) is what stands in for the missing
  signature. Razorpay is deliberately exempt: it signs.
- **Dual inquiry's re-probe loop is load-bearing, not a stray retry.** The webhook comes off the gateway's WRITE side
  and the probe hits its READ side, so a replica a beat behind reports a real capture as missing or uncaptured — the
  shape of a refusal. `VERIFY_LAG_PROBES` re-asks those two readings; an amount mismatch is refused on the first
  answer because a captured amount is settled. It must stay INLINE: `processEvent` records nothing when it throws, so
  relying on the gateway's redelivery instead means no `webhook_events` row and no alert while it retries, and nothing
  at all once it stops. Deleting the loop silently returns to refusing real money on ordinary lag.
- **`event_type = 'hdfc.order_succeeded'` on a capture means the host is running an OLD BUILD.** The current parser
  writes `payment_link.paid`. That one column tells a stale deploy from a parser bug in a second.

### Itinerary Composer — SIS destination slugs and the recommendation service

The Python recommendation service does not index every destination slug the app uses. `mauritius_sis` returns no
matches; `maldives_sis` resolves fine. PR #1274 (Sep 2026) papered over this for flights with
`REC_DESTINATION_ALIASES` in `backend/constants/itineraryComposer.constants.js` (`mauritius_sis` → `mauritius` — same
island, same airport, so the suggested sectors are identical). The alias applies **only** to the flight-recommendation
payload; hotels, pricing and persistence keep the original SIS slug.

The two things that are easy to get wrong here:

- **The fix has two halves that must move together.** The backend alias above, and `flightRoute: ["Mauritius"]` in
  `SPECIAL_DESTINATION_CONFIG` (`frontend/src/utils/itineraryComposerUtils.js`) — the rec API **rejects an empty route
  list for every destination except Maldives**, so a flow with no Routes step cannot ask for flights without one.
  `flightRoute` is deliberately separate from `defaultRoute`: it is used only to ask for flights, never seeded into
  Hotels, because a SIS flow is quotation-based and has no Hotels step. Adding a future `*_sis` destination needs
  both halves; neither file cross-references the other.
- **Only the flights call is aliased — `getTopRecRoutes` and `getTopRecActivitiesService` still send the raw slug.**
  For `mauritius_sis` that makes `getQuickPlan` resolve `routeToUse = routes[0]?.route?.items` to `undefined` and then
  throw inside `addDatesToRoutes(undefined, …)`. **This is a known, deliberately deferred gap (decided 2026-09-21) —
  do not re-raise it as a bug.** Nothing reaches it today: the Quick Plan button is gated on
  `flowHasStep(specialConfig, STEP.ROUTES)` (`StepsContainer.jsx`), so it never renders for a SIS flow, and
  `/generate-pdf-from-recommendation`, which could reach it, is not called with a SIS slug. If either path is ever
  opened to `mauritius_sis` or a new `*_sis` slug, fix this first — alias in those two service functions too, or
  guard `routeToUse` before `addDatesToRoutes`.

## Deployment

- **CI/CD:** Jenkinsfile.development — builds and deploys to EC2 (ap-south-1)
- **Process manager:** PM2 for both frontend (preview on 4173) and backend (dev on 3001)
- **Python services:** Dockerized with uvicorn, SSL support
- **Health checks:** Curl-based in Jenkins pipeline

## Key Integrations

- Freshsales CRM (leads, deals, webhooks)
- Firebase Auth + Analytics
- AWS S3, Secrets Manager
- Google BigQuery, Sheets (gspread), Cloud Storage
- OpenAI APIs
- Payment gateway APIs

## Common Commands

```bash
# Frontend
cd itenarary_creator/frontend && npm run dev     # Vite dev server
cd itenarary_creator/frontend && npm run build   # Production build

# Backend
cd itenarary_creator/backend && npm start        # Nodemon dev
cd itenarary_creator/backend && npm run prod     # PM2 production

# Lint
cd itenarary_creator/backend && npm run lint
```

## Reviewing GitHub PRs (private repo, no gh auth)

The repo is private but git credentials are saved in macOS keychain. Use this method:

```bash
# Get token from keychain via git credential helper
TOKEN=$(echo "url=https://github.com" | git credential fill 2>/dev/null | grep password | cut -d= -f2)

# Fetch PR diff (repo: apunjani/couple_trails_itinerary_builder)
curl -sL -H "Authorization: token $TOKEN" -H "Accept: application/vnd.github.v3.diff" \
  "https://api.github.com/repos/apunjani/couple_trails_itinerary_builder/pulls/{PR_NUMBER}" \
  > /tmp/pr{PR_NUMBER}.diff

# List changed files
curl -sL -H "Authorization: token $TOKEN" \
  "https://api.github.com/repos/apunjani/couple_trails_itinerary_builder/pulls/{PR_NUMBER}/files" \
  | grep '"filename"'
```

Read the diff in chunks (limit 500 lines at a time) due to size. Review ONLY the changed files listed.

### Posting a PR review (ALWAYS do both — every PR review)

When asked to review a PR, don't stop at printing the review in chat — **post it to GitHub as two things**, using the same keychain token:

1. **A top-level summary review comment** — overview, "what's correct", the full findings list (each tagged `[High]`/`[Medium]`/`[Low]`), and a verdict. Post via the issue-comments endpoint:

   ```bash
   TOKEN=$(echo "url=https://github.com" | git credential fill 2>/dev/null | grep password | cut -d= -f2)
   # Build the body in a file, then:
   python3 -c "import json; print(json.dumps({'body': open('/tmp/review.md').read()}))" > /tmp/review.json
   curl -sL -X POST -H "Authorization: token $TOKEN" -H "Accept: application/vnd.github.v3+json" \
     "https://api.github.com/repos/apunjani/couple_trails_itinerary_builder/issues/{PR_NUMBER}/comments" \
     -d @/tmp/review.json
   ```

2. **Inline code comments on the exact lines that have an issue** — one per finding of any severity (High/Medium/Low). Each inline comment repeats the `[Severity]` tag and the specific issue. Post them together as ONE review via the reviews endpoint (`event: "COMMENT"`), anchored to the PR head SHA:

   ```bash
   # Get head SHA:
   curl -sL -H "Authorization: token $TOKEN" \
     "https://api.github.com/repos/apunjani/couple_trails_itinerary_builder/pulls/{PR_NUMBER}" \
     | python3 -c "import sys,json; print(json.load(sys.stdin)['head']['sha'])"
   # Then POST { commit_id, event:"COMMENT", body, comments:[{path, line, side:"RIGHT", body}, ...] }
   # to .../pulls/{PR_NUMBER}/reviews  (build the JSON with python3, post the file with curl -d @file).
   ```

**Rules:**

- **Only comment inline where there's an actual issue** (correctness, risk, convention, perf, security, test gap) — do NOT annotate lines that are fine. The summary carries the praise; inline comments carry the problems.
- `line` = the line number in the **new file** (`side: "RIGHT"`); it must be a line that appears in the diff (added or context). Derive it from the diff hunk headers (`@@ -old +new @@`).
- Prefer `python3` to build the JSON payloads (correct escaping), write to `/tmp/*.json`, and post the file with `curl -d @file`. **Do NOT use Python's `urllib`/`requests` to hit GitHub — it fails with `CERTIFICATE_VERIFY_FAILED` in this environment. Always POST with `curl`.**
- The inline-review's own `body` should be a one-liner pointing back to the summary comment (don't duplicate the whole review there).
