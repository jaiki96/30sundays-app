# Trailix — agent guardrails

## Google Places API — hard rules

**This is the most expensive third-party dependency in the app. Do not soften any of these rules without product sign-off.**

1. **Enrich is admin-only EXCEPT for hotels** (hotels exception added 2026-06-26 with product cost sign-off). `/api/places/enrich` and `/api/places/bulk-enrich` are gated by `isAdmin(session.roleId)` for activities / restaurants / shopping. For `entityType === "hotel"` they are allowed for editors with `hasPermission(roleId, "hotels", "write")` — product wanted editors to run the full hotel Places workflow (attach Place, enrich, photos) without bouncing through an admin, and accepted the cost. `/api/places/lookup-by-id` (cache-first Place preview, used by the hotel add-wizard) is likewise open to hotels/activities editors. Do NOT widen the enrich exception to other entity types, or add a new role tier, without another cost review.
   **Remap and search-candidates are editor-accessible** (lowered 2026-05-23): they use `hasPermission(roleId, "activities", "write")`. Rationale: the cache-first path is usually free, and product wanted editors to fix mis-mapped places without bouncing through an admin. The `recompute-matrix` follow-up (Routes API, billable per pair) stays `isAdmin`.

2. **No automation.** Never call `searchPlace`, `fetchAndStorePlacesPhoto`, or the enrich routes from:
   - cron jobs / scheduled tasks
   - sync workers (`SyncRun` jobs)
   - Prisma middleware or hooks
   - background queues
   - entity create / update handlers
   - any non-admin user-facing surface
   The only legitimate triggers are an admin clicking the per-entity button or admin-only bulk endpoint.

3. **Re-enrich is admin-only via `force=true`** (re-loosened 2026-05-26 after the 2026-05-23 lockout broke the Remap→refresh workflow). Once `placesEnrichedAt` is set, `/api/places/enrich` refuses with 409 unless the caller is admin AND passes `force=true`. The admin UI confirms before sending force. Bulk is still enrich-missing-only — never sends force. To switch to a different Place, prefer `/api/places/remap` (cache-first, usually free) over re-enrich.

4. **3 photos per place, no exceptions.** `MAX_PHOTOS_PER_PLACE` in `lib/places.ts`. Each photo is a separate billable call (~$7 / 1k). Don't raise without weighing the cost.

5. **Cache is permanent.** `PlacesCache` rows keyed by `googlePlaceId` are intentionally never expired. This is a deliberate product decision that diverges from Google's TOS retention guidance — do not add a TTL or cleanup job. Photos referenced from `Media.placesPhotoName` are also kept indefinitely.

6. **Cache-first.** Both routes look up `PlacesCache` by `googlePlaceId` and reuse `photos[]` (S3 URLs) before refetching from Google. Per-photo dedup against existing `Media.placesPhotoName` for the entity. If you add a new code path that fetches photos, route it through the cache.

7. **Field mask is intentionally maximal.** Atmosphere/Enterprise fields are billed per request, but product chose to keep all fields. Do not slim the mask without a product decision — this is a known trade-off, not an oversight.

## Public API — list/detail parity

Every public list endpoint (`/api/public/<resource>`) must expose the same scalar fields as its matching detail endpoint (`/api/public/<resource>/{id}`). The only allowed delta is heavy nested arrays (`rooms`, `activities`, `offerings`, `documents`, `usedInTours`) which stay detail-only because they balloon list payloads.

To enforce this:
1. **Single source of truth per resource.** Keep one `<RESOURCE>_SCALAR_SELECT` and one `serialize<Resource>Scalars` in `lib/public-<resource>-shape.ts`. Both list and detail spread from these. Adding a column means editing one place.
2. **No ad-hoc `LIST_SELECT` next to a different `DETAIL_SELECT`.** That's how drift happens.
3. **Run `scripts/check-list-detail-parity.ts` after touching any public route.** It fetches one row from each list and the matching detail and asserts every detail key is present in the list (minus the nested-only allowlist).

If you genuinely need a list field detail doesn't have (e.g. `images_urls` on hotels), it's fine — parity only checks list-superset-of-detail-scalars, not the other direction.

## API docs — always update in the same change

The public API reference is `app/(app)/api-docs/page.tsx` (rendered at `/api-docs`). It is hand-maintained, not generated.

**Whenever any API is added, changed, or removed, update the docs in the same commit/PR — no exceptions.** This applies to every public-facing surface, not just `/api/public/*`: a new route, a new/renamed/removed query param, a changed response shape or field meaning, a new error/status, a changed default or cap, a changed auth scope. If you touch the contract, you touch `api-docs/page.tsx` in the same change.

For each affected endpoint keep these in sync: the `summary`, the `query` param list (name + desc), the `scope`, and the `sample` response JSON. Treat a contract change with no accompanying docs edit as an incomplete change — call it out and fix it before opening the PR.

## Other

- DB schema is pushed via `prisma db push --accept-data-loss --skip-generate` in CI (`.github/workflows/deploy.yml`). There is no `prisma/migrations/` directory — schema is the source of truth.
- Trailix moved from EC2-local Postgres to AWS RDS on 2026-04-24. The local PG on EC2 is kept as a rollback. Be careful with destructive schema changes.

## Catalog sync removed 2026-05-26

Trailix is now the **single source of truth** for Tours, Activities, Restaurants, Shopping Places, Hotels. No external CATALOG sync runs anywhere — the entry scripts, the GHA workflow, the SyncButton component and the `/api/sync/{tours,activities,day-combos}` routes have all been moved under `tmp/_disabled-sync-2026-05-26/`. Do not re-enable without product sign-off.

What is still allowed to read from the external source DB:
- `scripts/recompute-metrics.ts {activity|hotel|maldives|all}` — read-only aggregation of live booking outcomes into `UsageMetric`. Runs nightly via cron. Never writes catalog data.
- `/api/sync/runs` — read-only history endpoint for the legacy SyncRun table. No new rows are created by app code.

If you ever need to import a single missing tour / activity / hotel manually, do it through Prisma directly (or temporarily un-archive the relevant `lib/sync/*` module under `tmp/`). Never reintroduce a periodic sync.
