---
name: 30sundays-analytics
description: Reference guide for 30 Sundays app analytics system — events, schema, Metabase dashboards, and recommended metrics
---

# 30 Sundays App Analytics Reference

## Architecture

```
Flutter App --> AnalyticsService (lib/core/analytics/)
                  |-- FirebaseAdapter --> Firebase Analytics (GA4)
                  |-- BackendAdapter  --> POST /logs/fire --> MongoDB (app_clickup_logs)
                  |                                              |
                  |                                              v
                  |                                        Metabase Dashboards
                  +-- [MoEngageAdapter] (planned)
```

- **Skip logic**: Events NOT tracked on web, non-release, non-production, seller/internal users, test phone 8750465800
- **Riverpod provider**: `ref.read(analyticsService).track(...)`
- **Auto-enriched**: Every event gets `customer_id` + `screen_name`
- **Trip context**: Use `trackWithTripCtx()` to add `trip_deal_id`, `trip_version_id`, `trip_status`, `is_converted`

## MongoDB Schema: `app_clickup_logs`

| Field | Type | Description |
|-------|------|-------------|
| `screen_name` | String (indexed) | Screen where event fired |
| `screen_id` | String | Numeric screen identifier |
| `user_id` | String (required, indexed) | Customer ID — join key to `customers` and `customer_deals_infos` |
| `timestamp` | Date (required, indexed) | Event timestamp |
| `event_type` | String (required, indexed) | `login`, `logout`, `user_action`, `navigation`, `error`, `other` |
| `event_data` | Mixed | Event-specific payload. `event_data.event` = event name |
| `session_id` | Object | Session tracking (currently empty — needs fix) |
| `device_info.platform` | String | Platform (currently "unknown" — needs fix) |
| `device_info.app_version` | String | App version + build number |
| `device_info.os_version` | String | Android/iOS version |
| `device_info.device_model` | String | Device model |
| `ip_address` | String | User IP address |

**Compound indexes:**
- `{ user_id: 1, timestamp: -1 }` — User timeline
- `{ screen_name: 1, event_type: 1 }` — Screen + event analysis
- `{ user_id: 1, event_type: 1, timestamp: -1 }` — User event history

## Related Collections for Joins

| Collection | Join Key | Key Fields |
|-----------|----------|------------|
| `customers` (26 cols) | `customer_id` | name, phone, email, status, createdAt, referral_code |
| `customer_deals_infos` (69 cols) | `customer_id` | deal_id, booking_date, trip_start_date, trip_end_date, destination, departure_city, nights, is_cancelled |
| `deals_table` | `deal_id` | Deal/pricing details |

## User Segments (derived from `customer_deals_infos`)

| Segment | Definition |
|---------|-----------|
| New User | Has events but NO record in customer_deals_infos |
| Lead | Has customer_deals_infos record but booking_date IS NULL |
| Pre-Trip | booking_date NOT NULL AND trip_start_date > NOW |
| On-Trip | trip_start_date <= NOW AND trip_end_date >= NOW |
| Post-Trip | trip_end_date < NOW |

## Event Catalog (95 events)

### Tier 1 — Critical Business
`app_open`, `screen_view`, `session_start`, `session_end`, `login_success`, `logout`, `delete_account`, `otp_requested`, `otp_request_failed`, `otp_verification_failed`, `otp_resent`, `deep_link_received`, `deep_link_handled`, `notification_permission_status`

### Tier 2 — Revenue & Conversion
`payment_webview_opened`, `payment_webview_completed`, `payment_webview_failed`, `document_downloaded`, `document_download_failed`, `document_uploaded`, `document_upload_failed`, `document_deleted`, `visit_installment_confirmation_link`, `visit_installment_payment_link`

### Tier 3 — Engagement & Navigation
`chatbot_opened`, `chatbot_message`, `chatbot_suggestion_tapped`, `chatbot_new_chat_started`, `chatbot_conversation_loaded`, `chatbot_place_link_tapped`, `chatbot_speech_input_used`, `chatbot_session_duration`, `tab_switched`, `trip_tab_switched`, `trip_details_tab_switched`, `pull_to_refresh`, `notification_viewed`, `notification_tapped`, `hotel_details_viewed`, `flight_details_scrolled`, `feedback_submitted`, `feedback_reason_selected`, `view_booked_trip_details`, `view_itinerary_pdf`, `view_document`, `view_visa`, `view_forex`, `view_insurance`, `view_before_you_go`, `view_30_sundays_pass`, `view_manage_guests`, `guest_added`, `guest_removed`, `view_wallet`, `view_referral`, `copy_referral_code`, `share_referral_link`, itinerary map events (6), recommendation events (4), planned trip events (4), activity video events (4)

### Tier 4 — Seller & Error
`seller_login`, `seller_customer_searched`, `seller_shadow_login`, `api_error`, `video_playback_failed`, `app_force_update_shown`, `app_force_update_accepted`

## Metabase

- **URL**: https://metabase.30sundays.club
- **Primary dashboard**: App Analytics Dashboard (ID: 161, by Jaikishan) — DO NOT DELETE
  - User Segmentation - Trip Status Overview
  - DAU - Daily Active Users (Last 30 Days)
  - Destination Split by Segment
  - Feature Engagement - Top Events (Last 30 Days)

## Key File Locations

| What | Path |
|------|------|
| Events catalog + params | `30-sundays-app/lib/core/analytics/analytics_events.dart` |
| Analytics service | `30-sundays-app/lib/core/analytics/analytics_service.dart` |
| Firebase adapter | `30-sundays-app/lib/core/analytics/adapters/firebase_adapter.dart` |
| Backend adapter | `30-sundays-app/lib/core/analytics/adapters/backend_adapter.dart` |
| Backend API endpoint | `30-sundays-backend/src/controllers/logs.controller.js` |
| Batch processing | `30-sundays-backend/src/services/batchLogging.service.js` |
| MongoDB model | `30-sundays-backend/src/models/appClickupLogs.model.js` |
| Router observer | `30-sundays-app/lib/common/utils/app_router_observer.dart` |
| Schema docs | `30-sundays-app/docs/analytics_schema.md` |
