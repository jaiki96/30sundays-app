# PATTERNS: cross-app pattern library for 30 Sundays

Merged from the nine group reports in this folder: travel-1, travel-2, scapia-social-splash, 30sundays-audit,
banking-insurance, food-services, retail, health-mobility, edtech-jobs-realestate. Every node id is the
Figma id as written in those reports (open with the colon form). Scapia destination screens are cited by
file name (IMG_3933 to IMG_3939). Nothing here goes beyond what the reports say.

Brand board used for the rules: sunsetFuchsia #FD014F (in-app #E31B53) for the one primary action,
tropicalForest #254342, lagoonBliss #00A898 for proof, goldenHour #FDA201 for attention, coastalMist
#EAE6E3, cream grounds #FFF6E6 / #FFFBF2, navy headings #181E4C, handwriting display face, Figtree body.
House rules: no subtitles under section titles, no solid pill badges, no red or green for good or bad,
short plain copy, one fuchsia action per screen, no em dashes.

## Read this first

1. One fuchsia action per screen, never two equal primaries, never fuchsia on a destructive act: Scapia destination holds one colour on every screen (IMG_3933 to IMG_3939) and Rapido one yellow (35:63), while BookMyShow (41:437), Zomato (41:347), Pristyn (41:801) split the action and we spend fuchsia on Delete (141:79) but leave the itinerary bar empty (141:6).
2. Proof must be specific, counted and sourced: OYO "fixed in 30 min" (41:845), CARS24 "Based on 1.7K similar cars sold" (41:584), apna "94% in last 6 days" (41:871), Headout "14K+ bookings last month" (41:926) beat generic grids like ours (141:20) and stat circles (41:796).
3. Show one honest all-in price with the breakup one tap away and exclusions beside it: Ola total then line items then exclusions (35:92), Cleartrip "total with taxes & fees" plus breakup (35:104), never a struck anchor and solid % pill (2014:20) or stacked discounts (35:160, 38:207).
4. No scarcity, countdowns or viewer counts on a considered trip: "9 Seats Left" (41:901), "Selling Fast" (41:502), "04:54 min" (41:584), "103 People Viewing This" (22:41) and the Housing.com paywall (111:18) all cheapen the product.
5. Consent is opt-in and permissions are asked in context after value, in our own words first: never pre-tick (41:849, 41:507, 41:595), never chain six asks on launch (41:957, 41:958, 41:956, 41:955, 41:953, 41:954); copy BookMyShow's soft ask with recovery (41:455, 41:454) and PhonePe's in-context ask (41:408).
6. The wizard asks one thing per screen with chips, a reason line, a progress bar and a disabled Next that explains itself: apna (41:877, 41:874), CRED (22:9), Urban Company's priced estimate steps (41:559, 41:558), Spinny's stepper with editable past answers (41:890); never a form hidden in a chat (113:126).
7. Compare options in identical layouts with the difference first: Cleartrip fare cards (35:116), Paisabazaar bond cards (41:502), redBus cancellation table (113:82); never "V4 - Quotation 1" look-alike cards (141:14, 141:16).
8. The booked trip leads with status and the one pending task: Rapido live status sheet (35:63), INDmoney "only 3 steps remaining" (41:484), cult.fit mini bar (41:831); ours shows documents and add-ons as identical tiles with no status (141:13, 141:2).
9. Keep one system across every destination and tab: Zomato runs one template over 17 tabs (41:357 to 41:373), Nykaa shares one store template (41:627 to 41:630), Flipkart changes only the ground (41:727 vs 41:707); BigBasket (38:196 to 38:212) and Physics Wallah (41:524, 41:525) repaint everything and lose the brand.
10. Give every colour one job and keep recommendations editorial: no red or green for good or bad (41:947, 113:107 vs 113:108, 141:12), no solid pills (141:9, 41:251), no paid or Ad tags inside "recommended" (41:451, 41:357, 35:141).

---

## Splash

**Best examples**
1. Booking.com, 129:143 to 129:142: the wordmark shrinks into the home header, so the splash is the first frame of the app.
2. Airbnb, 129:117, 129:116, 129:115: the logo draws itself in one stroke, with nothing else on screen.
3. Cleartrip, 35:130 (129:113): brand-colour flood with a short handwritten line, "So, where to?".
4. redBus, 129:161, 129:160: motion that means something (the bus drives off), then one welcome line.
5. ixigo, 129:166 (41:959): one quiet partner seal at the bottom, proof without noise.

**Rules for 30 Sundays**
- Flat cream #FFF6E6 ground, no gradient, at least 90% empty; 12 of 13 apps sit at 89 to 100% and ours is the busiest in the set (129:164, 141:21).
- Logo only, in its own colours, drawn in three strokes (palm, the "n", the sun) in under a second; keep the whole sequence under 1.5 s on a cold start and skip it on warm starts.
- At most one line in the handwriting face, navy #181E4C, sentence case, no exclamation, neutral for any traveller.
- Hand over by moving the logo into the home header (129:142), or fade.

**Never copy**
- MakeMyTrip, 129:152 vs 129:153: the splash used as a feature ad, with "25 years" in one frame and "26 years" in the next.
- EaseMyTrip, 129:138: clip-art crowd, user count and a "Made in India" badge; reads as an ad.
- 30 Sundays today, 141:21 (92:2, 129:164): logo, couple tagline and illustration all at once, static, off-brand.

**Use on:** splash.

---

## Onboarding

**Best examples**
1. Hopper (pasted in our audit), 141:68: the illustration is the real product UI, and sign-in comes last with "Not now".
2. Physics Wallah, 41:520 then 41:519: one easy question, then real playlists and one free video, with Skip on every step.
3. Swiggy, 41:311: interest picker of photos with one word each, "Select at least 3".
4. INDmoney, 41:486: three clear doors with one-line descriptions.
5. cult.fit, 41:830: big photo choice cards, each with its own button, plus "Explore others".

**Rules for 30 Sundays**
- No welcome carousel or sign-up wall between splash and home; none of the 13 studied apps has one.
- At most three light, skippable questions (where, when, who), with a visible Skip top right (our old placement, 113:158).
- Never block an answer; if we cannot plan something yet, say what we can do in one line and keep the button live.
- Show real UI in any explainer (141:68), and offer a three-door start like "Pick a ready trip, Build your own, Talk to a planner" (41:486).
- Ask for the phone number only when saving a trip or asking for a quote.

**Never copy**
- ixigo, 41:957, 41:958, 41:956, 41:955, 41:953, 41:954: six interruptions before the first search.
- 30 Sundays earlier build, 113:158: two "We're so sorry" blocks and a greyed button stop families and groups.
- Khatabook, 41:497: four permissions at once before any value, including SMS "even when the app is not in use".

**Use on:** splash, home, wizard.

---

## Login and OTP

**Best examples**
1. PhonePe, 41:411, 41:412: reason line, OTP auto-read with a visible timer, SMS fallback, "We will create an account if you don't have one".
2. Yatra, 113:120: OTP "valid for next 15 mins", number with an edit pencil, resend countdown.
3. Tata 1mg, 41:789: after the timer, "Resend on SMS" or "Resend on call".
4. Housing.com, 111:26: phone, "Continue with WhatsApp" as the alternative, Skip top right.
5. Cleartrip, 35:128 with 35:122: login as a bottom sheet over the current page, so context is never lost; 4-box OTP with edit pencil.

**Rules for 30 Sundays**
- Phone first with +91, shown as a sheet over the current screen, only when saving a trip or asking for a quote.
- One promise for login, the same everywhere; redBus shows three different ones in one session (113:98, 113:97, 113:91).
- Always show validity, a resend timer, an edit-number link and a call or WhatsApp fallback.
- Keep a "Not now", no promo banners on the login or OTP step, and leave every consent box unticked.

**Never copy**
- Paisabazaar, 41:507: pre-ticked consent appointing them as the user's representative, plus pre-ticked WhatsApp marketing.
- PharmEasy, 35:168, 35:169: promo banner on top of login and OTP.
- redBus, 113:98, 113:97, 113:91: a different login sheet and promise for each feature.

**Use on:** wizard, itinerary, wishlist, profile.

---

## Home header

**Best examples**
1. Zepto, 35:142: the one fact that matters (delivery time) is the biggest type on the screen; for us, "Bali in 23 days".
2. Housing.com, 111:20: "Welcome back!" greeting with no clutter, followed by a revisit rail.
3. Mamaearth, 41:637: one script word ("Hey") over a bold name gives personality with a single word of type.
4. BookMyShow, 41:451: big greeting title, city link under it, search and bell on the right.
5. Headout, 41:926: full-bleed city photo with a city picker and a search card overlapping the hero.

**Rules for 30 Sundays**
- "Hi <first name>" in the handwriting face plus one status line in Figtree ("Your Maldives quotes are ready", "Bali in 12 days"), per the audit fix for 141:22.
- A search pill in the header; the status slot replaces any floating toast.
- No coin, wallet or reward pills, no bell badge counts, no sponsored slot.

**Never copy**
- 30 Sundays, 141:22: "Explore" is a tab name, not a welcome; no name, status or search.
- CRED, 41:336: glowing "unclaimed reward" pill, bell with count, micro-badges.
- 99acres, 41:262: sponsored builder banner and a coach mark on top of home, so the user's task comes second.

**Use on:** home.

---

## Search bar

**Best examples**
1. Cleartrip, 35:121, 35:109: route summary pill (place, dates, guests, edit pencil) kept on results and detail, one tap to edit.
2. BookMyShow, 41:439, 41:438: full-screen search with trending when empty, grouped suggestions with type labels, "View All Results".
3. Headout, 41:926: white search card overlapping the hero, rotating placeholder of real places.
4. upGrad, 41:551: goal chips under the search, "Or select your goal", for people who do not know what to type.
5. ixigo, 41:950, 41:952: remembers starred favourites and offers the nearest option.

**Rules for 30 Sundays**
- Never open to a blank page; show recent, popular and goal chips ("Beach and rest", "First trip abroad", "Under ₹1.5L", from 41:551).
- Rotating placeholder with real destinations; keep a summary pill on any result list.
- No ad or sponsored rows in suggestions.

**Never copy**
- Zepto, 35:141: an ad row inside autosuggest.
- Headout, 41:918: blank white screen while city results load.
- Urban Company, 41:567: focusing the field wipes the trending chips and leaves a blank page.

**Use on:** home, destination page, wishlist, community.

---

## Hero banner

**Best examples**
1. BigBasket, 38:209: "Mango of the week" with one fact chip ("Carbide free") and short witty copy.
2. PolicyBazaar, 41:467 vs 41:468: the banner updates with the user's answers; use it as a quiet live price line.
3. Ola, 35:94: one warm illustrated road-trip hero, then a rail of popular destinations.
4. Flipkart, 41:722: a seasonal takeover done with one texture and arch shapes.
5. Spinny, 41:891: an illustrated seasonal hero that adds warmth without photos.

**Rules for 30 Sundays**
- The hero sells the user's next step or a destination, never a product they did not come for (Cleartrip trains hero, 35:129).
- One fact, short copy, no celebrity, no countdown, no ad.
- Do not repeat one campaign at the top of several screens (Spinny, 41:887, 41:888, 41:891).

**Never copy**
- Cleartrip, 35:129: a trains announcement above everything, logo below it.
- PhonePe, 41:410: "Introducing SILVER" never says what Silver is.
- cult.fit, 41:831, 41:828: blank dark heroes waiting for video, with only an offer line visible.

**Use on:** home, destination page.

---

## Category tiles

**Best examples**
1. Blinkit, 41:285: bento collage of four photos with "+385 more", showing range and depth in one tile.
2. Cleartrip, 35:110: real-photo destination tiles with a serif place name and a "From Delhi" card that pages origin cities.
3. BigBasket, 38:202 and 38:198: entry by intent ("Shop by goal / diet / lifestyle") and by audience ("Shop by age").
4. Zomato, 41:356: "In the mood for" tiles group places by occasion, not type.
5. CARS24, 41:590: price band tiles ("Budget, under 7 lakhs"), the way people actually think.

**Rules for 30 Sundays**
- One tile style per screen (BigBasket's calm categories page, 38:211).
- Real photos with the place name in the display face and a count ("Bali, 14 trips").
- Offer doors by mood, budget and who is going (solo, friends, family, couple) to stay neutral.
- No offer stickers or tags on tiles, and start every rail at the gutter (141:22, 141:24).

**Never copy**
- ixigo, 41:951 and redBus, 113:90: mode tabs carrying discount stickers.
- PolicyBazaar, 41:469: a tag on every tile, so no tile stands out.
- Physics Wallah, 41:524, 41:525: tapping a mode tile repaints the whole screen.

**Use on:** home, destination page, wizard, wishlist.

---

## Card rail

**Best examples**
1. Scapia destination, IMG_3935: portrait highlight cards with verb-led captions ("Cruise Ha Long Bay, then move to a kayak").
2. Headout, 41:920: an expanded child rail of bookable variants sits under its parent item on a grey band.
3. Scapia Hotels, 2014:15: nearby rail in four plain tabs (Attractions, Restaurants, Essentials, Transport) with distances.
4. Housing.com, 111:20: "Revisit properties seen by you", a gentle return path.
5. Paytm, 41:395: recent searches rail that repeats a past search in one tap.

**Rules for 30 Sundays**
- Fixed two-line title slot and price pinned to the bottom, so text lines up across cards (audit note 141:48 on 141:22).
- Rails start at the 16 px gutter, never at the screen edge (141:24).
- Show four, then "See all"; every card editorial, never paid.

**Never copy**
- BookMyShow, 41:451: "PROMOTED" posters inside "Recommended Movies".
- Zomato, 41:357: Ad tags on almost every curated section.
- 30 Sundays, 141:24: rail starts at x = 0 and guest photos carry no name, month or trip.

**Use on:** home, destination page, itinerary, booked trip, community.

---

## Listing card

**Best examples**
1. Headout, 41:921: ranked row with a big italic numeral, rating with count, recent proof chip, two-line blurb, "from" price.
2. Swiggy Dineout, 41:309 (with Zomato 41:375): rating with count, area and km, cuisine, price for two, one offer line.
3. PharmEasy, 35:167: expert card that answers who, experience, languages, proof ("98% Happy Patients | 526 Consults"), next slot and price.
4. Spinny, 41:887: calm card with one price, one EMI line, a few grey chips and one quality mark.
5. Housing.com, 111:22: option mini cards inside one card (2 BHK, 3 BHK, each with price).

**Rules for 30 Sundays**
- Order: photo, name, rating with count, route string with nights (113:152), price per person pinned at the bottom.
- Say the unit once at the head of the list ("Price per person, flights included", from OYO 41:843).
- At most two outline chips; no solid pills, no % off.
- One action per list, not a fuchsia button on every card (141:10).
- Where to eat cards follow the audit's Indus spec: rating with count, price for two, distance from the hotel, "Open till", veg options, "Directions" as text.

**Never copy**
- BigBasket, 38:207: three prices and four tags on one card.
- OYO, 41:843: five accents, 66% off on every card, and "Couples are welcome".
- 99acres, 41:243: three equal contact buttons, a featured tag and a "View Number" lead gate.

**Use on:** home, destination page, itinerary, wishlist.

---

## Filters and sort

**Best examples**
1. redBus, 113:85: two-column sheet, counts per option, search inside long lists, live "View 307 buses".
2. Cleartrip, 35:119, 35:120: the price of each option shown inside the filter.
3. Meesho, 41:735: two-pane filter with a live "1000+ Products" count.
4. EaseMyTrip, 41:901: sort tabs that preview their top result ("CHEAPEST £584, 16h 50m").
5. Lenskart, 41:662: sticky Sort / Filter / View bar with state captions ("0 Applied").

**Rules for 30 Sundays**
- Header names what is applied and the count ("Bali trips, 12 trips"), with applied filters as removable chips (fix for 141:85).
- The Apply button carries the count ("Show 12 trips").
- Ranges never overlap (ours do at 8N, 141:11); add budget, month and style; use one pace scale everywhere.
- Each sort option gets a one-line explanation (Facebook, 2028:23).

**Never copy**
- 30 Sundays, 141:85: floating dock over content that hides what is applied.
- Meesho, 41:741, 41:740: sizes sorted as text and overlapping price ranges.
- Pepperfry, 22:49: tan Apply button that reads as disabled.

**Use on:** destination page, wishlist, community, home.

---

## Detail hero

**Best examples**
1. Scapia destination, IMG_3933: full-bleed photo that fades into the ground, display-face name, starting price, nights pill.
2. Lenskart, 41:674: photo with a two-weight overlay headline, provider line, price, rating with count.
3. Housing.com, 111:23: six "Top Highlights" in the first screen, media counter, map tile beside the name.
4. OYO, 41:839: labelled thumbnails (Entrance, Room, Lobby, Reception) and a 1/34 counter.
5. Headout, 41:925: video-first hero, then a title band with category in caps and the rating link.

**Rules for 30 Sundays**
- A place shot, not an interior with people (141:17); the first carousel image differs from the hero (141:18).
- Place name in the handwriting face; "from" price with "Flights not included" next to it, not in the FAQ (IMG_3939).
- Media counter and labelled thumbnails (Room, Pool, Breakfast, View).
- Highlights sit under the photo so the photo stays clean (the 111:23 scrim hides it).

**Never copy**
- 30 Sundays, 141:17: a spa interior with people as the Vietnam hero.
- Stanza Living, 111:33: property name repeated in the nav bar and as the H1 below it.
- cult.fit, 41:829: hero left as a blank dark area when video does not load.

**Use on:** destination page, itinerary, booked trip.

---

## Detail sections

**Best examples**
1. BookMyShow, 41:429: icon fact list (date, duration, age, language, venue) and a "You should know" tip card.
2. Scapia Hotels, 2014:17 to 2014:16, 2014:19 to 2014:18: short preview then a sheet for the long text; titles that speak to the guest ("Where you'll sleep").
3. PharmEasy, 35:160: three practical facts (prep, sample, wait) in one tinted box.
4. Scapia Hotels, 2014:5, 2014:4: Check-in / Check-out twin tiles and icon-led policy groups ("Before you reach here").
5. apna, 41:871: the facts that matter above the fold and a tinted "Job highlights" box.

**Rules for 30 Sundays**
- A quick spec block: best months, flight time, visa, currency, time difference (from 41:429, 35:160).
- Section titles speak to the traveller, sentence case, no subtitle.
- Long content moves into sheets; lists show five, then "+ N more".
- Different kinds of thing look different: documents we hold are not styled like add-ons we sell (141:13).

**Never copy**
- Scapia Hotels, 2014:3: supplier boilerplate including "may be translated using automated translation tools".
- Ola, 35:88: a wall of rule bullets with the key rule buried.
- 30 Sundays, 141:13: Documents and Add Ons as identical tiles with no status.

**Use on:** destination page, itinerary, booked trip.

---

## Inclusions list

**Best examples**
1. Urban Company, 41:558: "Price includes" names exact items, down to the paint brands.
2. Scapia Hotels, 2014:17, 2014:16: five shown, "+ 58 more", full list grouped in a sheet.
3. Lenskart, 41:674: a short checklist on the service page.
4. NoBroker, 111:49: "Service includes" right under the option the user picked.
5. Cleartrip, 35:106: tick list with an "+ 5 inclusions" expander.

**Rules for 30 Sundays**
- Name hotels and airlines, not categories.
- Ticks in lagoonBliss, not green; exclusions in plain words, not red crosses.
- Top six as a two-column icon grid with "See all 10" (audit fix for 141:19).
- Check supplier lists before showing them.

**Never copy**
- Scapia Hotels, 2014:17, 2014:16: blue amenities that are not tappable, and "Jungle Safari" listed for a city haveli.
- 30 Sundays, 141:19: ten equal light-grey bullets mixing marketing with facts.
- Cleartrip, 35:106: red cross for "Non-refundable" and a floating "3 Room types" pill over the list.

**Use on:** destination page, itinerary, booked trip.

---

## Reviews and ratings

**Best examples**
1. BookMyShow, 41:449: review summary as hashtag chips with counts ("#GreatActing 5630").
2. Scapia Hotels, 2014:9, 2014:7: score with three named sub-scores and reviews labelled by source, including "Booked on Scapia".
3. Urban Company, 41:560: "4.70 (10K bookings)", proof by bookings, not only stars.
4. apna, 41:870: testimonial with a face, a quote and a before and after.
5. Headout, 41:926: every rating carries its count, "4.7 (83,180)".

**Rules for 30 Sundays**
- Score with the exact count and a distribution; filters for destination, trip length and most recent (fix for 141:7).
- Each review: first name, month and year, trip ("5N Bali"), quote clamped to four lines, source named.
- Theme chips on what travellers praise ("Smooth transfers 212") tinted in lagoonBliss; rating chips neutral, never green.
- Name the source of every rating ("8.9 on Booking.com").

**Never copy**
- 30 Sundays, 141:7: a wall of five-star reviews, a vague "1,000+", light grey body text.
- CarDekho, 41:860: "Rate & Win 1000" next to reviews, so they read as paid.
- Mamaearth, 41:648: "5.0 1 Reviews" shown proudly as proof.

**Use on:** home, destination page, itinerary, community.

---

## Trust and proof

**Best examples**
1. OYO, 41:845: one bold claim with a number ("fixed in 30 min") and five icons of what is guaranteed.
2. CARS24, 41:584: a price range with its reason, "Based on 1.7K similar cars sold successfully".
3. apna, 41:871: "HR responded to 94% candidates in last 6 days", specific and checkable.
4. PharmEasy, 35:158: a promise with a consequence, "ON-TIME sample collection or your test is FREE".
5. Scapia destination, IMG_3936: a four-card grid that says what the company handles in plain lines.

**Rules for 30 Sundays**
- Proof is a fact with a number, a period and a source ("120 trips to Bali this year"), in lagoonBliss text, never a solid VERIFIED pill.
- Build the USP band in the OYO shape from our three USPs, on tropicalForest with cream icons.
- One proof line right under the main action (ixigo 41:949, INDmoney 41:489), only with a true number.
- Merge photos, quotes and scores into one "From our travellers" rail (fix for 141:24, 141:7, 141:20).
- Add a "Know your planner" check (PolicyBazaar 41:462) and a calm money-safety sheet (99acres 41:248).

**Never copy**
- 30 Sundays, 141:20: generic 2x2 grid, couples copy, four decorative tints, nothing checkable.
- Pristyn Care, 41:796: stat circles and a celebrity doctor on sign in.
- Pepperfry, 22:41: "103 People Viewing This" next to a 1.0 star rating.

**Use on:** home, destination page, wizard, itinerary, booked trip.

---

## Price display

**Best examples**
1. Ola, 35:92: total first, then line items, then plain fine print on what is excluded.
2. Cleartrip, 35:104, 35:111: "total with taxes & fees" and a dashed underline that means "tap for breakup", in the same place on every step.
3. CARS24, 41:584 and 41:588: range with proof on browse; per month and total split, each with its own drill-down.
4. Urban Company, 41:560, 41:558: "Starts at ₹9,499 . 27 hrs", then a "Your estimate is" strip.
5. Lenskart, 41:662: the price says what it includes ("including lenses").

**Rules for 30 Sundays**
- One all-in price per person, "from" on browse and exact on the quote, with "Flights not included" beside it when true.
- One format everywhere: rupee tight to the number, Indian grouping (we mix "₹ 3,57,000" and "₹42,434", 141:14, 141:22).
- No strike-through, no % off, no paise; say "per person" once at the head of a list.
- A quiet freshness line ("Prices checked 2 hours ago", ixigo 41:945; "Checking latest price", EaseMyTrip 41:898).

**Never copy**
- Scapia Hotels, 2014:20: struck anchor price, solid red "58% off" pill, taxes added on a third line.
- PharmEasy, 35:160, 35:162: MRP, strike, % off, coupon price and membership credits on one item.
- Zomato, 41:358: prices to the paisa ("₹184.24").

**Use on:** home, destination page, wizard, itinerary, booked trip.

---

## Offers and coupons

**Best examples**
1. Zomato, 41:357: "Final price, best offer applied", no coupon hunting.
2. Zomato, 41:349: coupon sheet with one message and one button.
3. Zomato, 41:375: welcome benefits as a three-step path, step 1 open, steps 2 and 3 locked.
4. Headout, 41:920: the saving stated in words inside the product title, "Combo (Save 15%)".
5. Paytm, 41:395: an add-on that states its benefit in numbers ("100% refund") before search.

**Rules for 30 Sundays**
- Apply the best offer for the traveller and show the final price.
- No coupon strips, bank banners or stickers on browse screens.
- Add-ons start unticked (Pepperfry's plant-a-tree add-on, 22:40) and say their benefit in numbers.

**Never copy**
- Cleartrip, 35:115: a modal that blocks the screen to announce "Flat ₹310 off".
- Zepto, 35:151: deal interstitial on home open with "Available till stocks last".
- Housing.com, 111:18: countdown in the CTA, live purchase ticker, pre-added paid add-on.

**Use on:** wizard, itinerary, booked trip.

---

## Sticky CTA bar

**Best examples**
1. Headout, 41:925, 41:923: "from" price left, one action right, "View details" link for the breakdown.
2. Cleartrip, 35:114: the button names the next step ("Select Meal", "Select Baggage").
3. Urban Company, 41:559, 41:560: one CTA, disabled with an amber reason strip until ready.
4. BookMyShow, 41:444: the amount in the final button, "Pay ₹460".
5. Stanza Living, 111:33: a clean soft versus hard pair, "Schedule Visit" filled and "Reserve Now" outline.

**Rules for 30 Sundays**
- Price left, one fuchsia button right, never empty (141:6).
- The label names the step or the amount ("Book this option", "Pay ₹1,24,000").
- "Talk to us" is a quiet outline beside the main action (cult.fit 41:822), never a second filled colour.
- A disabled button shows its reason in a line, never a toast (BookMyShow 41:428).
- "Free changes until ..." sits under the button (CARS24 "100% REFUNDABLE", 41:588); the bar never sits on top of the nav.

**Never copy**
- 30 Sundays, 141:6: a price-only bar with no button.
- Zomato, 41:347 and Zepto, 35:133: two pay buttons side by side.
- Pepperfry, 22:41: sticky bar stacked on the bottom nav with a call button floating over it.

**Use on:** destination page, wizard, itinerary, booked trip.

---

## Booking form

**Best examples**
1. apna, 41:877 and 41:874: one question per card, chips over typing, Yes/No gates that reveal more, suggestions that say why.
2. Urban Company, 41:559: numbered steps, a price on every option, later steps locked, live total.
3. Spinny, 41:890: stepper, earlier answers with EDIT, next steps as a vertical timeline, "takes 45 - 60 mins".
4. CRED, 22:9: one question over a full-bleed photo, the answer set large in a display face, one reason line.
5. BookMyShow, 41:446: "How many seats?" with an illustration that changes with the count and every price tier visible.

**Rules for 30 Sundays**
- One question per screen, each with its own title (PolicyBazaar repeats one title on every step, 41:474).
- Chips over typing; echo the input back ("6 nights, 12 to 18 March", from 41:473).
- Helper text says why we ask and how to type it ("Name should be same as in Passport", 41:898; "only be used for sending tickets", 41:440).
- Optional fields behind one link (Khatabook, 41:492); neutral gender options and no required honorifics.
- Next stays disabled until valid, with the reason shown.

**Never copy**
- Yatra, 113:126, 113:123: four questions in one chat paragraph, a form hidden in a chat.
- PolicyBazaar, 41:466: "Are you sure your annual Income is less than 2 lakhs?", a judgmental confirm.
- Yatra, 113:118: a valid email marked invalid and the keyboard covering the button.

**Use on:** wizard, booked trip, profile.

---

## Payment

**Best examples**
1. CRED, 41:340: amount, exact account, method, time promise, member count, terms, then one button.
2. Groww, 41:415, 41:417: confirm against a replica of the real document, with "CANNOT be changed later" in plain words.
3. Headout, 41:922: the order summary pinned above the form, sticky total with "View details".
4. Pepperfry, 22:38: payment failed sheet that says when the refund lands, then one Retry.
5. Paisabazaar, 41:502: "You Invest, You Get" with a timeline arrow, the grammar for a part-payment schedule.

**Rules for 30 Sundays**
- Trip name and exact amount at the top, then method, then what happens next, then one fuchsia button.
- Confirm traveller names on a passport-style card before tickets are issued, with a plain irreversible warning (41:415).
- Part payment as an equation: "Paid ₹40,000 today", arrow, "₹1,20,000 balance by 12 Feb".
- State reversibility where it exists ("You can change this anytime before you pay", 41:416).
- The same total on every step, to the rupee.

**Never copy**
- PhonePe, 41:406: a telecom ad inside the balance screen.
- Pepperfry, 22:38, 22:39: raw "<br/>" printed in the delivery address at the payment step.
- Headout, 41:923 vs 41:922: totals differ by one rupee between seat map and review.

**Use on:** itinerary, booked trip.

---

## Confirmation

**Best examples**
1. CRED, 41:339: receipt first, perk second.
2. Urban Company, 41:575: pin with "Delivering service at" and the full address, the shape for "You're booked".
3. Rapido, 35:61, 35:70: done sheet with a check, one line, "Done".
4. Blinkit, 41:268: a key-value summary to check before saving.
5. Swiggy, 41:293: confirm details modal with Edit and Confirm.

**Rules for 30 Sundays**
- Say what happens next and when ("We'll call you within 2 hours"), with a link back to the trip.
- Show a short summary of what was booked or asked.
- The check in lagoonBliss; no confetti, no modal for non-events.

**Never copy**
- upGrad, 41:534: "You're all set!" with no time, no summary and no way back.
- apna, 12:3: an auto-advancing Proceed button that takes control away.
- Cleartrip, 35:115: a full modal to celebrate a ₹310 coupon.

**Use on:** wizard, itinerary, booked trip.

---

## Bookings list

**Best examples**
1. Headout, 41:928: Upcoming / Completed tabs with an empty state that still helps.
2. EaseMyTrip, 41:908: guest lookup by booking ID and email.
3. PhonePe, 41:404: history grouped by month.

**Rules for 30 Sundays**
- Upcoming and Past tabs, next trip first (fix for 141:9).
- Card title is the trip ("Thailand, 6 nights"), dates in grey meta, route without duplicates ("Bangkok 2N, Phuket 4N").
- Past trips offer "Share your photos" and "Rate your trip"; status is plain text, not a pill.
- Family members who did not book can open a trip with trip ID and email (41:908).

**Never copy**
- ixigo, 41:937: a category index instead of your trips, with "Failed Train Bookings" as a top row.
- 30 Sundays, 141:9: "2N Phuket" listed twice, green "Completed" pill, fuchsia "Refer & Earn" competing.
- Yatra, 113:137: "Login is required to view booking details." with only OK.

**Use on:** booked trip, profile.

---

## Wallet and rewards

**Best examples**
1. CRED, 41:339: the money confirmation shown cleanly, then a single reward.
2. Paytm, 41:398: spend grouped by category per month with totals, the model for a trip cost breakdown.
3. Zomato, 41:375: a multi-step reward as a short path with locks.
4. Tata 1mg, 41:774: the plan button restates the choice ("for 3 months at 165").

**Rules for 30 Sundays**
- No wallet hub; at most one perk after the receipt.
- A cost breakdown by category (flights, stays, activities, transfers) without red or green.
- Never shame an empty balance.

**Never copy**
- CRED, 41:337: slot-machine cards, "PLAY", live coin counter, countdown on the daily reward.
- NoBroker, 111:42: mystery box, scratch card and instant cash banner.
- Rapido, 35:67: red error line "You don't have any coins currently".

**Use on:** booked trip, profile.

---

## Profile

**Best examples**
1. Lenskart, 41:670: "My Eyes" card stores the user's own data, the model for "My travel details".
2. Headout, 41:927: settings in a bordered card with values on the right (Credits, English, INR).
3. Meesho, 41:758: rows grouped by purpose, with Help and Language as the two big tiles.
4. cult.fit, 41:819: accordion groups that preview what is inside ("Past sessions . Report . Memories").
5. apna, 41:866: kind empty prompts with "+ Add" ("Have you started working yet?").

**Rules for 30 Sundays**
- A hub: name with Edit, saved travellers with a reusable passport vault, travel preferences, settings (fix for 141:8, note 141:84).
- Delete account is a plain grey row at the bottom.
- Offer "Undisclosed" on personal fields (OYO, 41:841); never greet by phone number (41:896).
- No version numbers or commit hashes, no finance cross-sell, no NA or 0 stats.

**Never copy**
- 30 Sundays, 141:8: fields that look editable but are not, and Delete Account as the main thing on the page.
- Flipkart, 41:710: account leads with loans, EMI and credit cards.
- Khatabook, 41:491: profile strength "Weak" in red at 17 percent.

**Use on:** profile.

---

## Empty state

**Best examples**
1. Khatabook, 41:495: shows what the output will look like, "View sample bills".
2. Headout, 41:928: brand-framed photo, a warm line, one primary and one outline action.
3. Meesho, 41:759: teaches the action inline ("Just tap on the heart") with tabs for Shared and Viewed.
4. Tata 1mg, 41:771: a brand sign-off line turns a dead end into a brand moment.
5. Blinkit, 41:277: explains the feature and still offers a rail to act on.

**Rules for 30 Sundays**
- One illustration or frame family across every empty state (Lenskart, 41:667, 41:668, 41:672); ours could be a postcard or stamp frame.
- One warm handwriting line on cream, one action, and a sample of the finished thing ("See a sample Bali itinerary").
- Honest about what is missing and where else it can be done (Cleartrip, 35:114).

**Never copy**
- EaseMyTrip, 41:897: "Currently you have no Bookings." with no action.
- upGrad, 41:549: sad face, no reason, no action.
- Myntra, 41:701: empty bag with no way back to shopping.

**Use on:** wishlist, booked trip, community, Sunday School, profile.

---

## Bottom nav

**Best examples**
1. Headout, 41:926: three tabs only (Explore, Bookings, Account), calm next to five-tab rivals.
2. upGrad, 41:551: three tabs, simple and honest.
3. Groww, 41:418: three items with icon and label.

**Rules for 30 Sundays**
- Three or four tabs with plain labels.
- Active state is a fuchsia icon and label only, no filled pill (fix for 141:22).
- No offers, wallet, upsell or ad slot in the nav; the nav never changes between sessions or tabs.
- The nav never floats over content.

**Never copy**
- Tata 1mg, 41:775, 41:787: a raised "Get Care Plan" upsell in the nav slot.
- Zepto, 35:142 and Blinkit, 41:275: an ad slot and a rival brand inside the nav.
- Yatra, 113:140 vs 113:128: the centre slot changes between sessions.

**Use on:** home, destination page, wishlist, community, Sunday School, profile.

---

## Notifications

**Best examples**
1. Headout, 41:932: pre-prompt showing two sample notifications and three benefits before the system ask.
2. PhonePe, 41:408: asked in context with the benefit first, "Be reminded when your bills are due".
3. Swiggy, 41:313: an advisory that sets expectations before the user asks ("drivers are riding slow in rains").
4. Urban Company, 41:562: channel toggles and an honest line on which messages cannot be turned off.
5. Myntra, 41:703: empty notifications shown as pastel skeleton cards of what will arrive.

**Rules for 30 Sundays**
- Ask after the first quote or saved trip ("We'll tell you when your quote is ready"), never at launch.
- Ask once, in one place; Headout asks four ways (41:932, 41:928, 41:927, 41:913).
- Use calm advisories on the booked trip for weather or visa news; no red count badges.

**Never copy**
- Headout, 41:928, 41:927: the same notification ask repeated as bands and cards.
- Facebook groups, 2028:35: red "9+" badges on every screen.
- Pepperfry, 22:56: notification permission asked over the welcome screen.

**Use on:** wishlist, itinerary, booked trip, community.

---

## Help and chat

**Best examples**
1. Pristyn Care, 41:808: callback sheet with only two questions (where, what) and quick-pick chips.
2. CarDekho, 41:857: three ready questions in the user's own language mix, then a text field.
3. Scapia Hotels, 2014:5: human help with real hours, "Available from 8 AM to 11 PM".
4. upGrad, 41:537 to 41:534: three short enquiry steps with numbered plain questions and an in-person option.
5. EaseMyTrip, 41:909: WhatsApp help one tap away on every main screen.

**Rules for 30 Sundays**
- Name a real planner with photo, hours and live availability ("Free today at 4 pm", from 41:801), not an AI sparkle.
- Offer Call or WhatsApp as a simple toggle (41:801).
- Help lives in the page or in the sticky bar as an outline, never a floating button over content.
- Ask one thing at a time, and every enquiry ends with a time promise and a way back.

**Never copy**
- Scapia Hotels, 2014:4, 2014:9: floating "Call assist" cuts text mid-word and covers the room rail.
- Yatra, 113:126: the planner asks four questions in one paragraph.
- CRED, 22:24: leave-chat sheet with only "Yes, I want to leave" and no Stay.

**Use on:** destination page, wizard, itinerary, booked trip, profile.

---

## Map

**Best examples**
1. Scapia Hotels, 2014:15 (with 2014:13): map card with tabbed nearby places and distances, and Street View of the real street.
2. 30 Sundays earlier build, 113:154: day chips over a map with a "Your stay" pin and a day sheet.
3. Blinkit, 41:268: pin with neighbour house numbers and a key-value summary of the address.
4. Housing.com, 111:23: a small map tile right beside the title.
5. Swiggy, 41:297: inline guidance, "Zoom in to place the pin at exact delivery location".

**Rules for 30 Sundays**
- A map shows the route, nights per stop and travel legs, never decoration.
- Places show distance from the hotel (the audit note "how far???", 149:5).
- A map tile next to the place name; the full map on tap.
- Day chips read "Day 1, Dec 27", one system everywhere.

**Never copy**
- Scapia destination, IMG_3937: scrapbook map with no route order, nights or travel times, country laid on its side.
- Scapia Hotels, 2014:10: a cartoon 3D train replacing real photos in one tab.
- 30 Sundays, 141:10: location says only "Bangkok, THAILAND", the city the tab already names.

**Use on:** destination page, itinerary, booked trip.

---

## Date picker

**Best examples**
1. Headout, 41:924: day strip with a price under each day, cheaper days tinted, unavailable greyed, "More dates" tile.
2. PharmEasy, 35:170: date strip, then time slots grouped by part of day with counts ("16 slots available").
3. ixigo, 41:949: quick date chips that each carry a status strip ("Tatkal open").
4. Paytm, 41:395: named chips ("Today", "Fri") with a calendar fallback.
5. Spinny, 41:890: "Tomorrow, Sat, Sun, More dates" with how long the appointment takes.

**Rules for 30 Sundays**
- The wizard month step is a strip with "from ₹" per month.
- Mark the best value month with a lagoon dot or the word "Lowest", never green.
- One short status under outline chips ("Best weather", "Peak prices").
- When only one option exists, show a notice card instead of a one-option picker (41:924).

**Never copy**
- BookMyShow, 41:428: no CTA, and a toast "Please select time slot to proceed" as validation.
- Yatra, 113:129: cheapest date in green beside a red "1 Seat Left".

**Use on:** wizard, itinerary, booked trip.

---

## Editorial and stories

**Best examples**
1. Myntra, 41:700: lookbook bento, one theme, one big and four small images with prices on them, one "View 28 products".
2. Nykaa, 41:616: Luxe framed edit card with an airplane doodle line and postmark marks.
3. Mamaearth, 41:655: an editorial card placed before the rail it explains.
4. Lenskart, 41:661: guide rail with tag chips and big headlines on a transactional tab.
5. CRED, 22:27: kicker over title ("what just happened?") instead of a subtitle.

**Rules for 30 Sundays**
- A story card leads the rail it explains ("Why Bali in July", then the itineraries).
- Kickers above titles replace subtitles under them.
- "from ₹X from your city" on destination stories (Yatra, 113:139), without a coloured pill.
- Captions are verbs, and every guest photo carries name, month, trip and "See this trip" (fix for 141:3).

**Never copy**
- Mamaearth, 41:646: the editorial video fails to a solid black block.
- Myntra, 41:696: sticker labels and sale heroes in six to eight colours.
- 30 Sundays, 141:3: a lightbox of 50 guest photos with no names, months or trip links.

**Use on:** home, destination page, community, Sunday School.

---

## Video

**Best examples**
1. 30 Sundays, 141:4: full-screen day story viewer with segment bar, our strongest asset; add save, share and jump to next day.
2. Physics Wallah, 41:519, 41:516: playlist rows (16:9 thumb, title, "9 videos . Pawan Sir") and a library with Saved and Watched counts.
3. Myntra, 41:699: vertical video with like, share, save and product chips.
4. Housing.com, 111:19: vertical video with one Details link and one action.
5. upGrad, 41:544: a plain 16:9 intro video at the top of a detail page.

**Rules for 30 Sundays**
- Every video has a still image fallback.
- One specific line per stop ("Lunch on the beach, then free time on Loh Dalum Bay"), not filler.
- Every clip links to the itinerary it shows.
- Long-press to pause, swipe up for details.

**Never copy**
- cult.fit, 41:831, 41:828: heroes that are blank dark areas waiting for video.
- Mamaearth, 41:646: failed video left as a black block.
- 99acres, 41:262: a coach mark for the video product covering search on first open.

**Use on:** destination page, itinerary, community, Sunday School.

---

## Social and community

**Best examples**
1. Facebook groups, 2028:26: role badges next to names, one level of nested replies, reply counts.
2. Facebook groups, 2028:32: a living pulse in three short facts ("1 new post today", "+2 in the last week").
3. Facebook groups, 2028:27: composer with tag chips and a Poll tile.
4. 30 Sundays, 141:24 with 141:3: real guest photos in real places, our most believable proof.
5. apna, 41:867: count chips on filters ("Live 0", "Closed 43").

**Rules for 30 Sundays**
- "30 Sundays expert" shown next to the name in lagoonBliss text, not a solid pill.
- The home entry is one pulse line, not a card.
- Show every area of the community; no sideways chip row that hides tabs (2028:35).
- Hide phone numbers by default, number the rules in plain words (2028:33), and protect the reporter in report copy (2028:25).

**Never copy**
- Facebook groups, 2028:36: a "Call me at" phone number post in the main feed.
- Facebook groups, 2028:30: AI terms toast over the nav that asks for consent by usage.
- Mamaearth, 41:640: a poll sheet interrupting the profile.

**Use on:** home, destination page, community.

---

## Referral

**Best examples**
1. Urban Company, 41:563: both sides in one plain line, "They get ₹100 and you get ₹100".
2. Zomato, 41:375: the three-step locked path, reusable for referral rewards.
3. redBus, 113:98: a quiet "Have a referral code?" link at login.

**Rules for 30 Sundays**
- Referral lives in profile or on a past-trip card, never beside a page title (141:9).
- State what both people get in one line.
- No coloured amount pill.

**Never copy**
- 30 Sundays, 141:9: fuchsia "Refer & Earn" pill competing with the title and the card action.
- Cleartrip, 35:125: green "₹350 per month" pill on the referral row.

**Use on:** booked trip, profile.

---

## Comparison

**Best examples**
1. Cleartrip, 35:116: fare cards with the same icon grid in every card and a Selected state.
2. Paisabazaar, 41:502: identical card layout with input, output and time span, and risk in plain words.
3. redBus, 113:82: cancellation table, rows by time before departure, columns without vs with free cancellation.
4. Rapido, 35:79: each option with drop time and price, the selected one enlarged.
5. Cleartrip, 35:107: room switcher rows, "Starts from ₹8,196, 250 sq.ft, 3 Adults".

**Rules for 30 Sundays**
- Versions read "Option 1", "Option 2" with "Updated 30 Oct", never back-office labels.
- Same fields in the same positions (hotel, rooms, meals, price per person, total), with the difference first.
- Earlier versions say what changed and offer "Use this one" (fix for 141:16).
- The cancellation table uses real dates computed from the trip; one fuchsia "Book this option".

**Never copy**
- 30 Sundays, 141:14, 141:16: "V4 - Quotation 1", truncated room chips, look-alike cards with no status.
- Tata 1mg, 41:774: grey "Most Popular" and solid green "20% Cheaper", so the lesser tag shouts.

**Use on:** wizard, itinerary, booked trip.

---

## Itinerary and timeline

**Best examples**
1. EaseMyTrip, 41:899: a calm dashed pill between segments that names the gap ("9h 40m Layover in Dubai").
2. Meesho, 41:748: three steps joined by one line, each with a picture, the clearest policy explainer.
3. Cleartrip, 35:105: review card with check-in and check-out columns, a nights pill between, a ticket-notch divider.
4. Swiggy, 41:309: a three-step dotted "how it works" timeline.
5. Zomato, 41:350: rows with the photo right, a short description and "more", for day activities.

**Rules for 30 Sundays**
- Name the gap between days and stops ("3h drive to Ubud").
- Neutral timeline dots, never green (141:6).
- Plain words: "Shared transfer", not "SIC Transfer"; TCS behind an info tap.
- One day label system everywhere (141:6 says "Day 1", 141:17 says "Dec 27").
- Cancellation, payment schedule and "what happens next" as a three-step timeline in lagoonBliss.

**Never copy**
- 30 Sundays, 141:6: "SIC Transfer", "TCS", "Itinerary at glance" and green dots.
- 30 Sundays earlier build, 113:155: raw supplier text with "?" boxes and hard line breaks.

**Use on:** wizard, itinerary, booked trip.

---

## Progress and status

**Best examples**
1. Rapido, 35:63: status first ("Pickup in 1 min"), proof code, the person with face and rating, contact, details link, quiet help link last.
2. INDmoney, 41:484: vertical stepper, "only 3 steps remaining".
3. CRED, 22:8: a step checklist with ticks while the result loads, so the wait reads as careful work.
4. cult.fit, 41:820 with 41:831: a small goal, where you stand, what most people do, warm copy, and a pinned mini bar on home.
5. CarDekho, 41:859: earlier answers as chips you can tap to edit, current step outlined.

**Rules for 30 Sundays**
- The booked trip opens with "Next up": countdown and the one pending task ("Upload Priya's passport, 1 of 2 done").
- Name the steps and the count left; progress in goldenHour, never a red to green scale.
- Freshness stamps in caption grey ("Hotel confirmed today", from ixigo 41:945).
- Loaders carry one plain sentence (EaseMyTrip 41:904) or a skeleton (BigBasket 38:208).

**Never copy**
- Khatabook, 41:491: red "Weak" at 17 percent.
- INDmoney, 41:481: red "verification pending", two identical buttons and two progress bars.
- Rapido, 35:63: an ad under the live status.

**Use on:** home, wizard, itinerary, booked trip, Sunday School.

---

## Other

Covers account deletion, cancellation friction, permission asks, explainer sheets, calculators, share sheets
and undo.

**Best examples**
1. Headout, 41:914 then 41:913: deletion with consequences listed, an equal "I'll stay", then a plain confirmation.
2. Rapido, 35:62: humane cancel friction, names the person affected, "Go Back" is the primary, cancel is still one tap.
3. BookMyShow, 41:455, 41:454: location soft ask in its own words, a manual path, and a recovery sheet if denied.
4. 99acres, 41:245, 41:246: budget calculator with three sliders, a live range and one CTA into matching results.
5. 30 Sundays, 141:12: the Pace explainer, an idea no competitor has (fix colours, empty tip and "1.1h").

**Rules for 30 Sundays**
- Destructive actions are never fuchsia: "Keep my trip" or "Keep my account" is filled, delete is red text, with what is lost and a grace date (redBus 113:107).
- Permission asks give the benefit first, a manual option, and what we do not collect (Khatabook, 41:497), one at a time.
- Pace is a 1 to 4 dot scale in one neutral, the same four levels in filters.
- Sharing leads with WhatsApp and says a link beats a screenshot (99acres, 41:250); toggles that change the plan get an undo snackbar (redBus, 113:81).

**Never copy**
- 30 Sundays, 141:79 and Nykaa, 41:603: the brand primary on Delete.
- NoBroker, 111:55: contacts and installed apps requested with only "Allow Access".
- redBus, 113:107 vs 113:108: red is "Keep my account" on one screen and "Yes, Delete" on the next.

**Use on:** splash, wizard, itinerary, booked trip, profile.

---

## Skipped kinds

None. All 38 kinds have evidence in at least one report. Thinnest evidence: Bookings list, Referral,
Wallet and rewards (mostly what not to do), and Hero banner (few good examples).
