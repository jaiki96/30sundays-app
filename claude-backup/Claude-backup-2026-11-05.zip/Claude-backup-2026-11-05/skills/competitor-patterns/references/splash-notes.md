# Splash and onboarding study (Figma frame 129:108)

The designers laid 13 apps' splash screens in columns. Under each: what the splash shows
(content), how it opens (opening animation), how it hands over (closing animation). App names
were not labelled; identify them from the screenshots.

| Column | Splash file | Content | Opening animation | Closing animation | Onboarding files |
|---|---|---|---|---|---|
| 1 | splash-study/01 | logo + subtext + illustrations + data | sequential animation | screen fades out | onboarding-study/01-03 |
| 2 | splash-study/02 | logo | animated logo | directly changes | onboarding-study/04-06 |
| 3 | splash-study/03 | logo + illustration + data | no animation | fades out | onboarding-study/07 |
| 4 | splash-study/04 | logo | no animation | directly changes | onboarding-study/08 |
| 5 | splash-study/05 | logo | no animation | size diminishes while moving out of the screen upwards | onboarding-study/09-10 |
| 6 | splash-study/06 | logo | logo scales up | directly changes | onboarding-study/11-12 |
| 7 | splash-study/07 | logo + illustrations | logo, animates into logo again | fades out | onboarding-study/13-15 |
| 8 | splash-study/08 | logo + new feature + subtext | logo scales down upwards, central feature animation | fades out | onboarding-study/16-17 |
| 9 | splash-study/09 | logo | logo animation | directly changes | onboarding-study/18-19 |
| 10 | splash-study/10 | logo + authorisation | content fades in | fades out | onboarding-study/20 |
| 11 | splash-study/11 | logo + subtext | logo animation | onboarding content moves in | onboarding-study/21-23 |
| 12 | splash-study/12 | logo | no animation | fades out | onboarding-study/24 |
| 13 | splash-study/13 | logo + subtext + illustration | no animation | no animation | onboarding-study/25 |
