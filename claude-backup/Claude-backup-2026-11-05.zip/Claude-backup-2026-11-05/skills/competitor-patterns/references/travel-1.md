# Group travel-1: Cleartrip, BookMyShow, OYO, EaseMyTrip

91 screens studied, every file opened (Cleartrip 27, BookMyShow 33, OYO 14, EaseMyTrip 17). There are no
designer notes on the canvas for this group, only the four app name labels. In the Figma file the screens
of Cleartrip, BookMyShow and EaseMyTrip are laid out in reverse order of capture (the last step of the
journey comes first on the canvas), so the flows below are listed in journey order, not canvas order.
Pixel sizes are estimated for a 390 px wide phone.

These four are the closest booking competitors to 30 Sundays. The lens throughout: how they show price,
how they prove they can be trusted, how they move a person from browsing to paying, and what a curated
holiday app could lift without picking up the discount noise.

---

### Cleartrip (OTA: flights, hotels, buses, trains; 27 screens)

- **Flows covered (journey order):**
  - 35:130 Splash, orange flood, brush-script "So, where to?"
  - 35:129 Home, trains hero banner, coupon nudge with Login, 3D icon tiles for five verticals
  - 35:128 Login sheet over My trips, SuperCoin promo carousel, +91 phone field, disabled Get OTP
  - 35:127 My trips, logged-out empty state with cactus illustration and Login
  - 35:126 Work tab, Cleartrip for Work hero, login nudge, Flights and Hotels tiles, bank banner
  - 35:125 Account, logged-out profile list with Log in / Sign up
  - 35:124 Deals and offers, Flights / Hotels / Buses chips, 2-column coupon cards
  - 35:123 Flight search form, one way / round trip, special fares, Work toggle
  - 35:122 OTP (4 boxes) with Work benefit cards above
  - 35:121 Flight results, offer banner, date strip with lowest fare per day, Smart Filter, fare rows
  - 35:120 Filters, Included airports tab (nearby airports with prices)
  - 35:119 Filters, Stops tab (segmented tiles with price)
  - 35:118 Filters, Airlines tab (airline rows with lowest price)
  - 35:117 Filters, Flight times tab (take-off and landing time bands)
  - 35:116 Select your fare sheet, two fare cards compared
  - 35:115 Coupon applied modal "Flat ₹310 off" over flight summary
  - 35:114 Add upgrades, Seat tab, not-available empty state
  - 35:113 Add upgrades, Meal tab
  - 35:112 Add upgrades, Baggage tab
  - 35:111 Flight traveller details, no saved travellers warning, contact, GST
  - 35:110 Hotel search form, offer cards, nearby getaways destination tiles
  - 35:109 Hotel listing, big photo cards
  - 35:108 Hotel detail, full-bleed hero, rating card, benefits card
  - 35:107 Room type switcher overlay ("starts from" prices)
  - 35:106 Room detail, inclusions card, fare tag
  - 35:105 Review itinerary, hotel summary ticket, inclusions
  - 35:104 Hotel traveller form, coupon strip, Pay now
- **Typography:** neo-grotesque sans, very likely Inter, with a hand-brush script only on the splash
  (35:130). Weights 400 to 600, no heavy black weights. Page titles about 22 px semibold ("Who's
  travelling?" 35:104), hotel names 22 to 24 px medium in two lines (35:108), section heads 18 px
  semibold, body 15 to 16 px regular, captions 13 px grey. Sentence case for copy, all caps only for small
  tags (PREFERRED FOR WORK, BUSINESS FARE, 1 NIGHT). Prices: rupee symbol tight to the number, about
  20 px semibold, with a dashed underline under the total that means "tap for breakup" (35:104, 35:106);
  struck-out old price in grey 13 px beside it; savings in green.
- **Colour:** light theme. Primary action orange about #FF4F17 (splash and every CTA). Links and rating
  text in blue about #1A6AE0, rating score in a filled blue square about #1E5BFF (35:108). Savings green
  about #12A05C on a mint band #E6F6EE (coupon strip 35:104). Navy tag #0D2C6C (BUSINESS FARE), very dark
  teal chip #0E2B2B (PREFERRED FOR WORK). Text near-black #1A1A1A, secondary #6B6B6B, borders #E2E2E2.
  Hotel listing sits on a pale blue ground #EEF4FB (35:109). Bottom nav is solid black #141414. Gradients:
  the Smart Filter pill is magenta to violet (35:121), the Work checkbox card fades white to pale blue
  (35:110, 35:123), the Home trains hero is an illustrated sky. On one screen up to four accents compete
  (orange CTA, blue links, green savings, navy fare tag on 35:106).
- **Layout and spacing:** 16 px side gutters, generous vertical rhythm (24 to 32 px between blocks),
  cards at 16 to 20 px radius with a hairline border and almost no shadow. Hotel photos about 4:3 inside
  cards (35:109), full-bleed about 4:3 on detail with an overlapping white card (35:108). Sections are
  separated by white space and by moving to a tinted card, rarely by dividers, except the profile list
  (35:125) which uses hairlines. The sticky bottom bar is a constant: price on the left, one orange button
  on the right, on almost every booking step.
- **Section designs:**
  - Splash: brand-colour flood with a handwritten question as the tagline (35:130).
  - Hero banner: illustrated full-width announcement on top of Home, logo sits below it (35:129).
  - Category tiles: 2 large plus 3 small tiles, each with a 3D icon, a name and an offer line, plus a
    "10L+ Happy Stays" proof strip tucked under one tile (35:129).
  - Offers and coupons: soft ticket-shaped promo row with code and Login button (35:129); ticket card with
    a purple code stub "CTFIRST" (35:110); 2-column coupon grid with notched edge and code (35:124).
  - Search bar: route summary pill with back arrow, dates, guests and an edit pencil, reused on every
    results and detail screen (35:121, 35:109).
  - Booking form: stacked search card with labelled rows (city, check-in, 1 NIGHT pill, check-out, rooms
    and guests) and one full-width orange button (35:110, 35:123).
  - Date picker: horizontal date strip where each day shows its lowest fare, plus a calendar icon at the
    end (35:121).
  - Filters and sort: chip row (Map, Sort by, All filters, Price) on listings (35:109); full-height filter
    sheet with tabs, Reset all, a black Apply bar, and the lowest price shown next to every option
    (35:118, 35:119, 35:120); time bands with clock ranges (35:117).
  - Listing card: photo with carousel dots and heart, rating, name with stars, distance to the beach,
    outlined amenity chips, three green ticks of inclusions, fare tag, price with strike and % off (35:109).
  - Detail hero: full-bleed photo, round back, heart and share, "+40 more" stacked-photo count (35:108).
  - Reviews and ratings: blue score square, word label "Exceptional", count (35:108, 35:105).
  - Trust and proof: "On booking this hotel, you get" benefits card with ticks (35:108).
  - Inclusions list: tick list with a red cross for "Non-refundable" and "+ 5 inclusions" expander
    (35:106).
  - Comparison: room type switcher in a dark overlay, each row "Starts from ₹8,196, 250 sq.ft, 3 Adults"
    (35:107); fare cards side by side vertically with Selected pill and identical icon grid of
    cancellation, date change, meal, seat, cabin and check-in rules (35:116).
  - Price display: sticky bar with dashed-underlined total, "total with taxes & fees" caption, savings in
    green (35:104); "View breakup" link under the total (35:111).
  - Sticky CTA bar: price left, one orange button right; button label changes with the next step
    ("Select Meal", "Select Baggage", "Continue") (35:114, 35:113, 35:112).
  - Itinerary and timeline: review card with check-in and check-out columns, a "1 night" pill between
    them, and a ticket-notch divider (35:105).
  - Empty state: grey icon with a small "!" badge and one honest line, "Seat selection not available. You
    can select seat during web checkin." (35:114).
  - Confirmation: centred modal with a green rosette tick, "Flat ₹310 off", OK (35:115); a green "You saved
    ₹310 on this booking" bar above the sticky total.
  - Login and OTP: bottom sheet over the current page with a promo carousel above the form (35:128); 4
    box OTP with the number and an edit pencil (35:122).
  - Bookings list: icon tabs (Active, Flight, Hotel, Bus, Train) with a black filled selected state
    (35:127).
  - Profile: flat list with line icons and hairlines, inline promo tags (35:125).
  - Referral: "Invite and Earn" row with a green "₹350 per month" pill (35:125).
  - Bottom nav: black bar, five items, Offers as its own tab (35:124).
  - Other (business mode): Cleartrip for Work toggle carried through search, listing, detail and review
    as a tag (35:110, 35:109, 35:105).
- **Strengths:**
  - Price honesty on every step: total, taxes stated, and a tap-for-breakup cue in the same place on every
    screen (35:104, 35:106, 35:111). Visibility of system status and consistency.
  - The search summary pill at the top of results and detail always tells you what you searched and lets
    you edit it in one tap (35:121, 35:109). Recognition over recall.
  - Filters that show the cost of a choice (Non stop ₹7,972 vs 1 stop ₹7,145) help people decide without
    leaving the sheet (35:119, 35:120).
  - Fare comparison card lays out exactly what changes between tiers with the same icons in the same
    grid (35:116). Excellent for any "pick a version" decision.
  - CTA labels name the next step ("Select Meal") instead of a generic Continue (35:114). Clear forward
    motion.
  - Empty states are honest and tell you where else the thing can be done (35:114, 35:113).
  - Destination tiles on hotel search use real photos with a serif place name, and a "From Delhi" card
    that pages through origin cities (35:110). The most holiday-like moment in the app.
  - Restrained card system: hairline borders, little shadow, lots of white (35:105).
- **Weaknesses:**
  - Discount theatre: strike price, % off solid green pill, "WOW Savings" pill, coupon strip and a fare tag
    on one card (35:109, 35:121). Aesthetic and minimalist design broken; it also trains users to doubt the
    real price.
  - Accents fight: orange CTA, blue links, blue rating square, navy and dark teal tags, green savings on one
    screen (35:106).
  - The login button in Account is blue (35:125), while every other primary action is orange.
    Consistency and standards broken.
  - Floating "3 Room types" pill sits over the inclusions and hides text (35:106).
  - The Home leads with a trains announcement rather than with the user's own next trip or a search
    (35:129). Match between system and real world is weak on intent.
  - Flights traveller page opens with an orange warning sentence (35:111), and the GST note sits in a peach
    box that looks like an error. Error-like colour for neutral info.
  - Upgrades flow shows three tabs that are all "not available" (35:112 to 35:114), three steps of nothing.
  - The coupon applied modal blocks the screen to announce ₹310 (35:115). Interruption for a non-event.
- **Scores (1 to 5):** visual polish 4, clarity 4, information density 3, trust 4, brand distinctiveness 3.
- **For 30 Sundays:**
  - Borrow for itinerary: the sticky bar with total, "total with taxes and fees" and a tap-for-breakup
    underline (35:104), in fuchsia with one button. Replace "per night" with "per person".
  - Borrow for itinerary versions: the fare comparison card (35:116), each version as a card with the same
    icon grid (hotels, flights included, transfers, cancellation), Selected state on the chosen one.
  - Borrow for itinerary hotel swap: the room switcher list with "starts from" price and one-line facts
    (35:107).
  - Borrow for booked trip: the review card with check-in and check-out columns, a nights pill between,
    and a ticket-notch divider (35:105).
  - Borrow for wizard: CTA labels that name the next step (35:114), and the date strip idea (35:121)
    turned into a month strip with "from ₹" per month.
  - Borrow for home: real-photo destination tiles with a display-face name (35:110).
  - Avoid: stacked discount pills and strike prices, the coupon-applied modal, and a hero that advertises a
    product the user did not come for.

---

### BookMyShow (ticketing: movies, live events, streaming; 33 screens)

- **Flows covered (journey order):**
  - 41:459 Splash, red flood, logo, "It All Starts Here"
  - 41:458 App tracking prompt fired on the first screen
  - 41:457 Notification prompt over the onboarding carousel (coupon illustration, SKIP, phone field)
  - 41:456 Verify your mobile number, 6 box OTP, "Expect OTP in 30 seconds"
  - 41:455 Location soft ask sheet, illustration, Detect My Location / Select Manually
  - 41:454 Location denied sheet, Enable Location In Settings / I'll do this later
  - 41:453 Pick a region, popular cities as line-art landmark icons, other cities list
  - 41:452 Delhi-NCR sub-region list with skyline illustration
  - 41:451 Home (Faridabad), category icon rail, hero carousel, Recommended Movies, coachmark
  - 41:450 Now Showing listing, filter chips, Coming Soon banner, 2-column poster grid, Browse by Cinemas
  - 41:449 Movie detail, rating, Trending proof, Top offers, Top reviews hashtags
  - 41:448 "This movie is rated A" 18+ sheet
  - 41:447 Showtimes by cinema, date strip, filters, coachmark tooltip
  - 41:446 How many seats? sheet with scooter illustration and tier prices
  - 41:445 Seat map, nothing selected
  - 41:444 Seat map, 2 seats selected, Pay ₹460
  - 41:443 Terms and conditions sheet
  - 41:442 Grab a bite, food upsell, nothing added
  - 41:441 Grab a bite, 1 item added, Proceed
  - 41:440 Contact details, email and mobile with helper text
  - 41:439 Search, empty focus with Popular / Trending list
  - 41:438 Search, typing "mich", grouped suggestions, View All Results
  - 41:437 Movie detail (Michael), trailer, cast and crew rails, two CTAs
  - 41:436 City picker from Home
  - 41:435 City search typing "le"
  - 41:434 City search typing "leh"
  - 41:433 Home (Leh), skeleton loading, location toast
  - 41:432 Cinemas list with favourite heart hint
  - 41:431 Live Events tab, cut-out category tiles, Top Events rail, Filling Fast tiles
  - 41:430 Comedy Shows listing, banner, filter pills, rail
  - 41:429 Event detail (Papa Yaar), interest count, fact list, You should know, Book Now
  - 41:428 Event booking step 1, Date and Time with stepper and availability legend
  - 41:427 Profile
- **Typography:** humanist-neutral sans, very likely Roboto across the app (Android-born system), with the
  wordmark in the brand's own condensed face. Weights 400 to 500 for most UI, 700 for screen titles. Title
  about 22 px bold ("It All Starts Here!" 41:451), section heads 20 px medium ("Recommended Movies"),
  body 15 px, meta 13 px grey, tiny caps tags 11 px (PROMOTED). Title Case Everywhere, including buttons and
  some section heads ("Choices Vast But Filling Fast" 41:431). Prices plain: "₹999 onwards" 16 px regular
  (41:429), seat tiers as caps headers "₹500 RECLINER ROWS" (41:444), the CTA carries the total
  ("Pay ₹460").
- **Colour:** light theme on a cool grey ground about #F2F3F7. Primary red-pink about #F84464 for CTAs,
  links and active nav; splash a deeper #EE1A4E (41:459). Seat map uses green #1EA83C for available and
  selected, grey #D9D9D9 sold, gold #F6C343 bestseller (41:444). Info blue #3C78F0 for the location banner
  and coachmarks (41:451, 41:447). Orange #F28A3B for "Filling Fast" (41:429), salmon #F0907A for the date
  chips on events (41:428), peach #FFF1EA "You should know" card. Text #222, secondary #666. Many accents
  on one screen: red CTA, blue banner, green proof number, yellow offers on 41:449. Movie posters bring their
  own colour, which drowns the UI.
- **Layout and spacing:** 16 px gutters, dense. Cards at about 12 px radius with soft shadow on the
  profile and detail cards (41:427), hairline lists elsewhere. Posters 2:3 in grids (41:450), 16:9
  trailers on detail (41:437). Sections separated by white space and heading, plus grey bands between
  white blocks on detail (41:429). Many bottom sheets with a grabber, a title, and a full-width red button.
- **Section designs:**
  - Splash: red flood with wordmark and tagline (41:459).
  - Onboarding: illustrated carousel with SKIP, phone field on the same screen (41:457, seen behind the
    system prompt).
  - Login and OTP: 6 box OTP, red outline on the active box, countdown line, disabled grey Continue
    (41:456).
  - Other (location soft ask): illustrated sheet asking "Where are you?" with two choices before the
    system prompt (41:455); recovery sheet when denied (41:454).
  - Other (city picker): popular cities as line-art landmark icons in a 4-column grid, selected one filled
    teal with a green dot, then an A to Z list (41:436, 41:453); sub-region list for metros (41:452).
  - Home header: big greeting title, city link in red under it, search and bell on the right (41:451).
  - Category tiles: horizontal icon rail with a tiny FAV tag (41:451); on Live Events, photo cut-out people
    in rounded squares (41:431).
  - Hero banner: carousel of posters with an in-banner Book Now (41:451).
  - Card rail: poster rail with PROMOTED corner tags and offer strip under the poster (41:451); event cards
    with photo, title, type and date range (41:431, 41:430).
  - Listing card: 2-column poster grid with likes count under it (41:450).
  - Filters and sort: red-outline pill chips (41:430, 41:450, 41:447), funnel icon first.
  - Search bar: full-screen search with category chips (Movies, STREAM, Events, Plays), trending list when
    empty, grouped suggestions with type under each, and View All Results (41:439, 41:438).
  - Detail hero: trailer with play chip and a black status strip "In cinemas, Streaming from 09 Jun"
    (41:437).
  - Detail sections: icon fact list (date, duration, age, language, genre, venue with directions arrow)
    (41:429); "You should know" tip card with a lightbulb (41:429); cast and crew portrait rails with name
    and role (41:437).
  - Reviews and ratings: star score 8.9/10 with votes count (41:449); review summary as hashtag chips with
    counts, "#GreatActing 5630" (41:449).
  - Trust and proof: "Trending" chip plus "5.56K tickets booked in last 1 hour" (41:449); "9.5k are
    interested" with an Interested? button (41:429).
  - Offers and coupons: yellow-ringed card rail "Top offers for you" (41:449); bank offer strip with 1/3
    pager above Pay (41:444).
  - Date picker: date strip with a red block for today and greyed days without shows (41:447); outlined
    date chips with a filled selected chip (41:428).
  - Progress and status: 4 step stepper, Date and Time > Seats > Ticket Mode > Review and Proceed
    (41:428); availability legend Available / Fast Filling / Sold out (41:428).
  - Booking form: "How many seats?" sheet with number row and a scooter illustration that changes with the
    count, plus tier price grid (41:446); seat map with tier headers and legend (41:444); contact details
    with helper text under each field explaining why it is needed (41:440).
  - Other (upsell): food add-on sheet with Skip, tabs, steppers and "1 item added" Proceed (41:441).
  - Other (rules sheet): 18+ rating sheet with a red ring badge and a refund warning (41:448); long T&C
    sheet (41:443).
  - Sticky CTA bar: "₹999 onwards, Filling Fast" left, Book Now right (41:429); full-width "Pay ₹460"
    (41:444).
  - Help and chat: coachmark tooltips (41:447, 41:451) and a bottom hint bar "Favorite cinemas by tapping
    on the heart", Got it (41:432).
  - Profile: greeting card, "Never lose a ticket" add-email nudge, list in a white card with chevrons
    (41:427).
  - Bottom nav: four tabs, red active (41:427).
- **Strengths:**
  - Location ask done well: a soft ask in its own words before the system prompt, a manual path, and a
    recovery sheet if denied (41:455, 41:454). User control and freedom.
  - The city picker with landmark icons is fast to scan and pleasant (41:453). Recognition over recall.
  - Review hashtags with counts summarise thousands of reviews in one row (41:449). Strong, scannable proof.
  - "How many seats?" turns a dull number pick into a small delight, and shows every tier price at the same
    time (41:446).
  - Helper text under each contact field says why it is needed ("only be used for sending tickets")
    (41:440). Builds trust at the moment of asking.
  - The CTA carries the amount ("Pay ₹460") so the last tap has no surprise (41:444).
  - Event detail fact list is a clean, scannable spec sheet (41:429).
  - The 4 step stepper tells people how long the booking will take (41:428).
- **Weaknesses:**
  - Two system prompts (tracking and notifications) fire on the very first screen before any value is
    shown (41:458, 41:457). Poor timing, and it hurts opt-in.
  - "PROMOTED" paid posters inside "Recommended Movies" (41:451, 41:450). Recommendation and advertising
    mixed, which erodes trust.
  - Urgency everywhere: "Filling Fast" (41:429), "Choices Vast But Filling Fast" tiles (41:431), "tickets
    booked in last 1 hour" (41:449). Scarcity cues lose meaning.
  - Two equal red primary buttons, Book tickets and Pre-buy ₹999 (41:437). One primary action per screen
    broken.
  - On the event date step the CTA is missing and a toast says "Please select time slot to proceed"
    (41:428). Error prevention broken; a disabled button with a hint would be clearer.
  - Seat map green for available and selected (41:444) makes the selection hard to see at a glance.
  - Home shows a blank grey skeleton block with the logo for a long time (41:433).
  - Title Case on every label and section reads shouty and old-fashioned.
  - Hard-coded personal email in an event's "You should know" card (41:429). Content governance gap.
- **Scores (1 to 5):** visual polish 3, clarity 3, information density 2, trust 3, brand distinctiveness 3.
- **For 30 Sundays:**
  - Borrow for destination page: review hashtag chips with counts (41:449), for example "Smooth transfers
    212", "Great hotels 180", tinted in lagoonBliss as proof.
  - Borrow for wizard: the "How many travellers?" sheet with a playful illustration that changes with the
    count (41:446); and the stepper with named steps so people know the length (41:428).
  - Borrow for destination page: the icon fact list as a quick spec block (best months, flight time, visa,
    currency, time difference) (41:429).
  - Borrow for wizard and profile: helper text under each field saying why we ask (41:440).
  - Borrow for app start: the location soft ask and recovery pattern (41:455, 41:454), reused for
    notification permission after the first saved trip.
  - Borrow for itinerary: put the amount in the final button ("Pay ₹1,24,000") (41:444).
  - Avoid: paid tags inside recommendations, urgency copy, two primary buttons, toasts as validation, and
    Title Case.

---

### OYO (budget hotel aggregator; 14 screens, Android)

- **Flows covered (journey order):**
  - 41:852 Welcome modal explaining location use, asks for "allow all the time"
  - 41:851 Login, logo top, empty white middle, "New User Offer, 1st Stay at ₹499", phone, Google, sign up
    later
  - 41:850 OTP sheet "Detecting passcode (27 s)", 4 boxes, Edit, Resend
  - 41:849 Finish creating account, name, referral, email, pre-ticked marketing box
  - 41:848 Home, black header, search pill, destination circles, brand banner, Handpicked for you rail
  - 41:847 Bookings, empty state
  - 41:846 Search, empty focus with Today / 1N / Tomorrow and "Search nearby OYOs"
  - 41:845 OYO Serviced tab, "Any issues? fixed in 30 min" promise band, destination circles, results
  - 41:844 Summer Stays deal sheet, "Under ₹999", 243 cities list
  - 41:843 Listing for Bangalore, 334 OYOs found, listing card
  - 41:842 Side drawer menu
  - 41:841 Profile edit
  - 41:840 Bulk bookings lead form
  - 41:839 Hotel detail, labelled photo strip, ratings, Why book this hotel, sticky price and Book now
- **Typography:** neo-grotesque sans, likely Inter (or OYO's Inter-like house sans), weights 400 to 700.
  Big bold headings 22 to 24 px ("Hotel O The Royal International Hotel" 41:839, "334 OYOs found"
  41:843), body 15 to 16 px, captions 13 px grey, tiny caps labels 11 px (GENDER, POPULAR). Sentence case.
  Prices 20 px bold, strike price 13 px grey right next to it, "66% OFF" in green caps, then a second line
  "+ ₹105 taxes & fees" (41:848).
- **Colour:** light content, black chrome. Primary crimson about #CE1C39 for CTAs and the logo (41:851,
  41:839); rating star red. Home and Serviced headers solid black #000 with white text (41:848, 41:845).
  Links and date controls blue about #1E6FD9 (41:843). Mint chips #E7F6EE with green text #1D8A55 for "Pay
  at hotel" and "First booking offer" (41:843). Purple #7B3FE4 for "Couples are welcome" and "Breakfast
  available" (41:843). Gold text #B8860B for a warning (41:852). Text #111, secondary #6E6E6E. Gradients:
  none; photos do the colour. Up to five accents on one listing card: red star, green %, mint chip, purple
  lines, blue map.
- **Layout and spacing:** 16 px gutters, bold scale contrast. Cards 16 px radius with soft shadow
  (41:843). Listing photo about 16:10 full card width; detail hero full-bleed with a strip of 4 labelled
  thumbnails overlapping its bottom edge (41:839). White sheets rising over a black header, with a 24 px
  top radius (41:845). Sections separated by white space and big headings, no dividers except the drawer.
- **Section designs:**
  - Login and OTP: phone with floating label and flag, red Continue, OR, Continue with Google, "I'll
    signup later" (41:851); OTP sheet with auto-detect countdown (41:850); account finish form (41:849).
  - Onboarding: welcome modal with illustration explaining why location is needed (41:852).
  - Home header: black band, hamburger, centred white logo, white search pill with place, dates and guests
    (41:848).
  - Category tiles: round destination photos with a black "Nearby" circle first (41:848, 41:845).
  - Hero banner: brand campaign "YE OYO ALAG HAI, TEST US" with a person cut-out (41:848).
  - Card rail: "Handpicked for you" hotel cards with tier tag (Super OYO, Mid range), heart, rating,
    wizard icon, price, taxes, Pay at hotel chip (41:848).
  - Trust and proof: OYO-Serviced promise band, "Any issues? fixed in 30 min" with a red highlight box and
    five white line icons for what is guaranteed (41:845); "1k+ bookings in the last 6 months", "5.0
    check-in rating, Delightful experience", "Lowest price for your selected dates" mint band (41:839).
  - Search bar: pill with back, place and clear; under it a blue line of Today / 1N / Tomorrow / 1 room 1
    guest (41:846, 41:843).
  - Filters and sort: outlined chips Sort, Locality, Price, plus a filter icon (41:843).
  - Listing card: big photo with OYO-Serviced badge and heart, rating with count, chips, name, locality,
    two purple feature lines, price, strike, % off, taxes, offer chip (41:843).
  - Map: floating black "Map" pill over the list (41:843).
  - Detail hero: full-bleed photo, close, heart, share, 1/34 counter, labelled thumbnails Entrance, Room,
    Lobby, Reception (41:839).
  - Reviews and ratings: star score, ratings count, reviews link, and a separate check-in rating with a
    word label (41:839).
  - Detail sections: "Why book this Hotel?" icon list (41:839); "View on map" link under the address.
  - Price display: listing head says "Price per room per night" once, top right (41:843, 41:845); sticky
    bar with price, strike and blue "+ ₹113 taxes & fees" (41:839).
  - Sticky CTA bar: price left, crimson "Book now & pay at hotel" right (41:839).
  - Offers and coupons: deal sheet with photo hero "Under ₹999" and list of cities offering it, each with a
    round photo and state (41:844).
  - Empty state: illustration, "No bookings, yet!", one line, black Book now (41:847).
  - Bottom nav: Home, Bookings, Search, OYO Serviced, Under 999 with a red dot (41:845).
  - Profile: floating-label fields, verified tick on mobile, segmented Gender and Marital status with
    "Undisclosed", GST button, WhatsApp updates toggle (41:841); side drawer with subtitle under each item
    (41:842).
  - Referral: "Invite & Earn, refer OYO app and earn OYO Rupee" (41:842); referral code field at sign up
    (41:849).
  - Other (lead form): Bulk bookings page, stock photo hero, numbered form, "our representative will reach
    out to you within 24 hours" (41:840).
- **Strengths:**
  - The OYO-Serviced promise is the best trust section in the group: one bold claim with a number ("fixed
    in 30 min") and five concrete icons of what you get (41:845). It turns a brand promise into a checklist.
  - Booking-level proof on detail is specific and believable: "1k+ bookings in the last 6 months", a
    separate check-in rating, and "Lowest price for your selected dates" (41:839).
  - Labelled photo thumbnails (Entrance, Room, Lobby, Reception) tell you what you are about to see
    (41:839). Recognition over recall.
  - "Price per room per night" said once at the head of the list, so cards stay clean (41:843).
  - Destination circles with a "Nearby" first item make the start of search one tap (41:848).
  - "Undisclosed" option on gender and marital status respects privacy (41:841).
  - The lead form states a response time, "within 24 hours" (41:840), which sets expectations.
- **Weaknesses:**
  - The marketing consent box is pre-ticked (41:849). A dark pattern, and against Indian data protection
    norms.
  - The welcome modal pushes "allow all the time" for location in warning-gold text (41:852). Asks for more
    than needed.
  - Huge empty white area on the login screen between logo and form (41:851). Wasted first impression.
  - Discounts of 66% to 80% off on every card (41:843, 41:848) make the strike price meaningless.
  - Colour soup on the listing card: red, green, mint, purple, blue (41:843). Weak hierarchy.
  - "Couples are welcome" as a feature line (41:843) signals a market problem that a curated brand should
    never need to mention.
  - Drawer mixes customer and partner items in one long list (41:842). Information architecture blur.
  - Bulk bookings page uses a generic stock photo and a long grey form (41:840).
- **Scores (1 to 5):** visual polish 3, clarity 4, information density 3, trust 4, brand distinctiveness 4.
- **For 30 Sundays:**
  - Borrow for home and destination page: a promise band in the OYO-Serviced shape (41:845), one claim with
    a number and a row of icons, built from our three USPs, on tropicalForest instead of black.
  - Borrow for destination page and itinerary: booking-level proof lines ("120 trips to Bali this year",
    "4.8 on-trip rating") in lagoonBliss, no badges (41:839).
  - Borrow for itinerary hotel cards: labelled photo thumbnails (Room, Pool, Breakfast, View) (41:839).
  - Borrow for listing heads: say the unit once ("Price per person, flights included") instead of on every
    card (41:843).
  - Borrow for wizard and enquiry: a stated response time on any "we will call you" form (41:840).
  - Avoid: pre-ticked consent, "allow all the time" asks, % off on every card, and any "couples welcome"
    style reassurance.

---

### EaseMyTrip (OTA: flights, hotels; 17 screens, UK region build in pounds)

- **Flows covered (journey order):**
  - 41:909 Home, single Flights tile, Why Choose Us, Top Destinations, WhatsApp button
  - 41:907 Login sheet over Home, flight promo carousel, email or mobile, Gmail and Apple
  - 41:908 Guest manage booking page (booking ID plus email), OR login card
  - 41:906 OTP sheet, hotel promo carousel, single OTP field, Create My Account
  - 41:905 Home after login (same layout)
  - 41:911 System location prompt over Home
  - 41:910 App tracking prompt over Home
  - 41:904 Full-screen loader "searching for the flights on this route"
  - 41:903 Results, Best tab
  - 41:902 Results, Cheapest tab
  - 41:901 Results, Fastest tab
  - 41:900 Loader over blurred results "Getting more fares for you"
  - 41:899 Flight review, two segments, layover pill, Important Information
  - 41:898 Traveller details, passenger counts, passport note, contact, T&C box, Grand Total
  - 41:897 My Bookings, empty state with tabs
  - 41:896 Side drawer
  - 41:895 My Profile edit
- **Typography:** geometric sans, very likely Poppins, weights 400 to 600. Route titles 20 px semibold
  ("London to Cape Town" 41:901), flight times 22 px semibold, airport codes 13 px, body 14 to 15 px,
  captions 12 px. Caps for sort tabs (BEST, CHEAPEST, FASTEST) and "+ ADD ADULT". Prices bold 22 px right
  aligned in results (41:901); "Grand Total £740" with an info icon in the sticky bar (41:898).
- **Colour:** light theme with blue chrome. Primary blue about #2196F3 for top bars and headers (41:899,
  41:895); buttons often a blue gradient #2F80ED to #56CCF2 (41:906, 41:908). Final CTA switches to orange
  #FF6A13 on a dark navy sticky bar #1E2937 (41:898, 41:899). Urgency red #E53935 for "9 Seats Left"
  (41:901), pink pill #FDE7EA with red text for "Non-Refundable" (41:899), yellow info box #FFF7D1
  (41:899), WhatsApp green #25D366 floating button, olive brown for a Delete pill (41:895). Pale blue
  ground #DCEBFB on bookings (41:897). Three to four accents per screen (blue, orange, red, yellow on 41:899).
- **Layout and spacing:** 12 to 16 px gutters, cards at 12 px radius with a light grey border and soft
  shadow (41:901). The blue header curves or carries a world-map texture behind the first card (41:899,
  41:898), with the card overlapping it. Results are dense list cards with a column header row (Depart,
  Duration, Price) (41:903). Profile uses old Material underline fields (41:895).
- **Section designs:**
  - Home header: hamburger, logo, country selector with flag (41:909).
  - Category tiles: a lone "Flights" illustrated tile (41:909).
  - Trust and proof: "Why Choose Us" two tiles, Guaranteed Savings and IATA Agents, with icon and two
    lines (41:905).
  - Card rail: "Top Destinations" big circular photos (41:905).
  - Help and chat: floating WhatsApp button on every main screen (41:909, 41:896).
  - Login and OTP: bottom sheet with a promo image carousel on top, email or mobile, social sign-in as
    round icons (41:907); OTP as a single field with an SMS icon (41:906).
  - Other (guest booking lookup): "View / Cancel / Reschedule your reservation (as a guest user)" with
    booking ID and email (41:908).
  - Progress and status: full-screen loader with paper plane and plain sentence (41:904); loader over a
    blurred list while more fares load (41:900).
  - Filters and sort: three sort tabs that each preview their top result ("CHEAPEST £584, 16h 50m") plus
    Other Sort and a Filter link (41:901, 41:902, 41:903).
  - Listing card: airline logo and flight number, departure and arrival times big, route code in blue on a
    thin line, duration and stops, price right (41:902).
  - Itinerary and timeline: segment cards with dashed duration line, and a dashed-border layover pill "9h
    40m Layover in Dubai" between segments (41:899).
  - Detail sections: "Important Information" yellow box with bullet list (41:899).
  - Booking form: traveller counts with person icons (1 adult, 0 children, 0 infants), "Name should be same
    as in Passport" info line, + ADD ADULT, contact block, T&C checkbox (41:898).
  - Price display: sticky dark bar with Grand Total, info icon and a "Repricing" status dots (41:898).
  - Sticky CTA bar: navy bar, orange Continue Booking (41:899).
  - Bookings list: Flight tile plus Upcoming, Cancelled, Completed tabs with icons (41:897).
  - Empty state: hiker illustration "Currently you have no Bookings." with no action (41:897).
  - Profile: drawer with bordered cards for each item and app version (41:896); edit form under a curved
    blue header (41:895).
- **Strengths:**
  - Sort tabs that preview their best result let people compare Best, Cheapest and Fastest without
    tapping (41:901). A neat way to show trade-offs.
  - The layover pill between segments is clear and calm (41:899). Good timeline grammar.
  - "Name should be same as in Passport" sits exactly where names are entered (41:898). Error prevention.
  - Guest booking lookup with only booking ID and email (41:908). Low-friction access to a trip.
  - "Repricing" status next to the total admits that the price is being checked (41:898). Visibility of
    system status.
  - Loaders use one plain sentence about what is happening (41:904, 41:900).
  - WhatsApp help always one tap away (41:909). Matches how Indian travellers already talk to agents.
- **Weaknesses:**
  - Visually dated: Material underline fields, curved blue header, olive Delete pill (41:895). Low polish.
  - Colour system breaks at checkout: blue everywhere, then orange on navy for the final step (41:898).
    Consistency broken.
  - "9 Seats Left" in red on almost every flight card (41:901). Scarcity as default stops meaning anything.
  - The T&C box is unticked and sits away from the button (41:898); easy to miss, and the cause of a
    failed tap.
  - "EaseMyTrip holds no liability with respect to transit visa" (41:899) as the first important
    information. Defensive legal copy where reassurance should be.
  - The drawer greets the user by phone number, "Hi, 9871177895" (41:896). Cold, and a privacy leak on
    screen.
  - Home in this region has only one product tile and a lot of white (41:905); "Guaranteed Savings" shows a
    dollar money bag in a UK build.
  - Empty bookings has no way forward (41:897).
  - The guest lookup and the login both use a gradient blue button of equal weight (41:908). Two primary
    actions.
  - ATT and location prompts fire on the Home before any task (41:910, 41:911).
- **Scores (1 to 5):** visual polish 2, clarity 3, information density 3, trust 3, brand distinctiveness 2.
- **For 30 Sundays:**
  - Borrow for itinerary: the layover pill grammar for transit days, flights and long transfers ("3h drive
    to Ubud" between day cards) (41:899).
  - Borrow for wizard route step: option tabs that preview their key number ("Fewest hotel moves, 2
    hotels", "Most islands, 4 stops") (41:901).
  - Borrow for booked trip: guest lookup by trip ID and email for family members who did not book
    (41:908).
  - Borrow for itinerary checkout: a quiet status line when the price is being rechecked ("Checking latest
    price") next to the total (41:898).
  - Borrow for traveller forms: the "same as passport" note at the point of entry (41:898).
  - Avoid: liability copy in the hero position of a review, greeting by phone number, gradient buttons,
    scarcity badges, and a dead-end empty state.

---

### Group summary

- **Patterns that repeat, by component kind:**
  - Splash: brand-colour flood with wordmark and a short line (Cleartrip 35:130, BookMyShow 41:459).
  - Login and OTP: phone-first with +91, OTP as 4 to 6 boxes with a countdown, shown as a bottom sheet over
    the current page so the user never loses context (35:128, 41:456, 41:850, 41:907). Two of four put a
    promo carousel above the login form (35:128, 41:907).
  - Search bar: a summary pill (place, dates, guests) that stays on results and detail and opens the edit
    (35:121, 35:109, 41:843, 41:848).
  - Filters and sort: outlined chip row above results plus a full filter sheet (35:109, 41:450, 41:843);
    the best versions show the cost or outcome of each option inside the control (35:119, 41:901).
  - Listing card: photo, rating with count, name, place, 2 to 3 inclusion lines, price with taxes on a
    second line (35:109, 41:843, 41:848).
  - Price display: total plus "taxes and fees" always visible, often a breakup link (35:104, 35:111,
    41:839, 41:898). Strike-through and % off are near universal (35:109, 41:843).
  - Sticky CTA bar: price left, one button right on every booking step (35:104, 41:429, 41:839, 41:899).
  - Trust and proof: numeric social proof (bookings in a period, people interested, ratings counts) and
    promise checklists (41:839, 41:449, 41:429, 41:845, 41:905).
  - Offers and coupons: coupon strips, ticket-notch cards and bank offers on almost every step (35:104,
    35:124, 41:444, 41:844).
  - Empty state: illustration, one line, one dark button (35:127, 41:847); EaseMyTrip forgets the button
    (41:897).
  - Bookings list: tabs by product or by status (35:127, 41:897).
  - Help and chat: WhatsApp button (41:909) and coachmark tooltips (41:447).
  - Progress and status: named stepper (41:428), loaders with a sentence (41:904).
  - Profile: flat list with line icons, inline promo tags, referral row (35:125, 41:427, 41:842).
  - Referral: Invite and Earn with an amount (35:125, 41:842).

- **The 5 best section designs for a travel app like ours (ranked):**
  1. **Promise band, OYO-Serviced (41:845), Trust and proof.** One claim with a hard number and five icons
     of what is guaranteed. It is the cleanest way to turn our three USPs into something a person can check.
     Rebuild on tropicalForest with cream icons for home and destination page.
  2. **Fare comparison cards, Cleartrip (35:116), Comparison.** Same icon grid in every card, Selected
     state, price with what changes. Direct fit for itinerary versions and hotel tiers.
  3. **Sticky price bar with taxes and breakup, Cleartrip (35:104, 35:111), Price display.** Total, "with
     taxes and fees", tap to see the breakup, one button. The honest total is what our quotes need on the
     itinerary and booked trip.
  4. **Review hashtags with counts, BookMyShow (41:449), Reviews and ratings.** Thousands of reviews in one
     scannable row. For destination pages, themed on what our travellers praise (hotels, transfers, help on
     trip).
  5. **Layover pill between segments, EaseMyTrip (41:899), Itinerary and timeline.** A calm, dashed
     connector that names the gap ("9h 40m layover in Dubai"). Exactly the grammar for transfers and
     transit days between itinerary days.
  - Close runners-up: labelled photo thumbnails on hotel detail (OYO 41:839), "How many seats?" sheet with a
    reacting illustration for the wizard traveller step (BookMyShow 41:446), sort tabs that preview their
    best result for route options (EaseMyTrip 41:901), location soft ask with recovery (BookMyShow 41:455,
    41:454), and the review ticket card for booked trip (Cleartrip 35:105).

- **The 5 things to never copy:**
  1. **Pre-ticked marketing consent (OYO 41:849).** A dark pattern and a legal risk; consent must be
     opt-in.
  2. **System permission prompts on the first screen (BookMyShow 41:458, 41:457; EaseMyTrip 41:910,
     41:911; OYO 41:852 asking for "allow all the time").** Ask only after showing value, in our own
     words first.
  3. **Paid "PROMOTED" items inside "Recommended" (BookMyShow 41:451, 41:450).** Mixing ads with advice
     destroys the very thing a curated brand sells.
  4. **Scarcity and discount theatre on every card ("9 Seats Left" EaseMyTrip 41:901, "Filling Fast"
     BookMyShow 41:429, 80% off strike prices OYO 41:843, stacked WOW savings Cleartrip 35:121).** It
     cheapens the product and makes the real price feel fake. It also breaks our no-solid-pill and no
     red-or-green rules.
  5. **Two equal primary buttons on one screen (BookMyShow 41:437; EaseMyTrip 41:908).** Breaks our one
     fuchsia action rule and slows the decision.
  - Also avoid: validation by toast instead of a disabled button with a hint (BookMyShow 41:428),
    defensive liability copy as the first information (EaseMyTrip 41:899), greeting by phone number
    (EaseMyTrip 41:896), and a hero that sells a product the user did not come for (Cleartrip 35:129).
