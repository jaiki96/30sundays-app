# Group travel-2: Headout, ixigo, redBus, Yatra

114 screens studied (Headout 21, ixigo 25, redBus 36, Yatra 32). Node ids are Figma ids (open with the colon form). The file order on the canvas is reverse chronological (newest screenshot first), so the flows below are re-ordered into the order a user would meet them. No designer notes sit on this part of the canvas, only the four app labels (41:934, 41:960, 112:72, 112:73).

---

### Headout (experiences and activities marketplace, 21 screens)

Headout is the closest thing in the whole group to a 30 Sundays destination page: a city, a ranked list of things to do, a product detail, and a dated booking. Read it closely.

- **Flows covered:**
  - 41:933 Splash. Purple airship mark inside a pale lilac scalloped frame on white.
  - 41:932 Notification pre-prompt. Illustrated phone with two sample notifications, "Ding, ding!", three benefit rows, purple "Stay updated", text "Not now".
  - 41:930 Explore with no city chosen. Photo hero with "Select a city" picker, overlapping search card, "World's top destinations" circle rail, location card, "Top attractions globally" tall card rail.
  - 41:931 Same screen with a coachmark on the city picker ("New" tag, "Tap here to change your location", black "Got it").
  - 41:919 Select a city, default. Search, location card, Recent searches, Nearby, All locations, each row a rounded square city photo with country underneath.
  - 41:918 Select a city, typing "p", results not yet loaded (blank white).
  - 41:917 Select a city, results for "p" (Paris, Perak, Prague, Phuket, Page).
  - 41:926 London city home. Photo hero, city picker, search with rotating placeholder, location card, "Top 10 trending things to do" with item 1 expanded.
  - 41:921 London list scrolled. Items 2 to 4 collapsed, each with rank numeral, rating, "bookings last month" chip, two-line blurb, "from" price with chevron, then "See 6 more".
  - 41:920 London item 2 expanded into "Experience the best of it", a rail of bookable variants including a combo with strike price and "15% off" tag.
  - 41:916 Prague city home, same template.
  - 41:915 Prague item 2 expanded, combo "Save 6%" card.
  - 41:925 Product detail (Phantom of the Opera). Video hero with play button and dots, dark title band with category in caps and pink rating link, fact rows (Duration, Age Limit), description, "Your experience" accordion, sticky "from Rs 4,016" plus purple "Check availability".
  - 41:924 Date step. Horizontal date strip, each date with its price, cheaper dates in a green tint, "More dates" calendar tile, a single-time info card, sticky date summary plus "Next".
  - 41:923 Seat map. Theatre map with zoom controls, tooltip on a chosen seat (C27, Royal Circle, price), price-tier chips at the bottom, sticky "3 seats | Rs 55,819", "View details", "Next".
  - 41:922 Review and pay. Dimmed show image behind a summary card (date tile JUN 4 Thu, time, guests, seats, Total payable with chevron), lead guest form, promo code link, payment options below, sticky total plus "Confirm & pay".
  - 41:929 Bookings tab when logged out. Octagon photo, "Hop in! We're going places", Google, Apple, email buttons.
  - 41:928 Bookings empty state. Upcoming / Completed tabs, pink notification band with black "Notify me", octagon photo, "Your next experience awaits", purple "Browse experiences", outline "Can't find your booking?".
  - 41:927 Account. Name, email, octagon avatar with a soft glow, pink "Ditch the mail, get app alerts" card with 3D mailbox, Essentials list (Credits, Audio guides, Saved cards, Promo codes, Language, Currency).
  - 41:914 Delete account sheet. Octagon photo of puzzled people in costume, "Think twice-this action is permanent", three bullets, "I'll stay" grey and "Delete account" black.
  - 41:913 Account deleted confirmation sheet over Account, plus the "Earn rewards for your feedback" card and Support list behind it.
- **Typography:** Grotesque sans with slightly narrow, friendly forms, very likely Headout's own Halyard (Display for headings, Text for body). Weights 400 to 700, no light weights. Hierarchy at 390 wide: page section titles about 20 px semibold ("Top 10 trending things to do", 41:926), list item titles 20 to 22 px semibold (41:921), card titles 16 px semibold (41:920), body 15 to 16 px regular grey (41:925 description is 16 px with 1.6 line height and italics for the show name), captions 13 px ("6K+ bookings last month"). Sentence case everywhere except the category label in caps with letter spacing ("MUSICALS", 41:925). The rank numerals are a heavy italic display face in a purple-to-magenta fill with a white keyline, about 40 px, cutting into the photo corner (41:921). Prices: "from" in lowercase grey 15 px, then the rupee amount bold 17 px; on cards the "from" sits on its own line above a bold 18 px price, with the old price struck through in grey and a small green "x% off" tag (41:920). Totals bold 18 px (41:922).
- **Colour:** Light theme. Primary purple about #8000FF on all money buttons (41:922, 41:925, 41:928). Secondary black about #222222 for system and utility buttons ("Okay", "Got it", "Notify me", "Delete account", 41:913, 41:931, 41:914). Rating magenta about #E5006E (stars and counts, 41:921). Numeral gradient about #7A1FA2 to #C2185B. Discount tag green about #0A8A3A (41:915). Promo link teal about #0F7C8C (41:922). Grounds: white, a pale grey band about #F8F8F8 behind the expanded rail (41:920), pink tint about #FFF0F6 for notification bands (41:928, 41:927), cyan-to-mint gradient on the location card (41:916). Text: near black #222, body grey about #555, caption grey about #888. Accents fighting on one list screen: purple numerals, magenta rating, green tag, plus the cyan location card, so four (41:915). Gradients only in small doses (numerals, location card, soft glow behind octagons).
- **Layout and spacing:** 16 px side gutters. Generous white space on detail and empty states, medium density on lists. Cards radius about 12 px, photo thumbnails about 10 px. Very few shadows; the search card on the hero has a light shadow (41:926), everything else uses 1 px light borders (Essentials list, 41:927) or nothing. Image ratios: list thumbnails about 3:4 portrait (41:921), rail cards about 16:10 (41:920), global attraction cards tall 2:3 (41:930), hero photos full bleed about 1:0.55. Sections separated by white space and one tinted band (the expanded rail sits on grey with a small caret pointing up at its parent, 41:920). The brand shape is an elongated octagon frame used for every hero image on empty, login, delete and avatar (41:929, 41:928, 41:914, 41:927).
- **Section designs:**
  - Splash: brand mark inside the brand frame shape, nothing else (41:933).
  - Notifications: full-screen pre-prompt that shows two sample notifications and three benefits before the system prompt (41:932).
  - Home header: full-bleed city photo with a city picker ("London" with caret) and a help icon, white text on photo (41:926).
  - Search bar: white card overlapping the bottom of the hero, rotating placeholder "Search for Burj Khalifa / Eiffel Tower / Vatican Museums" (41:926, 41:921, 41:930).
  - Other (permission card): inline "Enable location" card with illustration, one line of reassurance ("Location stays private") and a toggle (41:916).
  - Category tiles: circular destination photos with names underneath, horizontal rail (41:930).
  - Card rail: tall portrait attraction cards with the rank numeral hanging off the bottom left (41:930).
  - Listing card: ranked row, portrait photo left with a big italic numeral, right side rating, proof chip, title, two-line blurb, "from" price with chevron that expands the item (41:921).
  - Card rail (nested): "Experience the best of it", the expanded child rail of bookable variants for one ranked item, on a grey band with a pointer to the parent (41:920).
  - Trust and proof: "14K+ bookings last month" chip with a tiny overlapping avatar stack (41:926, 41:921).
  - Price display: "from" plus bold amount on rows; strike price plus bold new price plus green percent tag on combo cards; combo saving also written into the title "Combo (Save 15%)" (41:920).
  - Other (show more): full-width outline "See 6 more" ending a top-10 list after 4 items (41:921).
  - Detail hero: video-first hero with play button and slide dots, dark title band with category caps, rating link and title (41:925).
  - Detail sections: icon fact rows (Duration, Age Limit), long description, collapsible "Your experience" accordion (41:925).
  - Sticky CTA bar: "from" price left, one purple action right (41:925); date summary left with "Next" (41:924); seats and total with "View details" link (41:923).
  - Date picker: horizontal strip of days, each day showing its own price, cheaper days tinted, unavailable days greyed with a dash, "More dates" calendar tile at the end (41:924).
  - Other (single slot notice): peach info card "This experience is available only at this time" instead of a one-option time picker (41:924).
  - Other (seat map): zoomable venue map, tooltip with seat, section and price, price-tier legend chips (41:923).
  - Booking form: summary card over dimmed hero, floating-label inputs, confirm-email field, country code split field, promo code as a quiet link (41:922).
  - Login and OTP: three equal outlined social buttons under a brand photo and a one-line benefit promise (41:929).
  - Empty state: brand-framed photo, warm headline, scale claim ("10K+ activities ... 200+ cities"), one primary and one outline action (41:928).
  - Bookings list: Upcoming / Completed tabs (41:928).
  - Profile: name, email, framed avatar, settings list in a bordered card with values on the right (Credits $0.00, English, INR) (41:927).
  - Other (account deletion): friction sheet with consequences and an equal-weight "I'll stay" (41:914), then a plain confirmation sheet (41:913).
  - Other (coachmark): single tooltip with "New" tag on a changed control (41:931).
  - Bottom nav: three tabs only, Explore, Bookings, Account (41:926).
- **Strengths:**
  - The ranked "Top 10 trending things to do" with inline expansion (41:921, 41:920) is the best way in the whole group to show things to do in a place: a rank gives instant order, the expanded rail shows the actual bookable versions without leaving the city page, and "See 6 more" keeps the page short.
  - Social proof is specific and recent: "14K+ bookings last month" (41:926), not a vague "popular". Ratings always carry the count, "4.7 (83,180)" (41:926).
  - Price is always framed as "from" on browse and exact at checkout (41:921 to 41:922). Combo saving is stated in words in the title and again in the tag (41:920).
  - The date strip shows price per day, so the user can trade date for money in one glance (41:924). This is the pattern for a month picker.
  - The single-time card (41:924) avoids a fake choice. Good "recognition rather than recall".
  - Review and pay (41:922) keeps the order summary above the form, so the user never loses what they are paying for, and the sticky bar keeps total and action visible. "View details" expands the breakdown on demand.
  - One brand shape (the octagon frame) and one illustration style make utility screens feel owned (41:929, 41:928, 41:914, 41:932).
  - Three-tab bottom nav (41:926). Very calm compared with the five-tab nav in the other three apps.
  - Delete flow is honest: consequences listed, "I'll stay" as an equal option, no guilt copy (41:914).
- **Weaknesses:**
  - Blank screen while city search loads (41:918), no skeleton or spinner. Breaks "visibility of system status".
  - Total differs by one rupee between seat map and review (Rs 55,819 on 41:923, Rs 55,818 on 41:922). Small, but it hurts trust at the exact moment of paying. Breaks "consistency".
  - Two primary colours: purple for money actions, black for system actions (41:931, 41:928 has both on one screen: black "Notify me" and purple "Browse experiences").
  - The same notification ask appears four ways: full-screen pre-prompt (41:932), pink band on Bookings (41:928), pink card on Account (41:927), toggle in settings (41:913). The location card repeats on every city page (41:916, 41:926, 41:930). Nagging.
  - The "from" price on list rows doubles as the expand toggle (chevron next to the price, 41:921). It is not obvious that tapping the price opens a rail. Weak affordance.
  - Four accents on the list (41:915): purple numerals, magenta stars, green tag, teal/cyan location card.
  - Copy: "Think twice-this action is permanent" (41:914) jams a hyphen where a full stop belongs; delete sheet is a wall of legal text. "Epic experiences" (41:916) is hype.
  - Blurbs truncate mid-word with ellipsis on every row (41:921), adding noise for little information.
- **Scores (1 to 5):** visual polish 4, clarity 4, information density 4, trust 4, brand distinctiveness 4.
- **For 30 Sundays:**
  - Destination page: borrow the ranked top list with inline expansion for "things to do" (41:921, 41:920). Rank numerals in our handwriting display face, in fuchsia or navy, would be very ownable. Show 4, then "See all". Let each item expand into the 2 or 3 ways we include it (half-day, full-day, private) instead of a separate page.
  - Destination page: borrow the proof chip "X couples/travellers went last month" style (41:926), using lagoon teal (our proof colour), never a solid pill. Keep the rating with its count.
  - Wizard: borrow the date strip with a price under each option (41:924) for the month step, "from Rs X" per month. Mark the best value month with a lagoon dot or the word "Lowest", not with green.
  - Wizard and itinerary: borrow the sticky bar with total left, "View details" link and one fuchsia action right (41:923, 41:925). Borrow the single-slot notice card (41:924) for fixed things like a fixed ferry time.
  - Itinerary checkout: borrow the summary card pinned above the form (41:922), with a date tile, people and total.
  - Booked trip and wishlist empty states: borrow the brand-framed photo plus one warm line plus one action (41:928). Our equivalent of the octagon could be a postcard or stamp frame.
  - Profile: borrow the bordered settings card with values on the right (41:927) and the honest delete sheet with an equal "Stay" button (41:914).
  - Avoid: two primary colours, repeated permission asks, blank loading states, price mismatches between steps, and the price-as-toggle affordance.

---

### ixigo (trains, flights, buses super app, 25 screens)

- **Flows covered:**
  - 41:959 Splash. Solid blue, train mark, "IRCTC Authorised Partner" seal at the bottom.
  - 41:957 Welcome sheet "Welcome to ixigo trains" with "Proceed" over the dimmed home.
  - 41:958 iOS tracking prompt stacked on top of the welcome sheet.
  - 41:956 Notification pre-prompt sheet (bell illustration, "Next", "Later").
  - 41:955 Location pre-prompt sheet (pin on rails, "Next", "Later").
  - 41:953 Login sheet with three ticked benefits, mobile or email field, grey "Continue", social dropdown.
  - 41:954 "Yay! All Set" success sheet with "Get started".
  - 41:951 Trains home, From filled, To empty. Mode tabs with illustrated icons (Trains, Flights with "Flat 19% off" sticker, Buses, Hotels), form card, Tomorrow / Day After chips with "Tatkal open" strips, Assured opt-in, blue "Search Trains", IRCTC line, Running Status and PNR tiles, tool grid with "New" badges, video ad.
  - 41:949 Same home with both stations filled.
  - 41:952 Station search with "Nearest Station" and Popular Stations.
  - 41:950 Station search with Preferred Stations (starred) and Popular Stations.
  - 41:945 Train results. Route pill header with WhatsApp share, date strip with "Few Seats" dots, Assured opt-in bar, train card with class cards (SL, 3A, 2A), "Confirm or 3X Refund" ribbons, waitlist numbers, confirmation chance and alternate price, freshness stamps, cross-sell bus banner, filter bar.
  - 41:946 Results for another date with a red "WL 84 Low Chance" class card.
  - 41:947 Results for today, all red "Train Departed / Not Available" cards.
  - 41:948 Interrupting modal "Not sure about your travel dates? Opt Assured & get 100% refund", "Not now" / "Secure my trip".
  - 41:942 Train availability, Ladies quota, all dates "Not Available" in red, greyed Book buttons.
  - 41:943 Senior Citizen quota with green "AVL 23 Available" and outlined green Book buttons.
  - 41:944 General quota with waitlist rows, "91% Chance Rs 800" and "Alternate Rs 815" buttons, "Check WL Trends", "Check 2 Months Calendar".
  - 41:941 Book Flights form. One Way / Round Trip segmented, From / To, date, travellers, Special Fares chips, Assured opt-in, Search, tool grid with New / Pro / Free badges.
  - 41:940 Abhibus (bus) search. Green trust strip "Trusted by 5 crore+ Indian travellers", save banner, From / To with swap, date chips with "Today" label, Search Buses, quick links, celebrity login banner.
  - 41:939 Bus results. Route pill, Assured banner rail, "Popular Filters" with tabs and chips, operator group card (TGSRTC, rating, "Starts @Rs 946", coupon strip), ad card with "Top Rated" badge, amenities chips, "20 Seats Left", floating "Total 214 buses" toast, quick filter tiles plus "Sort & Filter".
  - 41:938 ixigo money tab. Blurred balance with "Log in to view your redeemable balance", wallet tiles, "Offers for you" carousel, "What's New".
  - 41:937 Bookings. Plain category list (Train, Failed Train Bookings, Flight, Bus, Hotel, Food Orders, Metro) with "Add PNR" floating button.
  - 41:936 Contact Us. "Need help with your recent booking?" with "Log in Now", Quick Guide list.
  - 41:935 Profile logged out. Grey avatar, "Easier Bookings, Faster Refunds", Login, long list of rows with blue icons and subtitles.
- **Typography:** Rounded grotesque, looks like Google Sans / Product Sans style (open "g", round dots). Weights 400 to 700. At 390 wide: home station values 18 px medium (41:949), card prices 16 px bold, class codes 15 px bold, list row titles 17 px regular with 14 px grey subtitles (41:935), captions 11 to 12 px ("25 mins ago", "Few Seats"). Title Case on nearly every label ("Easier Bookings, Faster Refunds", "Opt For Alternate Travel Plan"). Prices are plain bold rupees, often right aligned in class cards (41:945); waitlist numbers big and green (41:944).
- **Colour:** Light theme. Primary blue about #0770E3 (Search buttons, links, 41:949); splash blue about #1A56BE (41:959); navy about #0B3D91 ("Log in Now", 41:936). Semantic: green about #1E8E3E for available and waitlist-likely (41:944), red about #D93025 for not available and departed (41:947), pink-red tint about #FDECEC behind red cards, mint tint about #EAF7EE behind green cards, brown dot for "Few Seats" (41:945). Badges: purple about #7A2BD6 "New", green "Free", blue "Pro" (41:941). Promo yellow about #FFD23F and orange about #FF6B00 (41:945). Text near black #1F1F1F, grey #5F6368. On the results screen (41:945) blue, green, red, yellow and navy all compete, so five accents. Gradients on banners only.
- **Layout and spacing:** 16 to 20 px gutters. High density on results, medium on home. Cards radius about 12 to 16 px with light borders, a few soft shadows (form card, 41:949). Class cards are small bordered tiles in a horizontal scroller (41:945). Sections split by light grey bands and dividers. Images: almost none, mostly icons and ad banners at about 2.4:1.
- **Section designs:**
  - Splash: solid brand colour with mark and a partner seal (41:959).
  - Onboarding: sequence of bottom sheets for welcome, tracking, notifications, location, login and success (41:957, 41:958, 41:956, 41:955, 41:953, 41:954).
  - Login and OTP: sheet with three ticked benefits and a single mobile-or-email field (41:953).
  - Category tiles: mode tabs with illustrated 3D icons and a discount sticker on one (41:951).
  - Booking form: stacked From / To with swap, date with quick "Tomorrow / Day After" chips each carrying a status strip ("Tatkal open") (41:949).
  - Trust and proof: "IRCTC Authorised Partner" line under the search button (41:949); "Trusted by 5 crore+ Indian travellers" strip (41:940).
  - Offers and coupons: "Always opt for Assured, Rs 0 cancellation fee" opt-in row inside the search form (41:941).
  - Search bar: full-screen station search with Nearest, Preferred (starred) and Popular sections (41:952, 41:950).
  - Date picker: horizontal date strip in results with availability hint under each date (41:945); journey date chips with "Today" label (41:940).
  - Listing card: train card with route times, duration, and a rail of class cards showing class, price, status, chance and a guarantee ribbon (41:945).
  - Progress and status: freshness stamps above each class card ("25 mins ago", "Just Now") (41:945).
  - Trust and proof: confirmation probability ("91% Chance", "85% Chance") and "Confirm or 3X Refund" guarantee ribbons (41:944, 41:945).
  - Filters and sort: quota tabs (General, Senior Citizen, Ladies) (41:943); bottom filter bar with toggles (Available, AC Only) (41:942); bus "Popular Filters" tabs plus chips (41:939); quick filter tiles plus "Sort & Filter" (41:939).
  - Listing card (group): operator cluster card with count, seats, rating and "Starts @" price (41:939).
  - Other (result count toast): floating green "Total 214 buses" pill (41:939).
  - Hero banner: cross-sell banner between results, "Train waitlisted? Book bus now" (41:945).
  - Other (interrupting modal): upsell dialog mid-results (41:948).
  - Wallet and rewards: blurred balance as a login tease, wallet tiles, offer carousel (41:938).
  - Bookings list: category index rather than a list of trips (41:937).
  - Help and chat: Contact Us with Quick Guide list (41:936).
  - Profile: long icon list with a subtitle on every row (41:935).
  - Bottom nav: five tabs, Home, ixigo money, Bookings, Contact Us, Profile (41:935).
- **Strengths:**
  - Freshness stamps on every availability number ("8 mins ago", 41:945) tell users how much to trust the data. Strong "visibility of system status".
  - Confirmation probability with an alternate price (41:944) turns a scary waitlist into a decision. Prediction plus a plan B.
  - Quick date chips with a status strip (41:949) answer the next question before it is asked.
  - Station search remembers favourites and offers nearest (41:950, 41:952).
  - Floating count toast (41:939) gives the size of the result set without taking a row.
  - Partner seal on splash and under search (41:959, 41:949) is quiet, relevant trust.
- **Weaknesses:**
  - Six interruptions before the first search: welcome, tracking, notifications, location, login, success (41:957, 41:958, 41:956, 41:955, 41:953, 41:954). Breaks "user control and freedom".
  - Mid-results upsell modal (41:948) blocks the list the user is reading. Dark pattern adjacent.
  - Badge storm: "New", "Pro", "Free", "Flat 19% off" on one home (41:941, 41:951).
  - Red and green carry all status (41:942, 41:946, 41:947); colour-blind users lose the meaning where the text is small. A whole screen of red cards (41:947) feels like an error page.
  - Bus results pack about six chip types, an ad, a banner and a toast into one viewport (41:939). Weak hierarchy.
  - Bookings tab is a category menu, not your trips (41:937); "Failed Train Bookings" as a top-level row shows the internal model leaking out.
  - Every profile row has a subtitle that repeats the title (41:935, "My Bookings / View your travel bookings").
  - The tracking prompt fires on top of the welcome sheet (41:958 over 41:957), before the user knows what the app is. Two modals stacked.
  - Five-tab nav including a wallet and a contact tab (41:935).
- **Scores (1 to 5):** visual polish 3, clarity 3, information density 2, trust 4, brand distinctiveness 2.
- **For 30 Sundays:**
  - Itinerary and booked trip: borrow the freshness stamp idea for live things ("Prices checked 2 hours ago", "Hotel confirmed today") in caption grey.
  - Wizard: borrow quick chips with a one-line status under them (41:949), for example month chips with "Best weather" or "Peak prices" in small text. Keep them as outlined chips, not solid pills.
  - Destination page and itinerary: borrow the guarantee line placed right under the main action (41:949, IRCTC seal) for our own promise, in lagoon teal.
  - Avoid: prompt chains on first launch, modals during reading, badge storms, red and green for status, five-tab nav, subtitles under every row.

---

### redBus (buses, trains, hotels, metro, 36 screens)

- **Flows covered:**
  - 113:106 Splash, red bus logo on white.
  - 113:105 Splash variant, logo plus "Let's get started on your journey with redBus!".
  - 113:104 Country and language picker (India, English), red "Get started".
  - 113:103 Same picker for Indonesia in Bahasa, showing the app localised.
  - 113:102 Onboarding 1/3 "19 Years of happy journeys!" with three stat bullets and illustrated people, login sheet with mobile and Google.
  - 113:101 Location pre-prompt "Enhance your travel experience" with a map showing "Your nearest BP", "Continue", "Skip".
  - 113:100 Spotlight coachmark on Offers, "Get maximum discount on your next trip".
  - 113:98 Login sheet "Enter mobile number to unlock redBus special prices", "Get OTP", "Have a referral code?".
  - 113:80 OTP entry, six boxes, number with "Edit", loading button.
  - 113:90 Bus home. Mode tabs with stickers ("Rs 100 Off", "Upto 45% off", "New"), From / To, date with Today / Tomorrow chips, "Booking for women" toggle, red "Search buses", Government Buses rail.
  - 113:95 Bus home variant with illustration and subtitle "Exciting offers & discounts, 24*7 customer service(call/chat)".
  - 113:81 Bus home filled, women toggle on, snackbar "Booking for women enabled" with "Undo".
  - 113:89 Destination search, "Popular Destinations from Kashmiri Gate", "Nearby Cities".
  - 113:88 Bus results (432). Route header with count and date, promo card rail, "Filter and Sort" plus chips, government operator group cards ("HRTC Buses (17 Buses) From Rs 285") stacked like a deck, "Direct Bus" tag, "Free bus change" chip.
  - 113:87 Filter sheet, Sort by tab (Relevance, Price, Best rated, Early, Late).
  - 113:86 Filter sheet, Bus Type with counts.
  - 113:85 Filter sheet, Amenities with search and counts, "View 307 buses".
  - 113:84 Filtered results (307). Active red "SLEEPER" chip with x, filter count badge, cards with time, duration, seats, strike and new price "Onwards", rating chip with count, "Comfort score 8.7/10", "81% On Time", "Exclusive 12.5% OFF" tag.
  - 113:83 Seat map with price under each seat, sold and women-only seats, bottom sheet with operator, rating, photo, "Volvo 9600 Premium", "Bus Safety Available".
  - 113:82 Bus detail. Operator, time, rating, photo rail, tabs (Highlights, Booking policies, Bus route), feature cards, "Cancellation and refund policy" table comparing without vs with free cancellation.
  - 113:93 Train home with festival illustration, coupon ribbon on the form, "Opt-in for Free Cancellation" toggle, "Get Rs 150 off" art.
  - 113:76 Train home variant with "Seats filling fast" subtitle.
  - 113:94 Festival promo sheet "Rath Yatra Bookings are Now Open!", "Book Now", "Close".
  - 113:92 Hotels home "Pocket-friendly, comfortable stays", "30,000+ affordable stays" strip, form, "Lowest price guaranteed", "The Budget Collection" with subtitle.
  - 113:91 Metro login sheet "Enter your mobile number to book your metro ticket!".
  - 113:75 Coach Position tool, form plus "More rail information services" tiles.
  - 113:74 Order Food (partner page) with PNR field and IRCTC trust card.
  - 113:79 Offers tab. Dark header "ZERO convenience fees", "Lowest price guaranteed" octagon seal, "Offers for your next trip" route card, "MAXX savings combos".
  - 113:78 Help. "Need help with this trip?" empty with cat illustration, "Recent issues" empty, FAQ search, FAQ tiles per mode.
  - 113:97 Help login sheet "Enter your mobile number for quick help".
  - 113:99 My Bookings logged out, cat on suitcases, "Login to manage your trips", pink "Login".
  - 113:96 My Account logged out, "Log in to manage your bookings", red Log in, My details list, Payments.
  - 113:77 Personal information form (name, DOB, gender radio cards, state with "Required for GST" helper, phone, optional email), "Save changes".
  - 113:109 Account Settings with "Log out" and red "Delete account".
  - 113:107 Delete account page, warning triangle, "permanently delete your account in 90 days", three consequences, grace date box ("until 07 Sep 2026"), optional feedback, red "Keep my account with redBus", outline "Delete my account".
  - 113:108 Confirm deletion sheet, red "Yes, Delete", outline "Go back".
- **Typography:** Neo-grotesque that matches iOS system, most likely SF Pro (Display for 28 px titles, Text for body). Weights 400 to 700, headings heavy. At 390 wide: page titles 28 to 30 px bold ("Bus Tickets", 113:90), section titles 22 px bold ("Government Buses", "Cancellation and refund policy", 113:82), form values 18 px semibold, card times 18 px bold, body 16 px, captions 13 px grey. Sentence case mostly, with some Title Case and some ALL CAPS chips ("SLEEPER", 113:84; "LOWEST PRICE GUARANTEED", 113:92). Prices: bold 18 px right aligned with "Onwards" below in grey 13 px; old price struck through in grey before it (113:84); per-seat prices 11 px under each seat icon (113:83).
- **Colour:** Light theme with dark and gradient heroes. Primary red about #E3193A (all main buttons, 113:90). Pink tint about #FBD9D9 for date chips (113:90). Rating green about #1E8A3E with a pale green count strip (113:84). Comfort chip lavender about #ECE6FB with purple text (113:84). Exclusive tag yellow about #FCE59A (113:84). Links in default-looking blue about #1A1AE6 ("Close", "View all", "Know more", 113:85, 113:78). Offers tab ground near black about #1C1C22 with orange-yellow text (113:79). Festival gradients from peach #FCE3CF to navy #1D2A5B (113:76). Text #1A1A1A, grey #6B6B6B. Grounds white and light grey #F2F2F5. Accents on results (113:84): red, green, lavender, yellow, blue, so five. Red is used for brand, active filter, error and delete all at once.
- **Layout and spacing:** 16 px gutters. Big bold page titles with lots of air on home, dense on results. Cards radius about 16 px with soft shadow plus hairline border (113:84). Pill buttons fully rounded. Floating pill bottom nav with the active tab in a grey capsule (113:90). Sections separated by grey bands and big type. Images: operator photo rail about 16:10 (113:82), promo cards square-ish (113:84).
- **Section designs:**
  - Splash: logo only (113:106), logo plus one warm line (113:105).
  - Onboarding: country and language picker first (113:104); stat-led slide "19 years, 4 crore+ travellers, 4400+ operators" with paged dots and a login sheet below (113:102).
  - Other (permission explainer): location ask with a map illustration of the actual benefit, "Your nearest BP" (113:101).
  - Login and OTP: mobile with country code split field, Google alternative, referral link (113:102); six-box OTP with "Edit" on the number (113:80).
  - Category tiles: mode tabs with offer stickers (113:90).
  - Booking form: big title, From / To with swap, date with Today / Tomorrow chips, one feature toggle, full-width search (113:90).
  - Other (undo snackbar): toggle confirmation with "Undo" (113:81).
  - Search bar: destination search with "Popular from X" and "Nearby" lists (113:89).
  - Offers and coupons: promo card rail at the top of results (113:88); coupon ribbon on top of the train form (113:93).
  - Listing card (group): stacked operator cards "HRTC Buses (17 Buses) From Rs 285" (113:88).
  - Listing card: time range, duration, seats, price "Onwards", rating chip, comfort score, on-time percentage, feature chips (113:84).
  - Filters and sort: two-column sheet, left category rail with selected counts, right options with result counts, live "View 307 buses" button (113:85, 113:86, 113:87).
  - Detail hero: operator header with rating and a photo rail (113:82).
  - Detail sections: tabbed "Highlights, Booking policies, Bus route" with feature cards (113:82).
  - Comparison: cancellation table, rows by time before departure, columns without vs with free cancellation (113:82).
  - Other (seat map): grid with price per seat, sold state, women-only seats in pink (113:83).
  - Trust and proof: "ZERO convenience fees" and "Lowest price guaranteed" seal (113:79); "30,000+ affordable stays" strip (113:92); stats slide (113:102).
  - Hero banner: festival illustration bands (113:93); promo sheet (113:94).
  - Help and chat: trip-first help with empty states, FAQ search and tiles (113:78).
  - Empty state: cat on suitcases illustration plus one line plus a soft action (113:99).
  - Profile: logged-out list with big title and login button (113:96); personal info form (113:77).
  - Other (account deletion): grace-period deletion with date, optional feedback, two-step confirm (113:107, 113:108).
  - Bottom nav: floating five-tab pill, Home, My Bookings, Offers, Help, My Account (113:90).
- **Strengths:**
  - Filter sheet (113:85) is best in class: categories on the left, counts per option, a search inside long lists, and the button shows how many results you will get. Strong "visibility of system status" and "error prevention" (no zero-result dead ends).
  - Cancellation table (113:82) explains a policy with real dates in two columns. Much clearer than paragraphs.
  - Proof that is measured, not claimed: "Comfort score 8.7/10", "81% On Time", rating with count (113:84).
  - Grouping many similar results into one stacked operator card (113:88) shortens a 432-item list.
  - Undo snackbar after a toggle (113:81) is good "user control and freedom".
  - Location explainer shows the real benefit on a map before the system ask (113:101).
  - Deletion with a grace date and a plain feedback box (113:107) is respectful and clear.
  - Language and country first (113:104, 113:103) for a multi-market app.
- **Weaknesses:**
  - Three different login sheets with three different promises in one session: "special prices" (113:98), "quick help" (113:97), "book your metro ticket" (113:91). Inconsistent and pushy.
  - Interruptions: spotlight coachmark (113:100), festival promo sheet (113:94).
  - False urgency: "Seats filling fast" as the page subtitle (113:76) on an empty form.
  - Red is the brand, the active filter, the danger colour and the delete link (113:84, 113:109, 113:108). On 113:107 the red primary is "Keep my account", on 113:108 the red primary is "Yes, Delete". The same colour means opposite things one tap apart.
  - Default-looking blue links ("Close", "View all", "Know more", 113:85, 113:78, 113:90) look unstyled next to the polished red.
  - Festival art is heavy and pushes the form into a busy gradient (113:93, 113:76).
  - Too many tag styles on one card: strike price, yellow "Exclusive" tag, green rating, lavender comfort chip, grey on-time chip (113:84).
  - Gender is two options only (113:77). Subtitle copy with typos and asterisks: "24*7 customer service(call/chat)" (113:95).
  - Five-tab floating nav with an Offers tab (113:90).
  - Food ordering opens a partner page with its own logo, orange caps "SUBMIT" button and a different bottom nav (113:74). Breaks consistency.
- **Scores (1 to 5):** visual polish 3, clarity 3, information density 3, trust 4, brand distinctiveness 3.
- **For 30 Sundays:**
  - Itinerary: borrow the policy comparison table (113:82) for "What happens if you cancel", rows by days before travel, with real dates computed from the trip. Use lagoon teal ticks, not green.
  - Destination page (stays and things to do lists) and wishlist: borrow the two-column filter sheet with counts and a live "Show 24 stays" button (113:85).
  - Destination page: borrow measured proof (113:84), for example "Rated 4.8 by 167 travellers" or "9 of 10 trips ran on time", in caption grey with a lagoon icon.
  - Wizard: borrow the undo snackbar for toggles that change the plan (113:81).
  - Profile: borrow the grace-period deletion with a date (113:107), but keep one consistent colour rule for the destructive action.
  - Avoid: multiple login promises, festival gradients behind forms, scarcity subtitles, red as both brand and danger.

---

### Yatra (flights, hotels, buses, trains, cabs, with an AI planner, 32 screens)

- **Flows covered:**
  - 113:141 Splash, red wordmark on white.
  - 113:140 Home (logged out). Wordmark, gift / wallet / bell pill, five round category icons, "Offers" with tabs (All, Flights, Hotels, Bus, Cabs), bank offer card with coupon code, eCash login banner, "Trending Hotels". Bottom nav has "Talk to Us" in the centre.
  - 113:128 Home in a later session. Same top, "Trending Hotels" big photo card with name and price, "Yatra Prime" banner. Bottom nav now has a "Diya AI" avatar in the centre.
  - 113:139 Discover tab. "Return Flight to Popular International Destinations from New Delhi" with a big Asia photo card and a salmon "Starting From Rs 14,426" pill, then a domestic city rail.
  - 113:134 Book a Flight, One Way, with "Book round trip to save extra" in the empty return slot, Special Fares chips.
  - 113:133 Book a Flight, Round Trip, return date filled with a clear x.
  - 113:132 Book a Flight, Multi-city, Flight 1 and Flight 2 blocks, "+ Add another".
  - 113:130 Book a Flight, Delhi to Leh.
  - 113:131 Flight results Delhi to Mumbai. Route pill, date strip with prices, sort chips (Price, Duration, Departure, Arrival), "Showing 23 results", flight cards, bank offer strip, summer sale banner between results.
  - 113:129 Flight results Delhi to Leh, one result, "1 Seat Left" in red, cheapest date in green, "Free Meal" chip.
  - 113:135 Diya AI chat start. Greeting bubble, suggestion chips (Air India info, Set price drop, Flights, Hotels, Plan a trip, Bookings, FAQs, More), "Hide suggestions", input with mic, "Powered by DIYA AI".
  - 113:127 Diya AI with a popover from "Plan a..." (Plan a trip, Search Flights + Hotels, Create itinerary).
  - 113:126 User sent "Plan a trip"; bot asks four questions in one paragraph.
  - 113:125 User answered "monaco"; bot avatar thinking.
  - 113:124 "Processing your reque" (truncated status bubble).
  - 113:123 Bot asks three numbered questions in prose, including an airport suggestion.
  - 113:122 "Rate Your Experience" sheet, mascot, number 10, red-to-green slider 1 to 10, optional text, character count.
  - 113:137 Your Trips logged out, alert "Login is required to view booking details." with only "OK".
  - 113:136 Account logged out. Benefits row with ticks cut off at the edge, red "Login / Sign Up", list (My Settings, Refer & Earn, Share the App, Rate Us, About Yatra, Investor Relations), app version.
  - 113:138 Login sheet, Personal / SME toggle, email or mobile field, "Continue".
  - 113:121 Same login sheet over Account.
  - 113:120 OTP sheet, "valid for next 15 mins", number with edit pencil, six underline slots, "Verify & Continue", "Resend OTP (59 seconds)".
  - 113:119 Sign Up sheet, Personal / SME, verified mobile, password with eye, email, title plus first and last name, referral link, "Create Account".
  - 113:118 Sign Up with errors ("Please enter a valid email id" under a valid email; name length rules) and the keyboard covering the button.
  - 113:117 Sign Up with the Mr / Mrs / Ms popover open.
  - 113:116 Success sheet, teal tick, "Your email and mobile number has been successfully associated with Yatra", "Continue".
  - 113:115 Account logged in. Avatar, "Hi, name", list with My Settings expanded on grey (Notifications, Saved Cards, Saved Travellers, Voice Chat, Linked Cab Providers), Refer & Earn.
  - 113:114 Edit Profile. Dark patterned header, avatar with camera badge, Mr / Ms / Mrs segmented, underline fields, "Verified" in green, "Add GST details (Optional)", text links Delete Account / Change Password / Logout.
  - 113:113 iOS alert "Are you sure you want to delete your account?" with two bullets and 90-day note.
  - 113:111 Web page (secure.yatra.com) deactivate modal with Confirm / Cancel.
  - 113:110 Web deactivate modal asking to re-enter the password, "Deactivate Now", "Forgot Password?".
  - 113:112 Web login page (secure.yatra.com) reached from account management: "View/Cancel/Reschedule your bookings by Login / Register", mobile field, red "Continue", Facebook and Google buttons in two different styles.
- **Typography:** Mixed. Native screens use iOS system sans (SF Pro) at 16 to 18 px (113:115). Flight form labels are small caps 12 px grey above 17 px bold values ("DEPART FROM / New Delhi (DEL)", 113:130). The Diya AI chat and rating sheet switch to a geometric sans with round forms, likely Figtree or Manrope (113:135, 113:122). The web pages use Lato (113:110). So three families in one app. Prices in results bold 18 px right aligned (113:131), date strip prices 17 px semibold (113:131). Title Case on most labels, caps on tabs ("ONE WAY / ROUND TRIP / MULTI-CITY", 113:134).
- **Colour:** Light theme. Primary red about #EF1C2A on most buttons; brighter #FF0019 on login and web (113:138, 113:110); a maroon about #8B1A3D in the chat header and chips (113:135). Pink tint about #FCE3E6 behind category icons (113:128). Green about #2BB24C for verified, toggles and cheapest date (113:114, 113:129). Teal tick about #1AA59A (113:116). Links blue about #1A8FE3 (113:119). Banner blues and yellows in promos (113:131). Discover pill salmon about #F56B63 (113:139). Text near black #1C1C1C, greys #6E6E6E and #9A9A9A. Three reds plus green plus blue, so about five accents across the app, three on a typical screen. A faint pink-to-peach gradient at the top of home (113:128).
- **Layout and spacing:** 16 px gutters, but the results date strip and Discover card run edge to edge and get cropped (113:139). Cards radius 10 to 24 px (big trending hotel card about 24 px, 113:128; flight cards about 10 px, 113:131). Mostly borders, a few shadows. Sections split by grey bands. Images: trending hotel 4:3 (113:128), Discover hero about 4:5 (113:139).
- **Section designs:**
  - Splash: wordmark only (113:141).
  - Home header: wordmark left, a pill of three icons right (gift, wallet, bell) (113:128).
  - Category tiles: five round tinted icons with a chevron to expand more (113:128).
  - Offers and coupons: offer tabs plus bank offer card with a coupon code button (113:140); bank offer strip inside a result card (113:131).
  - Card rail: "Trending Hotels" one big card at a time with name and price under (113:128).
  - Editorial and stories: Discover with region cards and "Starting From" prices from your city (113:139).
  - Booking form: label-above-value fields, swap button, the empty return slot used as a nudge "Book round trip to save extra" (113:134), multi-city with "+ Add another" (113:132), special fare chips with info icons (113:130).
  - Date picker: date strip with fare per day and calendar icon (113:131, 113:129).
  - Filters and sort: sort chips with direction arrow (113:131).
  - Listing card: airline, flight number, times, duration line, stops, price, "Free Meal", scarcity in red (113:129).
  - Hero banner: sale banner inserted between results (113:131).
  - Help and chat: AI trip planner chat with suggestion chips, sub-menu popover, voice input, feedback button (113:135, 113:127, 113:123).
  - Reviews and ratings: 1 to 10 slider with mascot (113:122).
  - Login and OTP: Personal / SME toggle (113:138); OTP with validity and resend timer (113:120); sign-up with title, names, password (113:119).
  - Confirmation: success sheet after linking (113:116).
  - Profile: account list with an inline expanding settings group (113:115); edit profile with honorific segmented control (113:114).
  - Other (account deletion): native alert (113:113) then web pages (113:111, 113:110).
  - Bottom nav: five tabs with a raised centre slot that changes between "Talk to Us" and "Diya AI" (113:140, 113:128).
- **Strengths:**
  - Using the empty return slot to offer a round trip (113:134) is a smart, quiet nudge that costs no space.
  - Labels above values in small caps (113:130) make a filled form easy to scan.
  - OTP sheet states validity and shows a resend countdown (113:120). Good "visibility of system status".
  - Discover frames destinations by "Starting From" price from the user's city (113:139), which is the right idea for an inspiration page.
  - The AI planner offers starting chips so users do not face a blank box (113:135), and the popover splits "Plan a trip" from "Create itinerary" (113:127).
- **Weaknesses:**
  - The planner chat then asks four questions in one paragraph (113:126) and three numbered questions in prose (113:123), instead of chips for city, dates and nights. A form hidden inside a chat. Breaks "recognition rather than recall". Status bubble truncates to "Processing your reque" (113:124). Bot copy uses em dashes (113:135).
  - Login dead end: "Login is required to view booking details." with only "OK" (113:137). No path forward.
  - Sign-up marks a valid email as invalid and stacks two name rules in one red line (113:118). Keyboard covers the main button (113:118).
  - Honorifics are required in sign-up and profile (113:117, 113:114).
  - Account management drops into web pages: a web login with mismatched Facebook and Google buttons (113:112), then a deactivate page that asks for a password the user may never have set (113:110). Two different flows for delete (113:113) and deactivate (113:111).
  - Bottom nav centre slot changes between sessions (113:140 vs 113:128). Breaks "consistency and standards".
  - Three type families and three reds (113:110, 113:135, 113:130).
  - "1 Seat Left" in red with a single result (113:129) is scarcity pressure; banners interrupt results (113:131).
  - Rating slider runs red to green and the mascot changes character between avatar and sheet (113:122 vs 113:135).
  - Benefits row truncated at the edge with pipe separators (113:136). "Investor Relations" in a consumer account menu (113:136).
- **Scores (1 to 5):** visual polish 2, clarity 2, information density 3, trust 2, brand distinctiveness 2.
- **For 30 Sundays:**
  - Wizard: borrow the "empty slot as a nudge" idea (113:134), for example an empty second-city slot that says "Add Gili Islands, most people do". Borrow label-above-value fields (113:130).
  - Wizard: borrow the starter chips for the planner (113:135) but keep the questions as tappable steps, never a paragraph of questions.
  - Destination list (home "where next"): borrow "from Rs X from your city" on each destination card (113:139), without the salmon pill.
  - Profile: borrow the OTP sheet with a validity line and resend timer (113:120).
  - Avoid: chat as a form, dead-end alerts, web views for account actions, required honorifics, a nav that changes, scarcity in red.

---

### Group summary

**Patterns that repeat, by component kind**
- Splash: three of four apps show only the logo on white or a solid colour (41:933, 113:106, 113:141, 41:959). Only Headout uses its brand shape. Only ixigo adds a trust seal (41:959).
- Onboarding and Notifications: every app asks for notifications and location before value is shown, usually with a soft pre-prompt sheet (41:932, 41:956, 41:955, 113:101). Headout and redBus explain the benefit with a picture; ixigo chains six sheets.
- Login and OTP: all four use bottom sheets with a mobile field and a social option; three tie a different benefit to each sheet ("special prices", "quick help", "seamless experience"). OTP is six boxes or six underlines with an edit link (113:80, 113:120).
- Booking form: the Indian transport pattern is identical across ixigo, redBus and Yatra: stacked From / To with a swap button, a date row with "Today / Tomorrow / Day After" chips, one opt-in row (free cancellation, women, Assured), one full-width primary button (41:949, 113:90, 113:130).
- Date picker: all four use a horizontal date strip with information under each day: price (41:924, 113:131), seat status (41:945), or availability. The cheapest day is highlighted in green in two apps (41:924, 113:129).
- Listing card: the price sits right or bottom with a qualifier ("from", "Onwards", "Starts @"), a rating chip with count, and two to five small chips (41:921, 113:84, 41:939, 113:131).
- Trust and proof: scale claims ("5 crore+", "19 years", "10K+ activities", "30,000+ stays"), partner seals (IRCTC), recent activity ("14K+ bookings last month"), measured scores ("Comfort score", "81% On Time", "91% Chance"). The specific and measured ones are the convincing ones.
- Offers and coupons: coupon codes in banners, stickers on mode tabs, banners inserted between results, bank offers inside cards. Present everywhere except Headout, which keeps savings inside the product card.
- Filters and sort: chips on the list plus a full sheet; redBus's two-column sheet with counts is the best version (113:85).
- Sticky CTA bar: price or summary left, one action right (41:925, 41:923, 41:922). Only Headout does this well; the transport apps use full-width buttons at the end of forms.
- Empty state: an illustration (cat on suitcases, octagon photo) plus one line plus one action (113:99, 41:928).
- Profile: long icon lists; redBus and Headout group them under small headings, ixigo adds subtitles to every row.
- Bottom nav: three apps use five tabs including money or offers or help; Headout uses three.
- Other (account deletion): all four apps show deletion, which says the team cared about it. Headout and redBus are respectful; Yatra mixes native and web.

**The 5 best section designs for a travel app like ours, ranked**
1. Headout ranked "Top 10 things to do" with inline expansion into bookable variants (41:921, 41:920). It is exactly our destination page problem: order, proof and price in one row, details on demand, no extra page. Rank numerals in our handwriting face would be distinctive.
2. Headout date strip with a price under each date plus the sticky summary bar (41:924). Direct map to our wizard month step ("from Rs X" per month) and the trip total bar.
3. Headout review and pay with the order summary pinned above the form and a sticky total with "View details" (41:922). Map to our itinerary quote and checkout.
4. redBus cancellation and refund table (113:82). Map to the itinerary "if plans change" section; real dates computed from the trip are far clearer than policy text.
5. redBus filter sheet with left categories, counts and a live result button (113:85). Map to stays and activities lists on the destination page and to the wishlist.
Runners-up: Headout proof chip "14K+ bookings last month" (41:926) for destination cards; ixigo freshness stamps and confirmation chance (41:945, 41:944) for live itinerary and booked trip status; Yatra's empty-slot nudge (113:134) for the wizard route step.

**The 5 things to never copy**
1. The first-launch prompt chain: welcome, tracking, notifications, location, login, success (ixigo 41:957, 41:958, 41:956, 41:955, 41:953, 41:954). It spends all goodwill before the user has seen a single trip.
2. Interrupting sheets and modals while the user reads or plans: mid-results upsell (41:948), festival promo (113:94), spotlight coachmark (113:100). Our planning moments need calm.
3. Red and green as good and bad, and red as both brand and danger (41:947, 41:942, 113:84, 113:107 vs 113:108). It breaks our house rule and confuses users when the primary colour means "keep" on one screen and "delete" on the next.
4. Badge and sticker storms and scarcity copy: "New", "Pro", "Free", "Flat 19% off" stickers (41:941, 113:90), "Seats filling fast" (113:76), "1 Seat Left" in red (113:129). Our rule is no solid pill badges and short honest copy.
5. A planner that is a form hidden in a chat, plus dead-end account screens (Yatra 113:126, 113:123, 113:137, 113:110). A wizard must ask one thing at a time with tappable answers, and every blocked screen must offer the next step.
