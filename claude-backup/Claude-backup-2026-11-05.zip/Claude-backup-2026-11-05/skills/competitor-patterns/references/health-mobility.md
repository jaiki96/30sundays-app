# Health and mobility: critical evaluation

Group: health-mobility. 163 screens across 9 apps, every file opened.
pharmeasy 23, tata 1mg 21, pristyn care 17, cult fit 26, rapido 28, ola 15, cars24 17, cardekho 9, spinny 7.

Housekeeping notes for the team:
- Two screens inside the cars24 frame are CarDekho screens: 41:854 (News list, CarDekho watermark) and 41:860 (Tata Sierra model page, CarDekho orange). They are reviewed under CarDekho below but still counted in the cars24 total.
- The canvas has no designer notes for this group, only the app name labels.
- Rapido and Ola frames run newest first (the splash is the last screen). Flows below are listed in user order where that helps, with file order kept in the screen lists.
- No car app here shows a full inspection report screen. Trust is carried by chips and strips instead (for example "300+ quality checks", "No Major Accident or Flood History"). If the team wants the inspection report pattern, it still needs capturing.
- No Ola live ride screen was captured, so ride status evidence comes from Rapido only.

---

### PharmEasy (pharmacy, lab tests and doctor consult, 23 screens)

- **Flows covered:** (file order)
  - 35:157 Payment options (amount payable, cash on delivery, UPI, wallets, cards)
  - 35:158 Lab test: select sample collection slot
  - 35:159 Lab test: add address form
  - 35:160 Lab test cart
  - 35:161 Lab test cart with "coupon unlocked" modal
  - 35:179 Splash with three service illustrations
  - 35:162 "Book for" patient count bottom sheet
  - 35:163 Full body checkup listing
  - 35:164 Diabetes care: shop by brand, guide banner, top products
  - 35:165 Glucometer product grid with sort and filter
  - 35:166 Diabetes care hub: hero carousel and category tiles
  - 35:178 iOS tracking permission prompt over home
  - 35:167 Doctor consult: select a doctor (digestive)
  - 35:168 OTP entry with promo banner on top
  - 35:169 Login (phone) with the same promo banner
  - 35:170 Consultation summary and slot picker
  - 35:171 Select a doctor (skin and hair) with free follow-up banner
  - 35:177 Home with "register to get 22% off" sheet
  - 35:172 Doctor consult landing page
  - 35:173 Lab test home with register sheet
  - 35:174 Lab test home
  - 35:175 Healthcare products home
  - 35:176 Main home (lab tests, medicines, order via WhatsApp or call)
- **Typography:** neo-grotesque sans, likely Inter or a close system match. Weights 400 to 700. Screen titles about 20 px semibold (35:167 "Select Doctor" is a large light 24 px, the odd one out), card titles 16 px bold, body 14 px, captions and fact labels 11 to 12 px. Small caps dividers for structure ("1 TEST IN CART", "OR YOU CAN ORDER VIA", 35:160, 35:176). Prices bold 18 px with grey strikethrough MRP and a pink "71% OFF" next to them; 35:162 even shows two strikethrough prices stacked.
- **Colour:** primary teal about #10847E (buttons, selected states), dark teal header gradient about #0B4F4A to #10847E (35:176), purple membership about #5B2D90 ("PLUS", 35:160), discount pink about #E5486C, amber about #E8A317 for urgency ("Consult in 17 minutes", 35:167), navy about #0F2A5C for the consult world (35:170, 35:172), mint tint about #E9F8F4 for proof strips. White ground, grey #F3F4F6 bands. Text near black #1F2937, greys #6B7280. Three to five accents compete on one screen (35:160 has teal, blue, pink, purple and amber). Light mode, gradients on headers and promo cards.
- **Layout and spacing:** 16 px gutters, dense. White cards with hairline borders and very light shadows, radius about 8 to 12. Sections separated by 8 px grey bands (35:164) or hairlines. Product images square, banners about 2.4:1. Sticky bottom bars on every booking step.
- **Section designs:**
  - Expert card (Listing card): doctor photo, specialty tag, years, degrees, concern chips, languages spoken, mint proof strip "98% Happy Patients | 526 Consults", price, "Select Slot" and next availability. Best at 35:167.
  - Slot picker (Date picker): horizontal date strip with a month tab, then time slots grouped into Afternoon, Evening and Night accordions with counts ("16 slots available"). Best at 35:170.
  - Date chip plus slot grid (Date picker): three date chips, two-column slot buttons, address strip with Change. 35:158.
  - Guarantee strip (Trust and proof): "ON-TIME sample collection or your test is FREE". 35:158, 35:163.
  - Fact row (Detail sections): three icon facts in a tinted box, fasting, sample type, report time. 35:160, 35:163.
  - Stat laurels (Trust and proof): "100% private sessions, 50K+ guided consultations, 40+ certified doctors". 35:172.
  - Consult landing hero (Hero banner): navy gradient, two-tone italic headline, "Doctor consult in 18 mins" pill, OR divider, Top Concerns rail. 35:172.
  - Patient count sheet (Booking form): radio list 1 to 5 people with per-person price. 35:162.
  - Coupon unlocked modal (Offers and coupons): badge, "Yay! You've unlocked 850 off". 35:161.
  - Membership upsell card (Wallet and rewards): purple PLUS card with gold ribbon in the cart. 35:160.
  - Quick actions row (Category tiles): order via WhatsApp, call, upload prescription. 35:174, 35:176.
  - Concern tiles (Category tiles): 4-column mint tiles with circular photos. 35:174.
  - Address form (Booking form): labelled fields, helper "Our technician will call on this number", Home, Work, Other chips. 35:159.
  - Payment list (Payment): inline "Place Order" inside the chosen method, "Recommended" tag on UPI. 35:157.
  - Bottom nav (Bottom nav): five tabs, active teal with a top indicator bar. 35:174.
- **Strengths:**
  - The doctor card (35:167) answers every pre-booking question in one card: who, how experienced, what they treat, what language, how loved, how soon, how much.
  - Slot grouping by part of day with counts (35:170) keeps a long list calm. Collapsed groups still say how many slots are inside.
  - Guarantees are stated as a promise with a consequence ("or your test is FREE", 35:158), stronger than a generic "trusted" badge.
  - Helper text explains why a field matters (35:159), which lowers form anxiety.
  - Fact row (35:160) puts the three practical questions (prep, sample, wait) in one glance.
- **Weaknesses:**
  - Price noise: 35:160 and 35:162 show MRP, strike price, % off, coupon price, PLUS credits and a "BEST VALUE" upsell on one item. Breaks aesthetic and minimalist design, and makes the real price hard to find.
  - Promo banners on login and OTP (35:168, 35:169) put marketing in the way of a task. Breaks user control and focus.
  - Register sheets over home on first open (35:173, 35:177) block exploration before value is shown.
  - Too many accents on one screen (35:160: teal, blue, pink, purple, amber). No single action colour.
  - Brand tile block on a loud blue gradient (35:164) looks like an ad slot, not part of the app.
  - A sexual wellness ad is the hero on the products home (35:175). Tone mismatch for a health app used by families.
  - "Select Doctor" title style (35:167, 35:171) is lighter and larger than every other title. Breaks consistency.
- **Scores (1 to 5):** visual polish 3, clarity 3, information density 2, trust 4, brand distinctiveness 2.
- **For 30 Sundays:**
  - Borrow the expert card for "talk to a trip planner" (profile or home): photo, name, destinations they plan, years, languages, one proof line ("Planned 420 Bali trips"), next free slot, one fuchsia "Pick a time".
  - Borrow the day-part slot picker (35:170) for booking a planner call.
  - Borrow the fact row (35:160) on the itinerary: best months, flight time, visa, in one tinted box.
  - Borrow promise-style guarantees (35:158) for trust sections on the destination page, written in our voice.
  - Avoid stacked discounts, promo banners on login, and multiple accent colours per screen.

---

### Tata 1mg (pharmacy, lab tests, consults, 21 screens)

- **Flows covered:** (file order)
  - 41:771 Empty cart with brand sign-off footer
  - 41:772 "Continue to purchase from" sheet (pharmacy or lab cart)
  - 41:773 Select delivery location sheet
  - 41:774 Care Plan membership page and plan picker
  - 41:775 Profile with membership upsell and menu
  - 41:791 Splash with certification seals
  - 41:776 My lab tests empty state
  - 41:777 Radiology listing with filters and "Call to Book" pill
  - 41:778 Lab tests home
  - 41:779 Health plans (partner programmes)
  - 41:780 Health insights intro
  - 41:790 Login with illustrated header
  - 41:781 Insurance home
  - 41:782 Vaccines: how it works
  - 41:783 Doctor consult entry
  - 41:784 Pet care home
  - 41:785 Lab tests home (search state)
  - 41:789 OTP verify
  - 41:786 Pharmacy home
  - 41:787 Main home
  - 41:788 Searching your location loader
- **Typography:** geometric humanist sans, likely a custom face close to Figtree or Inter, weights 400 to 800. Titles 18 to 20 px bold, body 14 px, captions 12 px grey. Display moments use big gradient type ("Adding some sunshine to your life", 41:771) and 3D lettering ("PAYDAY SALE", 41:787). Spaced small caps for labels ("MEMBERSHIP BENEFITS", 41:774; "YOUR HEALTH INSIGHTS", 41:780). Prices bold with "onwards" or "/month" in grey ("55/month", 41:774).
- **Colour:** primary coral about #FF5B45 (CTAs, links, icons), black #1A1A1A as a second CTA colour (41:776, 41:787), cream about #FFF3E0 (splash, 41:791), peach tints about #FDE8E0, maroon about #9B2C2C and gold about #C9A35B for the Care Plan world, pastel tiles in lavender, blue, green, pink (41:778). Semantic green for "20% Cheaper" (41:774), red pills for worsening metrics (41:780). Light mode, many soft gradients. Usually two to three accents per screen, five on home (41:787).
- **Layout and spacing:** 16 px gutters, medium density, generous top areas. Cards radius 12 to 16, soft shadows. Sections separated by white space more than dividers; peach tinted bands for featured blocks (41:786). Illustrations are 3D Pixar-style characters (41:790) and soft 3D icons.
- **Section designs:**
  - Brand sign-off footer (Empty state): wavy divider then a large gradient line of brand voice. 41:771.
  - Empty state with one action (Empty state): illustration, plain apology, black "Book Now" pill. 41:776.
  - Membership page (Wallet and rewards): sunburst header, benefits list with icon tiles, two plan cards with "Most Popular" and "20% Cheaper" tabs, button that repeats the plan ("for 3 months at 165"). 41:774.
  - Value props with icons (Trust and proof): "Talk within 30 mins", "3 day FREE follow up", "Get a valid prescription". 41:783.
  - Certification splash (Splash): seals and a plain claim of what they certify. 41:791.
  - Quick task tiles (Category tiles): four pastel tiles, packages, book via call, WhatsApp, upload prescription. 41:778.
  - Listing row with turnaround (Listing card): icon, name, "Report within 12-48 hours", "900 onwards", outlined BOOK. 41:777.
  - Floating call pill (Help and chat): "Call to Book" that can be closed. 41:777, 41:778.
  - Step cards (Itinerary and timeline): numbered how-it-works steps with a side colour band. 41:782.
  - Insights carousel (Progress and status): metric cards showing before and after values. 41:780.
  - Login sheet over illustration (Login and OTP): floating label phone field, email as secondary. 41:790.
  - OTP with fallbacks (Login and OTP): resend timer, then "Resend on SMS" or "Resend on call". 41:789.
  - Location sheet (Search bar): "Use your current location" and "Add new address". 41:773.
  - Profile menu with icon rows and "Beta" and "New" chips (Profile). 41:775.
- **Strengths:**
  - The brand footer on the empty cart (41:771) turns a dead end into a brand moment. Cheap, memorable, and kind.
  - Plan picker (41:774) restates the choice inside the button, so the user knows exactly what they are agreeing to. Supports recognition over recall.
  - Consult entry (41:783) states the three outcomes a worried user cares about, in plain words, before any price.
  - OTP fallbacks (41:789) give a way out when SMS fails. Good error recovery.
  - Turnaround time on each listing row (41:777) sets expectations before booking.
- **Weaknesses:**
  - Floating phone pill collides with step cards on the vaccine page (41:782). Visual bug that hides content.
  - Two CTA colours (coral and black) with no clear rule which is primary (41:776 vs 41:774). Breaks consistency.
  - Home (41:787) stacks category cards, an authenticity banner, a 3D sale headline and a raised centre nav button. Too many focal points.
  - Raised "Get Care Plan" nav button (41:775, 41:787) puts an upsell in the navigation slot. Navigation should navigate.
  - "Most Popular" tab is grey while "20% Cheaper" is solid green (41:774), so the less important tag shouts louder. Also uses green for good, which our rules ban.
  - Health insights cards (41:780) use red pills for change, which reads as alarm even when the change is good.
- **Scores (1 to 5):** visual polish 4, clarity 3, information density 3, trust 4, brand distinctiveness 4.
- **For 30 Sundays:**
  - Borrow the brand sign-off footer (41:771) for our empty states (empty wishlist, no trips yet) with a handwriting line on cream.
  - Borrow "say the choice in the button" (41:774) for the wizard and booking ("Plan 7 nights in Bali").
  - Borrow outcome-first value props (41:783) for the planner call: "Talk within a day", "Free changes for 7 days", "A plan you can share".
  - Borrow the "Resend on call" fallback (41:789).
  - Avoid an upsell in the bottom nav, two primary colours, and red or green for change.

---

### Pristyn Care (surgery and expert consultation, 17 screens)

- **Flows covered:** (file order)
  - 41:793 My appointments empty state
  - 41:794 Enter your details (name, mobile, email)
  - 41:795 Sign in OTP with "first step" card
  - 41:796 Sign in landing with stats and celebrity doctor
  - 41:797 Profile menu
  - 41:809 Prominent disclosure (why each permission is needed)
  - 41:808 "Get FREE Callback" sheet (city and condition)
  - 41:798 Condition page: Know More tab
  - 41:799 Doctor profile with inline booking form
  - 41:800 Select city sheet
  - 41:801 Condition page: Our Doctors tab (online)
  - 41:802 Doctors list with callback sheet over it
  - 41:803 Search: top searches and specialities grid
  - 41:804 Insurance support page
  - 41:805 Free expert advice grid
  - 41:806 Home
  - 41:807 Android location permission over home
- **Typography:** humanist sans, likely Open Sans or Noto Sans. Weights 400 to 700. Titles 20 px bold navy, section heads 16 px bold, body 14 px, chips 12 px. Purple italic tagline on sign in (41:796). Orange caps on some CTAs ("CONTINUE", 41:794). Prices: "Consultation Fee: 1000" struck through, then green bold "FREE" and grey "(Limited Time Offer)" (41:801).
- **Colour:** primary orange about #FF8A00 (CTA, chevrons, icons), secondary blue about #3B7DD8 (Request Call Back), navy headings about #0E2A47, green about #1DA851 for FREE and "Available in 1 minutes", purple about #7B4FC9 only in the logo world. Grounds white and light grey #F5F5F5, pale yellow rows (41:799), lavender and yellow pastel cards (41:804). Three accents fight on most screens (orange, blue, green). Light mode, faint peach to blue gradient header on profile (41:797).
- **Layout and spacing:** 20 px gutters, medium density. Cards radius 8 with drop shadow. Icon tiles radius 8 in 3 or 4 columns. Sections split by white space and some hairlines. Feels dated, about 2018 Android.
- **Section designs:**
  - Callback sheet (Help and chat): photo carousel of reasons (insurance help, bullets), a five-star quote, "Get FREE Callback", city search with quick chips, condition search with quick chips, Continue. 41:808.
  - Expert card with two actions (Listing card): photo, degrees, years, rating, live availability "Available in 1 minutes", fee, specialty chip, Request Call Back and Book Free Consult. 41:801.
  - Online or in clinic toggle (Filters and sort): segmented control plus a banner to pick a city for in-person. 41:801.
  - Expert profile with inline form (Booking form): profile summary then name, phone, city, condition, Book Now, then "best known for" list. 41:799.
  - Condition explainer (Editorial and stories): Know More tab with about, symptoms photo and 2-column bullets. 41:798.
  - Speciality icon grid (Category tiles): duotone line icons on white tiles. 41:803, 41:805, 41:806.
  - Stat circles (Trust and proof): "400+ Doctors, 50+ Diseases, 45+ Cities". 41:796.
  - Permission disclosure (Onboarding): each permission with a one-line reason, Deny and Allow. 41:809.
  - City picker (Search bar): search, use current location, popular city chips, A to Z list. 41:800.
  - Insurance help page (Detail sections): headline, family photo, two pastel benefit cards, form, sticky CTA. 41:804.
  - Hospital carousel (Card rail): "NOW LIVE" tag, photo, location. 41:806.
- **Strengths:**
  - The callback sheet (41:808) asks only two things (where are you, what do you need) with quick-pick chips. Very low effort to reach a human. This is the closest model in the group for "talk to a trip planner".
  - Live availability on the expert card (41:801, "Available in 1 minutes") answers "how soon" before the user asks.
  - Online or in clinic toggle (41:801) is a clean way to choose a mode of help.
  - Prominent disclosure (41:809) explains every permission in plain words before the system prompt. Builds trust.
  - Condition explainer (41:798) gives the user knowledge before the sales step.
- **Weaknesses:**
  - Two coloured CTAs of equal weight on every card and on the sticky bar (blue and orange, 41:798, 41:799, 41:801). Users cannot tell which is the main path. Breaks Hick's law and consistency.
  - The callback sheet pops over the doctor list uninvited (41:802). Interrupts the task the user chose.
  - "FREE" in a green pill plus "(Limited Time Offer)" (41:801, 41:808) feels like a sales trick and cheapens the expert.
  - Empty appointments (41:793) gives no next step except "Back To Home Screen", and the active tab is unclear (grey vs orange). Breaks visibility of system status.
  - Home speciality grid is cut off on the right with no scroll hint (41:806).
  - Stat circles and a celebrity doctor on sign in (41:796) feel like an ad, not a welcome.
  - Inline booking form inside a profile (41:799) repeats what the sticky bar already offers.
- **Scores (1 to 5):** visual polish 2, clarity 3, information density 3, trust 3, brand distinctiveness 2.
- **For 30 Sundays:**
  - Borrow the two-question callback sheet (41:808) for "talk to a trip planner" from the destination page and wizard: destination chips (pre-filled from context), when to call, one fuchsia button. Keep the reasons carousel short and use lagoonBliss for proof.
  - Borrow live availability on the planner card ("Free today at 4 pm").
  - Borrow the call or chat toggle (41:801) as "Call" or "WhatsApp" for planner contact.
  - Borrow the disclosure pattern (41:809) for location and notifications.
  - Avoid two coloured primary buttons, uninvited sheets over a list, and "FREE, limited time" framing for expert help.

---

### cult.fit (fitness memberships, classes, store, 26 screens)

- **Flows covered:** (file order, user order is roughly the reverse)
  - 41:811 Help and support (FAQ search, no recent query, chat)
  - 41:812 cultpass CORP benefits
  - 41:813 Profile: Activity and records expanded
  - 41:814 Profile: Fitness devices expanded
  - 41:815 Profile: Account settings expanded
  - 41:816 Explore cultpass plans
  - 41:817 Fitness: centres near you
  - 41:818 Pick an area
  - 41:819 Profile top (no membership)
  - 41:820 Home: weekly activity sheet expanded
  - 41:821 Weight loss: doctor-led tab
  - 41:822 Weight loss: at-centre tab
  - 41:823 Weight loss: at-home tab
  - 41:824 Store (web view): city delivery picker, cultXpress
  - 41:825 Store account and empty orders
  - 41:826 Store: gym accessories grid
  - 41:827 Store home banner
  - 41:828 Sports tab
  - 41:829 Fitness tab top
  - 41:830 Onboarding: preferred activity
  - 41:831 Home
  - 41:832 Email OTP
  - 41:833 "One last step, what's your email?"
  - 41:834 "Before we start, what do we call you?"
  - 41:835 Phone OTP
  - 41:836 Login with photo carousel
- **Typography:** Inter, weights 400 to 800. Question titles 28 px bold (41:833, 41:834), section titles 20 px bold, card titles 16 px bold, body 14 px grey, captions 12 px. Buttons are letterspaced caps 14 px with gradient text. Promo display uses condensed sans in caps (Bebas-like, "GOAL RUSH", "PACKS STARTING AT 1448/MONTH", 41:823, 41:829). Prices "1448 / month* onwards", bold number then a small "onwards" (41:816).
- **Colour:** dark mode. Ground deep navy about #0B0E2A to #1A1F4A with blurred yellow and blue light blobs. Text white, secondary grey about #9AA0B5. CTA is a white button with orange to pink gradient text (about #F27B4F to #E8457A). Glass cards white at 6 to 8% with a thin light border. Semantic green toggles about #2FD18B, amber sale pill about #F5A623, a red to green progress scale (41:820). Promo pages break the palette with yellow-lime bursts (41:823) and plum (41:821). The store web view (41:824 to 41:827) is white with black and lime, a different product.
- **Layout and spacing:** 20 px gutters, airy. Glass cards radius 16. Full-bleed video or photo heroes, about 60% of the first screen. Circular photo thumbnails in list cards (41:816). Sections separated by space and a few hairlines. Sticky two-button bands at the bottom of programme pages.
- **Section designs:**
  - Weekly progress sheet (Progress and status): arc gauge "0/3 this week", a motivating line, a 1 to 6+ workouts scale with a highlighted band "most cult athletes" and your avatar on it, illustrated landscape, quick access tiles. 41:820.
  - Persistent progress mini bar (Progress and status): "0/3 This Week Activity, BOOK" pinned above the nav, expands into the sheet. 41:831.
  - One question per screen (Onboarding): "Before we start, what do we call you?" big type, one field, one button. 41:834, 41:833.
  - Big choice cards (Onboarding): "What's your preferred activity", two photo cards each with its own button, plus "Explore others". 41:830.
  - Programme tabs (Detail hero): AT-HOME, AT-CENTRE, DOCTOR-LED tabs over full-bleed heroes. 41:821, 41:822, 41:823.
  - Talk or buy band (Sticky CTA bar): one outcome line ("Expect to lose upto 5 kgs in 6 weeks") over "TALK TO US" and "BUY NOW". 41:822, 41:823.
  - Expert hero (Help and chat): doctor portrait, "Medicine-Assisted Weight Loss", "CONSULT A DOCTOR" and "CHAT WITH US". 41:821.
  - Plan cards (Listing card): circular photo, plan name, two-line description, divider, monthly price. 41:816.
  - Place card with two actions (Listing card): photo, type tag, sale pill, "Extra 1,700 OFF applied" band, distance, price, "TRY FOR FREE" and "MORE DETAILS". 41:817.
  - Benefits with connectors (Inclusions list): a "BENEFITS" pill with lines dropping to three cards. 41:812.
  - Accordion profile (Profile): group titles with dot-separated previews of what is inside ("Past sessions . Report . Memories . Badges"). 41:819, 41:813.
  - Area picker with counts (Search bar): "Around your location", then areas with centre counts. 41:818.
  - Help with empty history (Help and chat): FAQ search, "No recent query", policies, "CHAT WITH US". 41:811.
  - Try for free tiles (Category tiles): 3D icons "play badminton", "learn swimming". 41:828.
- **Strengths:**
  - The weekly progress sheet (41:820) is the best motivation pattern in the group: a small goal, where you are, what "good" looks like among peers, and a warm line of copy. It is encouraging, not guilt based.
  - The progress mini bar (41:831) keeps the one thing that matters visible on every visit without taking over the home.
  - One question per screen (41:834) with a human question makes sign up feel like a conversation.
  - Talk or buy band (41:822) offers a human as an equal path to buying, which suits high-consideration purchases.
  - Accordion previews in profile (41:819) show what each group holds before opening. Good recognition over recall.
  - Consistent gradient-text white button gives one clear action colour across the app.
- **Weaknesses:**
  - The home and tab heroes are often blank dark areas waiting for video (41:831, 41:828, 41:829), with only an offer line visible. When video fails, the page has no content. Breaks visibility of system status.
  - Offers lead everything ("FREE 3 Months Extension + Extra 1,400 OFF", 41:831; "Extra 1,500 OFF + 2 Month Membership Pause", 41:828). The content and motivation story is pushed below discounts.
  - Literal placeholder "name" shown as the user name (41:819).
  - The store is a white web view with a different nav, logo bar and type (41:824 to 41:827). Breaks consistency badly; users feel they left the app.
  - Grey on navy secondary text (41:816, 41:815) is low contrast in places.
  - A red to green scale (41:820) uses red for "zero workouts", which our rules ban and which can shame.
  - Login offers Google, Facebook and email as three equal square icons with no labels (41:836).
- **Scores (1 to 5):** visual polish 4, clarity 3, information density 3, trust 3, brand distinctiveness 5.
- **For 30 Sundays:**
  - Borrow the progress sheet idea (41:820) for Sunday School: "2 of 5 Bali lessons watched", a warm handwriting line, and a band showing what most travellers watch before they fly. Use goldenHour, not red to green.
  - Borrow the mini progress bar (41:831) for the booked trip on home: "Bali in 23 days, 2 things to do", tap to open.
  - Borrow one question per screen with human copy (41:834) for the wizard ("Who is coming with you?").
  - Borrow the big photo choice cards (41:830) for the wizard's first step or the cold-start home.
  - Borrow "talk to us" as an equal path beside the main action (41:822), but keep only one fuchsia button: the talk option should be a quiet outline.
  - Avoid video-only heroes with no fallback, offers above content, and a web view that changes the app's look.

---

### Rapido (bike taxi, auto, cab, parcel, 28 screens)

- **Flows covered:** (user order, file order is the reverse)
  - 35:87 Splash (yellow, "Made in India")
  - 35:86 "What's your number?"
  - 35:85 Verify OTP (resend timer, send via WhatsApp)
  - 35:84 "One last step": name, gender, WhatsApp updates, referral code
  - 35:83 Location permission pre-prompt
  - 35:82 Search pickup location
  - 35:81 Ride home (map, "Where are you going?", recents, Everything In Minutes)
  - 35:80 Destination search with stops and saved places
  - 35:79 Choose vehicle with prices and drop times
  - 35:78 Offers with coupons
  - 35:77 Payment method sheet
  - 35:76 Loading splash (offer pin)
  - 35:75 Choose your pickup (walk and save)
  - 35:74 Set your price slider (cab)
  - 35:73 Searching for a captain (cab)
  - 35:72 Finding your ride with location details and fare
  - 35:71 Why do you want to cancel?
  - 35:70 Cab status with "cancelled successfully" sheet
  - 35:69 Parcel entry (pickup and drop cards)
  - 35:68 Parcel confirm
  - 35:67 Offers, no coupons empty state
  - 35:66 Payment sheet with pay at pickup or drop
  - 35:65 Set your price (parcel)
  - 35:64 Searching (parcel)
  - 35:63 Parcel live status (captain on the way)
  - 35:62 Cancel confirmation
  - 35:61 Parcel status with cancelled sheet
  - 35:60 All services grid
- **Typography:** SF Pro (iOS system), weights 400 to 700. Titles 20 to 22 px semibold, body 15 px, captions 12 px grey. Big price display 40 px regular ("40", 35:65). Licence plate set large and bold ("HR87Q9300", 35:63), PIN in separate digit boxes. ETA highlights the number in green ("Pickup in 1 min"). Prices right aligned with strikethrough for the old price (35:79).
- **Colour:** dark mode. Ground black #000 and #1C1C1E, cards #2A2A2C, borders #3A3A3C. Primary yellow about #FFC812 with black text, used only for the main action. Green about #4CC38A for ETA and proof, blue about #2D8CFF for links and "Searching in progress", red about #E5484D only on cancel text. Mint about #9EF0C9 for the cheaper price tile (35:75). Usually one accent plus one semantic per screen. Splash is full yellow.
- **Layout and spacing:** 16 px gutters. Map on top, a draggable sheet below, radius 16. Cards are dark with thin light borders, no shadows. Dashed dividers split info from help links (35:63). Floating capsule bottom nav with an active pill (35:60, 35:81).
- **Section designs:**
  - Live status sheet (Progress and status): a status card "Pickup in 1 min / Captain on the way", PIN boxes, a person card (plate, vehicle, name, photo with rating), call button and a message field, "Pickup from" with "Trip Details", then "Issue with pickup? Share feedback". Best at 35:63, also 35:70.
  - Searching state (Progress and status): radar pulse on map, "Searching in progress" with a progress bar, fare and "Trip Details". 35:64, 35:73.
  - Finding state with summary (Progress and status): what you asked for, route with dotted line between pins, fare, payment, Cancel or Back. 35:72.
  - Cancel with friction (Other: cancellation): "Sushant is already on the way to you" with his photo, safe "Go Back" as the yellow button, "Cancel Ride" in red text on grey. 35:62.
  - Cancel reasons (Other: cancellation): plain reason list, Continue. 35:71.
  - Done sheet (Confirmation): green check, one line, "Done". 35:61, 35:70.
  - Choice list with times (Comparison): each option with seats, "1 min away . Drop 11:58 am" and price, selected one enlarged with a light border. 35:79.
  - Set your price slider (Price display): huge price, honest line "We charge no commission", tip "Higher the price, higher the chance of getting a ride", stepped slider, button that repeats the price. 35:65, 35:74.
  - Walk and save (Comparison): two pickup options with prices, the cheaper tagged "Walk & Save", map pins show prices. 35:75.
  - Route cards (Booking form): pickup and drop cards with coloured dots and a Switch pill. 35:69.
  - Recents with distance (Search bar): clock icon, distance under it, heart to save. 35:80, 35:81.
  - Permission pre-prompt (Onboarding): illustration, plain reasons, Continue or "Enter pickup location manually". 35:83.
  - OTP with WhatsApp option (Login and OTP). 35:85.
  - Services grid (Category tiles): 3D vehicle renders on dark tiles. 35:60.
  - Coupon cards (Offers and coupons): header strip, code, "Select" link, saving line in green. 35:78.
- **Strengths:**
  - The live status sheet (35:63) is a model trip status: the one fact that matters first (when), a proof code, who is coming with a face and rating, how to reach them, the details one tap away, and a calm help link last.
  - "Searching" and "finding" states (35:64, 35:72) always show what was booked and what it costs, so waiting never feels empty. Good visibility of system status.
  - Cancel friction is humane, not a trap: it shows the person affected and makes "Go Back" the yellow button, but cancel is still one tap (35:62).
  - Drop time on every option (35:79) answers "when will I arrive", which matters more than ETA.
  - Honest price copy (35:65 "Full amount goes to the captain") builds trust.
  - One yellow action per screen, applied with discipline across 28 screens.
- **Weaknesses:**
  - An ad (Pokemon) under the live status (35:63) during a safety-sensitive moment. Distracting and cheap.
  - Coin balance shown with a red error line "You don't have any coins currently" (35:67, 35:78). Shaming copy for a normal state; error colour misused.
  - The "Back" pill overlaps the "captains didn't accept your ride" message (35:72) and the cancel sheet (35:62, 35:71). Visual bug hiding key status.
  - Gender is a required-looking chip set on sign up (35:84) with no reason given.
  - Set your price (35:74) hints that paying more gets a ride, which can feel like surge by stealth.
  - "Cancel" on the offers sheet is a bright blue pill (35:67) that out-shouts the content.
- **Scores (1 to 5):** visual polish 4, clarity 5, information density 4, trust 4, brand distinctiveness 4.
- **For 30 Sundays:**
  - Borrow the live status sheet (35:63) for the booked trip screen: a status card ("Flights confirmed, hotel vouchers on 12 Jan"), a booking reference in digit boxes, the trip planner card with photo and "Message Ana", "Trip details" link, and "Something not right? Tell us" at the end.
  - Borrow the "finding" summary (35:72) for itinerary versions waiting on the planner: show what was asked and the price while the planner works.
  - Borrow humane cancel friction (35:62): name the planner and what is already done, make "Keep my trip" the fuchsia button.
  - Borrow "drop time" thinking: show arrival day and local time on each flight option.
  - Avoid ads in status screens, red error copy for empty wallets, and overlapping back buttons.

---

### Ola (cabs, rentals, outstation, parcel, 15 screens)

- **Flows covered:** (user order, file order is the reverse)
  - 35:102 Splash (white, logo)
  - 35:101 Welcome ("Explore new ways to travel with Ola")
  - 35:100 OTP log in
  - 35:99 Notification pre-prompt over home
  - 35:98 Home (map, "Where to?", recents, service tiles)
  - 35:97 Ola Parcel (send or receive, rules)
  - 35:96 Ola Electric web page with cookie banner
  - 35:95 Personal loan offer
  - 35:94 Outstation entry with popular destinations
  - 35:93 Outstation route, one-way or round trip, cars
  - 35:92 Car detail with estimated fare breakdown
  - 35:91 Schedule one-way ride time picker
  - 35:90 Rentals entry with packages
  - 35:89 Rentals booking with package chips and cars
  - 35:88 Rental package rules and restrictions
- **Typography:** SF Pro system with a geometric "OLA" wordmark. Weights 400 to 700. Titles 22 to 24 px semibold (35:88 is two lines at 24 px), body 15 px, captions 13 px grey. Prices right aligned, bold, no decimals ("4276", 35:93). Fare breakdown uses label left, amount right, total in bold at the top (35:92).
- **Colour:** light mode. Primary black #111 buttons, brand lime about #C8E03A in the logo and car art, green about #20A84A for the search border and icons, mint tint about #E3F8E0 for the welcome ground. Blue about #1E88E5 for links ("View details", "SELECT"). Greys #F3F4F6 for info cards. Red alert icon on Payment (35:89). Calm: one accent per screen. The loans page (35:95) is loud green.
- **Layout and spacing:** 16 to 20 px gutters, airy. Map on top, white sheet radius 16. Info cards grey, radius 12, no shadow. Options as rows with car render left, name and line, price right. Bordered segmented cards with a check for binary choices (35:93, 35:97). Floating capsule bottom nav (35:98).
- **Section designs:**
  - Fare breakdown (Price display): total first, then base fare, driver allowance, taxes, convenience fee, then plain fine print of what is excluded and extra charges. 35:92.
  - Rules sheet (Detail sections): zebra rate table then bullet rules, Done. 35:88.
  - Destination rail (Card rail): "Popular destinations" square photo tiles under an illustrated travel hero. 35:94.
  - Package chips (Filters and sort): "1 hr 10 km", "2 hr 20 km" selectable chips with a summary line and "View details". 35:89, 35:90.
  - Binary choice cards (Booking form): "One-way, Get dropped off" or "Round trip, Keep the car till return", with a check. 35:93.
  - Wheel time picker (Date picker): day, hour, minute, AM or PM, with Reset. 35:91.
  - Car detail header (Detail hero): name, one-line description, three icon features. 35:92.
  - Rules with icons (Inclusions list): "Fit these specifications" with mint icon circles. 35:97.
  - Notification pre-prompt (Notifications): "Don't miss ride updates!", 3D bell, Not now or Enable. 35:99.
  - Welcome (Onboarding): illustration, one line, one black button. 35:101.
  - Home sheet (Search bar): "Where to?" with recent places in a soft card, then service tiles. 35:98.
- **Strengths:**
  - The fare breakdown (35:92) is the clearest price display in the group: total up top, line items, then honest exclusions in plain words. A direct model for itinerary pricing.
  - Outstation entry (35:94) has the travel mood we want: illustrated road trip, then popular destinations. Simple and warm.
  - Binary choice cards (35:93) explain each option in four words. Good recognition over recall.
  - Notification pre-prompt (35:99) gives a reason and an easy "Not now".
  - Restraint: black buttons and lots of white make each screen calm.
- **Weaknesses:**
  - The rentals screen (35:89) preselects "Prime Plus", which is unavailable, so the main button is disabled with no explanation. Breaks error prevention.
  - Loans (35:95) and Electric (35:96) in the main nav dilute a ride app; loans are cross-sold to every rider.
  - A cookie banner with a bright green "Got It" and no decline option (35:96).
  - The rules sheet (35:88) is a wall of bullets with no hierarchy; key rules (no changes after booking) are buried.
  - Payment shows a red alert icon (35:89) with no message about what is wrong.
- **Scores (1 to 5):** visual polish 4, clarity 4, information density 4, trust 4, brand distinctiveness 3.
- **For 30 Sundays:**
  - Borrow the fare breakdown (35:92) for the itinerary price: total per person first, then flights, stays, transfers, taxes, then "Not included" in plain words.
  - Borrow the outstation entry (35:94) for the cold-start home: one warm illustration, then a destination rail.
  - Borrow binary choice cards (35:93) in the wizard ("Fixed dates" or "Flexible by a week").
  - Avoid preselecting an unavailable option, unexplained alert icons, and cross-selling loans.

---

### CARS24 (used cars buy and sell, loans, services, 17 screens)

Two of the 17 files are CarDekho screens (41:854 and 41:860). They are reviewed under CarDekho. The notes below cover the 15 true CARS24 screens.

- **Flows covered:** (file order)
  - 41:581 Home, Insurance tab
  - 41:582 Home, Challan tab (traffic fines)
  - 41:583 My profile
  - 41:584 Sell: estimated price and free inspection pitch
  - 41:585 Sell: confirm car details
  - 41:586 Sell landing (plate number entry)
  - 41:854 (CarDekho) News list
  - 41:587 Home, Sell car tab
  - 41:588 Car detail page
  - 41:589 Used car listing with filters
  - 41:590 Home, Buy used car tab
  - 41:591 Home, All tab
  - 41:592 Select your location
  - 41:860 (CarDekho) Tata Sierra model page
  - 41:593 Grant access (permissions)
  - 41:594 Create your account
  - 41:595 Login or sign up
- **Typography:** geometric grotesque, likely Inter (possibly a custom cut), weights 400 to 700. Titles 20 to 22 px semibold near black #101828, card titles 16 px semibold, body 14 px grey #475467, labels 12 px. Letterspaced small labels ("Budget", 41:589). Prices bold 18 to 22 px in Indian notation ("4.27 lakh", "43.53L - 47.6L"), with "+ 45,796 other charges" in grey and EMI as a separate bold line ("EMI 7,532/m*", 41:588).
- **Colour:** primary electric indigo about #4736FE for CTAs. Header colour changes per tab: blue about #1E5BFF (insurance), teal about #2C6B66 (challan), forest about #2D6A4F (sell), navy about #1534B8 (buy), indigo (all). Orange about #F07A1A as a second action colour (test drive, location). Lavender tints about #EEF0FF for card grounds, green proof pills, red pills for "Up to 80,000 off" and the countdown. Light mode; four or more accents on home (41:591).
- **Layout and spacing:** 14 to 16 px gutters, dense. Cards radius 16 with no shadow on lavender grounds. 3D illustrated icons in circles. Cars shown as cutouts on a soft "stage" (a 3D grid floor, 41:584, or a lavender arc, 41:589). Sticky bottom bars with one or two buttons. Home is a stack of tile rails.
- **Section designs:**
  - Estimated price range card (Price display): a floating white card over the stage, "Estimated price range", the range, and a green proof pill "Based on 1.7K similar cars sold successfully". 41:584.
  - Why us icons (Trust and proof): three 3D icons "Best price guarantee", "Right at your doorstep", "300+ expert checks". 41:584.
  - Detail page price card (Price display): EMI line with "Check eligibility", then the full price with "+ other charges" and "Price breakup". 41:588.
  - Assurance strip (Trust and proof): "Zero Worry Max" with "Lifetime warranty . 30 days return . 300 checks". 41:588.
  - Gallery by category (Detail hero): full-bleed photo with 1/46 count, spec dots, and round chips Exterior, Interior, Features, Highlights, Tyres. 41:588.
  - Listing card (Listing card): car on a stage, ownership tag on the seam, tier label, "No Repaint" proof tag, price with other charges, spec chips, EMI, trust chips. 41:589.
  - Segment cards (Filters and sort): "Best cars for you", "Cars24 Owned stock", "Verified direct seller". 41:589.
  - Price band tiles (Category tiles): "Budget, under 7 lakhs", "Mid range, 7 to 15", "Premium, above 15". 41:590.
  - Confirm details list (Booking form): icon, value, label, edit pencil where it can change. 41:585.
  - Header category tabs (Home header): 3D icons in circles, active one white with an underline, header colour follows the tab. 41:581, 41:587.
  - Member seal avatar (Profile): "MEMBER SINCE 2026" ring text around the initial. 41:583.
  - City picker (Search bar): illustration, "Use your current location", landmark photo tiles. 41:592.
  - Book now with refund note (Sticky CTA bar): "Book now, 100% REFUNDABLE" next to "Free test drive". 41:588.
- **Strengths:**
  - The price range card (41:584) with a proof line ("Based on 1.7K similar cars sold") turns a scary number into a reasoned one. Strong trust pattern.
  - The detail page (41:588) splits the price question into "what per month" and "what in total, plus what else", each with its own drill-down. Honest and scannable.
  - Trust chips sit on every listing card (41:589), not only on the detail page, so trust is built while browsing.
  - "100% REFUNDABLE" under "Book now" (41:588) removes fear at the moment of commitment.
  - Gallery chips by part of the car (41:588) let buyers jump to what they care about.
  - Price band tiles (41:590) let people browse by budget, the way they actually think.
  - "MEMBER SINCE" seal (41:583) is a small, nice loyalty touch.
- **Weaknesses:**
  - A countdown timer "04:54 min" on a free inspection offer (41:584). False urgency, a dark pattern.
  - Login pre-ticks "Get updates on WhatsApp" and "Fetch my addresses from trusted partners" (41:595). Pre-ticked consent is a dark pattern.
  - Grant access asks to read financial SMS for credit offers (41:593), framed as "personalised experience". Misleading framing; trust risk.
  - The header colour changes on every tab (41:581, 41:582, 41:587, 41:590), so the brand has no stable colour. Breaks consistency.
  - Home (41:591) stacks four coloured tile rails plus red promo pills. Too many accents and too many choices.
  - Two primary colours (indigo and orange) on the same detail page (41:588).
  - The legal wall under login (41:595) has eight links in one paragraph.
- **Scores (1 to 5):** visual polish 4, clarity 4, information density 3, trust 3, brand distinctiveness 3.
- **For 30 Sundays:**
  - Borrow the price range card with proof (41:584) for the destination page and wizard result: "7 nights in Bali, 1.4L to 1.8L per person, based on 860 trips we planned". Proof line in lagoonBliss.
  - Borrow the two-part price card (41:588) for the itinerary: per person and total, then "What's included" and "Price breakup" links.
  - Borrow trust chips on browse cards (41:589) for destination and itinerary cards, but keep to two chips and use outline text, not solid pills.
  - Borrow "fully refundable" or "free changes until" right under the book button.
  - Borrow price band tiles (41:590) for home browsing ("Under 1L", "1L to 2L", "2L plus").
  - Avoid countdown timers, pre-ticked consents, per-tab header colours, and two primary colours.

---

### CarDekho (new and used cars, research, AI expert, 11 screens including 2 misfiled under cars24)

- **Flows covered:** (file order, then the two misfiled screens)
  - 41:855 Used car detail page
  - 41:856 Used car listing
  - 41:857 "Ask Expert" AI sheet over home
  - 41:858 Sell car: welcome back, resume listing
  - 41:859 Sell car: enter selling price with recommended range
  - 41:861 Explore new cars by price and by body type
  - 41:862 Home
  - 41:863 "Logged in successfully": name and WhatsApp opt-in
  - 41:864 Login or register
  - 41:854 (in cars24 frame) News list
  - 41:860 (in cars24 frame) Tata Sierra model page
- **Typography:** two families in use. Lato (light and regular) on the older login screens (41:863, 41:864), Poppins-like geometric sans on newer screens (41:858, 41:859). Weights 300 to 700. Titles 22 px semibold, card titles 18 px, body 14 px, captions 12 px. Prices bold 20 to 22 px in lakh ("12.75 Lakh", "11.49 - 21.29 Lakh*"), with "Get On-Road Price" underlined beside them (41:860).
- **Colour:** primary orange-red about #F15A2B. Home tiles in purple about #8C4BE8, orange, sky blue about #5AA8F5 and periwinkle about #5A6FE0 (41:862). Green call button about #2DBE60, blue "Make Your Offer" link about #1E88E5, pale blue tint strip for history proof (41:855), peach tints for the sell flow. Gradient range bar orange to teal (41:859). Light mode; four accents on home.
- **Layout and spacing:** 20 px gutters, medium density. Cards radius 16 with soft shadow, grey inner price card (41:855). Studio cutout cars on light grey for new cars (41:861), real photos for used. Sections split by white cards on a light grey ground. Sticky full-width orange buttons.
- **Section designs:**
  - Ask an expert (Help and chat): sparkle icon, "Looking for the perfect car? I'll help you find it.", avatars and "2.8M+ users actively asking", three suggested questions in Hinglish, input with mic. 41:857.
  - Recommended range bar (Price display): orange to teal bar from "Average" to "Excellent" with lakh values at each end. 41:859.
  - Answer breadcrumb (Progress and status): chips of earlier answers (1st owner, 40000 km, Pune, Price, Photos) where the current step is outlined and future ones greyed. 41:859.
  - Resume card (Progress and status): "Welcome back, thanks for sharing the details", saved car summary, "Complete Listing" and "Start a New Listing". 41:858.
  - Three-step strip (Itinerary and timeline): "Share your car details >>> Get details of interested buyers >>> Connect with buyers". 41:858.
  - History proof strip (Trust and proof): "No Major Accident or Flood History". 41:855.
  - Value versus new (Price display): "26% less in comparison to new car price" with a down trend icon. 41:855.
  - Price tabs (Filters and sort): "1 - 5 Lakh, 5 - 10 Lakh" tabs over a card rail, then "Cars under 5 Lakh" link. 41:861.
  - Model page tabs (Detail sections): Overview, Price, Compare, Offers, with media chips (+97 images, 360, colours, video, AI Expert). 41:860.
  - Compare checkbox (Comparison): on every listing card and detail page. 41:855, 41:856, 41:860.
  - News cards (Editorial and stories): photo with overlay headline and an orange side bar, title, author and date. 41:854.
  - Big service tiles (Category tiles): 2x2 illustrated colour tiles. 41:862.
- **Strengths:**
  - Ask Expert (41:857) lowers the barrier to asking with ready-made questions in the user's own language mix. A strong model for a planner chat entry.
  - The answer breadcrumb (41:859) shows what you already told them and how far you are, and lets you jump back. Good visibility of system status.
  - Resume card (41:858) remembers unfinished work and offers to finish or restart.
  - The range bar (41:859) frames a price in context of what is normal, not just a number.
  - "Compare" is everywhere it should be (41:855, 41:856, 41:860).
  - History proof (41:855) names the specific fear and rules it out.
- **Weaknesses:**
  - Bundled consent: login (41:864) asks you to agree to data sharing for loans, third-party sharing with dealers and OEMs, and marketing, in one paragraph of links. Dark pattern; no granular choice.
  - The green call FAB overlaps the main orange button (41:855). Visual collision and two competing actions.
  - Two type families across flows (Lato and Poppins). Inconsistent.
  - Home tiles (41:862) in four strong colours, plus a red "LAUNCHED" tag. No colour meaning.
  - "Hurry up to lock festive offers!" (41:860) is urgency copy with no deadline.
  - "Rate & Win 1000" next to reviews (41:860) suggests reviews are incentivised, which weakens their trust value.
- **Scores (1 to 5):** visual polish 3, clarity 4, information density 3, trust 3, brand distinctiveness 2.
- **For 30 Sundays:**
  - Borrow the Ask Expert sheet (41:857) for "talk to a trip planner": three ready questions ("Is Bali good in July?", "Can you fit Ubud and Nusa Penida in 6 nights?", "What will it cost for 2?"), then a text field. Name a real planner instead of an AI sparkle.
  - Borrow the answer breadcrumb (41:859) for the wizard: month, nights, route as chips you can tap to edit.
  - Borrow the resume card (41:858) for unfinished wizard or draft itineraries on home.
  - Borrow the range bar for "typical spend" on the destination page, using brand colours, not red to green.
  - Borrow "Compare" on itinerary versions.
  - Avoid bundled consent, FABs over buttons, and incentivised reviews.

---

### Spinny (used cars, sell, exchange, FASTag, 7 screens)

- **Flows covered:** (file order)
  - 41:886 Side drawer (buy by category, sell, finance, help line)
  - 41:887 Used car listing
  - 41:888 Exchange: estimated price range, check another car
  - 41:889 FASTag recharge
  - 41:890 SellRight: schedule an evaluation (stepper and timeline form)
  - 41:892 Login ("Start your journey")
  - 41:891 Home
- **Typography:** geometric sans, likely Jost or a Futura-style custom, weights 400 to 700. Titles 20 to 24 px semibold in deep aubergine, card titles 16 px bold, body 14 px, captions 12 px. Prices bold right aligned ("5.80 Lakh"), EMI in gold with a dashed underline ("EMI 10,013/m", 41:887). Long prices in full rupees with commas ("35,96,000 - 42,17,000", 41:888).
- **Colour:** brand red about #E8304F (logo, active nav), purple about #5B0F9E for primary CTAs, deep aubergine about #2E0A4A for text and heroes, teal about #0E9F86 for "Sell car", gold about #B8860B for EMI, lavender tints about #EFE6FA. Grounds white and light grey. Illustrated heroes in monsoon teal (41:887, 41:891). Light mode with dark heroes; two to three accents per screen.
- **Layout and spacing:** 16 px gutters, clean. Cards radius 16, soft shadow, car cutouts on a grey swoosh floor (41:887). Service tiles white with 3D icons, 3 columns. Tinted bands for heroes, white cards over them.
- **Section designs:**
  - Stepper and timeline form (Booking form): top stepper "Car Details (done), Car Evaluation (now), Instant Payment", summary of earlier answers with EDIT, then a vertical timeline of steps "Your Location, Select Date, Select Time Slot", with day chips "Tomorrow, Sat, Sun, More dates" and "Evaluation takes 45 - 60 mins". 41:890.
  - Honest failure line (Empty state): "Uh oh! We could not calculate the right price for your car", then the human next step. 41:890.
  - Estimated range with next step (Price display): range, specs, "Get Exact Price", helper "Book a car evaluation to get the accurate price". 41:888.
  - Tiered sub-brands (Category tiles): MAX (luxury), Assured+ (premium benefits), Assured (quality), budget (value picks). 41:886.
  - Listing card (Listing card): car on a floor, heart, title, variant, price right, EMI under, spec chips, hub location, "Assured" mark. 41:887.
  - Help line in the drawer (Help and chat): "Need help? Call us at 727-727-72" pinned at the bottom. 41:886.
  - Buy or sell tiles (Category tiles): two big 3D tiles. 41:891.
  - Plate input (Search bar): "IND" plate prefix field. 41:888, 41:889.
  - Why us list (Trust and proof): 3D icons with title and one line. 41:889.
- **Strengths:**
  - The SellRight screen (41:890) is the best booking form in the group: where you are in the process, what you already said (editable), what is next as a vertical timeline, and how long it will take.
  - It admits failure plainly ("We could not calculate the right price") and turns it into a human appointment. Good error recovery.
  - Range first, exact later (41:888) is honest about uncertainty and makes the next step obvious.
  - Tiered sub-brands (41:886) make quality levels understandable at a glance.
  - The listing card (41:887) is calm: one price, one EMI, a few grey chips, one quality mark.
  - Illustrated seasonal hero (41:891) gives the brand warmth without photos.
- **Weaknesses:**
  - Disabled buttons in pale pink or lilac (41:889, 41:890) look like active brand colour. Users may tap and wonder why nothing happens.
  - The brand red and the purple CTA compete (41:891, 41:892). Two brand colours with no clear split.
  - Season of Exchange banner repeats on home, listing and exchange (41:887, 41:888, 41:891), taking the top of three screens.
  - "Contact us" is a black pill floating on the hero (41:888), easy to miss.
- **Scores (1 to 5):** visual polish 4, clarity 4, information density 4, trust 4, brand distinctiveness 4.
- **For 30 Sundays:**
  - Borrow the stepper and timeline form (41:890) for the wizard and for booking a planner call: "Trip idea (done), Talk to a planner (now), Your plan", then location, day chips, time slot, "Calls take about 20 mins".
  - Borrow the honest failure line for routes we cannot price instantly: "We need a planner for this one" plus a time to talk.
  - Borrow range first, exact later (41:888) for wizard results.
  - Borrow the calm listing card (41:887) for itinerary cards: one price, one per-month or per-person line, few grey chips.
  - Avoid disabled buttons that look active and two competing brand colours.

---

### Group summary

**Patterns that repeat, by component kind**

- Login and OTP: every app uses phone plus OTP with a resend timer (35:85, 41:789, 41:835, 35:100). The good ones add a fallback (WhatsApp 35:85, call 41:789). The bad ones add promos (35:168) or pre-ticked consents (41:595, 41:864).
- Onboarding: permission pre-prompts with reasons are standard (41:809, 35:83, 35:99, 41:593). Best when each reason is one plain line and there is a manual option (35:83).
- Price display: big-ticket apps show a range before an exact price (41:584, 41:888, 41:859, 41:860), split monthly and total (41:588, 41:855), and offer a breakdown link (41:588, 35:92). Health apps stack discounts instead (35:160, 35:162).
- Trust and proof: specific proof beats general claims. "Based on 1.7K similar cars sold" (41:584), "98% Happy Patients | 526 Consults" (35:167), "No Major Accident or Flood History" (41:855), "or your test is FREE" (35:158). Generic stat circles (41:796) are weaker.
- Help and chat: every app offers a human, but in different strengths. Callback sheet (41:808), call pill (41:777), talk-to-us band (41:822), ask expert (41:857), help line in drawer (41:886).
- Listing card: expert and car cards both carry face or photo, credentials, proof, availability and price in one card (35:167, 41:801, 41:589, 41:887).
- Date picker: day chips plus grouped slots (35:158, 35:170, 41:890) and wheel pickers (35:91).
- Progress and status: Rapido's status sheet (35:63), cult.fit's weekly gauge (41:820), CarDekho's answer chips (41:859) and Spinny's stepper (41:890).
- Sticky CTA bar: almost universal. The problem in this group is two equal coloured buttons (41:798, 41:588, 41:855).
- Category tiles: 3D icon grids everywhere (35:60, 41:591, 41:891, 41:806). They are interchangeable across apps and add little brand.
- Empty state: mostly weak (41:793, 35:67, 41:825). Tata 1mg's brand footer (41:771) is the exception.

**The 5 best section designs for a travel app like ours, ranked**

1. Rapido live status sheet (35:63). Status first ("Pickup in 1 min"), proof code, person with face and rating, contact, details link, quiet help link last. This is the booked trip screen almost as is: "Hotel vouchers ready on 12 Jan", booking reference, your planner, "Trip details", "Something not right?".
2. Spinny stepper and timeline form (41:890). Shows the process, past answers with edit, next steps and how long it takes, and admits failure honestly. Model for the wizard and for booking a planner call.
3. PharmEasy expert card plus day-part slot picker (35:167 and 35:170). Answers who, how good, what language, how soon and how much in one card, then makes picking a time easy. Model for "talk to a trip planner".
4. CARS24 price range with proof (41:584), with Ola's fare breakdown (35:92) as its drill-down. A range that explains itself ("based on 1.7K similar") then an honest line-item breakdown with exclusions. Model for destination page price and itinerary price.
5. cult.fit weekly progress sheet and mini bar (41:820 and 41:831). A small goal, where you stand, what most people do, warm copy, and a pinned mini bar on home. Model for Sunday School progress and a pre-trip countdown on home.

Runners up: CarDekho Ask Expert with ready questions (41:857), CarDekho answer breadcrumb (41:859), Pristyn two-question callback sheet (41:808), Tata 1mg brand footer for empty states (41:771), Ola outstation entry with destination rail (35:94), Rapido humane cancel friction (35:62).

**The 5 things to never copy**

1. False urgency timers (41:584 "04:54 min" on a free inspection; also "Hurry up to lock festive offers!", 41:860). It makes a premium, considered purchase feel like a flash sale and erodes trust.
2. Pre-ticked and bundled consent (41:595 pre-ticked WhatsApp and partner data, 41:864 one paragraph agreeing to loan and dealer data sharing, 41:593 reading financial SMS framed as "personalised"). Dark patterns, and a legal risk.
3. Stacked discount pricing (35:160, 35:162: MRP, strike, % off, coupon price, membership credits, "best value" on one item). The real price disappears; it breaks our rule of short, plain price lines.
4. Two equal coloured primary buttons on every card and sticky bar (41:801, 41:798 blue and orange; 41:588 indigo and orange; 41:855 FAB over the button). Breaks our one-fuchsia-action rule and makes users hesitate.
5. Offer-led heroes with no content fallback (41:831, 41:828, 41:829: blank video area with only "FREE 3 Months Extension + Extra 1,400 OFF"), plus ads inside status screens (35:63). Our home and booked trip must lead with the trip, not a discount or an ad.
