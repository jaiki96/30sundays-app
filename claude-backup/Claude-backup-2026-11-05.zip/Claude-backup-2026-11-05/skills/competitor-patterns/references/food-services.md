# Food and services group: critical evaluation

Group: food-services. Apps: Zepto (24 screens), BigBasket (33), Blinkit (21), Swiggy (27), Zomato (43), Urban Company (21). Total 169 screens, every one opened.

Notes before reading:
- In every app the screens sit on the canvas in reverse order (newest capture first). The flows below are rewritten in user-journey order.
- None of the six sets contains an order-tracking or live-status screen, and none has a full reviews page. Status and proof patterns are taken from what is there: ETA headers, unlock progress, step journeys, confirmations and rating chips. A future capture round should add Swiggy and Zomato live tracking and Zomato reviews.
- Only one designer note sits on this part of the canvas: "white space" (122:2), placed beside the Zepto splash 35:155. Two audit notes elsewhere matter here: "how far??? exact location, opens till, book a table, amenities" (149:5) and "remake cards" (149:8) on our own Where to eat section, plus "revise where to eat section by researching competitors" (141:87). The Zomato and Swiggy Dineout sections below answer them.
- Sizes are approximate px at a 390 wide phone.

---

### Zepto (quick commerce, 24 screens)

- **Flows covered:**
  - 35:155 splash (purple gradient, wordmark, "everything in minutes*")
  - 35:154 sign-up name and optional referral code ("You're almost there!")
  - 35:150 home, default zepto tab (₹0 fees promise, first-order prices, referral card)
  - 35:151 home with "Introducing special deals" interstitial bottom sheet
  - 35:142 home, Fresh tab (store tabs as folder cards, category tiles, rail)
  - 35:143 home, Super Mall tab (dark header, sub-nav, "Home New Home" hero)
  - 35:144 home, Summer Store tab (sky header, 2x3 themed tile grid)
  - 35:149 all categories grid
  - 35:147 Fresh Fiesta sub-store ("Especially For You", icon tiles)
  - 35:148 Trending Near You grid
  - 35:145 Packaged Food listing (left category rail, banner, 2-col grid)
  - 35:146 brand page (Exo), sold-out state
  - 35:141 search autosuggest with an ad row
  - 35:140 search results "chips" (filter chips, sponsored rail, 3-col grid)
  - 35:139 product detail, not in cart
  - 35:138 product detail, in cart (stepper, View Cart)
  - 35:137 cart before address ("Add Address to Proceed")
  - 35:153 location permission off sheet
  - 35:136 map pin ("Order will be delivered here")
  - 35:135 add address details form
  - 35:134 "Your address has been saved" confirmation
  - 35:152 select location list (current location, request from friend)
  - 35:132 cart with "Add Receiver's Details" sheet
  - 35:133 cart final (coupon, schedule, two pay buttons)
- **Typography:** geometric grotesk, likely a custom face close to Gilroy or Norms. Weights 400 to 800. Delivery time "6 minutes" about 20px extra bold, section titles 18 to 20px bold, product names 14px medium (2 lines), pack size and captions 12px grey. Promo display is heavy all caps ("₹0 FEES", "EVERYDAY LOWEST PRICES", 35:150), plus one serif display only on Super Mall (35:143). Prices: selling price 15 to 16px bold set white on a green chip (35:140), MRP 12px grey strike, saving as green caps "₹31 OFF".
- **Colour:** brand purple #5B0FB3 to #8A12C9 (splash, header), CTA pink #FF3269, price chip green #1F8A3B, saving green #1B8A3A, coupon nudge orange #F07D0D, ground grey #F4F5F7, text #1C1C1C, secondary #6B7280, dark toast #2B2F3A. Store tabs re-tint the whole header: lilac #E9D5FF (35:150), pale yellow #FFF1C9 (35:142), navy #1E1446 (35:143), sky blue (35:144). On one screen pink, green, purple and orange fight (35:133, 35:140). Light theme, gradients in headers and splash.
- **Layout and spacing:** 16px gutters, high density. Tiles grey #F3F5F7 radius 12, cards white radius 12 to 16 on grey ground, no shadows, separation by ground colour and white space. Product images square. Sections split by tinted panels (35:144) and centred titles between hairlines (35:143). Floating layers stack up: dark "Unlock free delivery" toast, an Offers tab, an ad bubble on the right edge, and an ad inside the bottom nav (35:142).
- **Section designs:**
  - Splash: gradient + wordmark + one line (35:155).
  - Home header: delivery time as the headline, address under it, store tabs drawn as folder cards that merge into the header (35:142).
  - Search bar: rotating placeholder with a promo tile docked beside it (35:142).
  - Category tiles: grey square tiles, label below, active state pink underline (35:142); themed 2x3 tiles with title on top and product cut-outs below on a cream panel (35:144); mixed-span grid with one double-width tile (35:149).
  - Trust and proof: three green-tick promises "₹0 Handling fee, ₹0 Delivery fee*, ₹0 Rain & Surge fee" (35:150); refund and delivery trust tiles on product detail (35:138).
  - Offers and coupons: coupon card with "Shop for ₹776 more" progress copy and a Locked state (35:133); full-sheet deal interstitial (35:151).
  - Referral: "Got a referral code? Claim your FREE Gift!" card with outline button (35:150).
  - Listing card: image, heart, ADD button overlapping the image corner, price chip, strike, saving, attribute tag "No Palm Oil" (35:140).
  - Filters and sort: icon button + Sort, Brand, Type, Flavour chips with chevrons (35:140).
  - Detail hero: full-bleed product image with dots (35:138).
  - Price display: green price chip, MRP strike, "incl. of all taxes" (35:138).
  - Sticky CTA bar: View Cart outline + pink stepper (35:138); To Pay + Pay Online + Pay Cash (35:133).
  - Booking form: address form under a third-height map (35:135); receiver details sheet with contacts icon (35:132).
  - Map: pin with dark tooltip and a single Confirm Location (35:136).
  - Confirmation: full white "address saved" interstitial (35:134).
  - Empty state: location-off sheet with sky illustration and 3D pin (35:153).
  - Editorial and stories: Trending Near You with an illustrated shop awning header (35:148).
  - Bottom nav: Home, Categories, Trending, Fresh with LIVE tag (35:142).
- **Strengths:**
  - Speed is the headline, literally: the delivery time is the biggest type on home (35:142). Clear value framing.
  - The three ₹0 promises with ticks are a plain, scannable trust row (35:150).
  - Address flow is well staged: permission sheet, map pin, form, saved confirmation (35:153, 35:136, 35:135, 35:134). Disabled save until valid (35:135).
  - "Request address from friend" via WhatsApp is a thoughtful option for gifting (35:152).
  - Product detail puts rating, count and ETA on one line above the title (35:138).
- **Weaknesses:**
  - Two pay buttons side by side at checkout, one outline, one solid (35:133). Splits the primary action (Hick's law).
  - Interstitial deal sheet blocks home on open, with "Available till stocks last" scarcity copy (35:151). Dark pattern, breaks user control and freedom.
  - Ads everywhere: autosuggest ad row (35:141), Ad tags in grids (35:145, 35:148), an ad bubble floating over content and an ad slot in the bottom nav (35:142). Aesthetic and minimalist design broken.
  - Each store tab repaints the header in a new colour and type style (35:142, 35:143, 35:144). The app has no single visual identity across tabs (consistency and standards).
  - Fresh Fiesta shows a one-column card with half the width empty (35:147), likely a layout bug.
  - Sign-up screen is a bare form with no brand and no reason to give a name (35:154).
- **Scores (1 to 5):** visual polish 3, clarity 3, information density 2, trust 3, brand distinctiveness 3.
- **For 30 Sundays:**
  - Borrow for home: the promise row with ticks (35:150) as a short "What every trip includes" line, in lagoonBliss, not green.
  - Borrow for wizard: the staged address pattern (35:153 to 35:134), one decision per screen with a calm confirmation, for traveller details.
  - Borrow for booked trip: a big headline fact at the top (here "6 minutes", for us "Bali in 23 days").
  - Avoid: dual CTAs (35:133), opening interstitials (35:151), per-tab colour swaps (35:142 to 35:144), floating ad layers (35:142).

---

### BigBasket (grocery, 33 screens)

- **Flows covered:**
  - 38:214 login (photo-collage ground, "Share your number to get started", Skip)
  - 38:213 OTP (6 boxes, resend timer)
  - 38:212 home, All tab (Big Indian Grocery Sale panel, header collapsing on scroll)
  - 38:209 home, Fresh tab (mango of the week banner)
  - 38:210 Smart Basket / Top picks (left rail, 2-col grid)
  - 38:211 categories (sectioned 4-col tiles)
  - 38:196 home, Pets tab
  - 38:197 home, Beauty tab
  - 38:198 home, Kids tab ("Shop by age")
  - 38:199 home, Toys tab
  - 38:200 home, Gifting tab ("Occasion" icon tabs)
  - 38:201 home, Deals tab
  - 38:202 home, Health tab ("Shop by goal / diet / lifestyle / allergen")
  - 38:203 home, Organic tab
  - 38:204 home, Summer tab
  - 38:205 home, School time tab
  - 38:206 home, bbCafe tab
  - 38:207 home, Electronics tab
  - 38:208 Electronics tab loading skeleton
  - 38:193 BB Cafe store page
  - 38:191 empty search
  - 38:190 search autosuggest
  - 38:189 search results (filters, brand rail, 3-col grid)
  - 38:188 product detail (pack sizes)
  - 38:192 wishlist empty state
  - 38:194 my account
  - 38:195 select delivery location
  - 38:186 map pin
  - 38:185 address details, empty
  - 38:184 address details, filled
  - 38:187 basket without address
  - 38:183 basket with address (Now or Later, voucher, bag toggle)
  - 38:182 payment options
- **Typography:** clean humanist-geometric sans, likely Proxima Nova or a close custom face. Weights 400 to 700. Headers "12 mins" 22px bold, section titles 18 to 20px semibold in near-black navy, tile labels 13px medium centred on two lines, captions 12px. Campaign type is a heavy condensed display, all caps ("BIG INDIAN GROCERY SALE", "BESTSELLERS YOU'LL LOVE", 38:212, 38:204). Prices 16px bold, MRP 12px grey strike, discount as yellow tag black text "₹18 OFF" (38:189).
- **Colour:** brand green #0C8A41, deep green #0B3B1E (segmented control, login ground), lime #84C225, offer yellow #FFE600, magenta #D6006E (NeuCoins, Flash Sale), cafe red #E31837, link blue #1F7CE0, tile grey #F3F3F3, white ground. Every home tab has its own pastel header: lavender #E3E3FF (38:196), pink (38:197), sky #D6E8FA (38:198), yellow #FFF3B0 (38:199), lime (38:202), peach #FFE2C2 (38:204), cream (38:205). On deal cards three accents meet: yellow tag, magenta Flash Sale pill, green price (38:201). Light theme.
- **Layout and spacing:** 16px gutters, dense. Tiles radius 12, cards radius 16 on grey #F2F2F2 (38:182). Tile shapes change per tab: blobs (38:196, 38:198), arches (38:196, 38:198), shopping bags (38:197), jars (38:201). Floating pill bottom nav with a round BB Cafe button beside it. Sections split by white space and the per-tab tinted header band.
- **Section designs:**
  - Login and OTP: product photo collage ground with a white bottom card (38:214); OTP card with edit and timer (38:213).
  - Home header: time + 24x7 chip, address, rotating search, folder-style category tabs whose active tab merges into the page (38:212).
  - Category tiles: sectioned 4-col grey tiles with cut-outs (38:211); arch portrait tiles by age, "Infants (0-2)" (38:198); intent circles "Shop by goal / diet / lifestyle / allergen" (38:202); occasion icon tabs (38:200).
  - Hero banner: "MANGO OF THE WEEK" with a "Carbide free" chip and witty copy "Basically, mango nobility!" (38:209); illustrated "SUMMER is here!" (38:204); torn-paper "BACK TO SCHOOL" (38:205).
  - Card rail: bestsellers with arrow button (38:197); skeleton loading rail (38:208).
  - Listing card: veg dot, + square button, brand caps, weight dropdown, yellow offer tag, rating and ETA (38:189).
  - Filters and sort: chips with down triangles (38:189); left vertical rail with green active bar (38:210).
  - Detail hero and Price display: hero image with pack overlay, rating chip top right, pack-size cards with per-gram price (38:188).
  - Offers and coupons: voucher row "Add items for ₹279 more to unlock" + "25 more vouchers for you" (38:183); payment offers in green (38:182).
  - Booking form: "Who are you ordering for? Myself / Someone else", Home/Office/Others chips with icons (38:184).
  - Payment: UPI app tiles, card, offer rows (38:182).
  - Sticky CTA bar: Total with strike + green "Proceed to Pay" (38:183).
  - Empty state: wishlist with finger-heart illustration "Found something you like?" (38:192); empty search (38:191).
  - Profile: monogram pattern card, 3 icon shortcuts, list rows (38:194).
  - Video: video card inside the cafe page (38:193).
  - Bottom nav: floating pill with mint active state plus a separate cafe button (38:212).
- **Strengths:**
  - Intent-based entry points: "Shop by goal / diet / lifestyle / allergen" (38:202), "Shop by age" (38:198), "Occasion" (38:200). People choose by need, not by product type.
  - The categories page is the calmest screen in the group: three sections, one tile style, one label style (38:211).
  - Pack-size cards show the per-unit price so comparison is honest (38:188).
  - Real skeleton loading instead of a spinner (38:208).
  - Basket asks "Now 14 mins / Later 2 hrs" with a clear segmented control (38:183).
  - Witty, short banner copy that has a voice (38:209).
- **Weaknesses:**
  - Fifteen tabs, fifteen colour schemes and five tile shapes (38:196 to 38:212). The brand disappears; consistency and standards broken.
  - Electronics cards carry three prices and four tags: "EXTRA ₹50 OFF" ribbon, "35% OFF", strike, "BEST DEAL @ ₹22990" chip, spec tags (38:207). Recognition over recall fails, nobody can tell the real price.
  - Two promo tags on one card, yellow % OFF plus magenta "Flash Sale" (38:201).
  - Truncated section titles ("Grab your masaledaar favo...", 38:189; "First order treat" cut off, 38:209).
  - Payment screen is a wall of offer T&C copy in green (38:182).
  - Typo "See all result for Maggi" (38:190).
- **Scores (1 to 5):** visual polish 3, clarity 3, information density 2, trust 3, brand distinctiveness 2.
- **For 30 Sundays:**
  - Borrow for home or wizard: intent tiles (38:202) as "Trips by mood" (slow, adventure, food, beaches), and audience tiles (38:198) as "Who's going" (solo, friends, family, couple) to stay neutral.
  - Borrow for destination page: the single-style category page (38:211) as the model for a "things to do" grid.
  - Borrow for wishlist: the empty state (38:192), one illustration, one question, one action.
  - Borrow for itinerary loading: the skeleton rail (38:208).
  - Avoid: per-tab rainbow theming (38:196 to 38:212), stacked price tags (38:207, 38:201), T&C-heavy offer copy (38:182).

---

### Blinkit (quick commerce, 21 screens)

- **Flows covered:**
  - 41:287 login (product tile wall, "India's last minute app", Skip login)
  - 41:286 OTP
  - 41:285 home, All tab (bento bestseller collages)
  - 41:284 home, Vacations tab
  - 41:283 home, Electronics tab
  - 41:282 home, Beauty tab
  - 41:281 home, Decor tab
  - 41:280 home, Kids tab (bento deals)
  - 41:279 home, Gifting tab (Featured notch cards)
  - 41:278 home, Imported tab
  - 41:276 categories
  - 41:275 Print Store
  - 41:277 Order Again, empty
  - 41:272 product detail sheet (Monster)
  - 41:273 your account
  - 41:274 Blinkit Money
  - 41:271 checkout before address ("Choose address at next step")
  - 41:270 location question sheet over location picker
  - 41:269 add address details
  - 41:268 review delivery pin
  - 41:267 checkout with address (cart deal progress, payment CTA)
- **Typography:** Okra (Blinkit's known face), a geometric-humanist sans. Weights 400 to 800. "8 minutes" style header 24 to 26px extra bold, titles 18px bold, product names 13 to 14px medium, captions 11 to 12px. Store headers use custom display ("IMPORTED STORE" serif caps, 41:278; "TINY TOTS ZONE", 41:280). Prices 16 to 18px bold, small grey strike, discount in blue "9% OFF on MRP" (41:278).
- **Colour:** brand yellow #F8CB46 (header gradient), CTA green #0C831F, discount blue #256FEF, tile aqua #E9F5F4, beige tag #FDF1D9, ground white and #F4F6FB, text #1C1C1C, grey #666666. Lilac for "Imported" tags and the cart deal card (41:278, 41:267). Usually two to three accents per screen. Light theme, yellow and beige header gradients.
- **Layout and spacing:** 16px gutters, dense but even. Tiles radius 12, pale aqua with no border (41:276). Product cards white with a thin border. Bento grids mix a tall tile with four small ones (41:280, 41:284). Sections separated by white space and section titles with a one-line subtitle.
- **Section designs:**
  - Login and OTP: product tile wall that fades into white above a simple phone input (41:287).
  - Home header: yellow gradient, time, address, category icon tabs with underline (41:285).
  - Category tiles: bento collage tile, four product cut-outs in a 2x2 + "+385 more" pill + label (41:285); aqua tiles 4-col (41:276).
  - Hero banner: illustrated "SUMMER VACATION" store header (41:284); celebrity photo banner (41:282).
  - Card rail: "Featured" notch-tab photo cards (41:279, 41:283); global favourites rail with "All Rusks & Wafers >" link per card (41:278).
  - Listing card: tag, ADD outline, price, strike, blue discount, ETA, star count (41:278).
  - Detail sections: attribute chips (Chilled, Calorie, Sugar), unit selector cards, brand row, "72 hours only replacement" policy row (41:272).
  - Sticky CTA bar: price + "Inclusive of all taxes" + Add to cart (41:272).
  - Offers and coupons: cart deal with progress bar and lock "Add items worth ₹87 more" (41:267).
  - Booking form: City and Area cards with Change, Myself / Someone else, Save as Home / Work / Hotel / Other (41:269).
  - Map: pin with neighbour house-number bubbles and a key-value summary of the address (41:268).
  - Progress and status: honest CTA label "Choose address at next step" (41:271); "Do you want this order at your current location?" sheet (41:270).
  - Empty state: Order Again with illustration, explanation and a bestseller rail below (41:277).
  - Wallet and rewards: Blinkit Money with three benefit cards (41:274).
  - Profile: birthday prompt card, 3 tiles, appearance setting, "Hide sensitive items" toggle (41:273).
  - Other (utility store): Print Store with a bullet spec card and Upload Files (41:275).
  - Bottom nav: Home, Order Again, Categories, Print + a red Zomato slot (41:275).
- **Strengths:**
  - The bento collage tile with a "+385 more" count is the best category tile in the group: it shows range and depth at a glance (41:285).
  - Address is confirmed with a key-value summary before saving (41:268), and "Hotel" is a save-as option (41:269).
  - CTA copy says what happens next: "Choose address at next step" (41:271). Visibility of system status.
  - Product detail turns specs into chips and puts the replacement policy in plain words (41:272).
  - The empty Order Again screen explains the feature and still offers something to do (41:277).
  - Account offers "Hide sensitive items", a rare privacy courtesy (41:273).
- **Weaknesses:**
  - Two stacked bottom sheets with two close buttons (41:270). Users cannot tell which X closes what.
  - Every tab title carries a subtitle ("Nature's perfect gift / Get plants and bouquets...", 41:279; "Endless fun for busy minds" + subtitle, 41:284). Adds reading with no new information.
  - Store headers swap type styles (serif caps 41:278, rounded kids type 41:280, script 41:281).
  - A rival brand (Zomato) sits in the bottom nav (41:275), muddying navigation.
  - Blinkit Money uses huge grey watermark text that reads as noise (41:274).
- **Scores (1 to 5):** visual polish 4, clarity 4, information density 3, trust 4, brand distinctiveness 4.
- **For 30 Sundays:**
  - Borrow for home: the bento collage tile (41:285) for destinations, four photos and "+12 trips" on one tile.
  - Borrow for booked trip: the key-value summary with Edit (41:268) for traveller and flight details.
  - Borrow for wizard: next-step CTA labels (41:271), for example "Pick dates next".
  - Borrow for profile: the birthday card (41:273) to capture travel dates that matter.
  - Avoid: stacked sheets (41:270), subtitles under section titles (41:279, 41:284), house rule.

---

### Swiggy (food delivery and super app, 27 screens)

- **Flows covered:**
  - 41:318 phone login (flag, Skip)
  - 41:317 OTP (SMS or Call)
  - 41:316 name capture
  - 41:315 coach overlay on home tabs
  - 41:314 Food home (Crave-athon campaign, offer medallions)
  - 41:313 Instamart home (rain advisory toast)
  - 41:312 Dineout home (DineCash, mood tiles)
  - 41:310 Scenes home (event posters)
  - 41:311 Scenes interest picker
  - 41:309 DineCash wallet (how it works, restaurant cards)
  - 41:305 Bolt landing (15-minute food)
  - 41:304 99 store
  - 41:303 EatRight landing
  - 41:301 restaurant page top (McDonald's)
  - 41:302 restaurant page with coach mark on a filter
  - 41:299 restaurant menu scrolled (2-col items, View Cart bar)
  - 41:300 item customisation sheet
  - 41:298 cart, no address
  - 41:306 select location, no saved addresses
  - 41:297 map, zoom-in guidance
  - 41:296 map, pin placed
  - 41:294 add address, House
  - 41:295 add address, Other
  - 41:293 confirm details modal
  - 41:292 cart (Bolt), payment
  - 41:307 profile
  - 41:308 One membership
- **Typography:** Gilroy or a close geometric sans (Swiggy's known face). Weights 400 to 800. Restaurant name 22px bold, section titles 18 to 20px extra bold, body 14px medium, spaced caps labels 12px ("SAVINGS CORNER", "ONE BENEFITS", "POPULAR BRANDS"). Campaign display heavy condensed (Crave-athon, 41:314; "15 MIN SCOOPS", 41:305). Prices 14 to 16px bold, discounted price on a yellow highlight box (41:299, 41:304). Wallet balance 56px (41:309).
- **Colour:** Swiggy orange #FF5200 (address, OTP, save), green CTA #1BA672 (Pay, ADD, View Cart), rating green chip, price highlight yellow #FFE14D, text #02060C, grey #676A6D, ground #F0F0F5. Each vertical owns a dark header: maroon #4A0F14 (Food, Bolt), magenta #6A0F6E (Instamart), black (Scenes), green-black with gold #C9A24B (Dineout, DineCash), deep purple (EatRight), blue sunburst (99 store). Content is light, headers dark. Orange and green compete for "primary" on the same flow (41:294 vs 41:292).
- **Layout and spacing:** 16px gutters, dense. Cards radius 16 to 20, white on grey ground, no shadow. Folder-style vertical tabs across the top (41:312, 41:313). Segmented controls in black (41:294, 41:292). Floating black MENU button and green View Cart bar on menus (41:299).
- **Section designs:**
  - Login and OTP: plain phone input with Skip (41:318); OTP with "Get via SMS / Call" (41:317); name capture on an orange sheet (41:316).
  - Onboarding: interest picker "what's your vibe? Select at least 3", staggered photo tiles with caps labels (41:311); coach overlay (41:315).
  - Home header: dark header, address, membership pill, avatar, folder tabs, search with mic and VEG toggle (41:314).
  - Hero banner: campaign wordmark with mascot and Order Now (41:314); 3D mascot hero (41:303).
  - Category tiles: "What's on your mind?" circular photo tiles with active ring (41:304); dark Dineout tiles with white text and chevrons ("Fine Dining", "Nightlife & Drinks", 41:312); brand logo circles (41:305).
  - Offers and coupons: curved-text offer medallions (41:314); "SAVINGS CORNER" with applied coupon check (41:292).
  - Detail hero: restaurant card with medals "Best in Burger", rating box with "15K+ ratings", ETA, offer carousel inside the card (41:301).
  - Trust and proof: "Swiggy Seal" link (41:301); medals (41:301); Bestseller labels (41:299).
  - Listing card: dish card with protein and kcal line, restaurant and time row (41:303); Dineout restaurant card with rating, distance, cuisine, price for two, pre-book offer (41:309).
  - Filters and sort: veg toggles, Ratings 4.0+, EatRight chips (41:299).
  - Booking form: House / Office / Other segmented, optional building photo, delivery instructions (41:294).
  - Map: "Zoom in to place the pin at exact delivery location" inline guidance (41:297); building numbers on map (41:296).
  - Confirmation: confirm details modal with Edit and Confirm (41:293).
  - Sticky CTA bar: "1 Item added / View Cart" (41:299); "PAY USING" + Pay ₹208 (41:292).
  - Itinerary and timeline: "How does 2X DineCash work" 3-step dotted timeline (41:309).
  - Wallet and rewards: DineCash balance and 2X badge (41:309).
  - Notifications: rain advisory toast "Deliveries can take a little longer as drivers are riding slow in rains." (41:313).
  - Editorial and stories: Scenes tall event posters (41:310).
  - Profile: header, membership card, 4 tiles, long list, "BROWSE PAST ORDERS" pill (41:307).
  - Empty state: no saved addresses with map illustration (41:306).
  - Bottom nav: Food, Bolt (15 MIN), 99 store, EatRight (NEW) (41:303).
- **Strengths:**
  - The interest picker is a strong, visual onboarding step, photos with one word each (41:311).
  - Dineout restaurant cards answer the practical questions: rating, distance in km, area, cuisine, price for two, offer (41:309).
  - DineCash explains itself in three numbered steps (41:309). Good recognition over recall.
  - The rain advisory toast sets expectations before the user asks (41:313). Visibility of system status.
  - Map guidance tells the user exactly what to do ("Zoom in...", 41:297) and the address form asks for an optional door photo with the reason stated (41:294).
  - The customisation sheet explains why choices are preselected, in one friendly line (41:300).
- **Weaknesses:**
  - Cart shows a coach tooltip and a toast at the same time, plus a ₹1 membership upsell, a coupon block and a "Don't miss out" nag (41:292). Aesthetic and minimalist design broken.
  - Two brand colours both act as primary: orange for Save Address (41:294), green for Pay (41:292).
  - Six verticals, six header colour schemes and six display styles (41:303 to 41:314). The app feels like a mall, not one product.
  - Coach marks and spotlights interrupt the first visits (41:302, 41:315).
  - Profile list mixes insurance, train food and corporate rewards in one long list (41:307), poor grouping.
  - "LIMITED TIME DISCOUNT" urgency on the membership page (41:308).
- **Scores (1 to 5):** visual polish 4, clarity 3, information density 2, trust 3, brand distinctiveness 3.
- **For 30 Sundays:**
  - Borrow for destination page "Where to eat": the Dineout card fields (41:309): photo, name, rating with count, area and distance, cuisine, price for two, one offer line. Add "Open till" and "Book a table" from audit note 149:5.
  - Borrow for wizard or wishlist onboarding: the interest picker (41:311), "Pick 3 things you love on holiday".
  - Borrow for booked trip: the 3-step "how it works" timeline (41:309) for "What happens next", and the advisory toast (41:313) for weather or visa alerts.
  - Avoid: tooltip plus toast together (41:292), two competing primary colours (41:294, 41:292), urgency copy (41:308).

---

### Zomato (food delivery and dining, 43 screens)

- **Flows covered:**
  - 41:356 Dining tab (ticket banner, Top picks, "In the mood for", Map pill)
  - 41:355 Healthy mode home (centre-focus dish carousel)
  - 41:354 District cross-sell interstitial
  - 41:357, 41:358, 41:359, 41:361, 41:362, 41:363, 41:364, 41:365, 41:366, 41:368, 41:369, 41:370, 41:371, 41:372, 41:373, 41:360, 41:367 "Meals under ₹250" tab, one per dish tab (Fried Rice, Pizza, Pasta, Momo, Biryani, Fries, Chole Bhature, Sandwich, Bowl, Noodles, Chinese, Italian, North Indian twice, All, Wings, Rolls). 41:371 and 41:372 are duplicates.
  - 41:375, 41:376, 41:377, 41:378, 41:379, 41:380, 41:382, 41:383, 41:386, 41:387, 41:385, 41:384, 41:374, 41:389, 41:381, 41:388 dish category pages (Thali, Sandwich, Biryani, Chole Kulche, Chilli Potato, Cold Coffee, Samosa, Dosa, Chicken, Chole Bhature, Chicken Biryani, Burger, Pasta, Cake, Waffles, Pizza)
  - 41:350 restaurant page (Nirula's)
  - 41:351 select a location sheet
  - 41:348 map and delivery details
  - 41:349 coupon bottom sheet
  - 41:347 cart
  - 41:352 profile
  - 41:353 Zomato Money, empty
- **Typography:** geometric sans, likely Okra or Metropolis (Zomato's house faces). Weights 400 to 800. Restaurant name 24 to 26px bold (41:350), restaurant names in grids 14px semibold, dish names 16px semibold, spaced caps labels 13px with about 2px tracking in grey ("RECOMMENDED FOR YOU", "TOP PICKS", "TRANSACTION HISTORY"). Campaign display heavy condensed caps on a ribbon ("MEALS UNDER ₹250 / FINAL PRICE, BEST OFFER APPLIED", 41:357). Prices 16 to 18px bold, shown to the paisa (₹209.87, 41:357), strike grey, "Best offer applied" in blue.
- **Colour:** Zomato red #E23744 (CTA #EF4F5F), rating green chip #267E3E (white text), offer blue #256FEF, dark image tag black at 70 percent, ground #F4F5F7, text #1C1C1C, grey #696969, District purple #5A2BD9, Healthy mode dark green #2C3E1F, Gold black with gold. Usually red, green and blue on one screen (41:357, 41:375), which stays readable because each has one job. Light theme, sky-blue gradient header on Under ₹250.
- **Layout and spacing:** 16px gutters, medium density. Restaurant grid 3-col, photo 4:3 radius 12, rating chip overlapping the photo's bottom-left edge, offer tag on the photo's top-left (41:375). Dish rows put a 1:1 photo on the right with ADD overlapping its bottom (41:350). Floating pill bottom nav plus a separate dark "Healthy Mode" pill (41:357). Sections separated by white space and spaced-caps labels between rules.
- **Section designs:**
  - Home header: address with chevron, District pill, wallet icon, avatar (41:357).
  - Category tiles: circular dish photos with a red underline on the active one (41:357, 41:375); a promo poster tile at the start of the dish row (41:389); mood tiles "In the mood for" (Drink & dine, Cozy cafes, Romantic dining, Rooftops) (41:356).
  - Filters and sort: two rows of chips, with dish-specific sub-chips carrying tiny food icons ("Flat White", "Boneless", "Margherita") (41:375, 41:380, 41:385, 41:388).
  - Offers and coupons: welcome journey card "Enjoy welcome benefits on first 3 orders", step 1 open, steps 2 and 3 locked (41:375); coupon sheet "Save ₹100 on this order" with one APPLY (41:349); "You saved ₹35 on this order" strip (41:347).
  - Listing card: restaurant photo with offer tag, rating chip, name, time (41:375); dining card with "Flat 25% off" tag and mall name (41:356); dish combo card with split photo (41:365, 41:369).
  - Detail hero: restaurant header with name, info icon, distance and area, time and "Schedule for later", rating box with "2.2K ratings", "Frequently reordered" chip, free delivery line and "7 offers" (41:350).
  - Detail sections: menu rows with veg mark, "Highly reordered" bar, price, 2-line description with "more", bookmark and share, photo right (41:350).
  - Reviews and ratings: rating box with count link (41:350), rating chips on every card (41:375).
  - Trust and proof: "Frequently reordered", "Highly reordered" (41:350), "Final price, best offer applied" (41:357).
  - Card rail: centre-focus carousel with peeking sides and nutrition footer (41:355).
  - Map: delivery pin with tooltip, delivery details sheet (41:348); floating Map pill on dining (41:356).
  - Booking form: "Address details*" with an example placeholder, receiver details row (41:348).
  - Sticky CTA bar: To pay + Pay on delivery (outline) + Pay now (solid) (41:347).
  - Wallet and rewards: Zomato Money with filter chips and empty history (41:353).
  - Empty state: wireframe-card illustration "Your transactions will appear here" (41:353).
  - Profile: grouped lists with red accent bars on group titles (41:352).
  - Other (cross-sell takeover): District full screen (41:354).
  - Bottom nav: floating pill, Home / Under ₹250 / Dining + Healthy Mode (41:357).
- **Strengths:**
  - The restaurant header answers the first five questions in five lines: how far, how long, how good (with count), how popular ("Frequently reordered"), what's on offer (41:350). This is the model for our Where to eat card and detail.
  - Proof through behaviour, not stars: "Highly reordered" on a dish (41:350). More believable than a star.
  - "In the mood for" mood tiles group places by occasion, not cuisine (41:356).
  - The welcome journey card shows a multi-step reward as a short path with locks (41:375). Clear progress.
  - One template repeated across 17 dish tabs without drift (41:357 to 41:373). Strong consistency.
  - Sub-chips adapt to the dish (Cold Coffee gets "Flat White, French, Frappe", 41:380).
  - "Final price, best offer applied" removes coupon hunting (41:357).
  - The coupon sheet has one message and one button (41:349).
- **Weaknesses:**
  - Prices to the paisa (₹184.24, 41:358) look computed, not designed, and are hard to compare.
  - Ad tags on almost every restaurant section (41:357 to 41:373), so "recommended" reads as "paid".
  - District takeover interrupts the flow and pushes another app install (41:354).
  - Cart has two red actions side by side, Pay on delivery and Pay now (41:347), plus a ₹1 Gold upsell.
  - Offer tags are dark boxes on top of food photos, every card has one (41:375). Visual noise repeats twelve times per screen.
  - The rating chip colour (green) is the only quality signal; low and high ratings look the same at a glance.
- **Scores (1 to 5):** visual polish 4, clarity 4, information density 3, trust 4, brand distinctiveness 4.
- **For 30 Sundays:**
  - Borrow for destination page "Where to eat" (answers audit notes 149:5 and 149:8):
    - Card: photo 4:3 with one small tag, name, rating with count, area and distance, cuisine, "₹ for two" (fields from 41:375 and Swiggy 41:309).
    - Detail: Zomato's restaurant header lines (41:350) plus "Open till 11 pm" and a "Book a table" action.
    - Mood tiles (41:356) such as "Sunset dinners", "Beach cafes", "Local street food".
    - "Highly reordered" becomes "Loved by 30 Sundays travellers" in lagoonBliss.
  - Borrow for home: one template across many tabs (41:357 to 41:373), the right discipline for destination rails.
  - Borrow for booked trip and referral: the 3-step locked journey (41:375) for a "your trip, step by step" strip.
  - Borrow for itinerary: menu rows with photo right and "more" (41:350) for day activities.
  - Avoid: paise prices (41:358), Ad tags on curated lists (41:357), takeovers (41:354), green-only rating colour (house rule, use neutral or teal).

---

### Urban Company (home services, 21 screens)

- **Flows covered:**
  - 41:578 phone login (Skip, "Standard tariff may apply")
  - 41:577 OTP (6 boxes, timer)
  - 41:576 location question ("Where do you want your service?")
  - 41:565 location search
  - 41:575 "Delivering service at" confirmation
  - 41:574 UC home (black header, 4-col 3D icon tiles)
  - 41:566 search with trending chips
  - 41:567 search focused, keyboard
  - 41:571 Beauty tab ("Personal grooming")
  - 41:573 Revamp tab (interior photo, "Explore by space")
  - 41:568 Revamp wall panels detail
  - 41:572 Native products tab
  - 41:561 Painting & Waterproofing, select your scope
  - 41:560 Full Home painting service page
  - 41:559 estimate sheet, step 1
  - 41:558 estimate sheet, scrolled to "Price includes"
  - 41:569 empty cart
  - 41:570 account
  - 41:564 profile details (inline errors)
  - 41:563 my wallet
  - 41:562 notification settings
- **Typography:** neo-grotesk, a custom face close to Inter or Graphik. Weights 400 to 700, mostly 400 and 600. Page titles 24 to 26px bold, section titles 22px bold, service names 16 to 17px semibold, body 15 to 16px regular, captions 13px grey. One serif display on home ("Spring '26 Collection", 41:574). Prices "Starts at ₹9,499" 14px semibold with duration "27 hrs" (41:560). Rating set as text "4.70 (10K bookings)" with a dotted underline on the count (41:560).
- **Colour:** purple #6E42E5 (CTA #5A2FCF, links, focus), black #0F0F0F (home header, wallet header), green check #0E8345, mint info strip #E8F6EF, amber info strip #FFF4DC with text #8A5A00, error red #C62828, tile grey #F5F5F5, text #0F0F0F and #545454. Essentially monochrome plus one purple. Light theme, almost no gradients (one on a product card, 41:572).
- **Layout and spacing:** 16 to 20px gutters, lots of white space. Tiles grey radius 12 (41:574), photo tiles radius 8 (41:560), option cards with 1px border radius 8 (41:559). Sections split by 8px grey bands. Info strips sit directly above the sticky CTA (41:558, 41:560, 41:568).
- **Section designs:**
  - Login and OTP: icon, title, one-line reason, input, Skip (41:578); OTP with timer (41:577).
  - Onboarding: one question "Where do you want your service?" with one solid and one outline answer (41:576).
  - Confirmation: green pin with "Delivering service at" and the full address (41:575).
  - Home header: black band, ETA "In 44 minutes", address, cart, search with rotating hint (41:574).
  - Category tiles: 4-col grey tiles with 3D icons, a "44 mins" chip on one tile (41:574); 3-col grooming tiles (41:571).
  - Hero banner: "Try Skin analysis" card with New tag and Try now (41:571); full-bleed Revamp interior (41:573).
  - Card rail: "Explore by space" photo cards with bottom gradient labels (41:573).
  - Search bar: trending searches as outlined chips with trend arrows (41:566).
  - Detail hero: service title + "4.70 (10K bookings)" (41:560); product photo with overlay title (41:568).
  - Detail sections: sub-type photo tiles (1 BHK, 2 BHK, Room combos New) (41:560); scope chooser with two big rows (41:561); three line-icon process rows (41:568).
  - Booking form: numbered estimate steps as accordions with option cards and prices, later steps greyed until earlier ones are done (41:559, 41:558).
  - Inclusions list: "Price includes" with green check circles and named paint brands (41:558).
  - Price display: "Starts at ₹9,499 . 27 hrs" (41:560); "Your estimate is ₹9,499" strip (41:558).
  - Sticky CTA bar: one purple "Book Consultation at ₹49", disabled with an amber reason strip until ready (41:559, 41:560).
  - Reviews and ratings: "4.83 (2K reviews)" as a dotted link on each service (41:560).
  - Empty state: cart with bird illustration and Explore services (41:569).
  - Profile: "Incomplete profile" chip + Complete button, 3 tiles, list (41:570); form with inline errors (41:564).
  - Notifications: channel toggles and "Order related messages can't be turned off as they are important for service experience" (41:562).
  - Wallet and rewards and Referral: UC Cash + "They get ₹100 and you get ₹100" (41:563).
  - Bottom nav: UC, Revamp (dot), Native, Beauty, Account; line icons, filled when active (41:570).
- **Strengths:**
  - The estimate builder is the best configurator in the group: numbered steps, price on every option, later steps locked, live total, and the disabled CTA explains itself ("Please generate an estimate first") (41:559, 41:558). Error prevention and visibility of status.
  - "Price includes" names exact inclusions and even the paint brands (41:558). Trust through specifics.
  - Proof uses bookings, not only stars: "4.70 (10K bookings)" (41:560).
  - One accent colour across the whole app; sections breathe (41:561, 41:568). Highest polish in the group.
  - Scope chooser is two rows and nothing else (41:561). Low cognitive load.
  - Honest notification copy (41:562) and a plain location question (41:576).
- **Weaknesses:**
  - Default name "Verified Customer" shown as the user's name, with red errors on first open (41:564, 41:570). Feels like blame before the user did anything.
  - Wallet screen is mostly empty rows with no explanation of how to earn (41:563).
  - Empty cart copy has a typo, "Lets add some services" (41:569).
  - Search focused shows a blank page with no suggestions (41:567), trending chips disappear on focus.
  - Bottom nav labels are product brands (Revamp, Native) that new users won't understand (41:570). Match between system and real world broken.
  - Few reviews are visible on the page itself; the count is a link, no quotes or photos (41:560).
- **Scores (1 to 5):** visual polish 5, clarity 5, information density 4, trust 4, brand distinctiveness 3.
- **For 30 Sundays:**
  - Borrow for wizard: the estimate builder (41:559, 41:558). Numbered steps (month, nights, route, stays), price on every option, live "Your trip is ₹1,24,000" strip above one fuchsia CTA, and a plain reason when the CTA is disabled.
  - Borrow for itinerary: "Price includes" (41:558) with named hotels and airlines, ticks in lagoonBliss, not green.
  - Borrow for destination page: "4.8 (2K trips)" counts as proof (41:560); the scope chooser (41:561) for "Full trip / Just hotels".
  - Borrow for booked trip: the location confirmation layout (41:575) for "You're booked", and the three process rows (41:568) for what happens next.
  - Borrow for profile: "Incomplete profile" + Complete (41:570), with softer copy; DOB and anniversary fields (41:564) map to audit note 141:84.
  - Avoid: red errors on first open (41:564), brand names as nav labels (41:570).

---

### Group summary

**Patterns that repeat across the apps, by component kind**
- Home header: every app leads with the delivery promise as the biggest type (35:142, 38:212, 41:285, 41:313, 41:574), then address, then search with a rotating hint. For us the headline fact should be the next trip or "Plan your next Sunday".
- Category tiles: grey or pastel square tiles radius 12 with cut-out images and 2-line labels below are universal (35:149, 38:211, 41:276, 41:574). The calm versions use one tile style per screen. The best variant adds a count or a collage (41:285).
- Card rail: horizontal rails with a "see all" arrow, often with peeking cards (41:355, 41:279). Zomato and Swiggy put a rating chip overlapping the photo edge (41:375, 41:304).
- Listing card: photo, name, rating with count, time, one offer tag, price with strike. The more tags, the worse (38:207 vs 41:375).
- Filters and sort: two rows of chips, with sub-chips that adapt to the category (41:380, 41:385); Swiggy and BigBasket use a left vertical rail inside a category (38:210, 35:145).
- Offers and coupons: progress to unlock ("Add ₹87 more", 41:267; "Shop for ₹776 more", 35:133; "₹279 more", 38:183) and "You saved ₹35" strips (41:347, 41:298). Zomato's first-three-orders journey is the cleanest (41:375).
- Sticky CTA bar: total on the left, action on the right. Three of six apps split it into two pay buttons (35:133, 41:347, 41:292).
- Booking form: map pin with dark tooltip, then a details form with "Myself / Someone else" and Home/Work/Other chips (35:135, 38:184, 41:269, 41:294). Inline guidance on the map (41:297).
- Trust and proof: ratings always with a count; behaviour proof ("Highly reordered", 41:350; "10K bookings", 41:560); policy lines (41:272); promise ticks (35:150).
- Progress and status: no live tracking captured. Status lives in ETA chips, a rain advisory toast (41:313), unlock bars, numbered estimate steps (41:559), a 3-step how-it-works timeline (41:309), and full-screen confirmations (35:134, 41:575).
- Empty state: one illustration, one line, one action, often with a rail below so the page still helps (38:192, 41:277, 41:353, 41:569).
- Login and OTP: phone first, Skip in the top right, 4 or 6 boxes with a resend timer (38:213, 41:317, 41:577).
- Bottom nav: floating pills (38:212, 41:357) and ad or cross-app slots (35:142, 41:275, 41:313).
- Other (multi-store theming): Zepto, BigBasket, Blinkit and Swiggy all repaint the header per tab. It is the most common pattern in this group and the one that hurts brand identity most.

**The 5 best section designs for a travel app like ours, ranked**
1. **Urban Company estimate builder with "Price includes" (41:559, 41:558).** Numbered steps, a price on every option, locked later steps, a live total strip and one CTA that says why it is disabled. This is our wizard and itinerary inclusions almost as-is.
2. **Zomato restaurant header and menu rows (41:350).** Distance, time, rating with count, "Frequently reordered", offers count, then rows with photo right, short description, bookmark and share. The direct answer to our Where to eat audit (149:5, 149:8); add opening hours and Book a table.
3. **Blinkit bento collage tile with count (41:285).** Four photos in one tile plus "+385 more" shows range and depth without a long list. Ideal for destination tiles on home ("Bali, 14 trips").
4. **Swiggy Dineout card and DineCash how-it-works (41:309), with Zomato mood tiles (41:356).** The card carries rating, area, km, cuisine, price for two and one offer line, the full set of eat-out facts; mood tiles group places by occasion. Together they make a complete Where to eat section.
5. **Zomato first-three-orders journey (41:375).** A short path of three steps with the current one open and the rest locked. Reusable for the booked trip ("Booked, Visa, Flights, Fly") and for referral rewards, in our brand colours.

Honourable mentions: Swiggy interest picker (41:311) for wizard onboarding; BigBasket intent tiles "Shop by goal / diet / lifestyle" (38:202); Urban Company scope chooser (41:561); Blinkit key-value address review (41:268) for booked-trip details.

**The 5 things to never copy**
1. **Two pay buttons side by side (35:133, 41:347, 41:292).** Splits the single primary action and breaks our one-fuchsia-action rule.
2. **Full-screen interstitials and cross-sell takeovers (35:151, 41:354), plus coach marks stacked with toasts (41:292, 41:302, 41:315).** They block the task the user came to do and use scarcity copy ("Available till stocks last").
3. **Per-tab rainbow theming (38:196 to 38:212, 35:142 to 35:144, 41:303 to 41:314).** Every tab gets a new colour, tile shape and display face; the brand vanishes. Our destinations must share one system.
4. **Stacked discount tags and machine prices (38:207, 38:201, 41:358).** Three prices and four tags on one card, or prices to the paisa, make the real price unreadable. Show one clear per-person price.
5. **Ads in curated spaces and navigation (35:141, 35:142, 41:357, 41:275, 41:313).** Ad tags on "recommended" lists, ad bubbles over content and ad slots in the bottom nav destroy trust in recommendations. Our picks must read as editorial, never paid.

Also never copy the green-good, red-bad rating chips used by every app here (41:375, 41:304, 38:188). Use neutral or lagoonBliss for proof, as our house rules ask.
