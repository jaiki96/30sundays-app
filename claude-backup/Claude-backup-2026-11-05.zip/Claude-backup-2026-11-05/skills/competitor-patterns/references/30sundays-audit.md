# 30sundays-audit: the current 30 Sundays app, audited

Group: 30sundays-audit. Source frame titles on the canvas: "internal App Audit" and "heuristic eval, competitive analysis".
Files looked at: 52 of 52 (audit 48, where-to-eat-rework 4). Every file was opened.

What the 52 files are:
- 22 phone screenshots of the live 30 Sundays app (92:2, 141:2 to 141:24, 141:79, 141:85).
- 3 screenshots of Hopper onboarding pasted into the audit as a reference (141:67, 141:68, 141:69).
- 11 red outline boxes ("Rectangle N") drawn over screens as highlights (141:29, 141:51 to 141:54, 141:72, 141:75, 141:76, 141:81, 141:82). They export as empty red frames; what they point at was worked out from their canvas position over the screen below.
- 2 grey sticky-note boxes laid on the Where to Eat screen (149:6, 149:7).
- 14 pieces of the Indus card rework: a photo, card surfaces, grey placeholder blocks, a pin icon and two empty frames.

How notes were matched: every designer note between canvas y 19,700 and 75,000 was matched to the nearest screen by its x, y against that screen's box in index.json. Notes are quoted exactly, typos kept. A " / " marks a line break in the original note.

---

### 30 Sundays (current app) (travel, curated international holidays, 25 app screenshots + 27 overlays and rework parts)

- **Flows covered:**
  - 92:2 splash (older capture, 12:55)
  - 141:21 splash (newer capture, 09:37)
  - 141:22 Explore home, top
  - 141:24 Explore home, scrolled (Vietnam rail, Traveller moments, Thailand)
  - 141:20 Explore home, further down (Why 30 Sundays, Maldives)
  - 141:7 All Reviews (Google reviews list)
  - 141:85 Explore Trips listing (View all, Bali, filter dock)
  - 141:11 Filters sheet
  - 141:14 Plan tab (quotes for Maldives)
  - 141:16 Older itineraries sheet
  - 141:18 Itinerary detail, Maldives (hotel and rooms)
  - 141:17 Itinerary detail, Vietnam (highlights and day tabs)
  - 141:6 Itinerary detail, Thailand (highlights, day plan, sticky price)
  - 141:4 Day story viewer (Phi Phi Don)
  - 141:12 Pace explainer sheet over the story
  - 141:19 Hotel sheet (The Phu Beach Hotel)
  - 141:9 Trips tab (completed trip card)
  - 141:13 Booked trip detail, Thailand
  - 141:2 Booked trip detail, Bali
  - 141:10 Where to Eat
  - 141:5 Where to Shop
  - 141:3 Traveller moments photo viewer
  - 141:8 Account (personal details, delete account)
  - 141:79 Delete account confirmation sheet
  - 141:69, 141:68, 141:67 Hopper onboarding (reference, not our app)
- **Typography:** geometric sans throughout, almost certainly Poppins (round "a", single-storey "y", wide "S"). That is not the brand's Figtree. Weights run Light 300 (review bodies 141:7, amenity bullets 141:19) to Semibold 600 (card titles). Rough sizes at 390 wide: screen title 26 to 28 px semibold ("Explore", "Plan", "Trips"), section title 20 px semibold, card title on photo 18 px semibold white, body 14 to 15 px, caption 12 to 13 px grey. Small caps labels with tracking appear only in the Pace sheet ("THIS DAY'S MAKEUP", "PACE LEVELS", 141:12), so the label style is a one-off. The handwriting display face (casual marker script, Kalam-like) shows up only on the splash tagline (141:21). Prices: "From" in regular, figure in bold, "/person" in regular grey on one baseline (141:22); quotes use "₹ 3,57,000" with a space after the rupee sign (141:14) while home uses "₹42,434" with none. Title Case habit on headers ("Property Highlights", "Crowd Level", "Add Ons"), sentence case elsewhere: mixed.
- **Colour:** light theme.
  - Primary: fuchsia, measured near #FF0A54 on the nav pill, Apply and Delete buttons. Brighter than the in-app spec #E31B53.
  - Grounds: peach to pink gradient wash behind every header (#FFF1E4 to #FFE6EE), body off-white #F4F3F1, cards white #FFFFFF. Cream #FFF6E6 from the board is not used.
  - Text: near black #1F1F1F, mid grey #6E6E6E, light grey #9B9B9B. Navy #1E2357 appears only on bottom-sheet titles (141:16, 141:12, 141:79), so navy is a sheet colour, not a heading colour.
  - Accents competing: orange #F5A000 (cuisine line 141:10, "Best for" 141:5, "6 Nights" 141:9), green #2E9E4F (restaurant stars 141:10, Completed badge 141:9, timeline dots 141:13, Relaxed chip 141:12), Google yellow #F7A823 (stars 141:7), mint toast #E3F4EC (141:22), blue, green and purple icon tiles (141:20), dark red #C0262D (Delete Account outline 141:8).
  - Count: up to five accents on one screen (141:20 has fuchsia nav, pink, blue, green and purple tiles). Semantic colour is not fixed: green means rating on one screen, done on another, relaxed on a third.
  - Gradients: dark bottom scrim on every photo card; the header wash.
- **Layout and spacing:** side gutter about 22 px at 390 wide. Card radius about 20 px on photo cards, 14 px on white cards, 12 px on tiles. Soft drop shadow on white cards (141:7, 141:10), hairline borders on tiles (141:13), both styles in use. Photo cards are tall (about 4:5 on home 141:22, a little wider in the listing 141:85). Sections are split three ways at once: white space, tinted band (141:20) and a thick grey divider (141:13, 141:6). The floating glass bottom nav and the floating filter dock both cover content (141:85). Density is low on content screens (141:11 is half empty) and high on text cards (141:5 address, 141:7 reviews).
- **Section designs:**
  - Splash: stacked logo, handwriting tagline, couple illustration on pink skyline (141:21).
  - Home header: plain "Explore" title on the pink wash, no greeting, no search (141:22).
  - Category tiles: circular destination photos with grey labels, rail cut at the edge (141:22).
  - Card rail: full-photo trip cards with route title, destination, nights, "From ₹ /person" (141:22).
  - Other (floating nudge toast): mint card "Your getaway awaits you!" with plane icon and close X over the rail (141:22).
  - Social and community: Traveller moments rail of guest photos with location tag (141:24).
  - Trust and proof: Why 30 Sundays 2x2 icon grid on a pink band (141:20).
  - Reviews and ratings: Google score header plus quote cards with initials and stars (141:7).
  - Listing card: full-width photo trip card in a vertical list (141:85).
  - Filters and sort: floating chip dock plus a sheet of chip groups with Clear all / Apply (141:85, 141:11).
  - Listing card (quote): hotel-led quote card with version, room chips, price and timestamp (141:14).
  - Comparison: older versions in a bottom sheet (141:16), no real side-by-side.
  - Detail hero: full-bleed photo with flag, trip name, nights, dates and traveller count (141:18, 141:17).
  - Detail sections: Hotel, Rooms list with thumbnails, What's included (141:18).
  - Video: portrait highlight tiles and a full-screen story viewer with segment bar (141:6, 141:4).
  - Itinerary and timeline: "Itinerary at glance" day rows with green dots and bullet activities (141:6, 141:13).
  - Sticky CTA bar: price-only bar with no button (141:6).
  - Other (explainer sheet): Pace levels with coloured chips (141:12).
  - Inclusions list: hotel sheet with amenity bullets and a location row (141:19).
  - Bookings list: trip card with carousel, Completed badge, nights, route, Share Itinerary (141:9).
  - Referral: "Refer & Earn" pill in the Trips header (141:9).
  - Detail sections (booked): Documents tiles, Add Ons tiles, co-traveller invite, timeline, chat FAB (141:13, 141:2).
  - Help and chat: fuchsia round chat FAB (141:13).
  - Listing card (places): Where to Eat and Where to Shop cards with city tabs and Directions (141:10, 141:5).
  - Editorial and stories: full-screen photo viewer with counter and thumbnail strip (141:3).
  - Profile: read-only details fields and a delete-account panel (141:8).
  - Other (destructive confirm): delete sheet with Cancel and a fuchsia Delete (141:79).
  - Onboarding: Hopper three-step reference (141:69 to 141:67).
- **Strengths:**
  - Photography is big and warm, and the photo cards carry route, nights and price in one glance (141:22, 141:85).
  - Price is "per person" and "Incl. taxes" with a timestamp, which is honest (141:14, 141:6).
  - Traveller moments uses real guest photos, the strongest proof the app has (141:24, 141:3).
  - Story-style day viewer is a good fit for "see your trip before you go" (141:4).
  - Booked trip puts documents first (141:13), which is what a traveller opens the app for in the last week.
  - The Pace idea is distinctive and useful (141:12).
  - Reviews name the trip planner ("Gungun", "Ms. Pum"), which makes them feel real (141:7).
- **Weaknesses:**
  - Couple-only copy everywhere, against the neutral brand: splash tagline (141:21), "Real photos from couples" (141:24), "Made for Couples / Trips designed exclusively for two" (141:20). Heuristic: match between system and the real world (the audience changed, the words did not).
  - House rules broken: subtitles under every section title (141:22, 141:24, 141:20), an em dash in "Full split ... no hidden markups" (141:20), solid pill badges ("Completed" 141:9, "Relaxed" 141:12, "5 D 4 N" 141:14), red and green for good and bad (Pace chips 141:12, green Completed 141:9).
  - Fuchsia is spent on everything (nav pill, View all, Highlights tab, Share Itinerary, Add Guest, Directions, chat FAB, Delete), so there is no single primary action. On the one screen that needs a CTA, the sticky bar has none (141:6).
  - Internal back-office words reach customers: "V4 - Quotation 1" (141:14), "SIC Transfer", "TCS" (141:6). Heuristic: speak the user's language.
  - Consistency: Poppins instead of Figtree, navy only on sheets, "Day 1" tabs on one itinerary and "Dec 27" on another (141:6 vs 141:17), "co-travelers", "Guest", "Traveler" for the same idea (141:13).
  - No filters, sort or counts on lists (141:7, 141:85), and the filter dock hides what is applied (141:85). Heuristic: visibility of system status.
  - Places cards miss the facts people need: distance, opening hours, booking, veg options (141:10, 141:5).
  - Bugs on screen: empty "30 SUNDAYS TIP" box (141:12), "2N Phuket" listed twice (141:9), stray leading dot "• Day 1" (141:12), "Invite the ones who makes" (141:13).
  - Delete Account is the most prominent thing on Account, and the confirm button is the brand primary (141:8, 141:79). Heuristic: error prevention.
- **Scores (1 to 5):** visual polish 3, clarity 3, information density 3, trust 3, brand distinctiveness 2.
- **For 30 Sundays:** keep the big photo cards, per-person honest pricing, guest photos, the story viewer and Pace. Fix the words (neutral, no back-office terms), move to Figtree and the cream ground, give every colour one job, give each screen one fuchsia action, and add the missing facts to places and lists. Avoid the floating toast and the floating filter dock over content.

---

## Screen by screen

### 92:2 Splash, older capture
- **What it is:** launch screen. Stacked logo (palm and sun mark plus "30 sundays" in navy), handwriting tagline "Saving Relationships, One Vacation at a Time!", flat illustration of a couple taking a selfie on a pink city skyline.
- **Designer note (124:9, right of the screen):** "logo + subtext + illustration / / cluttered / no animation". Frame labels nearby: "splash screen" (124:6), "internal App Audit" (124:5), "heuristic eval, competitive analysis" (124:7). A to-do note sits far above the frame (124:3): "add all splash screens to research documentation, and make sure all others are there as well / analyze everything in numbers - spash screens white space percentage, text + logo + illustration / start uploading things on helm / figure out claude and figma connector, get claude subscription / internal audit backed by research proof and reasoning / prompting learn".
- **Evaluation:**
  - Hierarchy: three things compete (logo, tagline, illustration), each about a third of the height. Nothing leads.
  - Copy: the tagline says the product is for couples and implies relationships need saving. Off brand now, and an odd promise.
  - Style: generic stock vector people with a hot pink city clash with the photographic app that follows. The illustration does not show any of our destinations.
  - Colour: three pinks plus maroon plus teal; no cream.
  - Heuristic: aesthetic and minimalist design.
- **Fix:** logo mark only, centred on cream #FFF6E6, with a short animation (sun rises over the palm, under 1.5 s). Drop the tagline from the splash. If a line is needed, put it in onboarding and keep it neutral. Headout's splash (41:933) is a single mark on white; Cleartrip's (35:130) is one colour, one mark, one short line.

### 141:21 Splash, newer capture
- **What it is:** the same splash as 92:2, captured at 09:37.
- **Highlights on it:** 141:54 (red box over the whole screen below the status bar), 141:51 (logo, top 16 to 27 percent), 141:52 (tagline, 34 to 47 percent), 141:53 (illustration, bottom 54 to 100 percent).
- **Designer notes:** left of the screen, "no splash screen, animation" (141:60) and "logo + subtext + illustration" (141:59, level with the illustration box). Right of the screen, "very less white space / 33.951% approx. " (141:57).
- **Evaluation:** the three boxes make the point well. About 34 percent white space against 88 percent on the next screen measured (see 141:22). The illustration takes the bottom half and is cropped by the home indicator. No motion, so the launch feels like a static poster.
- **Fix:** same as 92:2. Target 70 percent or more white space, one element, one short motion. Measure the new version with the same method so the audit has a before and after.

### 141:22 Explore home, top
- **What it is:** "Explore" title, circular destination rail (Bali, Vietnam, Thailand, New Zealand, cut-off fifth), Bali section with flag, subtitle "Temples, rice fields & sunset beaches", View all, trip card rail ("3N Seminyak • 2N Ubud", "Bali • 5N", "From ₹42,434/person"), mint toast "Your getaway awaits you! ✨ / View itinerary →" with close X, floating bottom nav (Explore, Plan, Trips, Account).
- **Highlight:** 141:29 (red box over the "Explore" title band, 5 to 15 percent).
- **Designer notes:** left of the screen, "vague statement / explore what? / can add more personalisation here / no subtext like so in titles below" (141:28). Right of the screen, "white space / 87.916% approx." (141:31) and "misalignment of text across cards" (141:48, level with the trip cards). Below the home screens, the section order is written out (141:73): "explore / / bali / vietnam / / traveller moments / / thailand / new zealand / / why 30 sundays / / maldives / / testimonials".
- **Evaluation:**
  - Header: "Explore" is a tab name, not a welcome. No name, no trip status, no search. Wasted top 15 percent.
  - Subtitles: each section has a grey subtitle line, against house rules, and they add a row of height per section.
  - Cards: the first card's title is one line, the second wraps to two ("2N Seminyak • 1N Nusa Penida • ..."), so title, meta and price sit at different heights across the rail. This is the misalignment the note calls out.
  - Copy: "Bali • 5N" repeats the section's destination. The moon emoji for nights is cute but reads as "night mode".
  - Toast: a floating mint card with a sparkle emoji and an arrow-in-a-circle sits over the second rail, adds a green accent, and duplicates the Plan tab. Two close or go targets in 60 px.
  - Nav: the active tab is a big fuchsia pill, so the brightest thing on home is the tab you are already on.
  - Section order (141:73): five destination rails with proof (moments, why, testimonials) scattered between them. Proof arrives in pieces.
- **Fix:**
  - Header: "Hi <first name>" plus one status line ("Your Maldives quotes are ready" or "Bali in 12 days"), and a search pill.
  - Delete the subtitles.
  - Cards: reserve two lines for the route title with a fixed card height, and pin price to the bottom edge, so every card's text lines up. Drop "Bali •".
  - Toast: replace it with an in-flow card under the header, in the slot reserved for trip status.
  - Nav: active state as fuchsia icon and label only, no filled pill.
  - Order: one "Where to next" destination block, then one proof block (photos plus reviews), then the rest.
  - Better patterns: Headout's home (41:916, 41:930) leads with search and a destination circle rail; Zomato (41:356) leads with location and search.

### 141:24 Explore home, scrolled
- **What it is:** end of the Vietnam rail ("2N Hanoi • 3N Da Nang", "From ₹41,650/person"), "Traveller moments" section with a camera emoji and the subtitle "Real photos from couples who travelled with us", portrait guest photos with pin labels (Bali, Vietnam, Maldives), start of the Thailand section.
- **Designer notes:** left of the screen, "alignment of text &  image" (141:64). Right of the screen, "can we merge this section with testimonials / images + text reviews" (141:66).
- **Evaluation:**
  - Alignment: the moments rail starts at the screen edge (x = 0) while its title and every other rail start at the 22 px gutter. The first photo is cropped on the left. This is the note's point.
  - Proof is split: photos here, star reviews on a separate screen (141:7), "Why 30 Sundays" further down (141:20). Three half-proofs instead of one strong one.
  - Photos carry no name, month or trip, so they cannot be checked or acted on.
  - Copy: "couples" again, and an emoji in a section title.
- **Fix:** align the rail to the gutter. Merge moments and testimonials into one "From our travellers" rail: photo, one-line quote, first name, month, trip ("6N Thailand"), and a "See this trip" link. Lagoon #00A898 for the "Verified trip" mark, nothing else coloured. Better pattern: Headout's "6K+ bookings last month" proof line on cards (41:921) and BookMyShow's review chips with counts (41:449).

### 141:20 Explore home, Why 30 Sundays
- **What it is:** end of a rail ("From ₹2,15,917/person"), pink tinted band with "Why 30 Sundays?" and subtitle "Designed for couples who deserve better", 2x2 grid of white cards with tinted icon tiles: Made for Couples, Price Transparency, No Tourist Traps, 24/7 Support. Then the Maldives section.
- **Highlight:** 141:72 (red box over the whole Why 30 Sundays band, 25 to 67 percent).
- **Designer note:** none placed right next to it. The section order note 141:73 lists "why 30 sundays" between "new zealand" and "maldives".
- **Evaluation:**
  - Copy: "Made for Couples / Trips designed exclusively for two" and "couples who deserve better" are off brand now. "deserve better" also implies other trips are bad. "Full split" uses an em dash. "Only 8+ rated, hand-picked gems" never says rated by whom.
  - Colour: four icon tints (pink, blue, green, purple) for four equal claims. Pure decoration.
  - Form: a generic feature grid every travel app has. No number, no example, nothing a user can check.
  - Placement: halfway down home, after four rails. Most users never reach it.
- **Fix:** follow the standing direction. Show the remaining USPs (Price Transparency, No Tourist Traps) as a thin bar over the hero, in the brand's wording, no couples line. Give each one proof: "See the split" opens a real trip's price split; "8+ on Booking.com" names the source. Icons in one neutral. Drop the subtitle. Better pattern: CRED's tick bullets with one plain claim each (41:342) and Cleartrip's "Preferred for work" benefit card with concrete items (35:108).

### 141:7 All Reviews
- **What it is:** Google logo plus "All Reviews" header, "4.6" with 4.5 stars and "Based on 1,000+ Google reviews", then quote cards: pink initial avatar, name, destination, five stars, long quote in light grey, a pink left border on each card.
- **Highlights:** 141:75 (red box over the score header, 14 to 20 percent), 141:76 (tall red box over the star column on the right, 24 to 100 percent).
- **Designer note (141:78, left of the screen):** "no option to filter by recency, destination, travel package, dates etc".
- **Evaluation:**
  - The star column box (141:76) shows every review is five stars. A wall of perfect scores reads as curated. Heuristic: trust and credibility.
  - No filter, sort, date or trip type, as the note says. A Thailand traveller cannot find Thailand reviews.
  - "1,000+" is vague next to a precise 4.6.
  - Body text is Poppins Light in #6E6E6E at about 14 px: low contrast, tiring at this length. No "Read more", so one review fills a screen.
  - The pink left border and pink avatar add a decorative accent.
- **Fix:** score header with a five-bar distribution and the exact count. Filter chips (Destination, Trip length, Most recent). Each card: name, month and year, trip ("5N Bali"), quote clamped to four lines with "Read more", guest photo if any, "On Google" link. Body Figtree Regular #3A3A3A. Avatars in one warm neutral. Better patterns: BookMyShow top reviews with hashtag chips and counts (41:449); Headout rating plus count on every card (41:921); Zomato rating box with "2.2K ratings" (41:350).

### 141:8 Account
- **What it is:** "Account" header, "Personal details" with three outlined fields (Name, Phone, Email) holding a real customer's data, then a pink panel with an outlined red "Delete Account" button and an "Important Note" with a red alert icon.
- **Highlight:** 141:81 (red box over the Delete Account panel, 56 to 67 percent).
- **Designer notes (left of the screen):** "edit details?" (141:83) and "age / location etc / / upload personal docs so that you dont have to upload them across various trips again and again like passport" (141:84).
- **Evaluation:**
  - The fields look like inputs but cannot be edited and there is no Edit action. Heuristic: affordance and user control.
  - The only action on the page is Delete Account, given a tinted panel and a red outline. It is the most visible thing on Account.
  - Copy contradicts itself: "You will not be able to login with this account again" then "To revert this action you can contact support". "login" is a noun used as a verb.
  - Missing everything a travel profile needs: travellers, passports, preferences, addresses, notifications.
  - Privacy: the audit screenshot shows a real name, phone and email. Blur before sharing the research file.
- **Fix:** a profile hub. Header with name and Edit. "Saved travellers" with a document vault per person (passport, PAN, photo) reused across trips, which is the note's idea and the strongest repeat-booking feature here. "Travel preferences" (age band, home city, food: veg, Jain, no restriction). Settings list at the bottom with "Delete account" as a plain grey row. Better patterns: Zomato profile with "Your preferences" and Veg Mode (41:352); Headout "Essentials" list (41:927); CRED "All actions" list (22:23); Pepperfry account tiles (22:42).

### 141:79 Delete account confirmation
- **What it is:** dimmed Account screen with a bottom sheet: navy title "Delete Account", body copy, outlined "Cancel" and fuchsia filled "Delete".
- **Highlight:** 141:82 (red box over the sheet's body copy, 81 to 89 percent).
- **Designer note:** none next to it.
- **Evaluation:** the highlighted copy repeats the note already on the page word for word, so the sheet adds no new information (what happens to bookings, documents, refunds). The destructive action uses the brand primary, filled, on the right, which makes Delete the default. Heuristic: error prevention.
- **Fix:** list what is lost ("Your 2 trips, 4 saved documents and your wishlist"), offer a grace period ("We delete it after 30 days. Sign in before then to keep it."), make "Keep my account" the filled button and "Delete account" a red text button. Better pattern: Headout's "Think twice" sheet with consequences and "I'll stay" (41:914) and its 30-day message (41:913). Avoid Nykaa's fuchsia delete button (41:603), the same mistake.

### 141:85 Explore Trips listing
- **What it is:** "Explore Trips" header, full-width photo trip cards ("3N Seminyak • 2N Ubud", "2N Seminyak • 1N Nusa Penida • 1N Gili Trawangan • 3N Ubud"), floating white dock at the bottom with chips 6-8N, Relaxed, Offbeat and a fuchsia filter button with a "1" badge.
- **Designer note:** none next to it.
- **Evaluation:**
  - The list is filtered to Bali (badge 1) but the header still says "Explore Trips" and Bali is not shown as a chip. Users cannot see what is applied. Heuristic: visibility of system status.
  - No result count and no sort (price, length).
  - The dock floats over the third card, and its chips are quick filters, not applied ones, which is confusing next to a badge.
  - Two cards per screen; the four-stop route title wraps to two lines and pushes the meta down (same alignment problem as 141:22).
- **Fix:** header "Bali trips" with "12 trips" beside it. Applied filters as removable chips under the header, Sort and Filters buttons next to them, nothing floating. Fixed two-line title slot. Better pattern: Cleartrip's results bar with a "Filter (2)" count and sort (35:121) and its hotel listing chips row (35:109).

### 141:11 Filters sheet
- **What it is:** bottom sheet "Filters" with chip groups: Destination (flags, Bali selected in fuchsia outline and tint), Duration (3-5N, 6-8N, 8-10N, 10+N), Pace (Relaxed, Balanced), Crowd Level (Offbeat, Mixed, Busy), then Clear all and fuchsia Apply.
- **Designer note:** none next to it.
- **Evaluation:**
  - Clean and readable. Chips are big enough to tap.
  - Missing the filters people actually choose by: budget per person, month, trip style (beach, adventure, honeymoon, family).
  - "Busy" is not something anyone wants; say "Popular spots". Pace offers two levels here but four in the Pace sheet (141:12). Duration ranges overlap at 8N (6-8N and 8-10N).
  - Apply does not say how many trips match, so users apply blind. A third of the sheet is empty.
  - Title Case "Crowd Level" vs sentence case elsewhere.
- **Fix:** add Budget (slider or ranges with counts), Month, Style. Make ranges exclusive (3-5N, 6-8N, 9N+). Use the same pace scale as 141:12. Apply becomes "Show 12 trips". Better pattern: Cleartrip shows a price inside each filter option (35:119) and splits filters into tabs (35:117).

### 141:14 Plan tab
- **What it is:** "Plan" title, "Maldives Itineraries" with a hairline, quote cards on full photos: hotel name ("Centara Ras Fushi & Spa Maldives"), "Dec 30 - Jan 3 | V4 - Quotation 1", room chips cut off ("2N • Overwater Villa wit"), "₹ 3,57,000 Incl. taxes", "As on 30 Oct 2025, 10:25 AM. Final price may vary.", a "5 D 4 N" pill with sun and moon icons.
- **Designer note:** none next to it.
- **Evaluation:**
  - "V4 - Quotation 1" is back-office language. A customer does not know what V4 is or why Quotation 1 and 2 are both V4.
  - Two cards look identical in structure, so the real choice (which hotel, how much more) has to be worked out by scrolling up and down. No side-by-side.
  - No status (draft, ready, expiring), no planner name, no action. The tab is called Plan but you cannot do anything here.
  - The timestamp line is an anxious caveat in white over a photo.
  - Room chips are truncated, so the main difference between options is hidden.
  - Price formatting differs from home ("₹ 3,57,000" vs "₹42,434").
- **Fix:** title the section "Your Maldives options" and label cards "Option 1", "Option 2", with "Updated 30 Oct" as small grey text. Show the planner ("From Gungun, your planner"). Add a "Compare" view: hotel, rooms, meals, price per person and total in columns. One fuchsia action per screen: "Book this option" on the chosen card. Room names wrap to two lines instead of truncating. Better pattern: Cleartrip's fare cards that stack what each option includes (35:116) and BookMyShow's stepper that says where you are (41:428).

### 141:16 Older itineraries sheet
- **What it is:** dimmed Plan screen with a bottom sheet titled "Maldives Older Itineraries" (navy) holding a quote card "Adaaran Select Hudhuran Fushi", "V4 - Quotation 3", "₹ 3,60,000 Incl. taxes".
- **Designer note:** none next to it.
- **Evaluation:** the label says "Older" but the card is still V4 with the same timestamp as the current ones, so it is unclear what makes it older. There is no way to restore it or see what changed. "Older Itineraries" is clumsy. Heuristic: consistency and recognition over recall.
- **Fix:** a version history row on the trip: "Latest", "Earlier (2)". Each earlier version says what changed ("Hotel changed to Adaaran, ₹3,000 more per couple") and offers "Use this one". Keep it as a list on the same screen, not a sheet.

### 141:18 Itinerary detail, Maldives
- **What it is:** hero photo with back button, flag, "Your Maldives Trip · 4N", "Dec 30 - Jan 3 • 2 travellers"; "Hotel" section, "Sun Siyam Olhuveli", "Meal plan: Full Board", photo carousel; "Rooms" list with thumbnails (Grand Beach Villa 2N, Grand Water Villa with Pool 2N); "What's included" starts below.
- **Designer note:** none next to it.
- **Evaluation:** clear hierarchy and a calm screen. But the hotel carousel opens on the same photo as the hero, so the first scroll shows nothing new. "Meal plan: Full Board" is small grey 12 px though meals matter a lot in the Maldives. No hotel rating, so "No Tourist Traps" is not proven where it matters. "Hotel" and the hotel name are two headings stacked.
- **Fix:** start the carousel on rooms or the beach, not the hero. Make meal plan a fact row with an icon ("All meals included"). Add "8.9 on Booking.com" in lagoon under the hotel name. Merge the two headings into "Your hotel: Sun Siyam Olhuveli".

### 141:17 Itinerary detail, Vietnam
- **What it is:** spa photo hero, "Your Vietnam Trip · 9N", "Dec 27 - Jan 5 • 2"; "See your trip" with a fuchsia filled "Highlights" tab and date tabs ("Dec 27 Phu Quoc", "Dec 28 Phu Quoc"); portrait highlight tiles (Vinpearl Safari, VinWonders); "Itinerary at glance".
- **Designer note:** none next to it.
- **Evaluation:** the tabs show dates here but "Day 1, Day 2" on Thailand (141:6): same component, two labelling systems. "See your trip" is vague. The filled fuchsia "Highlights" tab is the loudest element and is a tab, not an action. The traveller count shows a person icon and "2" with no label. The hero is a spa interior with people in it, not Vietnam.
- **Fix:** tabs read "Day 1, Dec 27". Selected tab uses a dark text plus underline or a neutral fill, saving fuchsia for the CTA. Rename the heading "Day by day". Hero is a place shot (Ha Long, Hoi An). "2 travellers" in words.

### 141:6 Itinerary detail, Thailand
- **What it is:** collapsed header "Your Thailand Trip · 5N", Highlights plus day tabs, highlight tiles (Phi Phi Island Tour, ATV Ride in Krabi), "Itinerary at glance" timeline (Day 1 Krabi: "Krabi Airport Private Transfer", "Leisure Day at Krabi"; Day 2: "Phi Phi Island Tour with Lunch by Speed Boat (Incl. Park Fee) - SIC Transfer"), sticky bar "From ₹31,866/person / Price incl. GST & TCS".
- **Designer note:** none next to it.
- **Evaluation:**
  - The sticky bar shows a price and no button. The one place a primary action belongs is empty. Heuristic: user control, and a lost conversion.
  - "SIC Transfer" and "TCS" are jargon. "Itinerary at glance" drops "a".
  - Two highlight tiles leave a big empty space on the right of the rail.
  - Timeline dots are green, which is reserved for something else in the brand rules and used for ratings on 141:10.
- **Fix:** sticky bar: price on the left, one fuchsia "Book this trip" (or "Talk to your planner" before a quote exists) on the right. Say "Shared transfer" instead of SIC, and put "TCS" behind an info tap that explains the 5 percent tax collected at source and that it can be claimed back. Neutral timeline dots. Better pattern: Headout's detail with "from ₹4,016" and "Check availability" side by side (41:925); Cleartrip's sticky "Select Room" (35:108).

### 141:4 Day story viewer
- **What it is:** full-screen video story, six progress segments, mute and close, "Day 2 - Krabi", "Phi Phi Don", a two-line description ending in "....", "View details >".
- **Designer note:** none next to it.
- **Evaluation:** a strong pattern for a travel product, and the text sits on a dark scrim so it reads. Small problems: four dots instead of an ellipsis, no save or share, no way to jump to the next day except tapping through every segment, and the copy "Enjoy Phi Phi Don, the main inhabited island" is filler.
- **Fix:** add a heart (save to wishlist) and share at the bottom right. Long-press to pause, swipe up for details. Write one specific line per stop ("Lunch on the beach, then free time on Loh Dalum Bay").

### 141:12 Pace explainer sheet
- **What it is:** sheet over the story: navy "Pace", mint "Relaxed" chip, "• Day 1 • Krabi", explainer, "THIS DAY'S MAKEUP" with "Time in transit 1.1h", "PACE LEVELS" with four coloured chips (Relaxed mint, Balanced peach, Active peach, Fast-paced pink) and rules, a pink "30 SUNDAYS TIP" box that is empty, and an italic disclaimer.
- **Designer note:** none next to it.
- **Evaluation:**
  - The tip box has a title and no tip: a visible bug.
  - "1.1h" is a machine number; people think in "about 1 hour".
  - The chips run green to red, so "Fast-paced" reads as bad. Against the no red or green for good or bad rule. Two of the four chips share the same peach.
  - Pace here has four levels; filters (141:11) offer two.
  - Leading bullet before "Day 1" is a layout bug. "Makeup" is an odd word.
- **Fix:** show pace as a 1 to 4 dot scale in one neutral with the current level filled. "About 1 hour in transit". Fill the tip or hide the box when empty. Rename "This day" and use the same four levels in filters.

### 141:19 Hotel sheet
- **What it is:** sheet over "Your hotels" (a fuchsia "Hide details" link peeks out behind): hotel photo with a "Day 1 - 3" chip and carousel dots, "The Phu Beach Hotel", "Superior Pool View", "Property Highlights" with ten grey bullets, then "Krabi" with a pin tile and "Directions".
- **Designer note:** none next to it.
- **Evaluation:** ten equal bullets in light grey are a wall; "Wonderful Breakfast" is marketing mixed with facts like "Non-smoking rooms". No rating, no check-in and check-out times, no area or distance to the beach. Location is only the town name, so "Directions" goes somewhere vague. The photo includes the hotel's own logo graphics, cropped.
- **Fix:** rating line first ("8.4 on Booking.com", lagoon). Then check-in and check-out. Then a 2-column icon grid of the top six amenities with "See all 10". Location as a small map with the area name ("Ao Nang, 5 min walk to the beach"). Better pattern: Cleartrip amenities in two columns (35:106) and its hotel hero with rating and Map link (35:108).

### 141:9 Trips tab
- **What it is:** "Trips" title, fuchsia "Refer & Earn" pill top right, trip card: photo carousel with a white pill "Completed" with a green tick, "6 Nights" in orange with a moon, "<Name>'s Thailand Trip  - 7 Jun 2026" (the customer's first name), "2N Bangkok • 2N Phuket • 2N Phuket", divider, fuchsia "Share Itinerary".
- **Designer note:** none next to it.
- **Evaluation:**
  - Route lists "2N Phuket" twice: a data bug.
  - No Upcoming and Completed split; the next trip is below the fold.
  - The date is glued into the title with a double space and a hyphen.
  - "Completed" is a solid pill badge with green for done. The orange "6 Nights" adds another accent.
  - A completed trip offers "Share Itinerary" only. That is the moment to ask for a review, photos and the next trip.
  - "Refer & Earn" competes with the page title and with the card action, both fuchsia.
- **Fix:** tabs "Upcoming" and "Past". Card: trip name ("Thailand, 6 nights") as title, dates as grey meta, route deduplicated ("Bangkok 2N, Phuket 4N"). Past trips: "Share your photos" and "Rate your trip". Status as plain text, not a pill. Referral moves into Account or a past-trip card. Better pattern: Headout's Upcoming and Completed tabs with a helpful empty state (41:928).

### 141:13 Booked trip detail, Thailand
- **What it is:** pink header "Your Thailand Trip" with a palm emoji and "7 - 13 Jun 2026", tabs "Trip details" and "Day wise", "Documents" tiles (Itinerary PDF, Payment Receipts, Traveler Documents), "Add Ons" tiles (Visa, Forex, Insurance), "Manage co-travelers" with "Invite the ones who makes every journey special." and "Add Guest", "Itinerary at glance" timeline, fuchsia chat button over the timeline.
- **Designer note:** none next to it.
- **Evaluation:**
  - Documents (things you have) and Add Ons (things we sell) use identical tiles. Users cannot tell which tiles are done and which are offers. Heuristic: recognition, and "different kinds of thing must look different".
  - No status: is the visa approved, are all traveller documents uploaded, how many days to go?
  - Grammar error ("who makes"). Three words for one idea: co-travelers, Traveler, Guest. US spelling against Indian English elsewhere.
  - The chat button covers timeline text.
  - Emoji in the title.
- **Fix:** top card "Next up" with countdown and the one pending task ("Upload Priya's passport, 1 of 2 done"). Documents as rows with a status on the right ("Ready", "1 missing"). Add-ons as one smaller row of offers with prices, clearly separate. One word: "Travellers", "Add a traveller". Chat as a "Help" row or a smaller button that does not cover text. Better pattern: CRED's checklist with live status (22:8) and BookMyShow's "You should know" card (41:429).

### 141:2 Booked trip detail, Bali
- **What it is:** the same screen as 141:13 for "Your Bali Trip", "19 - 26 Dec 2025". Add Ons shows only Forex and Insurance (no Visa).
- **Designer note:** none next to it.
- **Evaluation:** the missing Visa tile leaves a hole in the grid, so the layout looks broken rather than smart. Nothing says why visa is not offered (Indians get visa on arrival in Bali), which would be useful information. All other issues from 141:13 repeat.
- **Fix:** show "Visa: on arrival for Indian passports, about ₹3,000 per person" as an information row instead of hiding the tile. Use rows, not a fixed grid, so a missing item never leaves a gap.

### 141:10 Where to Eat
- **What it is:** "Where to Eat" with city tabs (Bangkok, Phuket), restaurant cards: photo, name ("Bawarchi Indian Restaurant", "Indus"), green star rating (4.4, 4.5), cuisine in orange, "₹3,500 - 6,000 Price for two", "Bangkok, THAILAND" with a pin, fuchsia "Directions" with a diamond icon.
- **Overlays on it:** 149:6 (grey sticky box over the rating to Directions area, 43 to 53 percent down) and 149:7 (grey sticky box over the middle of the screen, 56 to 67 percent).
- **Designer notes:** on 149:6, "how far??? / exact location / opens till / book a table / amenities" (149:5). On 149:7, "remake cards" (149:8). A small "65" (149:4, 32 px) sits at the bottom edge, likely a measurement. Below the screen, "where to fond or located / experience / / revise where to eat section by researching competitors and making wireframes" (141:87).
- **Evaluation:**
  - Location says only "Bangkok, THAILAND": the city the tab already says, with the country in capitals. It answers nothing. Exactly the note's "how far???".
  - No distance from the hotel, no opening hours, no booking, no veg or Jain information (a key question for Indian travellers abroad), no rating count.
  - Green stars and orange cuisine add two accents; Directions is fuchsia on every card, so a list of ten cards has ten primary actions.
  - Card height is driven by a large photo; only two cards fit a screen, for a list people want to scan.
  - The list seems to be only Indian restaurants, which may be the point (familiar food abroad), but the screen never says so.
- **Fix:** see the rework below. Card: photo 3:2, name, "4.5 (1.2k on Google)", "Indian, Mughlai", "₹5,000 to 9,000 for two", "1.2 km from your hotel · Open till 11 pm", tags "Pure veg" or "Veg options" in grey text, and one quiet "Directions" text button plus "Reserve" only where bookable. Sort by distance from today's hotel. Better pattern: Zomato restaurant header with distance, rating box with count and veg filters (41:350); Zomato's District "Reserve a table" (41:355).

### 141:5 Where to Shop
- **What it is:** "Where to Shop" with city tabs, card for "Terminal 21 Asok": photo, grey description, orange "Best for unique shopping, themed experience, food court", four-line full Thai address, fuchsia "Directions"; "Siam Paragon" below.
- **Designer note:** none next to it.
- **Evaluation:** the full postal address (four lines, partly in Thai transliteration) is the biggest text block on the card and nobody reads it; Directions already covers it. The orange "Best for" line is long and wraps. No hours, no price level, no nearest metro station, which is how people move in Bangkok.
- **Fix:** replace the address with "Asok BTS, 2 min walk · Open 10 am to 10 pm". Turn "Best for" into three short grey tags ("Food court", "Budget", "Themed floors"). Keep the full address in the Directions sheet.

### 141:3 Traveller moments viewer
- **What it is:** black full-screen viewer, "19/50" counter, close button, a landscape guest photo, caption "Cheow Lan Lake • Thailand", thumbnail strip with a fuchsia border on the current photo.
- **Designer note:** none next to it.
- **Evaluation:** a standard, well built lightbox. But it is a dead end: no traveller name, no month, no link to the trip that took them there. Fifty photos of mixed quality without context weaken the proof.
- **Fix:** caption "Rohan and family, Feb 2026, 6N Thailand" and a "See this trip" button that opens the matching itinerary. Group by destination. Selected thumbnail in white border, not fuchsia.

### 141:69, 141:68, 141:67 Hopper onboarding (reference pasted into the audit)
- **What it is:** three onboarding steps from Hopper, placed under the home screens. 141:69 "Save money, travel far" with three icon rows; 141:68 "Get notified when prices drop" showing a real Price Watch card and a price timeline; 141:67 "Sign in to start saving now!" with mascots in a box and confetti. Sky blue buttons, "Not now" on steps 2 and 3, a cream wave ground.
- **Designer note:** none next to them.
- **Evaluation (as a reference):** the best idea is step 2: it shows the actual product UI as the illustration, so the user learns the feature before using it. Sign-in is the last step and can be skipped. Weaker: three exclamation-heavy headlines, cartoon mascots that only work for Hopper's brand, and a big bright blue that would fight our fuchsia.
- **For 30 Sundays:** a three-step onboarding that replaces the splash tagline. Step 1 "See the full price split" with a real split card; step 2 "Only hotels rated 8 and above" with a real hotel card showing the rating; step 3 "Talk to a real planner" with a planner card, then phone sign-in with "Not now". Use real UI, not illustration.

### Highlight boxes (red outlines) and sticky boxes, for reference
| Node | Sits on | Covers | What it flags |
|---|---|---|---|
| 141:54 | 141:21 | whole screen below status bar | splash as a whole (white space 33.951%) |
| 141:51 | 141:21 | logo, 16 to 27% | logo element |
| 141:52 | 141:21 | tagline, 34 to 47% | subtext element |
| 141:53 | 141:21 | illustration, 54 to 100% | illustration element |
| 141:29 | 141:22 | "Explore" title band, 5 to 15% | vague header, no personalisation |
| 141:72 | 141:20 | Why 30 Sundays band, 25 to 67% | the USP grid |
| 141:75 | 141:7 | score header, 14 to 20% | rating summary |
| 141:76 | 141:7 | star column, right side, 24 to 100% | every review is five stars |
| 141:81 | 141:8 | Delete Account panel, 56 to 67% | delete is the main thing on Account |
| 141:82 | 141:79 | sheet body copy, 81 to 89% | copy repeats the page note |
| 149:6 | 141:10 | rating to Directions area, 43 to 53% | grey sticky for note 149:5 |
| 149:7 | 141:10 | middle of screen, 56 to 67% | grey sticky for note 149:8 |

---

## Where to Eat rework: the Indus card

The team started a new restaurant card using Indus (the second card on 141:10) as the sample. Parts on the canvas:

- **152:37** photo: a couple dining at Indus under warm lamps, landscape, rounded top corners (about 16:10).
- **152:52** small fuchsia outline location pin placed on the photo's top right corner.
- **152:36** grey rounded rectangle and **152:40** white rectangle, same bounds (2130 x 1837), wrapping the photo and the text below. A card surface plus its shadow or border layer.
- Text on the card (from notes): title "Indus" (152:41, large), cuisine "Indian, Mughlai & Contemporary Indian" (152:49).
- **152:57** wide grey placeholder labelled "book now" (152:59), and **152:58** a square grey placeholder labelled "location" (152:60), side by side under the text: a main button plus an icon button.
- **152:68, 152:69, 152:70, 152:71** four grey image blocks (2130 x 1296 each, about 1.64:1) stacked vertically: a list wireframe of photo-led cards.
- **152:77** (Group 13) wireframe of a second card variant: a large grey image block with a short centred grey bar under it (a caption tile).
- **152:9** (Frame 2, phone-sized) and **152:62** (Frame 3) export as blank white. They are empty frames or their content did not render; nothing to evaluate yet.

Evaluation of the rework so far:
- Good: it adds the two actions the old card lacked, "book now" and a location action, and gives the photo more room.
- It drops facts the old card had (rating, price for two) and does not yet add the ones the team's own note asked for (149:5: how far, opening hours, amenities). The note listed five needs; the card covers two.
- The pin on the photo and the "location" button do the same job twice. A pin on a photo also reads as "this is on a map".
- If "book now" is a filled fuchsia button on every card, a list of ten restaurants gets ten primary actions, against the one fuchsia action rule. Most restaurants also cannot be booked through us, so the button would often be a lie or a dead end.
- The photo is a couple, a romantic cue the brand has moved away from. Food or the room says "restaurant" faster.
- The list wireframe (152:68 to 152:71) is photo-only; at 1.64:1 and full width, about two cards fit a screen again, the same scan problem as 141:10.

Recommended Indus card (for the next wireframe):
- Photo 3:2, no pin on it. Optional small "Near your hotel" text label if true.
- Title "Indus" (Figtree 17 semibold, navy #181E4C).
- One meta line: "4.5 (1.2k on Google) · ₹5,000 to 9,000 for two".
- One location line: "Sukhumvit · 1.2 km from your hotel · Open till 11 pm".
- Cuisine and diet as grey text: "North Indian, Mughlai · Veg options".
- Actions: "Directions" as a text button, "Reserve" as an outlined button only when we can actually book it; otherwise "Call".
- A compact row variant (thumbnail left, text right) for long lists, and the big card only for a "Planner's pick".
- Better patterns: Zomato restaurant header (41:350) for distance, rating count and diet filters; Zomato's District entry "Reserve a table" (41:355) for booking wording.

---

## The 10 biggest problems in the current app, ranked

1. **No single primary action; fuchsia is everywhere and missing where it counts.** Nav pill, View all, tabs, links, Directions and Delete are fuchsia (141:22, 141:17, 141:10, 141:79), while the itinerary's sticky bar has no button at all (141:6).
   - Fix: fuchsia only for the one action per screen ("Book this option", "Book this trip", "Pay now"). Tabs and links in navy or dark grey.
   - Better pattern: Headout (41:925, sticky price plus "Check availability"), Cleartrip (35:108, sticky "Select Room").
2. **Couple-only and off-brand copy.** Splash tagline (141:21), "couples who travelled with us" (141:24), "Made for Couples", "couples who deserve better" (141:20).
   - Fix: neutral wording everywhere, USP one retired, tagline off the splash.
   - Better pattern: Headout's neutral, warm sign-in line "Hop in! We're going places" (41:929); Cleartrip's short splash line (35:130).
3. **Back-office words shown to customers.** "V4 - Quotation 1" (141:14, 141:16), "SIC Transfer", "TCS" (141:6), "Older Itineraries".
   - Fix: "Option 1", "Updated 30 Oct", "Shared transfer", an info tap for TCS, a version history that says what changed.
   - Better pattern: Cleartrip fare cards that name what each option includes (35:116).
4. **Quotes cannot be compared or acted on.** The Plan tab is a scroll of look-alike photo cards with no status, planner or action (141:14).
   - Fix: option cards with the difference first (hotel, rooms, price per person), a Compare view, planner name, one "Book this option".
   - Better pattern: Cleartrip fare selection (35:116); BookMyShow stepper for where you are in the process (41:428).
5. **Proof is scattered and unverifiable.** Guest photos with no names (141:24, 141:3), all-five-star reviews with no dates or filters (141:7), a generic USP grid with no numbers (141:20).
   - Fix: one "From our travellers" rail (photo, quote, name, month, trip, "See this trip"), review filters and distribution, USPs as a thin bar with proof links.
   - Better pattern: BookMyShow reviews with tag counts (41:449); Headout ratings with counts and "6K+ bookings last month" (41:921); Zomato rating box with count (41:350).
6. **Places cards miss the facts that matter.** No distance, hours, booking or diet information; location repeats the city (141:10, 141:5).
   - Fix: the Indus card spec above, sorted by distance from today's hotel.
   - Better pattern: Zomato (41:350 distance and veg filters, 41:355 reserve a table).
7. **Booked trip has no status.** Documents and add-ons look the same, nothing says what is pending or how many days are left (141:13, 141:2).
   - Fix: "Next up" card with countdown and the one pending task, document rows with status, add-ons as a separate offer row.
   - Better pattern: CRED's live checklist (22:8); BookMyShow "You should know" card (41:429); Headout notification priming for trip updates (41:932).
8. **Profile is a data dump with Delete as the main action, and the delete flow nudges toward deleting.** (141:8, 141:79)
   - Fix: profile hub with Edit, saved travellers and a reusable passport vault, preferences, settings list; delete as a grey row; confirm sheet with consequences, 30-day grace and "Keep my account" as the filled button.
   - Better pattern: Zomato profile and preferences (41:352), Headout profile list (41:927), Headout delete flow (41:914, 41:913), CRED "All actions" (22:23). Avoid Nykaa's fuchsia delete (41:603).
9. **Lists hide state.** No result counts or sort, applied filters invisible, a floating dock over content (141:85), filters missing budget and month, Apply without a count (141:11).
   - Fix: header with destination and count, applied chips under it, Sort, more filters, "Show 12 trips".
   - Better pattern: Cleartrip (35:121 "Filter (2)" and sort, 35:119 price inside filters, 35:117 filter tabs).
10. **Visual system drift and visible bugs.** Poppins instead of Figtree, no cream ground, navy only on sheets, green meaning three things, solid pills, subtitles under titles, misaligned card text (141:22, 141:24), an empty tip box (141:12), a duplicated city (141:9), grammar errors (141:13), a cluttered static splash (141:21).
    - Fix: Figtree, cream grounds, navy headings, a colour table where each colour has one job, fixed-height card text slots, gutter-aligned rails, a copy and data QA pass.
    - Better pattern: Headout's restrained one-accent system (41:916, 41:925); CRED's consistent label and list styles (22:23).

---

### Group summary

- **Patterns that repeat across this group, by component kind:**
  - Card rail and Listing card: full-photo cards with white text on a dark scrim, used for trips, quotes and highlights (141:22, 141:85, 141:14, 141:6). Strong for mood, weak for comparing.
  - Detail hero: photo plus flag plus "Your X Trip · nN" on every trip screen (141:18, 141:17, 141:6).
  - Itinerary and timeline: the same "Itinerary at glance" day timeline on itinerary and booked screens (141:6, 141:13, 141:2).
  - Filters and sort, Comparison, Reviews and ratings: present but thin everywhere (141:11, 141:16, 141:7).
  - Other (bottom sheets): heavily used (filters, older quotes, hotel, pace, delete), always with a navy title that appears nowhere else.
  - Trust and proof: present in four forms that never meet (141:24, 141:20, 141:7, 141:3).
- **The 5 best section designs in this group for a travel app like ours, ranked:**
  1. Day story viewer (141:4, Video): sells the trip day by day in our own footage. Add save and share.
  2. Traveller moments rail and viewer (141:24, 141:3, Social and community): real guests in real places, the most believable proof we have. Add names, months and trip links.
  3. Pace explainer (141:12, Other: explainer sheet): a distinctive idea no competitor in the file has. Fix the colours, the empty tip and the time format.
  4. Hopper's onboarding step showing real UI (141:68, Onboarding): the model for replacing our splash tagline with product proof.
  5. Booked trip documents block (141:13, Detail sections): the right first thing for a traveller a week out. Needs status per document.
- **The 5 things to never copy:**
  1. Fuchsia filled "Delete" as the default in a destructive sheet (141:79): makes the harmful action the easy one.
  2. Price-only sticky bar with no action (141:6): spends the most valuable space on screen and asks for nothing.
  3. "V4 - Quotation 1" and other back-office labels on customer screens (141:14, 141:16): confuses people at the decision moment.
  4. Floating toast and floating filter dock over content (141:22, 141:85): hide content, add accents and duplicate navigation.
  5. A splash with logo, tagline and illustration all at once (92:2, 141:21): cluttered, static and off-brand on the very first screen.
