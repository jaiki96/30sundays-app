# Group: scapia-social-splash

Screens looked at: 81 of 81 in `screens/scapia-social-splash/` (scapia-hotels 19, facebook-groups 14,
orphan 10, splash-study 13, onboarding-study 25), plus the 7 Scapia destination page screenshots in
`Downloads/Scapia destination page/` (IMG_3933 to IMG_3939), cited by file name.

Reading notes that apply to the whole group:
- Scapia Hotels and Facebook groups are laid out in the Figma file in REVERSE order. The iOS clock
  runs 18:30 on 2014:20 to 18:35 on 2014:2, and 14:48 on 2028:36 to 14:51 on 2028:23. The flows
  below are listed in the real order a person scrolled.
- Hex values are estimates from JPEG exports. Where a value was measured by script, it says so.

---

## Part 1. Scapia

### Scapia Hotels (travel, hotel detail page, 19 screens)

One property (Suryaa Villa, a heritage haveli in Jaipur), top to bottom, plus the sheets it opens.

- **Flows covered:**
  - 2014:20 detail hero: photo carousel, name, Scapia score chip, photo category rail, sticky price bar.
  - 2014:19 "About the stay" card with captioned photo rail, "View details", start of "What the place offers".
  - 2014:18 "About the stay" bottom sheet: centred title, photo rail, long description.
  - 2014:17 "What the place offers" (5 shown, "+ 58 more"), start of "Where you'll be".
  - 2014:16 "What the place offers" sheet: Highlights, Room features, Bathroom amenities.
  - 2014:15 "Where you'll be": address, map card, Street view button, Attractions tab of a nearby rail.
  - 2014:14 full-screen map with Map view / Street view toggle.
  - 2014:13 full-screen Google Street View of the actual road.
  - 2014:12 nearby rail, Restaurants tab.
  - 2014:11 nearby rail, Essentials tab (DMart, a market).
  - 2014:10 nearby rail, Transport tab (railway station shown as a 3D train icon).
  - 2014:9 "Where you'll sleep" room rail, then the Scapia score panel with three bars.
  - 2014:8 Scapia score explainer sheet.
  - 2014:7 reviews page: score, three sub-scores, sort, a "Booked on Scapia" review with tag chips, TripAdvisor reviews.
  - 2014:6 reviews page scrolled: Google reviews.
  - 2014:5 "scapia assist" call card with hours, Check-in / Check-out tiles, start of "Before you reach here".
  - 2014:4 "Before you reach here" policies inline (IDs, charges, children, extra bed).
  - 2014:3 "Hotel policies" sheet, rest of the rules.
  - 2014:2 photo gallery with category chips and counts (All photos 89, Facade 5, Entrance 5).
- **Typography:** one rounded geometric sans throughout, likely Lexend (or a close cousin such as
  Outfit). Weights 400 to 600, no heavy display weight. At 390 wide: hero title about 28 px
  semibold on two lines (2014:20), sheet title about 26 px medium centred (2014:18), section titles
  about 18 px semibold ("Where you'll sleep", 2014:9), body 15 px, captions and meta 12 to 13 px.
  Sentence case for section titles, which reads calm. Prices: bold navy "₹4,206" about 20 px with a
  light "/night" suffix, struck-through grey anchor price above, and a third line "+ ₹262 taxes & fees"
  (2014:20). Room prices are grey "₹6,449 onwards" at body size (2014:9), so the room price is
  weaker than the headline price it feeds.
- **Colour:** light theme on white #FFFFFF with pale blue panels #EEF4FD (nearby rail, policy box).
  Primary action is a red-orange #E8401C ("Continue"). Brand accent orange #F15A24 for "Scapia score"
  and the rating bars. Link and icon blue #1A5FD8 for amenities and "Read more". Green #1E9B3B for
  "Book with ₹0" and "Free breakfast". Solid red pill #E5341D for "58% off". Navy #1D2340 for prices
  and stars. Greys #6B7280 (meta) and #9AA0AA (struck price). The assist card and score panel use a
  soft blue to lavender to pink gradient (2014:5, 2014:8, 2014:9). On one screen up to four accents
  compete: red-orange CTA, orange score, blue links, green checks (2014:9).
- **Layout and spacing:** 16 px gutters, generous 24 to 32 px between sections, no dividers between
  sections (white space only), with tinted pale blue boxes for grouped content. Cards 16 px radius
  with a 1 px cool grey border, almost no shadows. Hero image is inset with 16 px radius at about 4:3
  (2014:20). Room cards about 3:2 in a peeking rail (2014:9). Nearby cards are horizontal (square photo
  left, text right) inside a tabbed blue tray (2014:15). Sheets slide over a dimmed page with a grab
  handle and an X (2014:16, 2014:18, 2014:3). Sticky price bar on every page screen.
- **Section designs:**
  - Detail hero: inset rounded photo carousel with floating back and "Shortlist" buttons, title, score chip and ratings link (2014:20).
  - Category tiles: photo category rail (Facade, Entrance, Room) under the hero that jumps into the gallery (2014:20).
  - Other (gallery filter): gallery with category chips that carry counts (2014:2).
  - Editorial and stories: "About the stay" card with a captioned photo rail and "View details" (2014:19, sheet 2014:18).
  - Inclusions list: "What the place offers" with icon rows, 5 shown, "+ 58 more" button, full list in a sheet (2014:17, 2014:16).
  - Map: "Where you'll be" map card with expand, zoom and Street view buttons (2014:15); full map with Map / Street toggle (2014:14); Street View of the real street (2014:13).
  - Card rail: tabbed nearby rail (Attractions, Restaurants, Essentials, Transport) with rating count and distance (2014:15, 2014:12, 2014:11, 2014:10).
  - Listing card: "Where you'll sleep" room card with two green check tags, bed config and "from" price (2014:9).
  - Reviews and ratings: "Scapia score" 8.2 with Cleanliness / Service / Location bars (2014:9); reviews page with sub-scores, sort and source labels (2014:7, 2014:6).
  - Trust and proof: each review names its source (Booked on Scapia, Google, TripAdvisor) with the source logo (2014:7, 2014:6).
  - Other (explainer sheet): what the Scapia score is (2014:8).
  - Help and chat: "scapia assist" call card with live hours "Available from 8 AM to 11 PM" (2014:5); floating "Call assist" button (2014:9).
  - Detail sections: Check-in / Check-out twin tiles (2014:5); "Before you reach here" icon-led policy groups (2014:4, 2014:3).
  - Sticky CTA bar: struck price, discount pill, price per night, taxes line, "Continue" (2014:20).
- **Strengths:**
  - The score breaks into three named sub-scores with bars, so "8.2" has a reason (2014:9, 2014:7).
  - Reviews show where they came from, including "Booked on Scapia" for verified stays (2014:7). Honest and easy to trust.
  - Nearby places are sorted into four plain tabs with distances, so "is it central" is answered in one glance (2014:15).
  - Street View of the real road is brave and trust building, it shows the street as it is (2014:13).
  - Human help is offered with real hours, not a vague "24x7" (2014:5).
  - Long content lives in sheets, so the page stays scannable and each section shows a short preview first (2014:17 to 2014:16, 2014:19 to 2014:18).
  - Policy groups lead with a small icon and a bold label (IDs Accepted, Charges, Children Stay Policy), which helps scanning (2014:4).
  - Section titles speak to the guest: "Where you'll sleep", "Where you'll be", "Before you reach here" (2014:9, 2014:15, 2014:4).
- **Weaknesses:**
  - Price display uses a struck anchor "₹10,165 + tax", a solid red "58% off" pill, then adds "+ ₹262 taxes & fees" on a third line (2014:20). Anchoring plus drip pricing; the true total is never shown. Breaks "match between system and real world" and erodes trust.
  - The floating "Call assist" pill sits on top of content and cuts text mid-word ("Rollaway bed fee: IN", 2014:4) and covers the room rail (2014:9). It also changes shape between a pill and a circle with no clear rule (2014:9 vs 2014:15). Breaks "consistency and standards".
  - The hotel name truncates in the sticky header on every screen ("Suryaa Villa | A City Cent...", 2014:19). The name itself carries a pipe and a marketing tail.
  - Counts disagree: "1,543 ratings" (2014:20), "1.5k ratings" (2014:9), "84 reviews" (2014:7). They may measure different things but nothing says so.
  - The score explainer is marketing, not method: "We want the Scapia Tribe to Travel Better!" in pale grey, with no sources or weights named (2014:8). Low contrast and low information.
  - Amenities are blue like links but are not tappable (2014:17). False affordance. "Jungle Safari" and "Sun Deck" listed as highlights of a city haveli suggest supplier data is not checked (2014:16).
  - The Transport tab swaps real photos for a cartoon 3D train and an all-caps station name (2014:10). Inconsistent with the other three tabs.
  - Policy text is supplier boilerplate, including "may be translated using automated translation tools" and "Private host property" (2014:3). Long bullet walls.
  - Four accents on one screen (2014:9) and green used to mean "good" (2014:9 tags).
- **Scores (1 to 5):** visual polish 4, clarity 3, information density 3, trust 4, brand distinctiveness 3.
- **For 30 Sundays:**
  - Borrow for **itinerary** and **booked trip** (the stay inside each day): the "Where you'll be" map with tabbed nearby places and distances (2014:15), and Street View as an optional "see the street" link (2014:13).
  - Borrow for **destination page** and **itinerary** hotel blocks: score with three named sub-scores and source-labelled reviews (2014:9, 2014:7). Use lagoonBliss for the "Booked with 30 Sundays" proof, not green ticks.
  - Borrow for **booked trip**: Check-in / Check-out twin tiles (2014:5) and icon-led "Before you reach here" groups (2014:4), written in our own short words.
  - Borrow the pattern of short preview plus sheet for long text (2014:19 to 2014:18).
  - Avoid: the struck price, the solid "58% off" pill and the separate taxes line (2014:20). Show one all-in price.
  - Avoid: a floating help button over content (2014:4). Put help inside the page or in the sticky bar.
  - Avoid: blue non-tappable text (2014:17) and unchecked supplier lists (2014:16).

### Scapia destination page (travel, destination landing, 7 screenshots)

The Vietnam page in the Scapia app, captured top to bottom. This is the screen closest in purpose to
our destination page.

- **Flows covered:**
  - IMG_3933 hero: full-bleed aerial photo that fades into a warm grey ground, flag disc, serif "Vietnam", "Starting from ₹54,999/person", "6 Nights · 7 Days" pill, sticky expert CTA.
  - IMG_3934 intro paragraph, city chips (Hanoi, DaNang), start of "Choose your holiday highlights".
  - IMG_3935 highlights rail: tall photo cards in a cream frame with an italic serif caption ("Cruise Ha Long Bay, then move to a kayak").
  - IMG_3936 "Personalise your holiday with experts": a 2 by 2 grid of service cards with 3D icons.
  - IMG_3937 scrapbook map: taped polaroids with dashed leader lines to dots on a country outline.
  - IMG_3938 rest of the scrapbook, then a "Looking for more details?" banner with a second "Talk to an expert" button.
  - IMG_3939 "Frequently Asked Questions", all answers open.
- **Typography:** two families. Display is a high-contrast book serif (similar to Gloock or Fraunces)
  for "Vietnam" at about 44 px regular (IMG_3933) and in italic at about 22 px for highlight captions
  (IMG_3935). UI is the same rounded geometric sans as Scapia Hotels (likely Lexend). Section titles
  about 20 px semibold in two tones, dark then grey ("Choose your holiday" dark, "highlights" grey,
  IMG_3934). Card titles about 17 px semibold with 14 px grey support lines (IMG_3936). Map captions
  in a rounded grey sans about 18 px, slightly rotated (IMG_3937). Price "₹ 54,999" bold about 20 px
  with a light grey "/person".
- **Colour:** light, warm. Ground warm grey #F3F2EF, cards white #FFFFFF, highlight card frame cream
  #FBF8EC. One action colour, burnt orange #C2481F ("Talk to an expert"), with the same orange in the
  sparkle line above it. Chips pale periwinkle #E6EAF5 with navy text. Text navy #22273A, greys
  #8A8F99 and #A3A7AF. Red only in the Vietnam flag and the map dots #E0522D. No gradients except
  the photo fade in the hero. One accent per screen, well judged.
- **Layout and spacing:** 20 px gutters, very airy, about one idea per screen height. Highlight cards
  are portrait (about 3:4) and peek at the right edge. Service cards 16 px radius, white on grey, no
  border, 3D icons break out over the top edge (IMG_3936). Sections separated by space only. The
  sticky bottom block (sparkle line plus full-width button) takes about 18% of the screen on every
  scroll position.
- **Section designs:**
  - Detail hero: full-bleed photo fading into the page ground, flag, serif name, starting price, nights pill (IMG_3933).
  - Category tiles: city chips under the intro (IMG_3934).
  - Card rail: "Choose your holiday highlights", portrait photo cards with a verb-led serif caption (IMG_3935).
  - Trust and proof: "Personalise your holiday with experts" 2 by 2 service promise grid with 3D icons (IMG_3936).
  - Map: scrapbook map, taped polaroids linked by dashed lines to dots on the country outline (IMG_3937, IMG_3938).
  - Help and chat: "Looking for more details?" banner with illustration and text button (IMG_3938).
  - Other (FAQ): open FAQ list with honest exclusions (IMG_3939).
  - Sticky CTA bar: one-line promise "We'll help you build your own trip" plus "Talk to an expert" (IMG_3933).
- **Strengths:**
  - One action, one colour, on every screen (IMG_3933 to IMG_3939). Exactly our "one fuchsia action" rule.
  - Highlight captions are actions, not place names: "Cruise Ha Long Bay, then move to a kayak" (IMG_3935). They sell the day, not the dot on the map.
  - The serif display face gives an editorial, travel-magazine feel that no OTA in the file has (IMG_3933).
  - The service grid answers "what do you do for me" in four plain lines: stays, flights, experiences, visa (IMG_3936).
  - The FAQ is honest about what is not included ("International flights, visa & travel insurance aren't included", IMG_3939).
  - The scrapbook map is memorable and on-theme for a holiday (IMG_3937).
- **Weaknesses:**
  - Grey on grey: the intro paragraph, map captions and FAQ answers are pale grey on a warm grey ground (IMG_3934, IMG_3937, IMG_3939). Contrast looks under 4.5:1. Breaks accessibility (WCAG contrast).
  - Two-tone section titles add grey to the most important text on the screen (IMG_3934, IMG_3936).
  - The "starting from" price sits on the hero, but the fact that flights and visa are extra is only in the FAQ at the very end (IMG_3933 vs IMG_3939). Breaks "visibility of system status" for cost.
  - The scrapbook map carries almost no information: no route order, no nights, no travel times, and the country outline is laid on its side to fit the width, which makes it hard to read (IMG_3937). Decoration where a route could be.
  - "Talk to an expert" appears twice on one screen (sticky bar and banner, IMG_3938), and the sticky block eats about a fifth of every screen.
  - Inconsistent place names: "DaNang" in the chip (IMG_3934). Title Case "Frequently Asked Questions" (IMG_3939) against sentence case elsewhere.
  - No proof from people: no reviews, no traveller photos, no count of trips (all seven screens).
- **Scores (1 to 5):** visual polish 4, clarity 4, information density 3, trust 3, brand distinctiveness 4.
- **For 30 Sundays:**
  - Borrow for **destination page**: the photo-fade hero with serif name, starting price and nights (IMG_3933), using our handwriting face in place of the serif.
  - Borrow for **destination page**: verb-led highlight cards (IMG_3935). Each card is a moment someone will do.
  - Borrow for **destination page** or **home**: a four-card "what we handle" grid (IMG_3936), mapped to our three USPs, with titles only (no subtitle rule means the second line must earn its place or go).
  - Borrow the single sticky action with a one-line promise above it (IMG_3933), in sunsetFuchsia.
  - Avoid: grey body text on a tinted ground (IMG_3934). On cream, use navy #181E4C body text.
  - Avoid: a decorative map with no route (IMG_3937). Our map should show the route, nights per stop and travel legs.
  - Avoid: hiding exclusions in the FAQ (IMG_3939). Say "Flights not included" next to the price.

---

## Part 2. Community reference, and the loose screens

### Facebook groups (social, group feed, 14 screens)

A private group (UChat Community, 4.3K members) as a member sees it, from the Groups tab to a thread.

- **Flows covered:**
  - 2028:36 Groups tab "For you": pinned "Your groups" list with unread counts, then "From your groups" feed.
  - 2028:35 group home: cover image, name, "Private · 4.3K members · Invite", tab chips, composer entry, "Recent activity" feed.
  - 2028:34 About: privacy, visibility, history, tags, location map, start of rules.
  - 2028:33 "Group rules from the admins", numbered.
  - 2028:32 end of rules, Members (admins and moderators named), "Group activity" stats.
  - 2028:31 search inside the group, empty "No recent searches".
  - 2028:30 group overflow menu (Manage your content, Share group, Manage notifications, Your group profile, Group settings) plus a Meta AI terms toast.
  - 2028:29 cover scrolled up under the status bar.
  - 2028:28 header collapsed into a purple bar with group avatar and name.
  - 2028:27 post composer: People, Location, Feeling/activity chips; Gallery, GIF, Poll tiles; disabled "Post".
  - 2028:26 post detail: comments with "Admin" and "Moderator" badges, nested reply, like / dislike, "Comment as ..." field.
  - 2028:25 post overflow sheet: Save, Copy link, Report to admins, Report post, Be notified, Leave group.
  - 2028:24 group home with the tab chip row scrolled (About, Guides, Photos, Files, Albums).
  - 2028:23 "Sort by" sheet: Most relevant, Recent activity, New posts, each with a one-line explanation.
- **Typography:** iOS system face, SF Pro. Weights 400 to 700. Group name about 24 px bold
  (2028:35), section titles about 18 px bold ("Recent activity", "Group rules from the admins"), body
  15 px regular, meta 13 px grey. Sentence case everywhere. Numbers abbreviated (4.3K, 9+).
- **Colour:** light. White #FFFFFF ground, thick grey separators #CED0D4 between posts, chips and
  inputs on #E4E6EB / #F0F2F5. Facebook blue #0866FF for links, selected radio and "Follow". The
  header bar takes its colour from the group cover, here purple #8A4FE6 (2028:28), which is a smart
  adaptive touch. Red #E41E3F notification badges on the bottom nav. Role badges in blue. Two to three
  accents per screen (cover purple, blue, red badges).
- **Layout and spacing:** 12 to 16 px gutters, dense. Posts are full-bleed, separated by 6 to 8 px grey
  bands, not cards. Avatars 40 px circles. Sheets with grab handles for sort and post actions. Chip row
  scrolls sideways and hides most tabs. Five-item bottom nav with labels.
- **Section designs:**
  - Social and community: pinned group list with "25+ new posts" unread dots (2028:36).
  - Detail hero: group cover with name, privacy, member count and Invite link (2028:35).
  - Filters and sort: sideways tab chips (2028:35, 2028:24); sort sheet with an explanation under each option (2028:23).
  - Social and community: "Write something..." composer entry with own avatar and photo icon at the top of the feed (2028:35).
  - Social and community: post card with author, time, audience icon, truncated text with "more", like / comment / share row (2028:35).
  - Social and community: thread with role badges (Admin, Moderator, verified tick), indented reply, reply counts (2028:26).
  - Booking form: composer with tag chips (People, Location, Feeling) and Gallery / GIF / Poll tiles (2028:27).
  - Other (rules): numbered rules with a short title and an explanation (2028:33).
  - Trust and proof: Members block naming admins and moderators, plus "Group activity" stats ("1 new post today", "4.3K total members, +2 in the last week", "Created about 6 years ago", 2028:32).
  - Other (about): About with icon rows and a location map (2028:34).
  - Search bar: scoped "Search in UChat Community" (2028:31).
  - Other (action sheet): post overflow with plain consequences ("We won't let Adnan know who reported this.", 2028:25).
  - Bottom nav: five tabs with red count badges (2028:35).
- **Strengths:**
  - Role badges next to names make it clear who speaks for the group (2028:26). Strong trust cue in a thread.
  - Each sort option says what it does in one line (2028:23). Good "help users recognise" practice.
  - Rules are numbered, titled, and explained in plain words (2028:33).
  - "Group activity" gives a living pulse in three short facts (2028:32), which answers "is anyone here".
  - Report flow says what will happen and protects the reporter (2028:25).
  - The composer entry sits at the top of the feed, one tap to post (2028:35).
  - The header adopts the group's cover colour when collapsed (2028:28), so each group feels like its own place.
- **Weaknesses:**
  - Spam got through: a phone number post "Call me at 9643300742" in a flatmates group (2028:36). Moderation gaps are visible in the main feed.
  - The Meta AI terms toast covers the bottom nav and asks for consent by usage (2028:30). Dark pattern (consent by default).
  - Red "9+" and "1" badges shout on every screen (2028:35). Noise unrelated to the group.
  - Most tabs are hidden in a sideways chip row (2028:35 vs 2028:24). Breaks "recognition rather than recall".
  - The group's own cover art fights the status bar and back button (2028:29).
  - Search opens with nothing: no suggested topics or recent posts (2028:31). Empty state wasted.
  - The overflow menu mixes personal and group settings with no grouping (2028:30).
  - Dense chrome: separators, chips, composer and nav leave little room for posts (2028:35).
- **Scores (1 to 5):** visual polish 3, clarity 3, information density 3, trust 3, brand distinctiveness 2.
- **For 30 Sundays (community):**
  - Borrow: role badges for our trip experts and the community host, shown next to the name in replies (2028:26). Use lagoonBliss for "30 Sundays expert", not a solid pill.
  - Borrow: nested replies one level deep with a reply count (2028:26).
  - Borrow: a three-fact pulse line ("12 new posts this week", "Members from 40 cities") on the community entry (2028:32), kept as a single line on home.
  - Borrow: sort options with a one-line explanation (2028:23) and plain-language rules (2028:33).
  - Borrow: a composer entry at the top of the feed, with "Destination" in place of "Feeling" as the tag chip (2028:27). A Poll tile suits "Bali or Thailand in March?".
  - Borrow: report copy that protects the reporter (2028:25).
  - Avoid: unmoderated contact details and selling (2028:36). Hide phone numbers by default and route trade to our team.
  - Avoid: red count badges and consent toasts over navigation (2028:35, 2028:30).
  - Avoid: hiding sections in a scrolling chip row (2028:35). Our community has few areas; show them all.

### Orphan screens (10 loose items, worked out)

These sit outside any labelled app cluster. What each one is:

- 124:4 grey rectangle, 2493 by 1468 on canvas. It sits behind the designer's to-do note 124:3 ("add all splash screens to research documentation ... analyze everything in numbers - splash screens white space percentage, text + logo + illustration ..."). It is the note's background card, not a screen.
- 113:142 white rectangle, 59840 by 34176 on canvas, at the same origin as the title 113:143 "Competitor research and UI benchmarking (49 Apps)". It is the board behind the 49 apps, not a screen.
- 104:3 a website top nav: "Home, Blogs, Destinations, Itinerary analyser, About us, Contact" in white on a dark textured bar with thin dividers. It sits just above the 30 Sundays app screens on canvas, so it is most likely the 30sundays.club website header.
- 113:152 to 113:158 are seven screens of the **earlier live 30 Sundays app** (couples era, Poppins-like geometric sans, hot pink #FF0A5A, pastel pink-peach gradient grounds). They read as raw material for the internal audit. Evaluated briefly below.

#### 30 Sundays, earlier build (own app, 7 screens)

- **Flows covered:**
  - 113:158 planning questionnaire with "Skip": destination chip, adults stepper, "travelling with children" toggle, two "We're so sorry" blocks, greyed "Explore Itineraries".
  - 113:157 Explore home: destination rail ("Vietnam, Bays, lanterns & bustling streets", "View all"), "Traveller moments" rail, a promo toast and an error toast stacked over the bottom nav.
  - 113:152 "Explore Trips" listing: full-bleed route cards ("2N Seminyak • 1N Nusa Penida • ..."), floating filter bar (6-8N, Relaxed, Offbeat, filter button with a count).
  - 113:154 and 113:153 "Itinerary Map": day chips (Jun 10, Jun 11, Jun 12), map with a "Your stay" pin, bottom sheet of the day's items.
  - 113:156 booked trip "Your Maldives Trip · 4N, Dec 30 - Jan 3 · 2": rooms list and a hotel sheet (4 Star, Full Board, Directions).
  - 113:155 same trip: "Honeymoon Specials", "Birthday Specials", "Anniversary Specials" accordions, then "Flights not included in this price".
- **Typography:** geometric sans, likely Poppins, 400 to 600. Card route titles about 20 px semibold
  white over photo (113:152), page titles about 24 px medium, body 15 px, captions 13 px. Prices
  "From ₹56,262/person" with bold number and light suffix.
- **Colour:** hot pink #FF0A5A for selected day chip, links and pins; pastel pink-peach gradient tops;
  white cards with grey #E5E5E5 borders; green #1E9B3B for "4 Star" and the stay pin; orange pill
  "Full Board"; purple flight icon. Three to four accents per screen.
- **Layout and spacing:** 16 px gutters, 16 px radius cards with hairline borders, full-bleed photo
  route cards with dark bottom gradient, floating pill filter bar.
- **Section designs:**
  - Listing card: full-bleed route card with route string, nights and per-person price (113:152).
  - Filters and sort: floating chip bar with a filter button and count badge (113:152).
  - Map: day chips over a map with a "Your stay" pin and a day sheet (113:154).
  - Itinerary and timeline: day-by-day map items (113:153).
  - Detail sections: occasion accordions on a booked trip (113:155).
  - Booking form: who-is-travelling questionnaire with inline blocking messages (113:158).
  - Editorial and stories: "Traveller moments" photo rail (113:157).
- **Strengths:** day chips plus map plus day sheet is a clear itinerary map (113:154). Route strings
  with nights tell the trip shape at a glance (113:152). "Flights not included in this price" is said
  plainly (113:155).
- **Weaknesses:**
  - Two "We're so sorry" blocks and a greyed-out button stop a family or group from going further (113:158). A dead end, against the now neutral brand. Breaks "help users recover from errors".
  - An error toast stacked over a promo toast over the bottom nav (113:157). Three layers fight for the same spot.
  - Supplier text pasted raw: "?" boxes where emoji failed and hard line breaks mid-sentence (113:155).
  - A cartoon traveller placeholder in place of a missing photo inside a photo listing (113:152).
  - Couple-only copy now out of date: "Real photos from couples who travelled with us" (113:157), "Honeymoon Specials" (113:155).
  - Green for "4 Star" means "good" (113:156), against our colour rules.
- **Scores (1 to 5):** visual polish 3, clarity 3, information density 3, trust 3, brand distinctiveness 2.
- **For 30 Sundays:** keep the day chips and map pattern for **itinerary** (113:154), keep route
  strings with nights on cards (113:152). Remove dead-end gating (113:158), stacked toasts
  (113:157) and raw supplier text (113:155).

---

## Part 3. Splash and onboarding study (13 apps, frame 129:108)

### What the files actually are

- The 13 splash-study files (127:31 to 129:104) are the **app icons** used as column headers, not
  splash screens. They make identification certain.
- The 25 onboarding-study files are **frames from each app's launch sequence** (splash animation
  steps), not onboarding flows. No app in this set shows a welcome carousel, a sign-in screen or a
  permission ask. So the onboarding advice at the end leans on our own earlier questionnaire
  (113:158) and established practice, and says so.
- The node names run IMG_0022 to IMG_0047 in capture order, which confirms the frame order inside
  each column.

### App identification and pattern per column

Empty-ground share was measured by script on each frame (share of pixels within a small distance of
the dominant ground colour, status bar and home bar excluded). This answers the designer's to-do
(124:3) "white space percentage".

| # | App (icon) | Frames | Ground (measured) | What shows | Opening | Closing | Empty ground |
|---|---|---|---|---|---|---|---|
| 1 | Cleartrip (127:31) | 129:114, 129:113, 129:112 | orange-red #FC4414 | logo, then brush script "So, where to?", then enamel pins (Goa, Bali, Thailand, hills) and "55 Million+ happy journeys and counting!", footer "A Flipkart Company" | builds in three steps | fades | 98%, 96%, 89% |
| 2 | Airbnb (127:35) | 129:117, 129:116, 129:115 | white #FCFCFC | grey logo placeholder, then a pink stroke draws the Bélo, then full pink logo | logo draws itself | cuts | 99 to 100% |
| 3 | EaseMyTrip (129:48) | 129:138 | white | logo, clip-art trio, "Trusted by 30 Million+ Users" shield, "Made in India" badge | none | fades | 94% |
| 4 | Yatra (129:45) | 129:140 | white | red wordmark centred | none | cuts | 98% |
| 5 | Booking.com (127:23) | 129:143, 129:142 | navy #04348C | white wordmark centred, then it shrinks and slides up to the header position | none | logo becomes the home header | 98 to 99% |
| 6 | OYO (129:65) | 129:146, 129:145 | red #C4142C | faint logo grows to almost full width, solid white | logo scales up | cuts | 97%, 91% |
| 7 | BookMyShow (129:71) | 129:150, 129:149, 129:148 | red #DC2C44 | logo plus "It All Starts Here", then line icons burst out (film reel, mic, masks, film), then logo again | icon burst | fades | 98 to 99% |
| 8 | MakeMyTrip (129:79) | 129:153, 129:152 | white | logo plus "Powering magical trips for 25 years", then logo moves up and "Introducing OneCircle ... Rewarding Your Stays Across 11000+ Properties" | logo moves up, feature reveal | fades | 98%, 89% |
| 9 | Headout (129:82) | 129:157, 129:156 | white | purple blimp in a lavender ticket shape, then the ticket outline ripples outward | ripple | cuts | 99% |
| 10 | ixigo trains (129:42) | 129:166 | blue #144CB4 | logo, footer "IRCTC Authorised Partner" seal | fades in | fades | 98% |
| 11 | redBus (129:93) | 129:162, 129:161, 129:160 | white | bus logo, then speed lines as it "drives", then it lifts with "Let's get started on your journey with redBus!" | product metaphor motion | next content slides in | 98 to 99% |
| 12 | Hopper (129:91) | 129:163 | coral #F45C5C | white bunny and wordmark | none | fades | 99% |
| 13 | 30 Sundays (129:104) | 129:164 | cream to pink gradient (#F4F4F4 dominant) | logo, handwriting "Saving Relationships, One Vacation at a Time!", couple selfie illustration with hearts and a pink city | none | none | 75% |

Counts across the 13:
- Ground: 6 full-bleed brand colour (Cleartrip, Booking.com, OYO, BookMyShow, ixigo, Hopper), 6 white (Airbnb, EaseMyTrip, Yatra, MakeMyTrip, Headout, redBus), 1 gradient (30 Sundays).
- Content: 6 logo only (Airbnb, Yatra, Booking.com, OYO, Headout, Hopper); 4 add a line of text (BookMyShow, MakeMyTrip, redBus, ixigo seal); 3 add illustration or data (Cleartrip, EaseMyTrip, 30 Sundays).
- Motion: 8 animate in some way; 5 are static (EaseMyTrip, Yatra, Booking.com opening, Hopper, 30 Sundays).
- Hand-over: 6 fade, 4 hard cut, 2 carry the logo into the next screen (Booking.com, redBus), 1 has no transition (30 Sundays).
- Empty ground: 12 of 13 sit at 89 to 100%. 30 Sundays is the outlier at 75%, the busiest splash in the set.

### Evaluation as patterns

**Splash, kind: Splash**
- Best: Booking.com's hand-over (129:143 to 129:142). The wordmark shrinks and moves to where the home
  header will be, so the splash is not a separate wait but the first frame of the app. A shared
  element transition; it feels faster than it is.
- Best brand moment: Airbnb's logo drawing itself in one stroke (129:117, 129:116, 129:115). It is
  short, it says "made by hand", and it needs nothing else on screen.
- Best personality: Cleartrip's "So, where to?" with destination pins (129:112). Warm, on-topic,
  and the pins name real destinations. But it is three steps of reading inside about two seconds, and
  the "55 Million+" claim is noise at launch.
- Good product metaphor: redBus's bus driving off with speed lines, then lifting into a welcome line
  (129:161, 129:160). Motion that means something.
- Good trust: ixigo's "IRCTC Authorised Partner" seal (129:166). One quiet proof, at the bottom,
  that matters for its category.
- Weak: EaseMyTrip (129:138) packs a clip-art crowd, a user count and a "Made in India" badge. It
  looks like an ad and dates the brand.
- Weak: MakeMyTrip turns the splash into a product launch ad for OneCircle (129:152), and its footer
  says "25 years" in one frame and "26 years" in the next (129:153 vs 129:152). An ad on the one
  screen nobody can skip, and a copy error on top.
- Weak: Yatra and Hopper are correct but forgettable (129:140, 129:163). A static logo with a cut
  is the baseline, not a design.
- 30 Sundays today (129:164):
  - The claim "Saving Relationships, One Vacation at a Time!" ties the brand to couples, which we have dropped, and frames relationships as needing rescue.
  - A flat stock-style couple illustration with hearts, in pinks that are not sunsetFuchsia.
  - Title Case and an exclamation mark, against our plain copy rules.
  - No motion and no hand-over, so it reads as a still image, then a jump.
  - 75% empty ground against 89 to 100% for every other app: the busiest splash in the set.
  - What works: the logo itself (palm, the "n", the sun) is hand-drawn and distinctive (129:104), and the handwriting face already matches the brand board.

**Onboarding, kind: Onboarding**
- None of the 13 apps puts a carousel or a sign-up wall between splash and home in these captures.
  The pattern of the category is: splash, then straight to a usable home. redBus is the only one that
  hands over to a welcome line (129:160).
- Our earlier build asked questions up front (113:158): destination, adults, children, then blocked
  the answer with two apology blocks and a greyed button. Asking is fine; blocking is not.

### Comparison in one view

| Pattern | Who does it well | Why it works | Risk |
|---|---|---|---|
| Logo draws itself | Airbnb (129:116) | short, brand-only, memorable | needs a logo built from strokes |
| Logo becomes the header | Booking.com (129:142) | splash feels like part of the app | needs the home header to hold the logo |
| Tagline joins the logo | Cleartrip (129:113), BookMyShow (129:150), redBus (129:160) | sets the tone in a few words | copy must be very short |
| Destination imagery | Cleartrip (129:112) | on-topic for travel | crowding, slow to read |
| One trust seal | ixigo (129:166) | proof without noise | only if the seal means something |
| Stats and badges | EaseMyTrip (129:138), Cleartrip (129:112) | none at launch | clutter, dated feel |
| Feature ad | MakeMyTrip (129:152) | none for the user | annoys, copy errors slip in |

### What 30 Sundays should do

Splash:
- Use a cream #FFF6E6 ground, flat, no gradient. Keep it at least 90% empty, like the rest of the category.
- Show the logo only, in its own colours (palm in tropicalForest or lagoonBliss, the "n" in sunsetFuchsia, the sun in goldenHour).
- Opening: draw the logo in its three strokes, palm, then "n", then sun, in under a second (the Airbnb idea, 129:116). Our logo is already hand-drawn, so this is natural.
- One short line in the handwriting face may join under the logo in navy #181E4C, in sentence case, no exclamation, neutral for any traveller. Examples to test: "Your holiday, planned with you" or "Let's plan your next Sunday". Drop "Saving Relationships".
- Closing: the logo shrinks and moves into the home header (the Booking.com idea, 129:142), or fades if the home header has no logo.
- Keep the whole sequence under 1.5 seconds on a cold start. Skip the animation on warm starts.
- Never use the splash for offers, stats, new features or illustrations of people (129:152, 129:138, 129:164).
- Optional, later: one quiet proof line at the bottom in the way ixigo does (129:166), only if we have one true, simple fact.

Onboarding:
- No welcome carousel. Go from splash straight to a home that already shows destinations, as every app here does.
- Ask at most three light questions, each one skippable: where (a destination chip), when (a month), who (just me, two, family or group). Use the answers to sort home. Our old questionnaire (113:158) had the right shape.
- Never block an answer. If we cannot plan something yet, say what we can do instead in one line and keep the button live.
- Ask for the phone number (OTP) only when it is needed, for example when saving a trip or asking for a quote. Do not ask on first open.
- Ask for notifications in context, after the first quote or booking ("We'll tell you when your quote is ready"), not at launch.
- Keep one fuchsia action per onboarding screen and a visible "Skip" in the top right (113:158 placement).

---

### Group summary

**Patterns that repeat, by component kind:**
- Sticky CTA bar: both Scapia surfaces keep one full-width action pinned (2014:20, IMG_3933). Hotels adds price and discount to it; destination adds a one-line promise.
- Help and chat: both Scapia surfaces push talking to a human (2014:5, IMG_3938). Scapia sells expertise, as we do.
- Map: three takes on place: Scapia Hotels (useful, tabbed nearby, 2014:15), Scapia destination (decorative scrapbook, IMG_3937), our old itinerary map (day chips, 113:154).
- Detail sections in sheets: Scapia Hotels (2014:16, 2014:18, 2014:3) and Facebook (2028:23, 2028:25) both move long or secondary content into sheets with grab handles.
- Trust and proof: source-labelled reviews (2014:7), role badges (2028:26), group pulse stats (2028:32), a partner seal on a splash (129:166).
- Social and community: only Facebook here; the useful parts are roles, sort explanations, rules and the composer.
- Splash: logo-centred, 89 to 100% empty ground, under two seconds, in 12 of 13 apps.
- Onboarding: none of the 13 apps puts a carousel or login before home.

**The 5 best section designs for a travel app like ours (ranked):**
1. Highlight cards with verb-led captions, Scapia destination (IMG_3935). Sells the moment, not the place name. For our destination page.
2. "Where you'll be" map with tabbed nearby places and distances, Scapia Hotels (2014:15). Answers "is it central" in one look. For itinerary and booked trip stays.
3. "Personalise your holiday with experts" four-card service grid, Scapia destination (IMG_3936). States what the company does in four plain lines. For destination page or home, mapped to our USPs.
4. Thread with role badges and one level of nested replies, Facebook groups (2028:26). Makes expert answers stand out in a community. For Sunday Community.
5. Splash logo that becomes the home header, Booking.com (129:143, 129:142). The launch feels like part of the app. For our splash.
   Honourable mention: score with three named sub-scores and source-labelled reviews (2014:9, 2014:7).

**The 5 things to never copy:**
1. Struck anchor price, solid red "58% off" pill and taxes added on a third line (2014:20). Anchoring and drip pricing, plus a solid pill badge we ban.
2. A floating help button that covers content and cuts text (2014:4, 2014:9).
3. A splash used as a feature ad, with a copy error between frames (129:152 vs 129:153).
4. Blocking a traveller with apology boxes and a dead button (113:158), and couple-only claims on the splash (129:164). Both contradict the neutral brand.
5. Red count badges and consent toasts laid over navigation (2028:35, 2028:30), and letting phone numbers and selling into a community feed (2028:36).
