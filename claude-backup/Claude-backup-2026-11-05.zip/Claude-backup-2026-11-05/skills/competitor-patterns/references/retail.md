# Retail group: critical evaluation

Apps: Pepperfry (27), Nykaa (34), Mamaearth (25), Lenskart (21), Myntra (23), Flipkart (25), Meesho (36). 191 screens, all opened.
Screens are cited by Figma node id. Most sets were captured in reverse order (last screen first), so flows below are listed in the order a user would meet them, not the canvas order.

Gaps to know before using this file: no app in this group shows a filled wishlist, a reviews page, or reviews with photos. Only two detail pages exist (Pepperfry product 22:41, Lenskart eye test service 41:674). Nykaa, Mamaearth, Myntra, Flipkart and Meesho have no product detail page in the set. Advice on those topics below is drawn from the cards, listings and empty states that are present.

---

### Pepperfry (furniture and home, 27 screens)

- **Flows covered:**
  - 22:57 Splash: lifestyle room photo, wordmark, handwriting script mixed into a sans tagline.
  - 22:56 Notification permission asked over the welcome screen, before any value is shown.
  - 22:55 Welcome: full-bleed sofa photo, gradient wordmark, "Happy Furniture to You", one orange sign-up button, Skip for now.
  - 22:54 iOS tracking permission prompt.
  - 22:53 Home: search, text category tabs, photo category tiles (5 x 2 scroll), summer sale banner.
  - 22:48 Home with the help menu open (Buy on Phone, WhatsApp, Store, Still need help).
  - 22:52 Search: popular searches as outlined chips with trend arrows, voice mic.
  - 22:51 Listing: Categories / Sort / Filter toolbar, category chip with count, 2-column product grid.
  - 22:50 Sort bottom sheet (Relevance active).
  - 22:49 Filter side drawer with accordions, Clear all and Apply.
  - 22:41 Product detail top: breadcrumb, title, brand, rating, "103 People Viewing This", full-bleed image, dual Add to cart / Buy now.
  - 22:40 Cart: delivering to, coupon row, item with quantity, price summary, plant-a-tree add-on, sticky You Pay bar.
  - 22:39 Payment methods: suggested UPI, accordions, EMI disabled, sticky Pay now.
  - 22:38 Payment failed bottom sheet with refund timeline and Retry.
  - 22:44 Sign up (single field, coupon banner HELLO1500).
  - 22:43 Login with OTP and 29 second timer.
  - 22:42 My Account: blurred photo header, 2-column tile grid.
  - 22:33 Side drawer: orders, wallet, list rows, blog link.
  - 22:34 Categories accordion expanded (Lamps and Lighting) with bottom nav.
  - 22:35 Categories collapsed with thumbnails.
  - 22:37 Gift card landing (Buy / Redeem toggle).
  - 22:36 E-gift card builder (denomination tiles, stepper, sticky Show preview).
  - 22:45 Stores: furniture exchange banner, find a store by pincode, why visit us.
  - 22:46 iOS location permission prompt.
  - 22:32 Chatbot welcome with intent menu (vendor 1).
  - 22:31 Chatbot "Need help buying" lead form (name, phone, email, pincode).
  - 22:47 Second chat pre-form from a different vendor, with End chat.
- **Typography:** humanist sans, likely Lato or a close relative, regular to bold. Page titles about 18 px, card titles 14 px, body 13 px, captions 11 px. Buttons and section labels in UPPERCASE (SIGN UP OR LOG IN, PROCEED TO PAY, RETRY PAYMENT, CART SUMMARY). Splash 22:57 pairs a rust handwriting script ("Magic", "home") with black sans, which is the brand's one warm moment. Prices bold with the rupee glyph, MRP struck through in grey, "% off" in green.
- **Colour:** primary orange #FF6A1F used as a gradient into red-orange #F2413A on every main button. Brown-gold #A0652A for some headings ("Welcome Back" 22:43, "Find a store near you" 22:45). Tan #C8A27A on the filter Apply button (22:49), which reads as disabled. Dark forest green #0E5A4F promo strip (22:34). Chat teal #0A7A86 (22:31). Lilac #9B7BC0 Best Seller flag (22:51). Green #2E9E5B discount, red #E53935 "Only 2 left". Cream #FFF3E6 ground on the gift card page only. Light theme. Four to five accents fight on the cart and listing screens.
- **Layout and spacing:** 16 px gutters, medium-high density. Card radius 4 to 8 px, mostly hairline borders, almost no shadows. Product images about 1:1 in the grid, full-bleed on detail. Sections separated by grey bands. Floating elements stack badly: the "Buy on Phone" tag and orange call button sit over grid cards (22:51) and over the sticky CTA (22:41).
- **Section designs:**
  - Splash: room photo with script-plus-sans lockup (22:57).
  - Onboarding: full-bleed photo welcome with one button and a skip link (22:55).
  - Login and OTP: promo hero above a single field, timer (22:43).
  - Search bar: popular searches as chips with trend arrows (22:52).
  - Category tiles: photo tiles with labels in a 2-row horizontal scroll (22:53).
  - Filters and sort: three-part toolbar with state captions ("Relevance", "0 Filters Applied") (22:51); side drawer of accordions (22:49); plain sort sheet (22:50).
  - Listing card: image, Best Seller flag, heart on image corner, swatches "+2 more colors", brand, rating, warranty, price, EMI line (22:51).
  - Detail hero: breadcrumb, title, brand link, rating, full-bleed image, View similar pill (22:41).
  - Sticky CTA bar: outline Add to cart plus solid Buy now, stacked above the bottom nav (22:41).
  - Price display: cart summary with MRP, discount, You Pay (22:40).
  - Payment: delivering-to card, suggested UPI, accordions, split sticky bar with total and Pay now (22:39).
  - Confirmation: payment-failed sheet with refund window and Retry (22:38).
  - Profile: photo header plus 2-column tile grid (22:42).
  - Help and chat: floating help menu (22:48), two different chatbots (22:32, 22:47).
  - Other (gift card builder): denomination tiles plus live preview (22:36).
  - Other (store finder): pincode search, detect location, why-visit photo cards (22:45).
- **Strengths:**
  - Splash and welcome (22:57, 22:55) set a warm, photographic mood with a script accent. Closest in spirit to our brand.
  - Filter toolbar shows state under each control ("0 Filters Applied") (22:51). Good visibility of system status.
  - Payment failure sheet (22:38) says what happened and when the refund lands, then gives one Retry.
  - Plant-a-tree add-on in cart (22:40) is unticked by default. An ethical upsell.
- **Weaknesses:**
  - Raw "<br/>" tags print in the delivery address (22:38, 22:39). Broken trust at the payment step.
  - "103 People Viewing This" and a 1.0 star rating shown on the same detail (22:41). A FOMO dark pattern next to proof that hurts the sale.
  - Floating help tag and call button cover product cards and the CTA bar (22:41, 22:51, 22:48). Breaks aesthetic and minimalist design and blocks targets.
  - Sticky CTA bar sits on top of the bottom nav (22:41), so two bars eat 140 px.
  - Two different chat vendors with different looks and forms (22:32 vs 22:47). Consistency and standards.
  - Notification permission asked on first launch (22:56) before any value.
  - Filter Apply in tan (22:49) looks disabled and is a different accent from the orange used everywhere else.
  - Chat lead form asks for phone, email and pincode before helping (22:31).
- **Scores:** visual polish 3, clarity 3, information density 3, trust 2, brand distinctiveness 3.
- **For 30 Sundays:**
  - Borrow: the photo-plus-script splash and welcome (22:57, 22:55) for our first-run screen. The filter toolbar with state captions (22:51) for the itinerary list. The refund timeline wording of 22:38 for a failed payment on booked trip.
  - Avoid: floating help buttons over content, viewer counters, a sticky CTA stacked on the bottom nav, and any second accent for an Apply button.

---

### Nykaa (beauty, 34 screens)

- **Flows covered:**
  - 41:633 Login bottom sheet over a magenta onboarding carousel (Mobile, Google, Email, Skip).
  - 41:632 OTP bottom sheet over the same carousel (6 boxes).
  - 41:631 Home: wordmark with "Join Prive" script, rotating search keyword, ticker, category tiles, shortcut chips (including a Travel Beauty store), hero card, coupon strip, countdown deals.
  - 41:619 Shop hub: big title, stacked pink rows each with three round thumbnails.
  - 41:618 Categories: big title, full-width pink rows with pink 3D product renders.
  - 41:611 Shop and help hub: "Need help in buying?" circular tiles, More from Nykaa.
  - 41:617 Brands directory: search, Top / Luxe / Only at Nykaa logo grids.
  - 41:612 Collection page: gradient hero, sub-brand cards, product rail.
  - 41:615 Listing "Best of Beauty": coupon banner, category icon rail, quick filter chips, 2-column grid, sticky Sort / Filter bar.
  - 41:614 New at Nykaa: brand hero, "Latest in Luxury".
  - 41:616 Nykaa Luxe: framed editorial card "The Luxe Travel Beauty Edit", postmark illustrations.
  - 41:626 Duplicate of 41:616 one minute later.
  - 41:613 Gift Store: purple gradient hero, script words inside sans headings, occasion tiles.
  - 41:620 Nykaa Fashion sub-store: sale ticker, giant sale hero.
  - 41:621 Men store: dark teal band, editorial hero, brand cards.
  - 41:622 Mom and Baby store: cartoon clouds, wavy photo edge.
  - 41:623 Appliance store: lavender brand band, product rail.
  - 41:624 Wellness store: "What's your self-care goal?" goal cards.
  - 41:625 Fragrance store.
  - 41:627 Bath and Body store (shared store template).
  - 41:628 Hair store.
  - 41:629 Skin store with a Skin Analyser tool card.
  - 41:630 Makeup store.
  - 41:608 Brand storefront (Rare Beauty): black band, video hero, collection tiles.
  - 41:610 Nykaa Play: video, livestream schedule, games, "1 of 7" counter.
  - 41:609 Game zone: lavender ground, neon sign, Click to win.
  - 41:606 Wallet: tabs, balance 0, benefits grid, notes.
  - 41:607 Wallet loading spinner.
  - 41:605 Wishlist empty with a notification nudge banner.
  - 41:604 Profile settings list.
  - 41:603 Delete account: what you lose, fuchsia Delete button.
  - 41:602 "What went wrong?" reasons.
  - 41:601 OTP to confirm delete.
  - 41:600 Account deleted: illustration, "This isn't goodbye", redirect toast.
- **Typography:** geometric sans, likely Inter or a custom Nykaa grotesk, weights 400 to 800. Hub titles very large (about 32 px bold "Categories", "Shop" on 41:618, 41:619). Section titles 18 px, card text 13 px, captions 11 px. Store pages mix in a purple script word ("Curated By You" 41:613), italic serif ("What's Your Self-Care Goal?" 41:624) and tracked UPPERCASE eyebrows (LUXURY 41:614). Prices bold, strike in grey, % off in green-teal.
- **Colour:** fuchsia #E80071 primary on buttons, links and tabs. Deep magenta #A3004F onboarding ground. A pink tint ramp from #FDEFF5 to #F7C6DA for hub rows (41:619). Lavender #E7DDFB (games, appliance band). Navy text #1E2A3B. Coral-red #E5294F on the empty wishlist button (41:605), which clashes with the fuchsia. Each sub-store brings its own accent (teal #0E4A5C men, purple #7B2CBF gifts, yellow #EEEA6A wellness). Light theme, gradients common on heroes.
- **Layout and spacing:** 16 px gutters. Hubs are calm and roomy; home and listing are dense. Radius 8 to 12 px. Few shadows, tinted fills do the separating. Round thumbnails for categories, square product images on grey. Section titles carry a pink "Explore all" link on the right and often a subline beneath.
- **Section designs:**
  - Login and OTP: login as a bottom sheet over an onboarding carousel (41:633, 41:632).
  - Home header: wordmark, membership script, bell, heart, bag (41:631).
  - Search bar: rotating keyword in pink ("Search for Serums") (41:631, 41:610).
  - Category tiles: monochrome pink rows with 3D renders (41:618); stacked rows with three round thumbs (41:619).
  - Hero banner: big warm hero card with a peek of the next card (41:631).
  - Offers and coupons: ticket-notch coupon strip (41:615, 41:631); countdown deals (41:631).
  - Filters and sort: emoji quick-filter chips (Price Drop, Bestseller, Most Gifted) plus sticky split Sort / Filter bar with captions (41:615).
  - Listing card: square image on grey, brand bold, two-line name, size, price, heart-plus square, pink Add to bag (41:612).
  - Editorial and stories: Luxe framed edit card with underlined "View the collection" (41:616); wellness goal cards with a yellow caption band (41:624).
  - Other (tool entry): Skin Analyser card "Let our Skin Analyser guide you" (41:629).
  - Other (brand storefront): brand-coloured band and video hero inside the app (41:608).
  - Video: Play hub with livestream schedule date pill (41:610).
  - Wallet and rewards: wallet tabs and benefits grid (41:606); game zone (41:609).
  - Empty state: wishlist empty with notification nudge (41:605); account deleted (41:600).
  - Profile: settings rows with title and subline (41:604).
  - Other (account deletion): loss list, reasons, OTP, goodbye (41:603, 41:602, 41:601, 41:600).
- **Strengths:**
  - One colour family carries the brand through busy hubs. Pink rows deepen as you go down (41:619) and the 3D renders are tinted pink too (41:618). The best example in the group of identity without a single banner.
  - Store pages share one template (41:627, 41:628, 41:629, 41:630), so twelve stores feel like one app while imagery changes.
  - Luxe (41:616) proves the same app can go calm and editorial: framed photo, serif feel, an airplane doodle line and postmark marks. It is also a "travel beauty" edit.
  - Goal-led entry "What's your self-care goal?" (41:624) and the Skin Analyser card (41:629) let users start from a need, not a product.
  - Account deletion is honest and complete, with reasons and a kind goodbye (41:603 to 41:600).
- **Weaknesses:**
  - Delete account uses the brand fuchsia (41:603). The brand's main action colour is spent on a destructive act. Error prevention.
  - Home (41:631) stacks a ticker, tiles, chips, hero, coupon and countdown above the fold. Aesthetic and minimalist design.
  - Subtitles under nearly every store section title (41:627, 41:623). Adds noise, and we ban this.
  - Empty wishlist button is coral-red #E5294F, not fuchsia (41:605). Consistency and standards.
  - Game zone and "Click to win" (41:609) feel like a different app.
  - Quick filter chips use emoji (41:615), which look cheap next to the 3D renders.
- **Scores:** visual polish 4, clarity 3, information density 3, trust 4, brand distinctiveness 5.
- **For 30 Sundays:**
  - Borrow: the single-hue tint ramp for stacked rows (41:619) for our destination list or wishlist folders, in cream to coastalMist. The shared store template (41:627 to 41:630) as the model for every destination page. The Luxe edit card (41:616) for a Sunday School or story entry on home. Goal-first entry (41:624) for the wizard's first step ("What kind of trip?").
  - Avoid: fuchsia on destructive actions, subtitles under section titles, emoji chips, a home that stacks six promo types.

---

### Mamaearth (personal care, 25 screens)

- **Flows covered:**
  - 41:639 Login: forest aerial photo, phone field, Continue.
  - 41:638 Create account: cashback coin illustration, masked phone, name, email, gender, date of birth, referral code.
  - 41:641 Profile logged out: "Hey There", outlined Login button.
  - 41:640 Profile logged out with a poll bottom sheet ("Which ingredient will give you soft hair?").
  - 41:637 Profile logged in: script "Hey" over bold name, shortcut pills, list rows.
  - 41:636 Edit details form with a trust footer (COD, free shipping, four certification seals).
  - 41:635 Plant Goodness: trees planted counter, forest photo, Shop now.
  - 41:643 All categories, Products tab: colour-coded gradient rows with lifestyle photos.
  - 41:644 All categories, Ingredients tab: same rows, browse by ingredient.
  - 41:642 All offers: script "All", payday banner, countdown boxes, bestseller grid.
  - 41:658 Flash sale, default tab.
  - 41:659 Flash sale, same tab seconds later (near duplicate).
  - 41:655 Flash sale, Rice tab: ingredient tab rail, editorial video card, product rail, free-shipping nudge.
  - 41:656 Vitamin C tab.
  - 41:645 Body tab (countdown flags, no editorial card).
  - 41:646 Perfumes tab (editorial video failed, black block).
  - 41:647 Combos tab.
  - 41:648 Top kits tab ("5.0 1 Reviews").
  - 41:649 Baby tab (celebrity ad still).
  - 41:657 Best sellers tab.
  - 41:650 Hair tab.
  - 41:651 Lipsticks tab (helper line copied from the Face tab, "17 Shades" chip).
  - 41:652 New launch tab.
  - 41:653 Face tab ("Glow Naturally").
  - 41:654 Sunscreen tab ("The Power of Vitamin C").
- **Typography:** geometric sans, likely Poppins or Montserrat, weights 400 to 700. Page titles 20 px, card names 14 px semibold, body 12 to 13 px. One word in a yellow handwriting script leads a bold sans word ("Hey" diya 41:637, "Flash" Sale 41:655, "All" Offers 41:642). Tabs in UPPERCASE (INGREDIENTS / PRODUCTS 41:643). Prices bold, strike grey, % off in red.
- **Colour:** cyan #00AEEF primary (buttons, tabs, active nav). Yellow script #F2B705. Red #E53935 for flags and % off. Purple #7E57C2 countdown flags. Green #2E9E5B for the free-shipping nudge. Category rows each get their own gradient (cyan, purple, amber, red, green) (41:643). Grey #F2F2F2 bands. Light theme. Three to four accents per sale screen.
- **Layout and spacing:** 16 px gutters, dense on sale pages, roomy on profile. Card radius 8 px with hairline borders. Product cards carry a grey "For all skins" band above the name. Sections split by grey bands and tab rails.
- **Section designs:**
  - Login and OTP: nature photo top, single field (41:639).
  - Profile: script greeting plus 2 x 2 shortcut pills plus rows (41:637).
  - Trust and proof: certification seal footer (41:636); trees planted counter (41:635).
  - Category tiles: full-width gradient rows with photo and two-line benefit (41:643).
  - Other (browse by ingredient): same catalogue reached by ingredient (41:644).
  - Editorial and stories: video still with title and one line, placed before the product rail it explains (41:655, 41:653).
  - Card rail: product rail with progress bar and "View all 10 Rice products" (41:655).
  - Listing card: flag, skin-type band, type chip, name, tagline, rating with count, size, price, full-width Add to cart (41:655).
  - Offers and coupons: countdown boxes "Offer will expire in" (41:642); countdown flags on cards (41:645).
  - Progress and status: free-shipping threshold nudge pinned at the bottom (41:655).
  - Social and community: poll bottom sheet (41:640).
- **Strengths:**
  - Two ways into one catalogue: by product and by ingredient (41:643, 41:644). Recognition rather than recall for people who know the "why" but not the "what".
  - Editorial card before the rail it introduces (41:655, 41:653): a story frames the products.
  - Script-word greeting (41:637) gives a lot of personality for one word of type.
  - Impact page (41:635) turns brand values into a number with a calm photo.
- **Weaknesses:**
  - Countdown timers and "B3P2" flags on most cards (41:642, 41:645, 41:647). False urgency and noise.
  - Perfume tab's editorial video fails to a solid black block (41:646). No fallback image. Error recovery.
  - Lipsticks tab shows the Face tab's helper line (41:651). Copy bug.
  - "5.0 1 Reviews" (41:648, 41:652): wrong plural and weak proof shown proudly.
  - "B3p2" vs "B3P2" casing (41:658 vs 41:642). Consistency.
  - Poll sheet interrupts the logged-out profile (41:640). User control.
  - Trees counter 1093966 has no thousands separator (41:635).
- **Scores:** visual polish 3, clarity 3, information density 2, trust 3, brand distinctiveness 4.
- **For 30 Sundays:**
  - Borrow: the script-word-plus-sans greeting (41:637) for home and profile, with our handwriting face. Browse by "why" (41:644) for a destination finder by trip mood. The editorial card leading a rail (41:655) for a destination page section ("Why Bali in July" then the itineraries).
  - Avoid: countdowns, deal flags on every card, unhandled video failures, review counts of 1 shown as proof.

---

### Lenskart (eyewear, 21 screens)

- **Flows covered:**
  - 41:681 Login: two models hero, Skip, phone sheet, Get OTP, Login via WhatsApp.
  - 41:680 Verify OTP: single field, "Auto verifying OTP, retry in 27 seconds".
  - 41:679 Tell us about yourself: first name, last name, email, gender, age group toggle, success toast.
  - 41:678 Face scan intro: "Every face is unique", faded portrait in scan corners, "Trusted by 10L+ Indians".
  - 41:677 Add your face: camera permission over a dark scanner frame.
  - 41:676 Home: avatar, delivery promise and pincode, Gold Max badge, search with scan, camera and AI stylist, Hustlr Club hero, smartglasses waitlist, Eyeglasses and Sunglasses tiles.
  - 41:666 Women's eyeglasses bottom sheet: four frame-shape tiles, View all shapes, WhatsApp expert help.
  - 41:665 Listing, All tab: AI match card, "100% match" badge.
  - 41:664 Listing, Essential tab.
  - 41:663 Listing, Premium tab (EMI chip).
  - 41:662 Listing, Sale tab: measure banner, big single-column card, sticky Sort / Filter / View bar.
  - 41:671 AI stylist intro: "Your perfect frame is waiting", portrait with spoken prompt, language picker, mic button.
  - 41:674 Eye test at home service detail: photo hero with overlay headline, price, rating, eligibility checklist, Book appointment.
  - 41:675 Find nearby stores: search, theme chips, store cards with distance and Book free eye test.
  - 41:661 Stores tab: benefits tiles, "How to buy your glasses" guide rail.
  - 41:669 Next day delivery location page.
  - 41:673 Add delivery address on a map.
  - 41:667 Wishlist empty: Wishlist / Recently viewed tabs.
  - 41:668 Cart empty with WhatsApp help.
  - 41:672 My orders empty.
  - 41:670 My profile: completion ring, Gold band, shortcut tiles, "My Eyes" data card.
- **Typography:** geometric grotesk close to Plus Jakarta Sans, weights 400 to 800. Display about 26 px heavy ("Your perfect frame is waiting" 41:671), overlay headline about 40 px two weights ("Need an / Eye Test?" 41:674). Section titles 18 px bold navy, body 14 px, captions 11 px. Tabs in tracked UPPERCASE (WISHLIST / RECENTLY VIEWED 41:667). Prices bold with "including lenses" in regular grey beside them (41:662), strike and % off in blue.
- **Colour:** navy #000042 primary on buttons, text and nav. Green #0F7A5A secondary for tools (Measure face width, Try in AR) and the delivery promise. Mint #B8F1DE as the illustration accent across every empty state. Orange #F04E23 reserved for the AI stylist (41:671). Gold gradient for the membership word "GOLD" (41:681). Lavender-grey ground #F5F5FA. Blue #3366CC for discount text. Light theme with dark navy hero cards. Two accents per screen, rarely more.
- **Layout and spacing:** 16 px gutters, generous white space. Radius 12 to 16 px. Soft shadows on store cards, grey fills on tiles. Listing uses one product per row with a large image (41:662). Sections separated by white space only. Sticky bottom actions sit on a white tray with a rounded top.
- **Section designs:**
  - Login and OTP: hero photo with login sheet, WhatsApp login alternative (41:681); auto-verify line with retry timer (41:680).
  - Onboarding: face scan promise with social proof laurel (41:678).
  - Home header: avatar, delivery promise, pincode, membership badge, heart, bag (41:676).
  - Search bar: search plus scan plus camera plus AI tile (41:676).
  - Hero banner: dark navy club hero with a mint "Limited spots" chip (41:676).
  - Category tiles: people wearing the product (Men, Women, Kids) plus a price-from tile (41:676); frame-shape picker sheet (41:666).
  - Listing card: big image, rating chip, heart, image dots, View similar, swatches, frame width box, measure tool, price with what is included, Try in AR, delivery chip (41:662).
  - Filters and sort: icon segment tabs (41:662); sticky tri-bar Sort / Filter / View with state captions (41:662).
  - Detail hero: photo with large overlay headline (41:674).
  - Inclusions list: eligibility checklist with mint ticks (41:674).
  - Sticky CTA bar: one navy Book appointment (41:674).
  - Map: store finder (41:675); address pin with Locate me (41:673).
  - Trust and proof: store benefits tiles (41:661); "Trusted by 10L+ Indians" (41:678).
  - Editorial and stories: "How to buy your glasses" navy guide cards with tag chips (41:661).
  - Other (AI assistant): voice stylist with 11 languages (41:671); AI match card (41:665).
  - Empty state: one illustration family across wishlist, cart and orders (41:667, 41:668, 41:672).
  - Profile: completion ring, membership band, "My Eyes" saved data card (41:670).
  - Help and chat: WhatsApp help row in sheets and empty cart (41:666, 41:668).
- **Strengths:**
  - The eye test service page (41:674) is the cleanest detail page in the group: photo, overlay headline, title, provider line, price, rating with count, a short checklist and one CTA. It is a service sold like a product, which is what a trip is.
  - Listing card states what the price includes ("800 including lenses") (41:662). Match between system and real world.
  - Filter bar always shows current state (Recommended, 0 Applied, Tile view) (41:662).
  - Guide rail on the stores tab (41:661) puts education next to the purchase.
  - Consistent illustration style and mint accent make every empty state feel on-brand (41:667, 41:668, 41:672).
  - Profile "My Eyes" card (41:670) stores the user's own data (powers, frame size, saved try-ons). A model for saved traveller details.
- **Weaknesses:**
  - Six-item bottom nav (41:661, 41:676). Too many targets; labels shrink.
  - Empty orders copy is filler ("Experience style elevation and enhanced vision") (41:672).
  - Skip on the OTP screen (41:680) is unclear: skip what?
  - Gender asked at sign-up with Male pre-selected (41:679).
  - Store filter chips named after themes (Superman, Harry Potter) without explanation (41:675). Recognition over recall.
  - Detail of an actual frame is missing from the set, so the gallery cannot be judged.
- **Scores:** visual polish 5, clarity 4, information density 4, trust 4, brand distinctiveness 4.
- **For 30 Sundays:**
  - Borrow: the eye test service page (41:674) as the skeleton for an itinerary top (hero photo with two-weight headline, name, "planned by" line, price from, rating, "good to know" checklist, one fuchsia CTA). The "including lenses" price phrasing for "including flights and stays". The guide rail (41:661) for Sunday School cards on a destination page. The "My Eyes" card (41:670) for a "My travel details" card on profile (passports, preferences). The tri-bar with captions for any filtered list.
  - Avoid: a six-tab nav, filler empty-state copy, a pre-selected gender.

---
### Myntra (fashion, 23 screens)

- **Flows covered:**
  - 41:689 Onboarding story: progress bars, close, photo card, "Fashion for Everyone, Every Occasion", "Get Flat 300 Off / Sign Up".
  - 41:690 Login: gift illustration, "Enjoy 500 off on your first order", phone field, 18+ consent checkbox, Continue.
  - 41:704 Login with keyboard and floating label.
  - 41:691 Verify OTP: 4 boxes, auto-fill timer, OTP on WhatsApp, password option, server error toast.
  - 41:692 Home, All tab: deliver-to, rotating search keyword, folder-style gender tabs, category row, code strip, sale hero, brand strips, bank strip.
  - 41:693 Home, Men tab (blue tint).
  - 41:694 Home, Women tab (pink tint).
  - 41:695 Home, Kids tab (cream tint).
  - 41:702 Search: popular trends with thumbnails, filter chips, image search and camera search.
  - 41:696 FWD sub-app home, Women: gradient ground, store tiles with "Starting 129", festival hero.
  - 41:697 FWD home, Men.
  - 41:698 FWD Trending: "What's HOT This Month", trend cards with sticker labels.
  - 41:700 Trends lookbook: tinted bands, bento collage with prices, View 28 products.
  - 41:699 Minis: full-screen shoppable video with product chips.
  - 41:688 FWD beauty: launch hero, brand banner, "Skin HEROES".
  - 41:683 FWD listing, accessories: pincode band, quick chips, multi-select category circles, offer split banner, 2-column grid, floating Gender / Sort / Filter pill.
  - 41:684 FWD listing, footwear.
  - 41:685 FWD listing, men.
  - 41:686 FWD listing, women (swatch dots).
  - 41:687 FWD listing, ethnic (offer banner failed, white gap).
  - 41:701 Shopping bag empty.
  - 41:703 Notifications empty.
  - 41:705 My profile logged out.
- **Typography:** humanist sans, likely Assistant (Myntra's long-time face), weights 400 to 800. Hero and edit headlines in heavy display caps with mixed sizes ("What's HOT This Month" 41:698, "Skin HEROES" 41:688). Section titles 18 px bold, card titles 13 px, captions 11 px. Many labels in tracked UPPERCASE (SORT, FILTER, SHOPPING BAG, NO NOTIFICATIONS). Price shows three numbers: green "Best price with coupon", grey strike, black price, then orange % off (41:683).
- **Colour:** Myntra pink #FF3F6C (buttons, links, active tab). Teal #14958F rating stars. Green #03A685 best price. Orange #FF905A % off. FWD yellow #FFE11B sub-brand. Purple #6A3FD6 "Just launched" ribbon. Lavender #F0EBFF pincode band. Home tabs tint the whole header (peach, blue, pink, cream) (41:692 to 41:695). Sale heroes bring gold, red and neon. Light theme. Five or more accents fight on home.
- **Layout and spacing:** 12 to 16 px gutters; listing images run almost edge to edge in 2 columns at about 3:4. Radius 8 px on cards, pills fully round. Little shadow except the floating filter pill. Sections on home separated by banner strips, not space.
- **Section designs:**
  - Onboarding: story-style progress bars over a photo card (41:689).
  - Login and OTP: offer-led login with a consent checkbox (41:690); WhatsApp OTP and password fallback (41:691).
  - Home header: deliver-to, search with mic and camera, bell, heart, profile (41:692).
  - Other (segment tabs): folder-shaped gender tabs that re-tint the header (41:692 to 41:695).
  - Hero banner: celebrity sale hero with 10 dots (41:692); framed hero with brand logo footer and Shop now (41:693).
  - Offers and coupons: code strip "USE CODE" (41:692); split offer banner with dashed code (41:683).
  - Category tiles: round photo row with pink tick for selected (multi-select) (41:683).
  - Filters and sort: quick chips with icons (41:683); floating Gender / Sort / Filter pill with a red dot when applied (41:683); search filter chips (41:702).
  - Listing card: image with rating pill, AD tag, heart beside the title, deal label, three-price stack, sub-brand chip (41:683).
  - Editorial and stories: trend cards with tilted sticker labels (COLOUR, MOOD) (41:698); lookbook bento with prices on images and "View 28 products" (41:700).
  - Video: shoppable vertical video with like, share, save and product chips (41:699).
  - Bottom nav: sub-brand wordmarks as tabs with promise sublines (Under 999, From 30 min) (41:692); FWD gets its own nav (41:696).
  - Empty state: bag empty (41:701); notifications empty with pastel skeleton cards (41:703).
  - Profile: logged-out list and one Log in button (41:705).
- **Strengths:**
  - Lookbook bento (41:700): one theme title, one big image and four small, prices on the photos, then a single "View 28 products". Editorial and shoppable at once.
  - Trend cards with sticker labels (41:698) name the theme in one word before the headline.
  - Header tint follows the selected tab (41:692 to 41:695), so the user always knows where they are without a heading.
  - Floating filter pill with a dot for "applied" (41:683) keeps state visible while scrolling.
  - Notifications empty state (41:703) shows what will arrive with pastel skeleton cards. Clear and light.
- **Weaknesses:**
  - Home (41:692) stacks a code strip, celebrity hero, two brand strips, a bank strip and a sponsored "Brand of the day". Aesthetic and minimalist design.
  - Three prices per card (41:683): best price with coupon, strike, price. Hard to know what you will pay.
  - Bag empty has no button back to shopping (41:701). User control and freedom.
  - Offer banner fails to a blank white gap (41:687).
  - Sticker labels and sale heroes use 6 to 8 colours on one screen (41:696, 41:698).
  - Onboarding CTA is a discount, not a reason (41:689).
- **Scores:** visual polish 4, clarity 3, information density 2, trust 3, brand distinctiveness 4.
- **For 30 Sundays:**
  - Borrow: the lookbook bento (41:700) for a destination page "Ways to do Bali" section (one theme, one hero, four small images with price-from, one "See 6 itineraries"). Sticker-labelled trend cards (41:698) for home edits by mood, using a goldenHour outline label, not a solid pill. Header tint by tab (41:692) for wishlist folders. Shoppable video (41:699) for Sunday School and community clips that link to an itinerary.
  - Avoid: three-price stacks, empty states without a way back, sale-hero colour overload.

---

### Flipkart (marketplace and super-app, 25 screens)

- **Flows covered:**
  - 41:731 Onboarding step 1: language picker with native script tiles.
  - 41:730 Step 2: login with a 3-step stepper (Language, Login, Welcome).
  - 41:729 OTP with underline slots and timer.
  - 41:728 Minutes home, For You: blue theme, location updated toast, sale hero, category tiles.
  - 41:727 Minutes, Fresh tab: magenta theme, featured photo picks, deal rail.
  - 41:726 Minutes, Grocery tab.
  - 41:725 Minutes, Beauty tab.
  - 41:724 Minutes, Pharmacy tab: "Order prescription medicine in 3 steps", shop by needs.
  - 41:723 Minutes, Home tab.
  - 41:722 Minutes, Summer tab: pool-water ground, arch tiles, sponsor line.
  - 41:721 Minutes, Deal zone.
  - 41:720 Minutes, XtraSaver tab.
  - 41:719 Minutes, Kids tab: cloud-shaped featured cards.
  - 41:718 Minutes, Healthcare tab.
  - 41:717 Minutes, Mobiles tab: phone hero, brand tiles.
  - 41:716 Minutes, Electronics tab.
  - 41:715 Minutes, Fashion tab: "Get your travel essentials now" hero.
  - 41:714 Minutes, Gifting tab: occasion bento.
  - 41:713 Minutes, Paan store (tobacco redirect notice).
  - 41:707 XtraSaver Grocery home: brown theme.
  - 41:708 Travel home: Flights, Hotels, Buses tiles, My trips, flash sale with countdown.
  - 41:712 Play: dark video feed, story circles, creator programme banner.
  - 41:711 All categories: left rail, store tiles, launches with Notify me.
  - 41:709 Cart empty with Flipkart / Minutes segment.
  - 41:710 Account: Black membership card, 2 x 2 shortcuts, email nudge, finance offers.
- **Typography:** neo-grotesk, likely Inter, weights 400 to 800. Sub-app titles in heavy italics inside the switcher tiles. Section titles 18 px bold, tile labels 12 px, captions 10 to 11 px. Sentence case almost everywhere. Discount shown as a green tab with a down arrow ("↓36%") on the image corner, price bold, strike grey (41:707).
- **Colour:** Flipkart blue #2A55E5 (main app, buttons, active nav), yellow #FFE500 logo. Each sub-app has its own ground: Minutes magenta #9C1557 with pink gradient (41:727), Grocery brown #6B2F0F with butter yellow (41:707), Travel sky blue (41:708). Green #1F7A3B discount tabs and rating stars. Theme also shifts per Minutes tab (blue For You 41:728, teal Summer 41:722, yellow XtraSaver 41:720). Light theme except Play, which is black (41:712). Heavy gradients and 3D renders.
- **Layout and spacing:** 16 px gutters, high density. Radius 12 to 16 px. Product rails sit inside tinted rounded bands (green, blue, yellow). Tiles are 3D renders on tinted squares. Sections separated by those bands.
- **Section designs:**
  - Onboarding: language first with large native glyph tiles (41:731); 3-step stepper header (41:730).
  - Login and OTP: underline OTP slots with timer (41:729).
  - Other (super-app switcher): four sub-app tiles at the top, active tile filled (41:707, 41:727).
  - Home header: address row with "8 min" promise chip (41:727).
  - Category tiles: icon tabs with underline (41:727); arch-shaped tiles with caption bands (41:722); occasion bento (Birthday, Anniversary, Wedding) (41:714); shop by needs photos (41:724).
  - Card rail: product rail inside a tinted band with a round arrow (41:707, 41:721).
  - Listing card: discount tab, rating chip, add button on image, size chip, locked member price row (41:707).
  - Editorial and stories: featured picks with seasonal captions ("The mango season!") (41:727).
  - Other (how it works): three icons with chevrons (41:724).
  - Hero banner: sale heroes (41:716, 41:728).
  - Offers and coupons: bank offer pill rail (41:716); flash sale time slots and countdown (41:708).
  - Video: dark creator feed with view counts (41:712).
  - Bookings list: "My trips" row on the travel home (41:708).
  - Profile: phone number header, membership upsell, shortcuts, finance list (41:710).
  - Empty state: cart with sub-app segment (41:709).
- **Strengths:**
  - Sub-app identity by ground colour (magenta, brown, blue) while the frame, nav and cards stay identical (41:727, 41:707, 41:708). Clear wayfinding inside a very busy product.
  - Occasion bento (41:714) and shop-by-need tiles (41:724) let users start from a life moment.
  - Three-step "how it works" strip (41:724) explains a new service in one line.
  - Language step with native glyphs (41:731) is warm and inclusive.
  - Summer tab (41:722) shows a seasonal takeover done with one texture and arch shapes.
- **Weaknesses:**
  - Account page leads with loans, EMI and credit cards (41:710). Cross-sell where users expect their own data.
  - Theme changes on every tab (41:728 vs 41:727 vs 41:720). The user loses the anchor. Consistency.
  - Countdown with seconds on travel deals (41:708). False urgency on a considered purchase.
  - Captions truncate ("Step into comf...") (41:723).
  - Tobacco redirect banner (41:713) in a family shopping app.
  - Travel home is a list of discounts ("Up to 65% Off") with no inspiration (41:708).
- **Scores:** visual polish 4, clarity 3, information density 2, trust 3, brand distinctiveness 3.
- **For 30 Sundays:**
  - Borrow: the occasion bento (41:714) for a "Trips for" grid (birthday, anniversary, first trip abroad, with parents). The three-step strip (41:724) for "How we plan your trip" on the wizard intro. The language-style glyph tiles (41:731) as a pattern for destination picker tiles with a big initial or flag. Arch tiles (41:722) echo travel windows and suit our soft brand.
  - Avoid: finance cross-sell on profile, per-tab theme changes, second-level countdowns, discount-only travel tiles.

---

### Meesho (value marketplace, 36 screens)

- **Flows covered:**
  - 41:768 Choose language: 2-column glyph tiles, translation disclaimer.
  - 41:767 Onboarding 1/2: select gender with illustrated avatars, product collage above.
  - 41:766 Onboarding 2/2: select age, list options with pink left bar.
  - 41:765 Home: "Hello, Let's shop!", search, trust strip, price-on-image collage, category circles, sticky Sort / Category / Gender / Filters bar, mic button.
  - 41:748 Seven-day easy returns sheet: green vertical timeline.
  - 41:746 Gender quick sheet with round portraits.
  - 41:747 Category quick sheet (checkbox list).
  - 41:745 Filters, Category (searchable list).
  - 41:744 Filters, Gender pills.
  - 41:743 Filters, Color pills (text only).
  - 41:742 Filters, Fabric checklist.
  - 41:741 Filters, Size (searchable, mixed units).
  - 41:740 Filters, Price range pills.
  - 41:739 Filters, Rating thresholds and M-Trusted.
  - 41:738 Filters, Occasion (one option).
  - 41:737 Filters, Combo pack sizes.
  - 41:736 Filters, Meesho Mall (one option).
  - 41:735 Filters, Material.
  - 41:749 Search empty with floating Speak button.
  - 41:734 Google voice search overlay.
  - 41:764 Categories, Popular.
  - 41:757 Categories, Kurti, Saree and Lehenga.
  - 41:756 Categories, Women Western.
  - 41:755 Categories, Kids and Toys.
  - 41:754 Categories, Jewellery.
  - 41:753 Categories, Electronics.
  - 41:752 Categories, Car and Motorbike.
  - 41:751 Categories, Books.
  - 41:750 Categories, Pet supplies and Musical instruments.
  - 41:763 Sign-up sheet with Android phone hint picker.
  - 41:758 Account (no nav visible).
  - 41:761 Account with bottom nav.
  - 41:733 Edit profile: tabs, avatar, underline fields.
  - 41:759 My products: Wishlist / Shared / Viewed, empty wishlist.
  - 41:760 Cart empty.
  - 41:762 My orders empty with search and filters.
- **Typography:** geometric sans, likely Mier (Meesho's own face), weights 400 to 700. Page titles in small tracked UPPERCASE (CATEGORIES, ACCOUNT, MY ORDERS, FILTERS). Section titles 18 px semibold, body 14 px, labels 12 px. Category section eyebrows in grey caps with a hairline rule (BOOKS, PET SUPPLIES) (41:751). Prices bold white on dark image gradients on home (41:765).
- **Colour:** purple-magenta #9F2089 primary (buttons, active rail, links). Lavender #ECEAF6 rail and tints. Green #038D63 timeline and balance chip. Pink #F49AC1 accents in illustrations. Text #353543, greys #8B8BA3. Light theme. Usually one accent per screen. Illustrations use pastel blue and pink.
- **Layout and spacing:** 16 px gutters. Utility screens are sparse and clean; home is dense. Radius 4 to 8 px on cards, fully round pills. Borders over shadows. Category pages use a left rail plus a 3-column grid of round thumbnails. Sections split by eyebrow plus hairline.
- **Section designs:**
  - Onboarding: language glyph tiles (41:768); gender and age as one-tap cards with a 1/2 counter (41:767, 41:766).
  - Login and OTP: system phone-number hint over the sign-up sheet (41:763).
  - Home header: greeting with a namaste avatar (41:765).
  - Trust and proof: three-up strip (7 days easy return, Cash on delivery, Lowest price) (41:765).
  - Other (policy explainer): returns as a three-step vertical timeline with spot illustrations (41:748).
  - Filters and sort: two-pane filter with left facets, right options, live "1000+ Products" count and Done (41:735); quick sheets from the sort bar (41:746, 41:747); sticky four-part sort bar (41:765).
  - Category tiles: left rail plus eyebrow-titled 3-column thumbnail grids (41:751, 41:764).
  - Listing card: price-on-image collage tiles (41:765).
  - Search bar: keyword or product ID, voice and camera (41:749, 41:734).
  - Profile: avatar, help and language tiles, grouped rows (My payments, My activity, Others) (41:758); edit profile tabs (41:733).
  - Empty state: wishlist that teaches the heart tap (41:759); cart (41:760); orders with search and filters still present (41:762).
- **Strengths:**
  - Returns timeline sheet (41:748): three steps, each a card with a picture, one green line joining them, one button. The clearest policy explainer in the group.
  - Two-pane filter with a live result count (41:735) prevents empty results. Visibility of system status.
  - Wishlist empty (41:759) tells you exactly how to add ("Just tap on the heart") with the glyph inline, and tabs for Shared and Viewed.
  - Account groups rows by purpose (41:758), with Help and Language as the two big tiles.
  - One accent per utility screen; calm and readable.
- **Weaknesses:**
  - Size filter sorts as text, so "10" comes before "2 meters" and units mix (41:741). Match between system and real world.
  - Price ranges overlap ("Under 299" and "250 to 299") (41:740).
  - Colour filter has no swatches and lists "Skin" twice (41:743).
  - Facets with one option (Occasion "Festive" 41:738, Mall "Mall Brands" 41:736) and the misspelling "Occassion".
  - "4.0 And Above" vs "3.5 and above" casing (41:739).
  - Bottom nav has 4 items on 41:751 and 5 on 41:764. Consistency.
  - Home collage (41:765) shows only prices on images, no names. Recognition is hard.
- **Scores:** visual polish 3, clarity 4, information density 3, trust 4, brand distinctiveness 3.
- **For 30 Sundays:**
  - Borrow: the returns timeline (41:748) for cancellation and refund rules on the itinerary and booked trip ("Free changes until 30 days", "50% back until 15 days", "Help on trip 24x7"), in lagoonBliss. The live result count in filters (41:735) for a destination or itinerary filter. The wishlist empty copy pattern (41:759) for our wishlist. Grouped account rows (41:758) for profile.
  - Avoid: text-sorted numeric options, overlapping ranges, single-option facets, colour filters without swatches.

---

### Group summary

**Patterns that repeat, by component kind**
- Login and OTP: phone first with +91, often as a bottom sheet over a photo or carousel (Nykaa 41:633, Lenskart 41:681, Myntra 41:690). WhatsApp as an OTP or login alternative (Lenskart 41:681, Myntra 41:691). Auto-fill timers everywhere. Skip is offered by most.
- Onboarding: language first in the mass-market apps with native glyph tiles (Flipkart 41:731, Meesho 41:768). One-tap personal questions with a step counter (Meesho 41:767).
- Home header: deliver-to or pincode row, rotating search keyword in quotes, voice and camera in the search bar (Myntra 41:692, Nykaa 41:631, Lenskart 41:676).
- Category tiles: round photo thumbnails in a scroll row; left rail plus grid for full catalogues (Flipkart 41:711, Meesho 41:751).
- Filters and sort: a sticky bar of two to four controls, each with a small caption showing its state (Pepperfry 22:51, Nykaa 41:615, Lenskart 41:662), or a floating pill with a dot when applied (Myntra 41:683). Full filters as a two-pane sheet (Meesho 41:735) or side drawer (Pepperfry 22:49).
- Listing card: image, rating chip on the image, heart on the corner or beside the title, deal label, struck MRP plus price plus % off. The price stack grows to three numbers in coupon-heavy apps (Myntra 41:683).
- Offers and coupons: countdown timers and coupon strips are everywhere (Mamaearth 41:642, Nykaa 41:631, Flipkart 41:708). This is the group's main source of clutter.
- Editorial and stories: every fashion or beauty app has an edit layer (Nykaa Luxe 41:616, Myntra Trends 41:698 and 41:700, Mamaearth editorial cards 41:655), and three have video feeds (Nykaa Play 41:610, Myntra Minis 41:699, Flipkart Play 41:712).
- Empty state: one consistent illustration family per app (Lenskart 41:667, Meesho 41:759). The better ones teach the next action.
- Brand identity in busy layouts is carried by four things, not by logos: a single colour family that tints grounds and rows (Nykaa 41:619), a display or script face used for one word only (Mamaearth 41:637, Pepperfry 22:57), a fixed illustration style for empty states (Lenskart), and ground colour per sub-brand with an unchanged frame (Flipkart 41:727 vs 41:707).
- Wishlists: always a heart, never folders. Wishlist sits beside "Recently viewed" or "Shared" as tabs (Lenskart 41:667, Meesho 41:759). No app here shows a filled wishlist.
- Reviews and ratings: only star chips and counts; no review page or photo reviews in this group.

**The 5 best section designs for a travel app like ours (ranked)**
1. Lenskart service detail, 41:674 (Detail hero, Inclusions list, Sticky CTA bar). Hero photo with a two-weight overlay headline, then name, "by certified professionals", price, rating with count, a short tick list and one CTA. A ready skeleton for the top of an itinerary or destination page.
2. Meesho returns timeline, 41:748 (Trust and proof, Itinerary and timeline). Three steps joined by one line, each with a picture. Turns a policy into something people read. Use for cancellation, payment schedule and "what happens after you book".
3. Myntra lookbook bento, 41:700 (Editorial and stories). One theme title, one large and four small images with prices on them, one "View 28 products". Maps directly to "Ways to do Bali" on a destination page or mood edits on home.
4. Mamaearth browse by ingredient with an editorial lead card, 41:644 and 41:655 (Category tiles, Editorial and stories). Two doors into one catalogue and a story card before each rail. Use for "Find by mood" and a "Why go now" card ahead of itineraries.
5. Lenskart guide rail, 41:661 (Editorial and stories). Dark cards with a tag chip and big headline, placed on a transactional tab. Model for Sunday School cards inside the destination page and wizard.
Honourable mentions: Nykaa Luxe edit card 41:616 (calm editorial, travel motif), Nykaa tint-ramp rows 41:619 (identity through one hue), Flipkart occasion bento 41:714 and three-step strip 41:724, Meesho live-count filters 41:735, Myntra shoppable video 41:699.

**The 5 things to never copy**
1. Pepperfry "103 People Viewing This" on a 1.0-star product, with a help tag and call button floating over the CTA bar, which itself sits on the bottom nav (22:41, 22:51). FOMO, clutter and blocked targets in one screen.
2. Countdown timers and deal flags on most cards (Mamaearth 41:642, 41:645; Flipkart travel 41:708 with seconds). False urgency is wrong for a considered, high-value trip.
3. Nykaa's brand fuchsia on "Delete Account" (41:603). Our fuchsia means the one primary action; it must never mean "destroy".
4. Myntra home stacking a code strip, celebrity hero, two brand strips, a bank strip and a sponsored slot (41:692), plus three-price card stacks (41:683). Nobody can tell what they will pay.
5. Unhandled content and data bugs: raw "<br/>" in the payment address (Pepperfry 22:38, 22:39), black block for a failed video (Mamaearth 41:646), helper copy from the wrong tab (Mamaearth 41:651), text-sorted size filter (Meesho 41:741). Each one costs trust at the moment it matters most.
