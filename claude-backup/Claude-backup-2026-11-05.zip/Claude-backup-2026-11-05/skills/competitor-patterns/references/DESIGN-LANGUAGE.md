# DESIGN LANGUAGE: cross-app findings for 30 Sundays

Merged from the nine group reports in this folder. Node ids are Figma ids exactly as the reports cite them;
Scapia destination screens are cited by file name (IMG_3933 to IMG_3939). Sizes are approximate px at a
390 wide phone, as the reports estimated them. Hex values are estimates from screenshots.

---

## 1. Typography

### Typefaces seen

| Family (as identified) | Apps |
|---|---|
| Inter or an Inter-like grotesk | Cleartrip, OYO, Paytm, INDmoney, upGrad, cult.fit, Flipkart, CARS24, Housing.com, apna (Android), PharmEasy, Groww (close), Urban Company (close) |
| Roboto | BookMyShow, PhonePe, Khatabook, PolicyBazaar (body) |
| SF Pro (iOS system) | redBus, Yatra (native), Facebook groups, Rapido, Ola, 99acres |
| Poppins | EaseMyTrip, 30 Sundays today (141:22), 30 Sundays earlier build, Paisabazaar, Mamaearth, CarDekho (newer screens) |
| Gilroy or close | CRED, Swiggy, Physics Wallah, Stanza Living (Zepto close) |
| Own or named faces | Headout (Halyard), Blinkit and Zomato (Okra), BigBasket (Proxima Nova like), Myntra (Assistant), Lenskart (Plus Jakarta like), Meesho (Mier), Spinny (Jost like), ixigo (Google Sans like), Scapia (Lexend like) |
| Lato | Pepperfry, Yatra web pages (113:110), CarDekho older screens (41:863, 41:864) |
| Others | Magicbricks (Montserrat), Pristyn Care (Open Sans or Noto), NoBroker (Source Sans or Open Sans), Tata 1mg and Yatra chat (Figtree-like) |

Display faces, and the one job each does:
- Serif for the user's own words only: CRED sets the input itself in a 32 to 36 px serif (22:9, 22:6, 22:5) and never uses it in buttons or lists. The clearest model for our handwriting face.
- Book serif for place names: Scapia destination "Vietnam" at about 44 px and italic captions at 22 px (IMG_3933, IMG_3935).
- One script word beside sans: Mamaearth "Hey" over a bold name (41:637), Pepperfry's script in the splash lockup (22:57), Nykaa's script word inside headings (41:613).
- Italic second line: Stanza Living "Homey Comfort / Conveniently Yours!" (111:34); PharmEasy two-tone italic headline (35:172).
- Display numerals: Headout's heavy italic rank numerals, about 40 px, cutting into the photo (41:921).
- Brush script on splash only: Cleartrip "So, where to?" (35:130). Our handwriting face also appears only on the splash today (141:21).

What goes wrong with families:
- Three families in one app: Yatra (SF Pro, a Figtree-like chat face, Lato on web, 113:130, 113:135, 113:110).
- Two families across flows: CarDekho (Lato and Poppins).
- A third loud voice added later: CRED's wide extended caps (41:342, 41:341) beside its serif and sans.
- Per-store display styles: Blinkit (serif caps 41:278, rounded kids type 41:280, script 41:281), Zepto serif only on one tab (35:143).
- Our own drift: Poppins instead of Figtree, Light 300 for long review text (141:7).

### Size hierarchies that work

| App | Page title | Section title | Card title | Body | Caption |
|---|---|---|---|---|---|
| Cleartrip | 22 semibold (35:104) | 18 semibold | 22 to 24 hotel name (35:108) | 15 to 16 | 13 grey |
| Headout | 20 semibold (41:926) | 20 to 22 list item (41:921) | 16 semibold | 15 to 16, 1.6 line height (41:925) | 13 |
| redBus | 28 to 30 bold (113:90) | 22 bold | 18 bold times | 16 | 13 grey |
| Urban Company | 24 to 26 bold | 22 bold | 16 to 17 semibold | 15 to 16 | 13 grey |
| Scapia Hotels | 28 semibold hero (2014:20) | 18 semibold | 26 sheet title (2014:18) | 15 | 12 to 13 |
| cult.fit | 28 bold questions (41:833, 41:834) | 20 bold | 16 bold | 14 grey | 12 |
| CRED | 32 to 36 serif input | 22 serif headline | 18 to 20 sans title | 13 to 14 grey | 11 to 12 |

Patterns behind these:
- Big type goes to the one fact that matters: Zepto "6 minutes" (35:142), Paytm airport codes at about 30 px (41:397), Rapido's 40 px price and bold plate number (35:65, 35:63), cult.fit's 28 px human question (41:834).
- Caps micro-labels with wide tracking give structure without subtitles: CRED "YOUR MOBILE NUMBER" at 11 px (22:13), Zomato spaced caps 13 px with about 2 px tracking (41:350), Yatra labels above values (113:130), Meesho eyebrows with a hairline (41:751).
- Two-weight headline adds hierarchy without a subtitle: Paisabazaar (41:504), Lenskart "Need an / Eye Test?" (41:674).
- Case: sentence case reads calm (Scapia 2014:9, Headout, Facebook). Title Case on everything reads shouty (BookMyShow 41:431, ixigo 41:935, Physics Wallah 41:517). All-lowercase hurts names and scanning (CRED). Our app mixes Title Case and sentence case (141:6, 141:11).

### Number and price styling

Works:
- Rupee sign tight to the number, bold figure, light unit on the same baseline: Cleartrip (35:104), CRED "₹865" (41:340), our home "From ₹42,434/person" (141:22).
- "from" in lowercase grey, then the bold amount: Headout (41:921, 41:920).
- Say the unit once at the head of a list: OYO "Price per room per night" (41:843).
- Price says what it includes: Lenskart "including lenses" (41:662).
- Indian notation and words for big numbers: CARS24 "4.27 lakh" (41:588), PolicyBazaar "₹2 Crore", "₹50 lakh".
- Amount inside the final button: BookMyShow "Pay ₹460" (41:444); Rapido repeats the chosen price in the button (35:65).
- Dashed underline means "tap for breakup": Cleartrip total (35:104), Spinny EMI (41:887).
- Ranges with a reason: CARS24 (41:584), Spinny (41:888), CarDekho range bar (41:859).

Fails:
- Prices to the paisa: Zomato "₹184.24" (41:358).
- Inconsistent format inside one app: ours "₹ 3,57,000" on quotes vs "₹42,434" on home (141:14, 141:22).
- Machine numbers: "1.1h" (141:12); counter with no separator "1093966" (41:635).
- Price weaker than the name: Magicbricks regular-weight price (111:2), Scapia room "₹6,449 onwards" at body size (2014:9).
- Three numbers per price: Myntra coupon price, strike, price (41:683); BigBasket three prices on electronics (38:207).
- Counts that disagree: Scapia "1,543 ratings", "1.5k ratings", "84 reviews" (2014:20, 2014:9, 2014:7).

---

## 2. Colour

### Accent counts

One accent per screen, and the screens feel calm and premium:
- Scapia destination: one burnt orange action on every screen (IMG_3933 to IMG_3939).
- Urban Company: monochrome plus one purple (41:561, 41:568).
- Rapido: yellow only on the main action across 28 screens (35:63).
- CRED onboarding: zero or one accent until the result (22:13, 22:11).
- Groww (one or two), Ola (one), Housing.com, Lenskart (two at most), Meesho utility screens, Stanza Living (two at most).

Four to six accents on one screen, and hierarchy collapses:
- ixigo results, five (41:945); redBus results, five (113:84); PharmEasy cart, five (35:160).
- OYO listing card, five (41:843); Cleartrip room detail, four (35:106); Scapia Hotels, four (2014:9).
- CRED rewards hub, five or more (41:337); NoBroker hub, four to six (111:57); Physics Wallah batches, five or more (41:513).
- 30 Sundays: up to five on one screen (141:20), with fuchsia, orange, green, Google yellow, mint, blue, purple and dark red all in use.

### How strong brands hold one hue

- One colour family tints grounds and rows: Nykaa's pink ramp deepens down the hub (41:619) and even the 3D renders are pink (41:618).
- Ground changes per sub-brand, frame stays fixed: Flipkart magenta, brown and blue grounds with the same nav and cards (41:727, 41:707, 41:708).
- Many colours, one job each: Zomato red, green and blue stay readable because none overlaps (41:357, 41:375).
- One action colour with discipline: Rapido yellow (35:63), cult.fit's single gradient-text white button.
- One brand shape and illustration family: Headout's octagon frame on every hero (41:929, 41:928, 41:914, 41:927), Lenskart's mint on every empty state (41:667, 41:668, 41:672).
- Adaptive tint as wayfinding: Facebook header takes the group cover colour (2028:28); Myntra header follows the selected tab (41:692 to 41:695).
- Dark done well: near-black #121212 to #161616, off-white type, one accent (CRED 22:3).

The opposite, per-tab rainbow theming, is the most common way brands vanish: BigBasket 15 tabs and 15 schemes (38:196 to 38:212), Zepto (35:142 to 35:144), Swiggy six verticals (41:303 to 41:314), Physics Wallah whole-screen modes (41:524, 41:525), CARS24 header per tab (41:581, 41:582, 41:587, 41:590).

For 30 Sundays (as the reports recommend): fuchsia only for the one action; lagoonBliss for proof and verified marks; goldenHour for attention and progress (not red to green, 41:820); tropicalForest for the promise band (in place of OYO's black, 41:845); navy #181E4C for headings and body on cream (Scapia warns against grey on tint, IMG_3934); a cream to coastalMist tint ramp for stacked rows (from Nykaa 41:619).

### Semantic colour misuse

- Red as both brand and danger: redBus primary is "Keep my account" (113:107) then "Yes, Delete" (113:108).
- Brand primary on a destructive act: Nykaa (41:603), ours (141:79).
- Red for normal states: Paytm "Recharge due tomorrow" (41:392), INDmoney "verification pending" (41:481), Khatabook "Weak" (41:491), Rapido empty coins (35:67), Groww "Attention required!" (41:422), cult.fit red for zero workouts (41:820), Ola red alert icon with no message (35:89).
- Red and green carrying all status: ixigo (41:942, 41:946, 41:947); a whole screen of red cards reads as an error page.
- Green for "good": rating chips (Zomato 41:375, BigBasket 38:188, Swiggy 41:304), solid VERIFIED (99acres 41:251), "20% Cheaper" (Tata 1mg 41:774), our Completed pill, Pace chips, timeline dots and restaurant stars (141:9, 141:12, 141:6, 141:10).
- Red to green scales: Yatra rating slider (113:122), cult.fit (41:820), our Pace chips (141:12).
- Warning colour for neutral info: Cleartrip's orange traveller sentence and peach GST box (35:111).
- Link colour on things that are not links: Scapia amenities in blue (2014:17); default-looking blue links beside a polished primary (redBus 113:85).
- Disabled that looks active, or active that looks disabled: CRED mid grey (22:13), Spinny pale pink (41:889), Physics Wallah pale grey primary on black (41:513), Pepperfry tan Apply (22:49), upGrad near-invisible disabled (41:553).
- Two primaries with no rule: Headout purple and black (41:928), Swiggy orange and green (41:294, 41:292), Tata 1mg coral and black (41:776, 41:774), Spinny red and purple (41:891), CARS24 indigo and orange (41:588).

---

## 3. Layout and spacing

### Gutters

- 16 px is the default in nearly every app (Cleartrip, Headout, Zomato, Meesho, CARS24, 99acres).
- 20 px reads airy and premium: Scapia destination (IMG_3933), CRED sheet margins (22:9), cult.fit, Pristyn Care, CarDekho.
- 12 to 16 px reads dense: Facebook groups, EaseMyTrip, Myntra listings.
- Ours is about 22 px, and one rail ignores it entirely, starting at x = 0 (141:24).

### Radius

- 12 to 16 px on cards is the norm (Headout 12, Scapia 16, Zomato 12, Housing.com 12, CARS24 16).
- 16 to 20 px with hairline borders reads polished (Cleartrip 35:109, 35:105).
- 24 px on sheets and floating cards (CRED 22:9, OYO sheet top 41:845).
- 4 to 8 px reads dated (Khatabook Material 2, Pepperfry, Mamaearth, Meesho cards).
- Ours mixes 20, 14 and 12 px on three card types.

### Shadows and borders

- Polished apps use hairline borders and almost no shadow: Cleartrip (35:105), Scapia Hotels, Headout Essentials (41:927), Groww (no shadows), Housing.com.
- Our app uses soft shadows on some cards and hairlines on others (141:7 vs 141:13).

### Density

- Highest scores pair low density with one idea per screen: Scapia destination (about one idea per screen height), Urban Company (sections breathe, 41:561), Lenskart.
- Lowest information density scores go with packed viewports: ixigo bus results with six chip types, an ad, a banner and a toast (41:939); NoBroker, density 1 (111:57).
- Our density is uneven: half-empty sheets (141:11) beside walls of text (141:5, 141:7).

### Separators

- White space only, or white space plus a move to a tinted card: Cleartrip, Scapia, Lenskart. Calmest.
- Grey bands: Paytm, Urban Company 8 px, Stanza 8 px, Facebook 6 to 8 px between posts.
- Caps label with a hairline rule: Meesho (41:751), Paisabazaar (41:506), Zomato.
- Ours uses white space, a tinted band and a thick grey divider at once (141:20, 141:13, 141:6).

### Image ratios seen

- Hotel and stay photos about 4:3 (Cleartrip 35:109, Scapia inset hero 2014:20, Zomato grid 41:375).
- Portrait highlight and list cards about 3:4 (Scapia IMG_3935, Headout 41:921).
- Rail cards about 16:10 (Headout 41:920), video and playlists 16:9 (Physics Wallah 41:519).
- Places cards 3:2 recommended for our Where to eat (audit Indus spec).

### Layering

- Floating layers over content are a repeated failure: Scapia "Call assist" (2014:4, 2014:9), Pepperfry help tag and call button (22:41, 22:51), Tata 1mg call pill on step cards (41:782), CarDekho FAB over the button (41:855), Zepto ad bubble and toast (35:142), our floating filter dock and toast (141:85, 141:22).
- Sheets are the right home for long or secondary content when they have a grab handle and one X (Scapia 2014:16, 2014:18, 2014:3); stacked sheets with two X buttons confuse (Blinkit 41:270).
- Sticky bars must stay small: Scapia's sticky block eats about 18% of every screen (IMG_3933); Pepperfry's sticky bar on top of the nav takes 140 px (22:41).
- Card text needs fixed slots so a rail lines up (141:22, note 141:48).

---

## 4. Copy

### Tone that works

- Section titles that speak to the guest: "Where you'll sleep", "Where you'll be", "Before you reach here" (2014:9, 2014:15, 2014:4).
- Human questions: "Before we start, what do we call you?" (41:834).
- Short, witty, specific: "Basically, mango nobility!" (38:209).
- Verb-led captions that sell the moment: "Cruise Ha Long Bay, then move to a kayak" (IMG_3935).
- Why we ask, at the point of asking: "only be used for sending tickets" (41:440), "additional information helps us fetch accurate credit reports" (22:6), "Our technician will call on this number" (35:159).
- CTAs that name the next step or the choice: "Select Meal" (35:114), "Choose address at next step" (41:271), "for 3 months at 165" (41:774).
- Honest disclosures: "Auto-renews at ₹299/month. Cancel anytime." (41:517), "We do not collect personal messages or OTPs" (41:497), "We charge no commission" (35:65), "72 hours only replacement" (41:272), "Flights not included in this price" (113:155).
- Plain explanations of choices: each sort option explained (2028:23), each level explained (41:875).

### Copy that fails

- Back-office words on customer screens: "V4 - Quotation 1" (141:14), "SIC Transfer", "TCS" (141:6), "Older Itineraries" (141:16).
- Brand names as navigation labels: Urban Company "Revamp", "Native" (41:570).
- Off-brand couple copy: our splash (141:21), "Real photos from couples" (141:24), "Made for Couples", "couples who deserve better" (141:20), and OYO's "Couples are welcome" (41:843).
- Judgmental or loaded questions: PolicyBazaar income confirm (41:466), gender framed as "who is taking responsibility" (41:472).
- Vague rejection dressed as good news: "good things are worth the wait" (22:3).
- Alarm for normal steps: "Attention required!" (41:422).
- Defensive legal copy where reassurance should be: EaseMyTrip transit visa liability as the first important information (41:899).
- Hype and filler: "Epic experiences" (41:916), "Experience style elevation and enhanced vision" (41:672), "Enjoy Phi Phi Don, the main inhabited island" (141:4).
- Typos and copy bugs: "24*7 customer service(call/chat)" (113:95), "Exiting offers" (41:405), "Lets add some services" (41:569), "Invite the ones who makes" (141:13), "What are you currently pursing?" (41:877), "Compete & see where stand!" (41:524), helper line from the wrong tab (41:651), an empty "30 SUNDAYS TIP" box (141:12).
- Emoji in titles: ours (141:13, 141:24), PolicyBazaar (41:464).
- Em dashes in copy: our "Full split" line (141:20) and Yatra's bot copy (113:135).
- Subtitles under section titles, against our rule: Blinkit (41:279, 41:284), Nykaa (41:627, 41:623), 99acres (41:247), Housing.com intent cards (111:27), ixigo row subtitles that repeat the title (41:935), and ours on every home section (141:22, 141:24, 141:20). Alternatives in the evidence: a kicker above the title (22:27), a two-weight headline (41:504), caps micro-labels (22:13).

### Badge and urgency misuse

- Solid pill badges: ours "Completed", "Relaxed", "5 D 4 N" (141:9, 141:12, 141:14); 99acres solid green VERIFIED (41:251); Scapia solid red "58% off" (2014:20); Stanza corner ribbons (111:36); Physics Wallah solid red LIVE pills (41:513).
- Badge storms: ixigo "New", "Pro", "Free", "Flat 19% off" (41:941, 41:951); redBus mode stickers (113:90); PolicyBazaar tag on every tile (41:469); Paisabazaar cashback tabs on every tile (41:506); "New" on two of five tabs (41:513).
- Paid labels inside advice: "PROMOTED" in Recommended (41:451), Ad tags across curated lists (41:357), AD in search results (35:140, 35:141).
- Urgency as default: see "Dark patterns seen" below. The reports agree that scarcity shown everywhere stops meaning anything and makes the real price feel fake.

---

## 5. Scores

Scores are the reports' own (1 to 5). Splash-only apps from the launch study (Airbnb, Booking.com,
MakeMyTrip, Hopper) were not scored.

| App | Category | Visual polish | Clarity | Info density | Trust | Brand distinctiveness | Verdict |
|---|---|---|---|---|---|---|---|
| Cleartrip | Travel OTA | 4 | 4 | 3 | 4 | 3 | Honest price bar and fare cards, buried under discount theatre. |
| BookMyShow | Ticketing | 3 | 3 | 2 | 3 | 3 | Great review chips and soft asks, but paid posters and urgency everywhere. |
| OYO | Budget hotels | 3 | 4 | 3 | 4 | 4 | Best promise band in travel; pre-ticked consent and % off on every card. |
| EaseMyTrip | Travel OTA | 2 | 3 | 3 | 3 | 2 | Dated, but the layover pill and sort tabs are worth taking. |
| Headout | Experiences | 4 | 4 | 4 | 4 | 4 | Closest to our destination page; ranked list with inline expansion is the model. |
| ixigo | Transport super app | 3 | 3 | 2 | 4 | 2 | Freshness stamps and confirmation chance, inside a six-prompt launch and badge storm. |
| redBus | Bus and rail | 3 | 3 | 3 | 4 | 3 | Best filter sheet and cancellation table; red means brand and danger. |
| Yatra | Travel OTA with AI planner | 2 | 2 | 3 | 2 | 2 | Smart empty-slot nudge, but a planner that is a form hidden in a chat. |
| Scapia Hotels | Hotel detail | 4 | 3 | 3 | 4 | 3 | Sourced sub-scores and a useful nearby map; drip pricing and a floating help button. |
| Scapia destination | Destination page | 4 | 4 | 3 | 3 | 4 | One action colour and verb-led highlights; decorative map and grey on grey text. |
| Facebook groups | Social | 3 | 3 | 3 | 3 | 2 | Role badges, rules and pulse stats to borrow; spam and red badges to avoid. |
| 30 Sundays earlier build | Own app | 3 | 3 | 3 | 3 | 2 | Day chips on a map are right; dead-end gating and raw supplier text are not. |
| 30 Sundays current | Own app | 3 | 3 | 3 | 3 | 2 | Big photos and honest per-person price, but fuchsia everywhere and back-office words. |
| CRED | Payments and rewards | 5 | 3 | 3 | 5 | 5 | The premium benchmark at payment; a casino in the rewards hub. |
| Paytm | Payments super app | 3 | 3 | 2 | 3 | 2 | Named date chips and spend summary; five primaries and ads in booking. |
| PhonePe | UPI payments | 3 | 4 | 3 | 4 | 3 | Calm, honest OTP and in-context asks; an ad on the balance screen. |
| Groww | Investing | 4 | 5 | 4 | 5 | 3 | Document-replica confirms with plain irreversible warnings; calm and consistent. |
| PolicyBazaar | Insurance | 3 | 4 | 3 | 4 | 2 | One question per card with echo; one title repeated and judgmental confirms. |
| INDmoney | Investing and credit | 3 | 3 | 3 | 4 | 2 | Clear "steps remaining" stepper; red pending states and repeated sales heroes. |
| Khatabook | Business ledger | 2 | 4 | 3 | 4 | 2 | Sample-output empty states and honest permission list; dated and shaming meters. |
| Paisabazaar | Loans and bonds | 3 | 3 | 3 | 3 | 2 | Bond card is a clean comparison; pre-ticked consents and "Selling Fast". |
| Zepto | Quick commerce | 3 | 3 | 2 | 3 | 3 | Headline fact and promise ticks; interstitials, ads and per-tab colours. |
| BigBasket | Grocery | 3 | 3 | 2 | 3 | 2 | Intent tiles and skeletons; 15 tabs and 15 colour schemes erase the brand. |
| Blinkit | Quick commerce | 4 | 4 | 3 | 4 | 4 | Bento tile with count and next-step CTA copy; subtitles and stacked sheets. |
| Swiggy | Food and super app | 4 | 3 | 2 | 3 | 3 | Dineout card has every eat-out fact; six verticals feel like a mall. |
| Zomato | Food and dining | 4 | 4 | 3 | 4 | 4 | Restaurant header answers five questions in five lines; Ad tags on curated lists. |
| Urban Company | Home services | 5 | 5 | 4 | 4 | 3 | Best configurator and inclusions list, one accent, highest polish in food-services. |
| Pepperfry | Furniture | 3 | 3 | 3 | 2 | 3 | Warm photo-plus-script splash; viewer counts and floating help over the CTA. |
| Nykaa | Beauty | 4 | 3 | 3 | 4 | 5 | One hue carries the brand through busy hubs; fuchsia on Delete. |
| Mamaearth | Personal care | 3 | 3 | 2 | 3 | 4 | Script-word greeting and browse by ingredient; countdowns on most cards. |
| Lenskart | Eyewear | 5 | 4 | 4 | 4 | 4 | Service detail page is the itinerary-top skeleton; six-tab nav. |
| Myntra | Fashion | 4 | 3 | 2 | 3 | 4 | Lookbook bento is excellent; three-price cards and an overloaded home. |
| Flipkart | Marketplace | 4 | 3 | 2 | 3 | 3 | Ground colour per sub-app with a fixed frame; loans on the account page. |
| Meesho | Value marketplace | 3 | 4 | 3 | 4 | 3 | Returns timeline and live-count filters; sloppy filter data. |
| PharmEasy | Pharmacy and labs | 3 | 3 | 2 | 4 | 2 | Expert card and day-part slots; stacked discounts and promo on login. |
| Tata 1mg | Pharmacy and labs | 4 | 3 | 3 | 4 | 4 | Brand sign-off empty state and choice-in-button; upsell in the nav. |
| Pristyn Care | Surgery and consults | 2 | 3 | 3 | 3 | 2 | Two-question callback sheet is the planner-call model; two equal CTAs everywhere. |
| cult.fit | Fitness | 4 | 3 | 3 | 3 | 5 | Encouraging progress sheet and mini bar; offers lead and video heroes go blank. |
| Rapido | Ride hailing | 4 | 5 | 4 | 4 | 4 | Live status sheet is our booked-trip model; one yellow action held across 28 screens. |
| Ola | Ride hailing | 4 | 4 | 4 | 4 | 3 | Clearest fare breakdown with exclusions; preselects an unavailable option. |
| CARS24 | Used cars | 4 | 4 | 3 | 3 | 3 | Price range with proof and two-part price card; countdowns and pre-ticks. |
| CarDekho | Cars research | 3 | 4 | 3 | 3 | 2 | Ask Expert with ready questions and answer breadcrumb; bundled consent. |
| Spinny | Used cars | 4 | 4 | 4 | 4 | 4 | Stepper and timeline form with honest failure; disabled buttons look active. |
| Physics Wallah | EdTech | 3 | 3 | 3 | 3 | 3 | Playlist rows and value-first onboarding; whole-screen re-theming. |
| upGrad | EdTech | 3 | 4 | 4 | 3 | 2 | Cleanest enquiry form, but its confirmation is a dead end. |
| apna | Jobs | 4 | 5 | 4 | 4 | 3 | Model wizard with self-explaining suggestions; pre-ticked WhatsApp and scarcity tags. |
| 99acres | Real estate | 3 | 3 | 3 | 4 | 2 | Budget calculator, live counts, anti-scam sheet; three equal contact buttons. |
| Magicbricks | Real estate | 2 | 3 | 2 | 3 | 3 | "Today's match" single pick is a strong idea; colour soup. |
| Housing.com | Real estate | 4 | 4 | 4 | 2 | 3 | Highlights on the detail hero; the paywall stacks every dark pattern. |
| Stanza Living | Co-living | 3 | 4 | 4 | 3 | 3 | Calm detail with a soft and hard CTA pair; viewer counts and ribbons. |
| NoBroker | Real estate super app | 2 | 2 | 1 | 2 | 2 | Tidy service sheet, inside a hub of colours, wallets and a no-exit permission ask. |

Notes on two scores: CRED trust 5 is for its payment screens; Housing.com trust 2 is dragged down by its paywall (111:18).

---

## 6. Dark patterns seen

### Pre-ticked or pre-selected consent
- OYO, 41:849: marketing consent box pre-ticked at sign up.
- Paisabazaar, 41:507: pre-ticked consent appointing Paisabazaar as the user's authorised representative, plus pre-ticked WhatsApp marketing; 41:505 WhatsApp toggle on by default.
- CARS24, 41:595: "Get updates on WhatsApp" and "Fetch my addresses from trusted partners" pre-ticked.
- upGrad, 41:552: WhatsApp updates pre-ticked.
- apna, 41:883 and 12:12: WhatsApp updates pre-ticked.
- Lenskart, 41:679: Male pre-selected for gender.
- Housing.com, 111:18: a paid add-on pre-added with a Remove button.

### Bundled or implied consent
- CarDekho, 41:864: one paragraph agreeing to loan data sharing, dealer and OEM sharing, and marketing.
- Facebook groups, 2028:30: AI terms toast over the nav that takes consent by usage.
- Ola, 35:96: cookie banner with "Got It" and no decline option.
- CARS24, 41:593: reading financial SMS for credit offers framed as a "personalised experience".

### Permission overreach and badly timed asks
- ixigo, 41:957, 41:958, 41:956, 41:955, 41:953, 41:954: six interruptions before the first search, tracking stacked over welcome.
- BookMyShow, 41:458, 41:457: tracking and notification prompts on the first screen.
- EaseMyTrip, 41:910, 41:911: tracking and location prompts over home before any task.
- OYO, 41:852: pushes location "allow all the time".
- Khatabook, 41:497: four permissions at once, SMS "even when the app is not in use".
- NoBroker, 111:55: contacts and installed apps with only "Allow Access", no "Not now".
- Pepperfry, 22:56 and PharmEasy, 35:178: system prompts before any value.

### Fake urgency and scarcity
- EaseMyTrip, 41:901: "9 Seats Left" on almost every flight card.
- Yatra, 113:129: "1 Seat Left" in red on a single result.
- BookMyShow, 41:429, 41:431, 41:449: "Filling Fast", "Choices Vast But Filling Fast", "tickets booked in last 1 hour".
- redBus, 113:76: "Seats filling fast" as the subtitle of an empty form.
- Paisabazaar, 41:502 and 41:504: "Selling Fast" on every bond card and a "5 Days Left" countdown.
- Mamaearth, 41:642, 41:645: countdown boxes and countdown flags on most cards.
- Flipkart, 41:708: travel deals counting down in seconds.
- CARS24, 41:584: "04:54 min" timer on a free inspection.
- CarDekho, 41:860: "Hurry up to lock festive offers!" with no deadline.
- Housing.com, 111:18 and 111:28: countdown in the paywall CTA, "Hurry!", and a 9:59 timer for "2 extra enquiries".
- Zepto, 35:151: "Available till stocks last" on an opening interstitial.
- Swiggy, 41:308: "LIMITED TIME DISCOUNT" on membership.
- Pristyn Care, 41:801, 41:808: "FREE" plus "(Limited Time Offer)" on expert help.
- apna, 41:869, 12:2: "Last seats left" tag and "Urgently hiring" on most cards.

### Fake or pressure social proof
- Housing.com, 111:18: live purchase ticker ("just bought Relax plan").
- Pepperfry, 22:41: "103 People Viewing This" next to a 1.0 star rating.
- Stanza Living, 111:36: "1+ Viewing Now" and "Hot Selling".
- CarDekho, 41:860: "Rate & Win 1000" beside reviews, so reviews read as incentivised.

### Ads inside recommendations and trusted spaces
- BookMyShow, 41:451, 41:450: "PROMOTED" posters inside "Recommended Movies".
- Zomato, 41:357 to 41:373: Ad tags on almost every restaurant section.
- Zepto, 35:141, 35:145, 35:148, 35:142: ad row in autosuggest, Ad tags in grids, an ad bubble over content and an ad slot in the bottom nav.
- Paytm, 41:396: a third-party "AD" carousel inside the bus booking flow.
- PhonePe, 41:406: a telecom ad inside the check balance screen.
- Rapido, 35:63: an ad under the live ride status.
- 99acres, 41:262: sponsored builder banner on top of home.
- Blinkit, 41:275: a rival brand slot in the bottom nav.

### Interruptions while the user reads or plans
- ixigo, 41:948: upsell modal in the middle of results.
- Zomato, 41:354: District full-screen takeover pushing another app.
- redBus, 113:94 and 113:100: festival promo sheet and spotlight coachmark.
- Pristyn Care, 41:802: callback sheet pops over the doctor list uninvited.
- PharmEasy, 35:173, 35:177: register sheets over home on first open.
- Mamaearth, 41:640: poll sheet over the logged-out profile.
- Cleartrip, 35:115: coupon-applied modal blocking the screen for ₹310.
- Swiggy, 41:292: coach tooltip, toast, ₹1 upsell and "Don't miss out" nag on one cart.

### Anchoring and drip pricing
- Scapia Hotels, 2014:20: struck anchor price, solid red "58% off", then "+ ₹262 taxes & fees" on a third line; the true total is never shown.
- OYO, 41:843, 41:848: 66% to 80% off on every card.
- Paisabazaar, 41:505: struck "₹1,200" before "Absolutely FREE".
- PharmEasy, 35:160, 35:162: MRP, strike, % off, coupon price, PLUS credits and "BEST VALUE" on one item.
- BigBasket, 38:207 and Myntra, 41:683: three prices and stacked tags per card.
- NoBroker, 111:46: strikethrough, solid green "23% off" and asterisks.

### Gamified variable rewards
- CRED, 41:337: slot-machine cards, a 3D "PLAY", a live coin counter and a countdown on the daily reward.
- NoBroker, 111:42: mystery box and scratch card.
- Nykaa, 41:609: game zone with "Click to win".

### Obstruction and lost control
- CRED, 22:24: leave-chat sheet with no "Stay" option.
- apna, 12:3: success button that auto-advances.
- Yatra, 113:110: deactivation asks for a password the user may never have set.
- 99acres, 41:243: "View Number" hides the number behind a lead gate.
- Ola, 35:89: preselects an unavailable option, so the main button is disabled with no explanation.

### Shaming and loaded framing
- PolicyBazaar, 41:466: "Are you sure your annual Income is less than 2 lakhs?" while moving the user to Basic cover.
- Khatabook, 41:491: profile strength "Weak" in red.
- Rapido, 35:67: red error "You don't have any coins currently".
- CRED, 22:3: soft rejection dressed as good news.
- Urban Company, 41:564: red errors and "Verified Customer" as the name on first open.

### Misdirection in destructive flows
- redBus, 113:107 vs 113:108: red primary means keep on one screen and delete on the next.
- 30 Sundays, 141:79 and Nykaa, 41:603: brand primary on the Delete button.

### Cross-sell in personal or safety spaces
- Flipkart, 41:710: loans, EMI and credit cards lead the account page.
- Ola, 35:95: personal loans in a ride app.
- NoBroker, 111:45: instant cash loan splash in a housing app.
- Tata 1mg, 41:775, 41:787: a raised "Get Care Plan" upsell in the navigation slot.

### Privacy leaks on screen
- EaseMyTrip, 41:896: drawer greets the user by phone number.
- Magicbricks, 111:8: Truecaller sheet shows the full name and number on a shared overlay.
- Facebook groups, 2028:36: a phone number post left in the main feed.
- 30 Sundays audit, 141:8: a real customer's name, phone and email in the research screenshot (blur before sharing).
