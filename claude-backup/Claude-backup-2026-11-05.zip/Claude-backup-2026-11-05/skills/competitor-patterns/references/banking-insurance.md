# Banking and insurance apps: critical evaluation for 30 Sundays

Group: banking-insurance. 8 apps, 107 screens, every file opened. Node ids are cited with the colon so each screen can be opened in Figma.

Notes on the capture itself:
- Most columns are stored in reverse time order (the newest screenshot first). Flows below are listed in the order a user would meet them, not the canvas order.
- Duplicates: 22:28, 22:29 and 22:30 are identical copies of the CRED waitlist 22:3. 41:400 sits in the Paytm column but is a CRED screen (a copy of 41:335). 22:22 is a mid-animation frame with no content.
- No PolicyBazaar plan list or plan comparison table was captured. The only true comparison layout in this group is the Paisabazaar bond list (41:502). Worth capturing PolicyBazaar's quote list and "compare plans" table in a later round.
- No app shows a part-payment (pay some now, rest later) flow. The closest patterns are CRED's checkout sheet (41:340), PolicyBazaar's per-month pricing (41:466) and Paisabazaar's invest-today-get-later timeline (41:502).

---

### CRED (credit card bill payments and rewards, 31 screens)

**Flows covered**
- 22:13 Login: mobile number, consent to fetch credit report, sheet over monochrome arches photo
- 22:12 OTP: four boxes, resend and OTP-on-call links
- 22:11 Permission priming: location, with a reason line and "Skip now"
- 22:10 Link bank for CRED UPI: search plus bank logo list
- 22:9 Name: one big serif input
- 22:6 PAN: one big serif input
- 22:5 Date of birth: one big serif input
- 22:7 Email: one big serif input
- 22:4 Eligibility check, all steps pending (score 660)
- 22:8 Eligibility check, two steps ticked (score 816)
- 22:3 Waitlist result (dark), copies at 22:28, 22:29, 22:30
- 22:23 "All actions" sheet over the waitlist (settings list)
- 22:27 "We couldn't locate a credit report" (dark) with help cards
- 22:22 Transition frame, sheet sliding away (no content)
- 22:25 Support chat with quick-reply chips
- 22:24 "Are you sure?" leave-chat sheet
- 22:26 FAQ search (empty)
- 41:345 Add credit card: outlined fields and in-sheet number pad
- 41:342 CRED Protect intro: "WE FIND WHAT YOUR STATEMENT HIDES"
- 41:343 Protect loading: shield on a pedestal, "we found your card"
- 41:344 Card added confirmation with card render
- 41:341 "You've successfully secured your accounts" with confetti
- 41:336 Home (light): money matters, for you tiles, explore chips, bottom nav
- 41:337 Rewards hub (dark): coins, story rings, live ticker, slot-machine cards
- 41:338 More tab: search with trending queries, tiles, gradient banner
- 41:335 UPI pay screen: cashback milestone track, pay-to search, empty state
- 41:340 CRED Pay checkout sheet inside Amazon Pay
- 41:339 Payment receipt then "claim your reward" reveal

**Typography**
- Two faces doing two jobs. Chrome and body: geometric sans, very likely Gilroy (round "a", single-storey feel, wide bowls), weights 400 to 600. Display: a high-contrast editorial serif with sharp wedge serifs (Cirka or Tiempos Headline class), used only for the user's own words and for emotional headlines.
- Serif use is the signature. The input itself is set in serif at about 34px: "Annie S" (22:9), placeholder "enter your PAN" (22:6), "DD/MM/YYYY" (22:5). On dark screens the serif carries headlines at about 22px: "hey Annie S, good things are worth the wait." (22:3). On the reward screen it is gold and animated letter by letter (41:339). It never appears in buttons, labels or lists.
- Labels: tiny uppercase sans, about 11px, letter spacing about 0.2em, mid grey: "YOUR MOBILE NUMBER" (22:13), "CHECKING ELIGIBILITY" (22:8), "MONEY MATTERS" (41:336).
- A third, louder voice appears on newer screens: wide extended caps sans (Monument Extended or similar) for "WE FIND WHAT YOUR STATEMENT HIDES" (41:342) and "YOU'VE SUCCESSFULLY SECURED YOUR ACCOUNTS" (41:341).
- Hierarchy at 390 wide: serif input 32 to 36, serif headline 22, sans title 18 to 20 semibold, body 13 to 14 grey, caption 11 to 12, CTA 15 semibold.
- Case: almost everything lowercase ("check my eligibility" style copy, "life can be a lot easier", "are you sure?"). Buttons are sentence case.
- Prices: bold sans, rupee sign tight to the number, "₹865" at about 26px (41:340, 41:339). Big numbers become objects: the credit score is a chrome 3D numeral inside a gauge (22:8).

**Colour**
- Light onboarding: ground #FFFFFF over desaturated photo greys (#E6E8EA to #B8BBBE), sheet white, field card #FAFAFA with soft shadow, primary button near-black #111111, disabled #8C8C8C, body grey #7A7A7A.
- Dark screens: ground #121212 to #161616 with a faint 1px grid (#222), text #F2F2F2, secondary #8A8A8A, accent lime #C8E03A used on one button shadow and highlighted words (22:3, 22:27).
- Semantic: success green #20C26A ticks (22:8), Protect deep green #0E5C3A (41:342), mint gradients for success (41:341), reward gold #D8B46A on black (41:339), info blue #2F6FEB links (22:27).
- Accents per screen: zero or one on onboarding and payment screens (22:13, 41:340). Five or more on the rewards hub (gold, purple, pink, green, yellow on 41:337) and four on home (mint, red badge, gradient chip glows on 41:336).
- Gradients: subtle underglows on chips (41:336), brown-to-gold banner (41:338), green-to-black receipt header (41:339), neon rings (41:337).

**Layout and spacing**
- Onboarding pattern: full-bleed monochrome photo on the top 55 to 60 percent, then a floating white sheet with 20px side margins, radius about 24, generous 24 to 28px inner padding (22:9, 22:13). One question per sheet.
- Trust strip sits below the sheet, outside it: "PCI DSS, 256 bit encryption" plus card network logos (22:11, 22:5, 41:342).
- Dark screens switch to square corners and hairline borders, neo-brutalist offset shadow on the CTA (22:3, 22:27).
- Home (41:336): 20px gutters, pill chips radius 999, circular icon tiles about 64px, caps section labels, dotted dividers, no cards.
- Shadows are soft and wide on light screens, absent on dark ones. Image ratio: photo fills width, no crops or frames.

**Section designs**
- Onboarding: photo-over-sheet, one big serif input per step, helper line explaining why. Best at 22:9.
- Login and OTP: four boxes, edit-number pencil, resend plus OTP-on-call as underlined text links, 22:12.
- Other (permission priming): one permission, one-line benefit reason, black Continue, "Skip now" escape, 22:11.
- Progress and status: checklist with ticks and spinner while the score animates (labour illusion), 22:8.
- Editorial and stories: dark grid band, serif headline, grey body, card rail of serif-titled dark tiles with topographic line art, 22:3.
- Empty state: kicker over title cards ("what just happened?" above "why is there no credit report?") with a "Know more" link, 22:27.
- Empty state: isometric line illustration, serif line "life can be a lot easier", outlined "Let's go" button, 41:335.
- Profile: "ALL ACTIONS" sheet, line icons, lowercase labels, chevrons, 22:23.
- Help and chat: outlined bubble with square corners, quick-reply chips, 22:25; FAQ search with "have a different question?" footer, 22:26.
- Booking form: outlined floating-label fields with a custom number pad inside the sheet, 41:345.
- Payment: checkout sheet with amount, source, method, biometric, social proof, terms, black "Pay now", 41:340.
- Confirmation: card render plus "your card has been added", 41:344; caps success headline with confetti and row "secured in 0.3s", 41:341.
- Wallet and rewards: receipt header then a black reward reveal with a gold 3D "Claim now", 41:339.
- Wallet and rewards: milestone track, five gift boxes for "assured ₹100 cashback on 5 UPI payments", 41:335.
- Wallet and rewards: rewards hub with coin balances, story rings, live ticker, slot-machine cards, 41:337.
- Home header: avatar, glowing "unclaimed reward" pill, bell with count, 41:336.
- Category tiles: circular icons with tiny black badges ("EARN ₹100", "INSTANT"), 41:336.
- Other (chip cloud): rounded chips with gradient underglow for explore links, 41:336.
- Search bar: rotating placeholder plus trending searches list, 41:338.
- Hero banner: gradient promo "pay any account via card at the lowest fees", 41:338.
- Trust and proof: "10M+ members pay via CRED" row above CTA, 41:340; "80M+ accounts secured" under CTA, 41:342; PCI strip, 22:11.
- Bottom nav: black bar, raised glowing circular UPI button in the centre, caps labels, 41:336.

**Strengths**
- The single-question serif screens (22:9, 22:6, 22:5, 22:7) make a dull KYC form feel like a concierge asking politely. The user's own answer is the biggest, most beautiful thing on screen.
- Restraint on onboarding: grey photography, white sheet, one black button. No accent colour at all until the result (22:13, 22:11).
- Best trust stack in the group at the moment of payment (41:340): merchant and amount at the top, the exact bank account ("SBI •• 3745"), a change link, a plain time promise ("finish set up in 5 seconds"), a member count, then a single black button.
- Receipt first, reward second (41:339). The money confirmation is shown cleanly before any celebration.
- Labour illusion done well (22:4 then 22:8): the wait is explained step by step, so a slow server call feels like careful work.
- Every ask carries its reason: location (22:11), PAN and DOB ("additional information helps us fetch accurate credit reports", 22:6), BBPS reminders (22:9).
- Kicker over title (22:27) gives context without a subtitle under the title, which matches our house rule.

**Weaknesses**
- The rewards hub is a casino: slot-machine cards, a yellow 3D "PLAY", a live counter of coins spent, a countdown timer on the daily reward (41:337). Variable-reward dark pattern.
- Disabled buttons are a mid grey that reads as a real grey button (22:13, 22:6, 22:12). Visibility of system status: users cannot tell what is missing.
- The waitlist is a soft rejection dressed as good news: "good things are worth the wait" and a vague "Check why" (22:3). Match between system and the real world, and honesty.
- Four visual languages in one app: architectural white onboarding, dark grid neo-brutalism (22:3), neon casino (41:337), pastel chip-cloud home (41:336). Consistency and standards.
- Leave-chat sheet offers only "Yes, I want to leave" with no "Stay" button (22:24). User control and freedom.
- FAQ opens to a blank white page with only a search box (22:26). Empty state with no content and no suggestions.
- All-lowercase copy everywhere hurts names and scanning, while two screens shout in wide caps (41:341, 41:342).
- Home mixes five micro-badges, a red notification dot, glows and chips in one view (41:336). Weak hierarchy.

**Scores (1 to 5):** visual polish 5, clarity 3, information density 3, trust 5 (payment screens), brand distinctiveness 5.

**CRED premium visual language, notes for our team**
- The premium feel comes from three things, not from dark mode: (1) a serif kept for human words only, (2) huge white space with one action, (3) monochrome photography that never competes with the UI.
- Dark surfaces work when they are near-black (#121212 to #161616), not pure black, with one accent and type in off-white. The grid texture on 22:3 adds craft but would fight our cream grounds.
- The serif is used big (22 to 36px) and lowercase, never for UI labels. Our handwriting display face can play the same role: the traveller's own words (trip name, names, the place they chose) set large, everything else in Figtree.
- Caps micro-labels with wide tracking give structure without subtitles. They fit our "no subtitles under titles" rule.

**For 30 Sundays**
- Borrow for the wizard: one question per sheet over a full-bleed destination photo, answer set large in the display face, a one-line reason, one fuchsia button (22:9). Replace the grey arches with the chosen destination.
- Borrow for booked trip (pay balance, part payment): the 41:340 stack. Trip name and amount due at the top, which payment method, what happens after, a proof line ("x travellers paid this way" only if true), one button, terms line.
- Borrow for itinerary generation: the 22:8 step checklist while a custom route is built ("checking hotels", "matching flights", "finalising days").
- Borrow for booking confirmation: receipt first, then any perk (41:339), but without the slot-machine theatrics.
- Borrow for Sunday School cards: kicker above title, no subtitle (22:27).
- Borrow for profile: the clean "all actions" list (22:23).
- Avoid: gamified rewards and live counters (41:337), vague rejection copy (22:3), grey disabled buttons that look active, all-lowercase copy, mixing several visual languages.

---

### Paytm (payments super-app with travel, 9 screens, one misfiled)

**Flows covered**
- 41:399 Home (dark): UPI transfer icons, recharge and bills card, bento tiles, Scan QR pill
- 41:392 Recharge or pay mobile bill: my number, past recharges, SMS-found numbers
- 41:398 Monthly AI spend summary (dark): month tabs, totals, category list
- 41:393 Paytm Money login: market ticker, zero-fee pitch, phone login sheet
- 41:394 Paytm Travel offers: rails of poster offer cards
- 41:395 Train search: mode tabs, recent search rail, from/to, date chips, class chips, free cancellation add-on
- 41:396 Bus search: date chips, type chips, ad carousel, floating pill nav
- 41:397 Flight search: one way/round trip, big airport codes, special fares
- 41:400 Not Paytm: a copy of CRED's UPI pay screen 41:335

**Typography**
- Neo-grotesk system sans, likely Inter or Roboto, weights 400 to 700. Screen titles 20px bold, section titles 17px semibold, body 14px, captions 12px.
- Airport codes are huge (about 30px bold, "DED" and "PNQ") with the city in 13px below (41:397). Good use of size for the one thing that matters.
- Prices: bold inline rupee ("1 GB for ₹19", 41:392). The zero-fee pitch uses giant "₹0" numerals with the old price struck in a small yellow tag (41:393).
- Title Case on most labels, emoji inside banners (41:397).

**Colour**
- Primary sky blue #00BAF2 (buttons), brand navy #002E6E (logo, "Search Trains"), header tint #E3F4FC, section bands #F2F6FA, borders #D9E2EC.
- Semantic: red #E02020 for "Recharge due tomorrow" (41:392, 41:399), green #1E9E4A for cashback and money received (41:398), yellow #FFD21F for "Popular" and "Get Gold" tags.
- Dark mode: ground #0D0D0D, cards #1E1E1E, blue #1E88E5 icon circles (41:399).
- Accents per screen: offers rail 41:394 has six or more unrelated palettes. Search screens hold to two (sky and navy).

**Layout and spacing**
- 16px gutters, white cards radius 16 with hairline borders, chips radius 10 to 12.
- Sections separated by grey bands with a bold label ("My Number", "My Recharges & Bills", 41:392).
- Dense. Floating pill bottom bars ("Offers", "My Bookings") sit over content (41:396, 41:397).
- Offer posters are 3:4 cards with text baked into the image (41:394).

**Section designs**
- Search bar: name or mobile number field with a contacts icon, 41:392.
- Listing card: operator logo, name, due line, "Recharge" button per row, plan chips beneath, 41:392.
- Offers and coupons: poster rails with promo codes under each card, 41:394.
- Category tiles: travel mode tabs (Flights, Bus, Trains, Hotels, Offers) with a "Get Gold" tag, 41:395.
- Card rail: recent searches ("Patliputra to Marhaura, 05 Jun, Fri"), 41:395.
- Booking form: from/to with swap button, date chips, class chips, add-on row, full-width CTA, 41:395; flight version with one way/round trip and special fares, 41:397.
- Date picker: "4 Jun Today", "5 Jun Fri", "6 Jun Sat" plus a "Calendar" chip, 41:395; five-day strip with "Show More Dates", 41:396.
- Other (add-on upsell row): "Add Free Cancellation, 100% refund on train ticket fare" with a checkbox and T&C link, 41:395.
- Trust and proof: "IRCTC Authorised Partner" under the search button, 41:395.
- Wallet and rewards: spend summary by category with month tabs, totals and payment counts, 41:398.
- Price display: zero-fee pitch with struck original prices, 41:393.
- Login and OTP: bottom sheet with +91 and number, long legal paragraph, gradient "Get OTP", 41:393.
- Home header: avatar initials, campaign logo lockup, search, bell, 41:399.
- Bottom nav: floating pill with two or four items, 41:396, 41:397; floating "Scan QR" pill, 41:399.

**Strengths**
- Date chips that name the day ("Today", "Fri") with a calendar fallback (41:395). Fast for the common case, complete for the rare one.
- The free cancellation add-on states the benefit in plain numbers ("100% refund") right before search (41:395).
- Airport codes as the hero of the flight form (41:397).
- Recent search rail lets a returning user repeat a trip in one tap (41:395).
- Spend summary groups payments by category per month with clear totals (41:398). A good model for a trip cost breakdown.
- "Recharges found from SMS" (41:392) pre-fills from data the user already has.

**Weaknesses**
- Five identical "Recharge" primary buttons on one screen (41:392). No single next step.
- Red used for a normal reminder ("Recharge due tomorrow", 41:392, 41:399). Alarm where none is needed.
- Offer posters each have their own palette and the copy is baked into images (41:394). Aesthetic and minimalist design broken, and text is not accessible.
- An "AD" carousel for another company sits inside the bus booking flow (41:396).
- Floating nav pills cover the CTA area and content (41:397).
- Dense legal paragraph with five links above the login button (41:393).
- Truncated note "Self-transfers and payments hidden b..." hides what was excluded from totals (41:398).

**Scores (1 to 5):** visual polish 3, clarity 3, information density 2, trust 3, brand distinctiveness 2.

**For 30 Sundays**
- Borrow for the wizard: named date chips with a calendar escape for the month step (41:395).
- Borrow for home: a "recent plans" rail so a returning user resumes a draft (41:395).
- Borrow for booked trip: a category cost breakdown (flights, stays, activities, transfers) styled like 41:398, without the green and red.
- Borrow for itinerary: an add-on row that states the benefit in numbers (travel insurance, flexible dates) like 41:395.
- Avoid: poster offer rails, many primary buttons, ads in booking flows, floating bars over CTAs.

---

### PhonePe (UPI payments, 11 screens, all dark mode)

**Flows covered**
- 41:413 Splash: black with a purple pill loader
- 41:412 Enter mobile number: flag, +91, consent checkbox
- 41:411 OTP: five boxes, auto-read timer, SMS fallback
- 41:410 Home top: "Introducing SILVER" hero, money transfers, recharge and bills
- 41:405 Home lower: offers, share.market banner, "Productivity with ChatGPT" grid, My QR
- 41:409 Send money: search, split expenses, payments and chat list
- 41:407 Scan any QR: viewfinder, upload and torch
- 41:406 Check balance: activate fingerprint, accounts, a large ad
- 41:408 Select FASTag provider: help link, SMS permission card, bank list
- 41:404 History: grouped by month
- 41:403 Alerts: empty state

**Typography**
- Neo-grotesk sans, likely Roboto or a close custom, weights 400 to 700. Screen titles 24px bold ("Verify your mobile number", 41:411), section titles 17px semibold, body 14 to 16, captions 12.
- Money: "+ ₹1,000" medium weight in green on history (41:404), "₹1,000 - Received Instantly" in list rows (41:409).
- Title Case for headings, caps for small section labels ("PAYMENTS & CHAT", 41:409).

**Colour**
- Ground #0E0E0E, surface #1C1C1E, section band #2A2A2A, text #EDEDED, secondary #9A9A9A.
- Brand purple #5F259F in the hero (41:410), brighter #7B2FF7 for the scan button and FAB, link lilac #B48CFF.
- Semantic: green #3DBE5A for money in, orange-brown #8A3A12 refer pill.
- Accents per screen: usually purple plus one. The check balance screen adds a red and yellow ad (41:406).

**Layout and spacing**
- 20 to 24px gutters, tiles radius 12 on #1E1E1E, list rows about 72px with icon tiles.
- Month section bands for history (41:404). Hairline dividers in lists.
- Circular 56px purple icon buttons for transfers (41:410). Raised round purple scan button in the bottom nav (41:403).

**Section designs**
- Splash: black with a brand loader, 41:413.
- Login and OTP: "We will create an account if you don't have one", 41:412; auto-read bar with countdown and "Verify by sending SMS" fallback, 41:411.
- Hero banner: purple "Introducing SILVER" capsule, 41:410.
- Category tiles: purple circles (To mobile number, To bank, Receive, Check balance) and dark recharge tiles, 41:410.
- Referral: "Refer Friends" pill in the section header, 41:410.
- Offers and coupons: offer tiles and chip rail, 41:405, 41:410.
- Search bar: dark pill "Search for mobile number", 41:409.
- Social and community: payments as chat threads, with a "Split expenses" entry marked "New", 41:409.
- Payment: QR viewfinder with purple corners, upload and torch, interoperable app names under the title, 41:407.
- Wallet and rewards: balance check with fingerprint activation card and linked accounts, 41:406.
- Other (contextual permission): "Be reminded when your bills are due", reason line, outlined "Allow", 41:408.
- Bookings list: transaction history grouped by month, 41:404.
- Empty state: illustrated mailbox, "All caught up", 41:403.
- Bottom nav: five items with a raised purple scan button, 41:403.

**Strengths**
- Each verification step says why it exists: "This verifies your identity and helps you securely log in" (41:411).
- OTP auto-read with a visible timer and a clear fallback (41:411). Visibility of system status.
- One screen for login and sign-up, stated plainly (41:412).
- Permission asked in context, at the moment it helps, with the benefit first (41:408).
- History grouped by month is easy to scan (41:404).
- "PhonePe • Google Pay • BHIM • Paytm" under the scan title removes doubt about which QR codes work (41:407).
- Friendly, calm empty state (41:403).

**Weaknesses**
- A large telecom ad inside the check balance screen (41:406). A money screen should never sell something else.
- Typo on a tag: "Exiting offers" (41:405).
- A ChatGPT productivity grid ("Plan My Day", "Make My Resume") on a payments home (41:405). Scope creep, weak information scent.
- Masked numbers on every history row make it impossible to recognise who paid (41:404). Recognition rather than recall.
- Hero "Introducing SILVER" never says what Silver is (41:410).
- Green for money in, which our house rules forbid.

**Scores (1 to 5):** visual polish 3, clarity 4, information density 3, trust 4, brand distinctiveness 3.

**For 30 Sundays**
- Borrow for login: reason line on OTP, auto-read timer, SMS fallback, "we'll create an account if you don't have one" (41:411, 41:412).
- Borrow for booked trip: payment history grouped by month or by instalment (41:404), with the trip name, not a masked id.
- Borrow for wishlist and booked trip: ask for notifications in context ("Get a nudge when prices for Bali drop") like 41:408.
- Avoid: ads or cross-sells inside payment screens, unexplained hero campaigns, scope creep tiles.

---

### Groww (stocks and mutual funds, 11 screens, dark mode)

**Flows covered**
- 41:425 Enter mobile number linked to bank, with logged-in email shown
- 41:424 Set up Groww PIN with custom keypad
- 41:423 Submit signature with FATCA declaration
- 41:415 Confirm PAN details on a PAN card replica
- 41:416 Confirm bank details as a label and value list
- 41:417 Confirm address on an Aadhaar card replica
- 41:422 Stocks explore before account is active: "Attention required!"
- 41:421 Watchlist with sparklines and a delayed-prices toast
- 41:419 F&O explore: index cards, top traded list, activate CTA
- 41:420 Index detail: big number, line chart, range chips
- 41:418 Mutual funds explore: popular funds grid, collections

**Typography**
- Clean geometric sans, Groww's own or close to Inter or Basier, weights 400 to 700.
- Screen titles 20 to 22px semibold ("Confirm PAN details", 41:415), big figure 28px bold ("74,147.11", 41:420), body 14px, captions 12px grey.
- Returns as "+50.40%" in green with "3Y" in grey beside it (41:418). Prices right-aligned with change below (41:421).
- Inconsistent case: "ACTIVATE STOCKS" and "COMPLETE SETUP" in caps (41:419, 41:422) while other buttons are sentence case (41:423).

**Colour**
- Ground #0A0A0A, surface #161616, border #2A2A2A, text #F5F5F5, secondary #9B9B9B.
- Primary teal-green #00B386, ghost button fill #0F2E27 with teal text.
- Loss orange-red #EB5B3C, gain #00B386, warning amber #F5A623, illustration blue-violet #5367FF.
- Accents per screen: one or two. Calm and consistent.

**Layout and spacing**
- 16 to 18px gutters, cards radius 12 with 1px borders and no shadows.
- Label and value lists with hairline dividers (41:416).
- Two-button footer, 50/50, decline on the left, confirm on the right (41:415, 41:416, 41:417).
- Document replicas are drawn at real card proportions (41:415, 41:417).

**Section designs**
- Login and OTP: mobile field with reason line and an info card showing the signed-in email with "Edit email?", 41:425.
- Other (PIN setup): reason line "we'll ask for this PIN every time you open the app", four boxes, keypad, 41:424.
- Booking form: confirm-the-document card with a warning under it and a consent line, 41:415; Aadhaar replica, 41:417.
- Detail sections: plain label and value list, 41:416.
- Sticky CTA bar: "No, Edit PAN" ghost and "Yes, Confirm" filled, 41:415.
- Card rail: market index cards, 41:419.
- Listing card: fund tiles in a 2x2 grid with logo, name, return, period, 41:418.
- Category tiles: isometric illustrated collections ("SIP with ₹100", "Gold & Silver Funds"), 41:418.
- Detail hero: price, change, line chart with dashed previous close, range chips, 41:420.
- Filters and sort: watchlist sort with a toggle for the price column, 41:421.
- Progress and status: illustrated "complete your setup" card, 41:422; toast "Prices will be live after stocks account is active", 41:421.
- Bottom nav: three items with icon and label, 41:418.

**Strengths**
- Confirm screens mirror the real document (41:415, 41:417). Users check against something they recognise, not a form.
- Irreversible step is stated in plain words with a warning icon: "Once confirmed, PAN details CANNOT be changed later" (41:415). Error prevention.
- Reversible step says so: "You can change or add another bank anytime later" (41:416). This lowers anxiety at the right moment.
- The same button pair, in the same positions, on every confirm screen (41:415 to 41:417). Consistency.
- Honest status toast about delayed prices (41:421).
- Restrained palette and no shadows make the dark theme feel calm, not flashy.

**Weaknesses**
- "Attention required!" is alarm copy for a normal next step (41:422).
- Caps buttons on some screens, sentence case on others (41:419 vs 41:423). Consistency and standards.
- Ghost decline buttons are dark teal on black with low contrast (41:415).
- Red and green for loss and gain (expected in finance, but against our rules).
- Generic isometric illustrations carry no brand (41:423, 41:418).

**Scores (1 to 5):** visual polish 4, clarity 5, information density 4, trust 5, brand distinctiveness 3.

**For 30 Sundays**
- Borrow for booked trip (before tickets are issued): a "confirm traveller details" screen that looks like a passport page or a boarding pass, with a plain warning "Names on flight tickets cannot be changed later" (41:415).
- Borrow for itinerary versions: reassurance on reversible actions ("You can change this anytime before you pay", 41:416).
- Borrow the decline-left, confirm-right footer for any "Yes, book this version" step (41:415). Keep fuchsia only on the confirm side.
- Avoid: alarm copy for normal steps, mixed button case, red and green states.

---

### PolicyBazaar (insurance marketplace, 16 screens)

**Flows covered**
- 41:476 Onboarding: "Your insurance, simplified!"
- 41:475 Login: WhatsApp first, mobile number second
- 41:474 Profile wizard: name
- 41:473 Profile wizard: date of birth with computed age
- 41:472 Profile wizard: gender
- 41:471 Profile wizard: marital status
- 41:469 Home: purple hero, investment rail, tagged category tiles
- 41:470 Home with "You have unlocked free roadside assistance" sheet
- 41:467 Term insurance: select annual income
- 41:468 Term insurance: occupation type
- 41:466 Term insurance: "Are you sure your annual income is less than 2 lakhs?"
- 41:465 Two-wheeler: enter vehicle number
- 41:464 Claims: "No policies yet?"
- 41:463 Your coverage: empty policies, offers
- 41:462 Profile: avatar and settings list
- 41:461 Travel insurance: where are you travelling, popular destinations, dates

**Typography**
- Serif headings (Merriweather class, sturdy slab-like serif) at 22 to 28px: "Your insurance, simplified!" (41:476), "Let's simplify your insurance" (41:474), "Your coverage" (41:463), "Explore the world / Worry free!" (41:461).
- Body and UI in Roboto, 14 to 16px; section labels 16px semibold.
- Prices as "Starting @ ₹487/month*" with an asterisk (41:466), "Plans starting @ ₹18/day*" (41:461). Lakh and crore spelled out ("₹2 Crore", "₹50 lakh").
- Sentence case mostly, some caps tags.

**Colour**
- Primary blue #0065FF (CTAs, radio fills, links), navy #1B2A4E headings, pale blue ground #EEF4FF for the wizard, white cards.
- Home hero: purple grid gradient #4A1A9E to #B026D9 with yellow #FFD84D headline (41:469).
- WhatsApp teal #128C7E login button (41:475), mint tags #7EE2B8 on tiles, black nav pill #111111.
- Travel insurance: mint gradient #DDF5EC with landmark line art (41:461).
- Accents per screen: wizard holds to one blue. Home stacks purple, yellow, green, mint and black (41:469).

**Layout and spacing**
- Wizard: a white card radius 16 on a pale blue ground, progress bar above, round blue arrow FAB bottom right (41:474).
- Radio option cards radius 12 with soft shadows (41:467). Selected state adds a blue border (41:468).
- Dashed borders for empty states (41:463, 41:464). Floating black bottom nav pill (41:469).
- 16 to 20px gutters, airy wizard, dense home.

**Section designs**
- Onboarding: flat illustration, serif title, circular next button with a progress ring, "SKIP", 41:476.
- Login and OTP: "Login via WhatsApp" filled, "OR", "Login via Mobile Number" outlined, 41:475.
- Booking form: one question per card with a serif title, a reason line and a FAB next, 41:474; computed age chip and date echo, 41:473; radio list, 41:471.
- Progress and status: named stage tabs ("Comprehensive cover", "Standard cover", "Basic cover") above the question card, 41:466.
- Hero banner: offer banner that updates with answers ("₹2 Crore at ₹487/month" becomes "₹50 lakh at ₹230/month"), 41:467 vs 41:468.
- Category tiles: product tiles each with a mint tag on top ("Upto 15% Discount", "In-built Life Cover"), 41:469.
- Card rail: investment plan card "Invest ₹10,000/month, Get ₹1 Crore on maturity", 41:469.
- Other (benefit unlock sheet): illustration, "You have unlocked free roadside assistance", one black button, 41:470.
- Empty state: "No active policies found" in a dashed card, 41:463; locked "Submit Claim Request, available only for Policybazaar customers", 41:464.
- Profile: memoji avatar, name, "View profile", list with pastel icon circles, title and subtitle, 41:462.
- Trust and proof: "Know your advisor: find if you spoke to a genuine advisor from Policybazaar", 41:462.
- Search bar: "Where are you travelling?" country search, 41:461.
- Category tiles: popular destination circle photos (Schengen, UAE, USA, Thailand, UK) with "You can select multiple countries", 41:461.
- Date picker: start date and end date fields side by side, 41:461.
- Sticky CTA bar: full-width "View plans", 41:461.
- Help and chat: call button fixed top right on every product flow, 41:466.

**Strengths**
- One question per card with a progress bar and a reason line ("Your marital status will help us plan your cover", 41:471). Calm and quick.
- The date of birth field echoes "September 13, 2004" and shows "21 years" inside the field (41:473). Error prevention without an error.
- Travel insurance entry is close to our own wizard: destination search, photo chips for popular countries with multi-select, then dates (41:461).
- "Know your advisor" lets users verify that a caller really works for the company (41:462). Strong anti-fraud trust signal for a phone-heavy sales model.
- Benefit unlock as a single focused sheet (41:470).
- Help by phone is always one tap away in product flows (41:466).
- Locked actions say why they are locked (41:464).

**Weaknesses**
- Every wizard step has the same title, "Let's simplify your insurance" (41:474, 41:472, 41:471). The title stops carrying meaning; only the small line changes.
- "Are you sure your annual Income is less than 2 lakhs ?" is judgmental and quietly moves the user to "Basic cover" (41:466). Match with the real world, respect.
- Gender asked as "who is taking responsibility for financial protection" (41:472). Loaded copy.
- Home tags every tile and stacks three loud promos (41:469). Aesthetic and minimalist design broken.
- A truncated "₹50 LA" ticket graphic with regulatory fine print in the empty coverage screen (41:463).
- Emoji in a title ("No policies yet?" plus thinking face, 41:464) and stray spaces before "!" and "?" (41:465, 41:466).
- No plan comparison screen in the capture, so we cannot judge their core comparison table here.

**Scores (1 to 5):** visual polish 3, clarity 4, information density 3, trust 4, brand distinctiveness 2.

**For 30 Sundays**
- Borrow for the wizard: card-per-question with a progress bar, reason line and next button (41:471), plus input echo ("6 nights, 12 to 18 March", like 41:473). Give each step its own title.
- Borrow for the wizard and wishlist: destination photo chips with multi-select (41:461).
- Borrow for itinerary: an offer line that updates as the user changes nights or hotels, like the banner in 41:467 and 41:468, but as a quiet price line, not a banner.
- Borrow for profile or booked trip: "Know your planner", a way to confirm the person calling is really from 30 Sundays (41:462).
- Avoid: one title repeated on every step, tags on every tile, judgmental confirm questions.

---

### INDmoney (investing and credit, 12 screens)

**Flows covered**
- 41:489 Enter mobile number with "Trusted by 1.5 Crore+ Indians"
- 41:488 Enter name
- 41:487 Securely verify your email: Google sign-in or OTP
- 41:486 Where do you want to make your first investment? (three doors)
- 41:485 Stocks tab: navy hero, index cards, top gainers rail
- 41:484 US Stocks tab: activation stepper, rewards card
- 41:483 MyIND tab: net worth hero, KYC card, UPI and Bills pill
- 41:482 Mutual funds tab: hero, sync folio strip, ways to invest
- 41:481 My profile: verification pending, KYC progress accordions
- 41:480 Credit cards: pay bill and get ₹500 in US stocks
- 41:479 Credit score: free score, bureaus, tip box, consent
- 41:478 INDpay: scan any QR, tiles, promo card

**Typography**
- Neutral grotesk sans, likely Inter or Manrope, weights 400 to 600. Screen titles 24px medium ("Enter your mobile number", 41:489), hero titles 22px semibold white on navy, body 14px, captions 12px.
- Green caps kicker "WELCOME SHIVAM" above a title (41:483).
- Prices: "₹105.80" semibold with "▲14.95%" green beneath (41:485). Reward amounts large and green: "₹500 in US Stocks" (41:480).

**Colour**
- Navy header band #233663, primary green #2DB563 (pill CTAs), mint #3FD8A0 (hero CTAs), blue #1E7BFF (tabs, links, strips), light ground #F4F5F7, white cards.
- Semantic: red #E5484D for loss and for "Profile verification pending" (41:481), info tint #EAF4FF (41:479).
- Accents per screen: three (navy, green, blue) plus red market moves.

**Layout and spacing**
- 16px gutters, white cards radius 16 with no borders, navy header with a curved bottom edge radius 24 (41:483).
- Pill CTAs fully rounded. Sections marked with a short green left bar ("Top Gainers", 41:485).
- Bottom nav five items with a top-line active indicator.

**Section designs**
- Login and OTP: underline field, terms line, disabled pale green CTA, proof line under it, 41:489.
- Trust and proof: "Trusted by 1.5 Crore+ Indians" with shield, 41:489; "Verified & 100% Secure" footer band, 41:487; "Powered by CIBIL, Experian, CRIF", 41:479.
- Onboarding: three-door fork with illustration, title, subtitle, chevron, 41:486.
- Hero banner: navy activation band per tab, 41:485, 41:482, 41:483.
- Card rail: index cards and top gainers, 41:485.
- Progress and status: vertical stepper "Activate US Stocks a/c, only 3 steps remaining", 41:484; KYC progress bar "16% Completed", 41:481.
- Wallet and rewards: assured reward card with split buttons "Learn more" and "Create a/c", 41:484; "Pay your credit card bill and get assured ₹500", 41:480.
- Profile: navy identity card, Help Center and Learn tiles, dark theme toggle, KYC accordions, 41:481.
- Other (tip box): "Did you know? A high credit score can give you access to lower interest rates", 41:479.
- Video: "Learn about US Stocks" cards with play buttons, 41:484.
- Payment: neon "Scan any QR" with interoperable logos, 41:478.
- Referral: "Refer & Earn" tile, 41:478.
- Bottom nav: five items, 41:485.

**Strengths**
- The vertical stepper names the remaining steps and the count (41:484). Visibility of system status.
- The fork screen gives three clear doors with one-line descriptions (41:486).
- The trust line sits right under the CTA where hesitation happens (41:489).
- Google sign-in first, OTP as a text fallback (41:487).
- A short "Did you know?" tip box explains why the ask matters (41:479).

**Weaknesses**
- Two identical "Complete Verification" buttons and two "16% Completed" bars on one screen (41:481).
- "Profile verification pending" in red on the profile card (41:481). Alarm for a normal state.
- Two stacked rows of tabs (41:482). Unclear navigation hierarchy.
- Every tab opens with the same navy "activate" hero (41:485, 41:482, 41:483). Repetitive selling.
- Floating "UPI & Bills" pill overlaps content (41:483).
- 3D brand-logo coins clutter the credit card hero (41:480).

**Scores (1 to 5):** visual polish 3, clarity 3, information density 3, trust 4, brand distinctiveness 2.

**For 30 Sundays**
- Borrow for booked trip: a stepper of what is left before departure ("Pay the balance", "Add passport details", "Visa", "Download vouchers"), with the count of remaining steps (41:484).
- Borrow for home or wizard entry: a three-door choice ("Pick a ready trip", "Build your own", "Talk to a planner") like 41:486.
- Borrow for login: proof line under the button (41:489), only with a true number.
- Avoid: red pending states, nested tab rows, the same sales hero on every tab.

---

### Khatabook (small business ledger, 9 screens)

**Flows covered**
- 41:499 Select your language (10 languages)
- 41:498 Login: mobile number with trust seal
- 41:497 Allow permissions: SMS, location, notifications, phone state with reasons
- 41:496 Parties (empty): give and get summary, add customer
- 41:495 Bills: sales and purchase stats, sample bills, add bill
- 41:494 Items (empty): benefits list, add product
- 41:493 Add item form with tooltip
- 41:492 Add party form
- 41:491 More: profile strength, business card banner, tile grid

**Typography**
- Roboto, Material 2 style. App bar title 20px medium white. Body 14 to 16px. Buttons in caps ("GET OTP", "ADD CUSTOMER", "SAVE ITEM").
- Amounts bold with coloured rupee: green "₹ 0" for give, red "₹ 0" for get (41:496); green and red rupee icons inside price fields (41:493).
- Language picker uses native script letters in avatars (41:499).

**Colour**
- Royal blue #0D4FAF app bar and CTA, navy #1A237E FAB, crimson #A3195B "Add customer" FAB, yellow #F9A825 tab indicator.
- Semantic: green #1E8E3E, red #D32F2F, "New" red pill, "Pending" red badge.
- Ground #F0F2F5, white blocks. Accents per screen: three to four.

**Layout and spacing**
- Material 2: blue app bar, white blocks separated by 8px grey gaps, small radius (4 to 8), flat.
- Tile grid 3 columns with pastel icon circles (41:491). Extended FABs bottom right.

**Section designs**
- Other (language picker): 2-column grid of languages in native script, 41:499.
- Login and OTP: logo, "Trusted by 5 Crore+ businesses" with a seal, +91 field, 41:498.
- Other (permission explainer): one card listing each permission with a plain reason, plus "guarantees 100% data safety" pill, 41:497.
- Empty state: illustration plus one line plus FAB, 41:496; benefits list, 41:494; sample output preview "View sample bills", 41:495.
- Wallet and rewards: "You will give / You will get" summary card, 41:496; monthly sales and purchases stat tiles, 41:495.
- Booking form: party form with "+ ADD GSTIN & ADDRESS (OPTIONAL)", 41:492; item form with inline tooltip, 41:493.
- Profile: profile strength bar, "Fill missing details for a FREE Business Card" banner, 41:491.
- Category tiles: 3x2 icon tiles, 41:491.
- Bottom nav: four items, 41:491.

**Strengths**
- The permission explainer says what is not collected: "We do not collect personal messages or OTPs" (41:497). Honest and specific.
- Empty bills screen shows what the output will look like, with "View sample bills" (41:495).
- Optional fields hidden behind one link (41:492). Progressive disclosure.
- Inline tooltip explains a jargon field at the point of use (41:493). Help and documentation in context.
- Language picker in native scripts (41:499).

**Weaknesses**
- Profile strength "Weak" in red with 17 percent (41:491). Shaming, not helping.
- Four permissions requested at once before any value is shown, including SMS "even when the app is not in use" (41:497).
- Two FABs compete on the bills screen (41:495). A crimson FAB breaks the blue palette (41:496).
- Permanent red "Pending" badge on the logo (41:491).
- Dated Material 2 look and caps buttons.

**Scores (1 to 5):** visual polish 2, clarity 4, information density 3, trust 4, brand distinctiveness 2.

**For 30 Sundays**
- Borrow for empty wishlist and empty itinerary: show a sample of the finished thing ("See a sample Bali itinerary"), like 41:495.
- Borrow for forms: optional fields behind one link, and a tooltip on travel jargon ("What is a land package?") like 41:493.
- Borrow for any permission ask: list what we do not collect (41:497), but ask one at a time, in context.
- Avoid: red strength meters, multiple FABs, permission walls.

---

### Paisabazaar (loans, cards, bonds marketplace, 8 screens)

**Flows covered**
- 41:508 Splash: tilted product cards, PCI DSS and ISO 27001 badges
- 41:507 Login: name and phone, pre-ticked consents, Google and Truecaller
- 41:506 Home: navy PB Money hero, recommended and loans tiles with cashback tabs
- 41:505 Credit score form: free report pitch, gender, name, email, consent
- 41:504 Bills and recharges: festive banner with countdown, add credit card, bill tiles
- 41:503 You tab: celebrity banner, explore more, settings list
- 41:502 Explore bonds by category: bond comparison cards
- 41:501 PB Money intro: "One View, All Accounts"

**Typography**
- Geometric sans, likely Poppins, for UI (weights 400 to 600). A serif display (Merriweather or Lora class) for some headings: "Explore Bonds by Category" (41:502), "Take control of your Finances" (41:506), "Bill Payments" (41:504); italic serif for "High Yield Bonds" (41:502).
- Two-weight headline trick: light first line, bold second ("Your one stop solution for / Bills and Recharges", 41:504; "India's best platform for / Loans, Cards & Investments", 41:507).
- Caps section labels with hairline rules ("RECOMMENDED FOR YOU", 41:506).
- Prices: "You Invest ₹10,026", "You Get ₹12,602" semibold at about 18px, return "14%" in green between them (41:502). Struck anchor "₹1,200" before "Absolutely FREE" (41:505).

**Colour**
- Blue #0B6BFF splash and links, indigo #1F2FBF CTA, navy hero #0F4A8A, ground #F5F7FA, white cards.
- Accents: magenta #E6007E ("Absolutely FREE"), green #2BA84A (returns, cashback tabs), orange #F28C28 ("Selling Fast"), gold #F5C542 ribbons, lilac #EFE7FF timeline end.
- Accents per screen: four to five on home and bonds.

**Layout and spacing**
- 16px gutters, cards radius 16 with light borders and soft shadows.
- Badges straddle the top border of cards ("Selling Fast", 41:502; "Cashback Offer" tabs, 41:506).
- Sections separated by caps labels with rules and white space.

**Section designs**
- Splash: tilted grid of product cards with a certification footer, 41:508.
- Login and OTP: name as per PAN, phone with digit counter "0 / 10 Digits", social login, 41:507.
- Home header: "Hey, Welcome to Paisabazaar!", support, wallet chip "₹0", bell, 41:506.
- Hero banner: navy with gold ribbon, serif title, three-up feature strip, 3D icon, 41:506.
- Category tiles: 3D icons with green offer tabs on top, 41:506.
- Comparison: bond cards in an identical layout (issuer, rating chip with mini gauge and "Moderate Risk", You Invest, Returns, You Get, timeline "Today to within 23 months"), 41:502.
- Booking form: credit score form with helper text "As per your bank records", 41:505.
- Offers and coupons: festive banner with "5 Days Left" countdown, 41:504.
- Other (add card placeholder): dark patterned card with a dashed plus "ADD CREDIT CARD", 41:504.
- Trust and proof: "PCI DSS COMPLIANT", "ISO 27001 CERTIFIED", "100% SAFE AND SECURE", 41:508; "Always Free, Always Secure", 41:501.
- Editorial and stories: phone mockup with floating balance cards, 41:501.
- Profile: You tab with settings list, 41:503.
- Bottom nav: four items with a black tooltip pointing at Pay Bills, 41:506.

**Strengths**
- The bond card is a clear equation: what you put in, what you get, and when, on a timeline arrow (41:502). Same layout on every card, so cards compare at a glance.
- Risk is translated into words ("Moderate Risk") next to the formal rating (41:502).
- Helper text under fields says which spelling to use ("As per your bank records", 41:505).
- Certifications presented as a calm footer, not a banner (41:508).
- The two-weight headline is a simple way to add hierarchy without a subtitle (41:504).

**Weaknesses**
- Pre-ticked consent that appoints Paisabazaar as the user's authorised representative, plus pre-ticked WhatsApp marketing (41:507). Dark pattern on consent.
- WhatsApp updates toggle on by default (41:505).
- "Selling Fast" on every single bond card (41:502) and a "5 Days Left" countdown (41:504). False urgency.
- Struck "₹1,200" price anchor on a free product (41:505).
- Celebrity cricket banner unrelated to the user's task (41:503).
- Cashback tabs on every tile and a tooltip pointing at the nav (41:506). Too many badges.

**Scores (1 to 5):** visual polish 3, clarity 3, information density 3, trust 3, brand distinctiveness 2.

**For 30 Sundays**
- Borrow for booked trip (part payment): the equation and timeline from 41:502. "Paid ₹40,000 today", arrow, "₹1,20,000 balance by 12 Feb". One layout for every instalment.
- Borrow for itinerary versions: identical card layout per version so differences stand out (nights, hotels, price), like 41:502.
- Borrow for forms: helper text that tells people exactly what to type ("As on your passport").
- Avoid: pre-ticked consents, "Selling Fast" on everything, countdowns, struck anchors on free things.

---

### Group summary

**Patterns that repeat, by component kind**
- Login and OTP: every app is phone-first with +91. Consent for credit bureau access sits right under the field (22:13, 41:412, 41:507). Good apps add a reason line and an OTP fallback (41:411, 22:12). Alternatives: WhatsApp login (41:475), Google and Truecaller (41:507), Google for email (41:487).
- Trust and proof: three recurring forms. (1) A count of users right under the CTA (41:489, 41:498, 41:340, 41:342). (2) A certification strip (22:11, 41:508). (3) A named partner line (IRCTC 41:395, HDFC and UPI 41:478, credit bureaus 41:479, Bharat Connect 41:408). The calm ones sit below the action; the loud ones become banners.
- Progress and status: checklists while waiting (22:8), steppers of what is left (41:484), progress bars over wizards (41:471), named stages (41:466), percent-complete meters (41:481, 41:491). The best name the steps; the worst colour the user red.
- Payment: the strongest screens show amount, source, method and what happens next on one sheet (41:340), confirm details against a real document (41:415), and group history by month (41:404).
- Wallet and rewards: every app has one, and most drift into gambling or noise: slot machines (41:337), gold campaigns (41:394, 41:397), cashback tabs on tiles (41:506), US-stock rewards (41:480). The tasteful version is a receipt followed by a single perk (41:339).
- Category tiles: round icons in a 4-column grid with small tags on top, on almost every home (41:336, 41:410, 41:469, 41:506, 41:491). Tags on every tile cancel each other out.
- Bottom nav: a raised centre action for the core job (UPI 41:336, scan 41:403) or a floating pill (41:396, 41:469).
- Empty state: illustration, one line, one button (41:403, 41:494, 41:496). The best show a sample of the output (41:495).
- Comparison: only Paisabazaar's bond cards (41:502) in this capture. Identical card layouts with an input, an output and a time span compare well.
- Other (permission): in-context asks with the benefit first (41:408, 22:11) beat permission walls (41:497).

**30 Sundays focus areas**
- Trust for large payments: put the trip name, the exact amount and the payment method on one sheet, add one proof line and the terms, then one button (41:340). Confirm traveller names against a document-style card before tickets are issued, with a plain "cannot be changed later" warning (41:415). State reversibility where it exists (41:416).
- Part payment: no app shows it, but 41:502 gives the visual grammar (paid now, arrow, balance by date) and 41:404 gives the history layout. 41:484 gives the "what is left before you fly" stepper.
- Rewards and wallet: keep it to a receipt then one perk (41:339). Never a hub of games.
- Comparison: same card layout for each option, numbers in fixed positions, plain-language labels beside formal ones (41:502). Capture PolicyBazaar's quote list next time for a richer reference.
- CRED's premium language: a display face reserved for the user's own words, huge white space, monochrome imagery, one action, caps micro-labels instead of subtitles (22:9, 22:13, 22:3). Our cream grounds and handwriting face can do the same job with warmth instead of cold grey.

**The 5 best section designs for a travel app like ours (ranked)**
1. CRED checkout trust sheet, 41:340. Amount, source, method, time promise, proof and terms in one calm sheet with one button. Direct model for paying a trip balance or deposit on booked trip.
2. Groww confirm-the-document screens, 41:415 and 41:417 (with 41:416 for the reassurance line). Checking traveller names against a passport-style card, with a clear irreversible warning, prevents the most expensive travel mistake (wrong name on a ticket).
3. CRED one-question serif sheet over a full-bleed photo, 22:9 (with the 22:8 progress checklist). The best feel for our wizard: the destination photo on top, one question, the answer large in our display face, then a step checklist while the route is built.
4. INDmoney "only 3 steps remaining" stepper, 41:484. A ready-made pattern for the booked trip screen (balance, passports, visa, vouchers) that tells people exactly what is left.
5. Paisabazaar invest-and-get timeline card, 41:502. Fixed positions for amounts and dates make options comparable at a glance. Use it for itinerary version cards and for a part-payment schedule.
- Close runners-up: PolicyBazaar travel insurance destination chips with multi-select (41:461) for the wizard, and Khatabook's sample-output empty state (41:495) for empty wishlist and itinerary.

**The 5 things to never copy**
1. CRED's rewards casino, 41:337. Slot machines, a "PLAY" button, live coin counters and countdown timers turn a premium brand into a gambling app. Variable-reward dark pattern.
2. Paisabazaar's pre-ticked consents, 41:507 and 41:505. Pre-ticked legal appointment and marketing opt-ins break trust the moment users notice, and break our "hints not pre-ticks" rule.
3. False urgency, 41:502 and 41:504. "Selling Fast" on every card and "5 Days Left" countdowns. Our trips are planned, not panic-bought.
4. Ads and cross-sells inside money screens, 41:406 and 41:396. A telecom ad on a balance screen and a third-party ad in a booking flow undercut the trust the payment step needs.
5. Alarm states and tag overload, 41:481, 41:491, 41:469 and 41:506. Red "pending" and "Weak" labels shame users for normal steps, and a tag on every tile means no tile stands out. Both break our rules on red and green and on solid badges.
