---
name: competitor-patterns
description: The 30 Sundays design reference library. A critical, screen-by-screen evaluation of 1,118 screens from 49 Indian consumer apps, Scapia, Facebook groups and our own app audit (the "Research - 30 Sundays" Figma file), sorted by component kind, plus the brand board and our own reusable components. Use before designing or changing any screen, section or card, when offering design variations, or when the user says "refer competitors", "refer the research file" or "refer the brand board".
---

# Competitor and brand patterns

Read this before drawing a new section. The order of authority:

1. **Brand board**: sunsetFuchsia `#FD014F` (in-app `#E31B53`), tropicalForest `#254342`,
   lagoonBliss `#00A898`, goldenHour `#FDA201`, coastalMist `#EAE6E3`. Cream grounds `#FFF6E6`
   / `#FFFBF2`, navy headings `#181E4C`, handwriting display face (Caveat stands in).
   Fuchsia is the one primary action per screen. Golden is attention. Lagoon is proof. Green is
   type. White is the default ground; a tinted block is a doorway, not a field. No solid pill
   badges; coloured text carries it. No red, no green for "good or bad".
2. **The app's own screens** (reuse before inventing): activity card and rail on the city page
   (`RegionDetail.jsx`, `ActCard` + `ThingsToDo`), the trip card (`BookedCard`), the wishlist
   heart (`SaveHeart`), Sunday School (`EduMultiCarousel`), the month chips (`skyStyle.js`,
   `seasonStyle.js`), the FAQ on the region page.
3. **Scapia destination page** (screenshots in `~/Downloads/Scapia destination page/`, 7 PNGs
   of the Vietnam page).
4. **Research Figma file**: https://www.figma.com/design/haAwWioQ8bxCJWkYNEcLaV/Research---30-Sundays--Copy-
   Fully evaluated on 2026-10-30. Do not re-read the Figma file for routine work; use the
   reference files below. Cite screens by node id (e.g. `35:104`) so the team can open them.

## Reference files (in `references/`), and when to open each

| File | Open it when |
|---|---|
| `PATTERNS.md` | Designing any section. One entry per component kind: best examples ranked with node ids, rules for 30 Sundays, never-copy list, which of our screens it fits. Start here. |
| `DESIGN-LANGUAGE.md` | Choosing type sizes, colour use, spacing, copy tone; app scores table; dark patterns seen. |
| `30sundays-audit.md` | Changing anything that already exists in our app. Screen by screen, with the designers' own notes quoted, and the 10 biggest problems ranked with fixes. |
| `travel-1.md` | cleartrip, bookmyshow, OYO, easemytrip (booking flows, price bars, hotel pages, proof). |
| `travel-2.md` | headout, ixigo, redbus, yatra (things to do, date-price calendars, cancellation tables, filters). |
| `scapia-social-splash.md` | Scapia Hotels, the Scapia destination page, Facebook groups (community), the old couples-era app, and the splash and onboarding study with a recommendation for ours. |
| `banking-insurance.md` | CRED, Paytm, PhonePe, Groww, PolicyBazaar, INDmoney, Khatabook, paisabazaar (payment trust, part payment, confirm screens, premium restraint). |
| `food-services.md` | zepto, bigbasket, blinkit, swiggy, zomato, urban company (dense homes, tiles, restaurant pages for "where to eat", estimate builders). |
| `retail.md` | pepperfry, nykaa, mamaearth, lenskart, myntra, flipkart, meesho (detail pages, galleries, policies as timelines, one-hue identity). |
| `health-mobility.md` | pharmeasy, tata 1mg, pristyn care, cult fit, rapido, ola, cars24, cardekho, spinny (expert booking, callback forms, live status, big-ticket pricing). |
| `edtech-jobs-realestate.md` | physics wallah, upgrad, apna, 99acres, magicbricks, housing.com, stanza living, nobroker (video lists for Sunday School, profile builders for the wizard, listing detail pages). |
| `splash-notes.md` | The designers' notes for the splash study columns. |
| `ids.json`, `screens-index.json`, `canvas-notes.json` | Node ids per app, every exported screen with its layer name and canvas position, every label and note on the canvas. |

Known gaps in the captured screens (do not claim evidence for these): no live order tracking
(swiggy, zomato), no full reviews page or reviews with photos, no filled wishlist, no full car
inspection report, no Ola live ride, no apna community feed, no part-payment flow, no welcome
carousels in the onboarding study (only launch animations). Frames 152:9 and 152:62 exported
blank.

Privacy: audit screens 141:8 and 141:79 show a real customer's name, phone and email. Never
quote those details; they should be blurred in Figma before the file is shared.

## How the file was read (if it ever needs re-reading)

One page, 1,193 top-level items: 1,076 loose phone screenshots (RECTANGLE nodes with image
fills), 86 text labels and notes, 5 frames. The Figma MCP tools hit the Starter plan's call
limit quickly and fail on the whole page (replies over about 28,000 characters get cut). What
works with no limit: open the file in Chrome, and in that page run JavaScript against the
`figma` global (`figma.getNodeByIdAsync(id)`, `node.exportAsync({ format: 'JPG', constraint: {
type: 'WIDTH', value: 420 } })`), zip the results in the page and download one file. Screens were
assigned to apps by the nearest app label above and to the left, within that label's column.

Layout of the file:
- "Competitor research and UI benchmarking (49 Apps)": ten category rows, one column per app.
  Travel and Ticketing (cleartrip, bookmyshow, OYO, easemytrip, headout, ixigo, redbus, yatra),
  Health and Pharmacy (pharmeasy, tata 1mg, pristyn care, cult fit), Automobile and Mobility
  (rapido, ola, cars24, cardekho, spinny), Banking and Insurance (CRED, Paytm, PhonePe, Groww,
  PolicyBazaar, INDmoney, Khatabook, paisabazaar), EdTech (physics wallah, upgrad), Food and
  Quick Commerce (zepto, bigbasket, blinkit, swiggy, zomato), Home Services (urban company),
  Jobs (apna), Retail (pepperfry, nykaa, mamaearth, lenskart, myntra, flipkart, meesho),
  Real Estate (99acres, magicbricks, housing.com, stanza living, nobroker).
- "Scapia Hotels" and "Facebook groups", top right.
- Frame 129:108: splash and onboarding study.
- "internal App Audit": the current 30 Sundays app with the designers' heuristic notes, and a
  "where to eat" card rework.

## Destination page decisions already made (Bali v4)

| Kind | Scapia | Our app today | Rule for new work |
|---|---|---|---|
| Hero | Full-bleed photo, back pill top left, gallery counter | Same, plus share and heart pills; soft fade into white | Keep. Vibe tiles under the photo, not on it |
| Quick facts | Tight grid of label over value | Fact grid 2x2, no icons | Label over value. Icons only when they add meaning |
| Why go / USPs | Four white cards with 3D emoji, one-line title, one-line sub | Plain copy, no cards | Do not copy the 3D icons; the user asked for fewer hard icons |
| Things to do | Polaroids with tape and handwriting captions, dotted lines to a map | White activity card in a rail, kind pill, clock | Default to the app's card. Polaroids only as a one-off character section |
| Places / map | White country outline with dots, polaroids tied to dots | Leaflet map, area cards with heart | Keep the real map. Save with the heart |
| Best time | Not shown | Seasons first (Peak, Mid, Off), months behind a toggle | Seasons first. Planner's words and colours. Never negative words |
| Packages | Not shown | `BookedCard` (who booked, nights, route, price, style tag) | Reuse the card as is |
| Reviews | Not shown | Summary, Liked / Didn't like chips, three cards, photos | Keep short. Real Google reviews when available |
| Trust / expert | "Talk to an expert" sticky with a sparkle line above | Sticky "Plan my trip" with the reassurance line above | One fuchsia button. Sparkle line in plum or ink, not fuchsia |
| Section titles | Title plus a one-line sub | Title only | Never a subtitle unless asked (standing rule) |

## How to use this on a new section

- Name the component kind, open its entry in `references/PATTERNS.md`, and start from our own
  component if one exists (list above).
- Borrow the idea from the best example, never its colours, icons or badges. Check the
  never-copy list for that kind.
- If the screen already exists in our app, read its entry in `30sundays-audit.md` first.
- Offer 3 to 5 variations as boards on the canvas when the user asks to choose; one is the
  app's own pattern, one is the competitor's idea re-coloured, the rest sit between.
- Every option: white ground (or brand cream), brand colours only, the wishlist heart where a
  thing can be saved, no em dashes, short copy, no subtitles.

## Log

- 2026-10-30: created from the Bali destination page review (canvas comments).
- 2026-10-30: every screen evaluated (1,118 of 1,118) by nine agents from local exports, merged
  into PATTERNS.md and DESIGN-LANGUAGE.md.
