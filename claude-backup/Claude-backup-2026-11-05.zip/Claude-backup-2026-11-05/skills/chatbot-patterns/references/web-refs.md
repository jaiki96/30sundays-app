# Web references: Figma community and Dribbble

Six links the user found. Figma community pages only expose one cover image without a
login, so each entry describes the cover and the shot, not every inner frame. Read on
2026-11-01.

| Reference | Link | What it shows | Kept | Left |
|---|---|---|---|---|
| Chatbot AI (Davoodi) | figma.com/community/file/1339143564730755965 | A warm cream chat home, a history list with titles and dates, a thread with short bubbles and a rounded composer. | The cream home, the history list as plain rows. | Purple accents, the mascot avatar. |
| AI Chatbot Mobile App UI Design | figma.com/community/file/1401789639851560960 | A welcome screen with starter prompts as one-line chips, a thread with the assistant's text unbubbled and the user's in a tinted bubble. | Starter prompts as chips, in the user's voice. Assistant text without a bubble. | Dark glass cards, gradient orb. |
| Miquido Gym Chatbot App Concept | figma.com/community/file/1124291019178940578 | Stacked quick replies under the assistant's question, a data card (a workout plan) inside the thread, one question at a time. | Stacked quick replies, a card in the thread, one question at a time. | Black ground, neon accent. |
| 3 Free AI Chatbot App UI Kit (slothui) | figma.com/community/file/1393822153168458311 | A long answer broken into sections with small headings, a copy and share row, a conversations list with search. | Sections in a long answer, search in the conversations list once there are many. | Gold and purple, badges on every row. |
| AI Dating Assistant (Dribbble 27734614) | dribbble.com/shots/27734614 | "Options to select" shown as stacked replies under one question, a progress line while the assistant works, a profile card the assistant built. | One question at a time, options as stacked replies, a result card at the end. | Pink gradient ground, the mascot. |
| AI Financial Assistant (Dribbble 26579516) | dribbble.com/shots/26579516 | A single soft visual for the assistant's presence, a contextual placeholder in the composer, a summary card with a figure and a one-line explanation. | One visual for presence (our orb), a placeholder that changes with context, a figure with one line under it. | Dark theme, glow effects. |

What all six share, and what we keep: short bubbles, chips as the main way to answer,
cards inside the thread for anything with a picture or a number, a history list as plain
rows. What all six share, and what we leave: purple or gradient grounds, a mascot, and a
dark mode as the default.
