# Chatbot screens: screen-by-screen read

40 phone screenshots of AI assistants in Indian consumer apps. Each image sits in the screens folder next to this file. All images matched the app named for their range. Fit is judged against a calm, white, brand-pink travel app that shows 2-3 options before any change.

## MakeMyTrip (assistant called Myra)

| Image | What the screen is | Elements worth noting | Take or leave |
|---|---|---|---|
| IMG_3949 | App home with an ask bar | Ask bar with gradient outline, placeholder "Ask Myra about 'Coorg Homestays'", "Speak" button inside it. Floating "Ask myra" round button over the tab bar. | Take the example-in-placeholder idea. Leave the gradient outline and the double entry, one is enough. |
| IMG_3950 | Chat home with recent chats | Heading "Hi, Jaikishan". Intro line, "I'm Myra", "Let's plan your next trip together". "Recent Conversations" with two rows ("Ubud Overview", "Hotel Comparison") and dates. Close and more buttons. | Take the calm greeting and short chat list. Leave the beta tag and the empty lower half. |
| IMG_3951 | Long reply, streaming | User bubbles "Ubud" and "Tell me about ubud". Reply with a "Myra" label, bold headings, bullets with bold lead words. Input "Ask me anything" with "Speak". Scroll-down arrow. | Leave the long essay. Take the clear speaker label. |
| IMG_3952 | End of reply with follow-ups | Four small icons (like, dislike, save, copy). Question "Shall I help you find flights or plan a complete trip to Ubud?". Three tinted rows: "Search flights to Bali", "Plan a trip to Ubud", "Find hotels in Ubud", each with an arrow. | Take the three next-step rows. Leave the tinted box, use white rows. |
| IMG_3953 | Compare request and reply | User bubble holds three hotel photos and the label "Compare these hotels". Reply text, then a raw table that shows as plain pipe characters. | Take the compare-by-picking idea. Leave the broken table, show a clean card. |
| IMG_3954 | Reply ending with a stay card | Text "Feel free to proceed with booking...". Card "Recommendations in Gurgaon, Wed, 20 May" with "View All". One photo card: "The Trenzy home : Skyline", "Starting at ₹4,465/night", save icon. | Take the one big card with price and save. Leave the card-in-a-card box. |
| IMG_3955 | Thinking card | User bubble "What can i do once in singapore?". Card "Working on your request..." with two steps, "Mapping the destination..." and a short grey line under each. Some text is cut off. | Take the idea of showing steps. Leave the two-step wording and the cut text. |
| IMG_3956 | Finished thinking, reply start | Collapsed bar "Done! Here's what I've put together!" with a chevron. Reply with heading "Iconic Landmarks and Modern Vistas" and bullets with tips. | Take the collapse-when-done behaviour. Leave the exclamation tone. |
| IMG_3957 | Table and experience cards | Small table with columns "Mode", "Cost", "Use for" (Bus, MRT, Taxi). Card "Recommended Experiences", photo card "Gardens by the Bay", "Landmarks", "Starting from ₹520", dots "1/5". | Take the short table and photo carousel. Leave the five-card swipe, we show two or three. |
| IMG_3958 | End of reply with five chips | Carousel tail with "1/5" pill. Four icons. Question about modern sites or cultural districts. Five tinted rows, last is "Help me plan a trip to Singapore". | Leave five rows, too many. Take the last row as a way into trip planning. |

## Mindtrip

| Image | What the screen is | Elements worth noting | Take or leave |
|---|---|---|---|
| IMG_3959 | Home with ask bar | "Jump back in" cards (a guide, a trip), "For you in Gurugram (Gurgaon)", "Get inspired". Bottom bar: "+", "Ask anything...", mic, waveform button. Tabs: Home, Chats, Trips, Explore, Profile. | Take the white home with a quiet ask bar and "Jump back in". Leave the black waveform button. |
| IMG_3960 | Chat starting to reply | Title "Singapore Travel Overview" with a dropdown, new-trip and share icons. User line with avatar. Reply begins with a small flag icon. Black stop button replaces the waveform. | Take the named chat title. Take the stop button idea. Leave the empty space before text arrives. |
| IMG_3961 | Drawer of chats and trips | Search "Search titles...". "New Chat", "New Trip". "Trips" list with "Trip to Bali". "Chats" list, current one in bold, some marked "Trip to Bali", two "Untitled Chat". | Take search, new chat, and chats grouped under a trip. Leave "Untitled Chat" rows, name them. |
| IMG_3962 | Reply end with place cards | Bullets, then question about itinerary, best time, food, nature. Two place cards side by side: "Singapore" and "Indonesia", "Country", "Mentioned by 7 people", heart and plus icons. Floating "Map" pill. | Take the white cards and the Map pill. Leave the "Mentioned by" social line for now. |
| IMG_3963 | Map view of the chat | Map with named pins (Little India, Chinatown, Marina Bay), small avatar stacks with counts, round tools on the right. Bottom sheet "Back to chat". | Take the map and Back to chat sheet. Leave avatar stacks. |
| IMG_3964 | Reply with a food list | Heading "Classic Singapore must-eats (local + iconic)". Entry "Song Fa Bak Kut Teh", "4.4" star, "Chinese", price marks. Large photo. Band: "Personalize your Mindtrip experience." with button "Set up your assistant" and a close. | Take the list entry with name, rating and one line. Leave the band sitting on top of the input. |
| IMG_3965 | Reply with a second food entry | "Lagnaa...barefoot dining", "4.5", "Indian", "₹₹", photo with dots, "Saved by 2 people". Map pill and the same band. | Take the photo entry. Leave the repeated band and the saved-by line. |
| IMG_3966 | Onboarding step 1 | Black sparkle icon. Heading "Let's Make Travel More You". "Take three minutes to set up your personal travel assistant". Three bold-led points. Progress line, black "Get Started" button. | Take the plain white step with one clear button. Leave the three-minute cost, too heavy. |
| IMG_3967 | Onboarding step 2, voice and personality | Heading "Before we dive in, how would you like our conversations to sound?". "Voice" list: Marin, Shimmer, Echo, Cedar, each with a play button. "Personality" starts with "Casual". | Leave voice picking, not needed. Take the choice rows with one selected outline. |
| IMG_3968 | Same step, scrolled | Personality rows: "Casual, Playful, treats planning as fun.", "Neutral, Clear, organized, helpful. Opinionated when asked, skips flattery.", "Professional". Back arrow, "Next". | Take the tone choice with one-line help. Leave it as a forced step. |
| IMG_3969 | Onboarding step 3, past places | Heading "Share a few places you've been." "Favorite places" with "Add place". "Countries you've visited" chips (Czech Republic, Indonesia) with remove marks. "Connect Google Calendar". | Leave, asks too much up front. Chips with a remove mark are fine. |
| IMG_3970 | Onboarding step 4, travel style | Heading "Tell me a bit about your travel style." Questions with chips: Solo, Couple, Family, Friends. Budget chips "$ On a budget" to "$$$$ Luxury". "Next" greyed out. | Take the chip questions for who and budget. Leave the dollar signs and the locked Next. |
| IMG_3971 | Same step, scrolled | Accommodation chips with icons: Luxury hotels, Boutique hotels, Bed & breakfasts, Hostels, Campgrounds, Eco-lodges, Inns, Resorts, Motels, Short-term rentals. | Leave, ten chips is a wall. |
| IMG_3972 | Guide detail sheet | Photo header "Foodie's guide to Singapore [Sample]", author, "12 places", date. Short text, "Read more". Gradient button "Plan a trip" and a map icon. | Take the single "Plan a trip" action. Leave the pastel gradient button. |
| IMG_3973 | Reply with a hotel entry, still streaming | Heading "Central + easiest for first-timers (great base for exploring)". Entry "Iyf Funan Singapore", "4.2" star, one-line why, photo with dots, "Mentioned by 4 people". Stop button in the bar. | Take a hotel entry with a one-line reason. Leave the social line. |
| IMG_3974 | Reply end with a trip prompt card | Text names two stays and asks for dates and budget per night in INR. Card "Looks like you're headed to Singapore." with line about keeping plans in one place and a "Create trip" button. | Take the quiet card that offers a trip. Leave the long double question above it. |

## Zomato

| Image | What the screen is | Elements worth noting | Take or leave |
|---|---|---|---|
| IMG_3975 | Voice greeting over search | Dark blurred top with "Hi! How can I help you?", "Speaking", mic and close. Search sheet "Search...", "Your recent searches" chips (Burgin, Tiny Tuscan, Theos) with "Clear". Diwali banner. Keyboard open. | Leave the dark voice overlay. Take recent searches with Clear. |
| IMG_3976 | Feed loading | Title "Your Feed", home and menu buttons. Grey blank blocks. Ask box "What do you feel like eating?" with "+" and cart, send arrow. Line "AI-powered responses. Please check important details." | Take the plain ask box with the disclaimer line. Leave the blank blocks, show real content. |
| IMG_3977 | Feed with a snack carousel | Pink-to-purple heading "More snacks options that you might like". Dark photo card "Mathania Chicken Tik...", "₹495", "4.3", "30-35 mins", pink "ADD +". Black "Explore more". Heading "Too many options? Let us help you decide". | Take the idea of one big card with price and a clear button. Leave the dark cards and gradient text. |
| IMG_3978 | Feed with Match my taste | Top shows a pink glow circle with floating food icons and a "Match my taste" tile. Heading "Want to keep it light ?". Card "Perfect way to start your evening" with three dishes (Tikka, Dimsums, Shikanji) and "Explore more". | Take the three-item row. Leave the glow and floating icons. |
| IMG_3979 | Feed with trending items | Heading "Trending items near you" with a pin. Large card "Samosa Party Bucket- Mini...", "₹179", "4.4", "20-25 mins", "ADD +". Ask box sits over the content. | Leave, one card at a time hides the rest. Keep the pin heading idea. |
| IMG_3980 | Working state | User bubble "I am thinking of a cheesy juicy burger". Centre animation of purple plus shapes and the words "Exploring local favorites...". Stop button in the ask box. Title "Your feed" with a dropdown. | Take a single short working line. Leave the heavy pattern, use a quiet dot. |
| IMG_3981 | Reply with a food card | Short paragraph that names two burgers and gives a reason ("Since you usually go for grilled chicken..."). Big photo card "Cheesy Peri Peri Chicken Grilled...", "₹254", rating, time, "ADD +". Second card peeks in. | Take reason-then-card in this order. Leave the dark overlay text on the photo. |
| IMG_3982 | Reply end with actions | Same card. Two pink outlined buttons: "Order Cheesy Peri Peri Burger", "View Kaffee Stories menu". Like and dislike icons. | Take two plain action buttons after a card. Leave the pink fill on the buttons. |

## ixigo

| Image | What the screen is | Elements worth noting | Take or leave |
|---|---|---|---|
| IMG_3983 | Voice listening over home | Home banner "Smart Lock" and category tiles (Flights, Trains, Buses, Hotels) dimmed behind. Dark pills "Best Hotel Stays, Find perfect accommodations" and "International Fli...". Colour orb, mic, keyboard buttons, word "Listening", closed captions icon, close. | Leave, the full-screen orb hides the app. Take the topic pills idea only. |
| IMG_3984 | Typing mode with prompt suggestions | Banner "Flat 10% off on your 1st Flight". Three dark rows: "Search hotels in Mumbai near Marine Drive.", "Find boutique hotels in Delhi's Connaught Place.", "Look for beachfront resorts in Goa for November." Input "Ask me anything about travel". Keyboard and wave toggle. | Take example sentences that read like real asks. Leave the dark glass and busy banner behind. |
| IMG_3985 | Assistant over a hotel list, searching | Hotel list behind: date pill "Marine Drive 02 Nov - 03 Nov", filter chips, card "Hotel Mari Aai Residency", "₹1,586". Over it a soft gradient with the line "Searching for the best hotels near Marine Drive in Mumbai for you." | Take the assistant changing the real results page. Leave text laid over the cards, it hides them. |
| IMG_3986 | Reply with follow-up chips | Same list. Reply text mentions premium options and offers to filter by price. Dark chips: "Marine Drive View", "5-Star Hotels", "Boutique Hotel...". Filter row now starts with "Best Price Guarantee". | Take chips that refine the list. Leave the dark chips and text over the list. |
| IMG_3987 | Dates changed, new chips | Date pill now "29 Nov - 30 Nov". Card "Bentley Hotel", "8.8 Excellent", "₹5,919". Reply "Sure, I can help with that. Where would you like to fly from and what is your destination?" Chips: "Pool & Breakfast", "Sea Facing Hotels", "Free Cancell...". | Leave, the reply does not match the screen and the dates changed without a clear sign. |
| IMG_3988 | Flight results after a voice ask | Header "New Delhi to Mumbai, 29 Nov, 1 Traveller, Economy". Date strip with prices. Chips "Filters", "Sort By", "Non-Stop", "Airlines". Card "IndiGo", "07:10", "09:15", "₹7,149", "CHEAPEST". Reply "I've launched a search for flights from Delhi to Mumbai..." | Take the assistant landing you on a real results page. Leave the text floating over the offers block. |

## Counts

- Screens per app: MakeMyTrip 10, Mindtrip 16, Zomato 8, ixigo 6. Total 40.
- Entry point (home or feed with an ask bar, or a launch overlay): MakeMyTrip 1 (IMG_3949), Mindtrip 1 (IMG_3959), Zomato 5 (IMG_3975 to IMG_3979), ixigo 2 (IMG_3983, IMG_3984). Total 9.
- Thinking or working state: MakeMyTrip 2 (IMG_3955 working, IMG_3956 done), Mindtrip 2 (IMG_3960 and IMG_3973, streaming with a stop button), Zomato 2 (IMG_3976 loading blocks, IMG_3980 working line), ixigo 2 (IMG_3983 listening, IMG_3985 searching line). Total 8.
- Inline cards: MakeMyTrip 3 (IMG_3954, IMG_3957, IMG_3958), Mindtrip 5 (IMG_3962, IMG_3964, IMG_3965, IMG_3973, IMG_3974), Zomato 5 (IMG_3977 to IMG_3979, IMG_3981, IMG_3982), ixigo 0. Total 13. The hotel photos inside the user bubble in MakeMyTrip IMG_3953 are not counted.
- Map: MakeMyTrip 0, Mindtrip 1 map screen (IMG_3963) plus a "Map" pill on 5 more screens (IMG_3962, IMG_3964, IMG_3965, IMG_3973, IMG_3974), Zomato 0, ixigo 0.
- Chips or quick actions: MakeMyTrip 2 (IMG_3952, IMG_3958), Mindtrip 3 (IMG_3969, IMG_3970, IMG_3971, all onboarding chips), Zomato 2 (IMG_3975 recent searches, IMG_3982 action buttons), ixigo 4 (IMG_3983, IMG_3984, IMG_3986, IMG_3987). Total 11.
- Conversations list: MakeMyTrip 1 (IMG_3950), Mindtrip 1 (IMG_3961), Zomato 0, ixigo 0. Total 2.
- Disclaimer line: MakeMyTrip 0, Mindtrip 0, Zomato 7 (IMG_3976 to IMG_3982), ixigo 0. Total 7.
