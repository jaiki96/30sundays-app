---
name: chatbot-patterns
description: The 30 Sundays reference for in-app AI assistants and conversational search. A screen-by-screen read of 40 competitor screenshots (MakeMyTrip Myra, Mindtrip, Zomato, ixigo) and 6 Figma and Dribbble chatbot references, with what to take and what to leave, plus the house rules for Annie, the 30 Sundays assistant. Use before designing or changing any chat, ask bar, assistant band, thinking state, option cards or conversation list, or when the user says "refer the chatbot research", "like Myra", "like Mindtrip" or "like ixigo".
---

# Chatbot and assistant patterns

Read this before drawing anything that talks back. The order of authority is the same as
the competitor-patterns skill: brand board first, the app's own screens second, then the
references here. Cite a screenshot by its number (IMG_3956) so the team can open it.

## Files

| File | Open it when |
|---|---|
| `references/screens.md` | You need one screen's detail. One row per image, 40 rows, grouped by app, with what is on it and whether to take it. |
| `references/screens/IMG_3949.jpg` to `IMG_3988.jpg` | You want to look. 420 px wide copies of the originals. |
| `references/web-refs.md` | The six Figma and Dribbble references, what each one shows and what was kept. |

## The four apps in one line each

- **MakeMyTrip Myra** (IMG_3949 to 3958): a full-screen chat that does real bookings inside
  the app. Long replies, visible thinking, recent conversations, next steps as a list.
- **Mindtrip** (IMG_3959 to 3974): a persistent "Ask anything" bar, places as cards inside the
  thread with a heart on each, a Map pill that opens a real map, a drawer of chats and trips.
- **Zomato** (IMG_3975 to 3982): a feed that reads like a conversation, headings phrased as the
  user's question, quick actions that name the exact dish or restaurant.
- **ixigo** (IMG_3983 to 3988): no chat window at all. The real hotel or flight list opens and a
  band at the bottom carries the assistant's line, chips and the composer.

## What to take and what to leave, per app

### MakeMyTrip Myra

Entry: a bar at the top of home, "Ask Myra about 'Coorg Homestays'", with Speak, plus a
round "Ask myra" button fused to the tab bar (IMG_3949). Chat home with a big greeting,
"Hi, Jaikishan", and a Recent Conversations list with title and date (IMG_3950). Replies
are long markdown with headings, bullets and bold names, a scroll-to-bottom arrow
(IMG_3951), and a feedback row of thumbs up, thumbs down, bookmark and copy. Next steps
come as a stacked list with arrows: "Search flights to Bali", "Plan a trip to Ubud", "Find
hotels in Ubud" (IMG_3952). A hotel comparison starts from three thumbnails in the user's own
bubble and ends in a table that leaks as raw pipes (IMG_3953). A stay card carries a date,
View All, a photo, "Starting at ₹4,465/night" and a bookmark (IMG_3954). Thinking is an
expandable "Working on your request" card with named sub-steps and one grey line each
(IMG_3955), collapsing to "Done! Here's what I've put together" (IMG_3956). A short
transport table and a "Recommended Experiences" rail with a 1/5 pager and "Starting from
₹520" (IMG_3957). A reply that ends in five stacked chips, two too many (IMG_3958).

Take: the recent conversations list, the stacked next-step list, the thinking card with named
sub-steps that collapses when done, a comparison that starts from the things the user picked.
Leave: walls of text, the broken table, em dashes, two entry points on one screen.

### Mindtrip

Home: "Jump back in" cards tagged Guide or Trip, "For you in Gurugram", and the persistent
"Ask anything" bar above the tab bar with attach, mic and a voice orb (IMG_3959). While
streaming the orb becomes a stop button; user lines have an avatar and no bubble; the chat
title doubles as a menu, with add-to-trip and share beside it (IMG_3960). The drawer has
search, New Chat, New Trip, Trips and Chats, with the trip name under each chat (IMG_3961).
Places appear inline: country cards with heart and plus and "Mentioned by 7 people"
(IMG_3962), restaurant and hotel rows with star, cuisine, price band and a photo carousel,
"Saved by 2 people" (IMG_3964, 3965, 3973). A floating "Map" pill in the thread (IMG_3962)
opens a full map with named pins and a "Back to chat" sheet (IMG_3963). Inline nudge
cards: "Personalize your Mindtrip experience" (IMG_3964) and "Looks like you're headed to
Singapore. Create trip" (IMG_3974). A four-step personalisation wizard: voice and
personality (Casual, Neutral, Professional), places you have been, travel style chips,
with a progress bar (IMG_3966 to 3971). A guide page with a gradient "Plan a trip" button
and a map icon (IMG_3972).

Take: the persistent bar, the Map pill and Back to chat, the heart on every place, the
drawer, social proof on a card ("Saved by 2 people"). Leave: the personalisation wizard
before any value, the black theme, ratings crammed next to names in headings.

### Zomato

A voice overlay at the top over the normal search sheet (IMG_3975). "Your Feed" loads as a
skeleton (IMG_3976) then reads like a conversation: gradient headings phrased as questions,
"Too many options? Let us help you decide", "Want to keep it light?", card rails with Add,
"Explore more" pills (IMG_3977, 3978). Composer "What do you feel like eating?" with add and
cart, and a line "AI-powered responses. Please check important details." (IMG_3976 to
3982). A trending card that hides the rest of the feed (IMG_3979). Chat mode: a user bubble,
a purple dot animation with "Exploring local favorites" while it thinks (IMG_3980), a reply
with a reason and a card (IMG_3981), then pink outline quick actions that name the exact
thing, "Order Cheesy Peri Peri Burger", "View Kaffee Stories menu", and thumbs (IMG_3982).

Take: section headings phrased as the user's question, quick actions that name the exact
thing, the one-line disclaimer. Leave: the dark overlay, emoji in headings, gradient text.

### ixigo

No chat window. A rainbow orb with "Listening", mic and keyboard buttons, over the live home
(IMG_3983). Dark suggestion cards, "Best Hotel Stays", expand into example prompts, "Search
hotels in Mumbai near Marine Drive" (IMG_3984). Ask for hotels and the real hotel list opens
behind. A gradient blur band at the bottom carries the assistant's line, "Searching for the
best hotels near Marine Drive in Mumbai for you", chips that act as filters (Marine Drive
View, 5-Star Hotels, Boutique Hotels) and the composer (IMG_3985, 3986). The dates change
and the chips change with them (Pool and Breakfast, Sea Facing) (IMG_3987). Ask for flights
and the real flight results open the same way: "I've launched a search for flights from
Delhi to Mumbai... right on your screen." (IMG_3988).

Take: the whole shape, a band over the live screen, chips that filter the screen behind, a
narration line that says what just happened. Leave: the rainbow orb, dark chips, the band
covering the price of the first result.

### Figma and Dribbble references

See `references/web-refs.md`. In short: warm cream chat home and history list (Chatbot AI),
starter prompts as one-line chips (AI Chatbot Mobile UI), stacked quick replies and a data
card in the thread (Miquido), a sectioned long answer (slothui), "Options to select" and one
question at a time (AI Dating Assistant), one visual for presence and a contextual
placeholder (AI Financial Assistant). Leave: purple, mascots, dark glass, gold.

## House rules for a 30 Sundays assistant

1. **Options before action.** Every change shows 2-3 options first. The customer picks, then
   it is saved. Never change something and tell them after.
2. **2-3, never more.** Cards, chips, levers, next steps. Three is the ceiling.
3. **Chips in the user's voice.** "Make it cheaper", "Change my Ubud hotel". Never a label.
4. **One idea per line.** Short, plain, conversational. Never a wall, never a table in prose.
5. **One pink action.** Choose, Yes change it, Send. The orb is pink. Nothing else is.
6. **Teach the real screen.** Hotels and day plans confirm on the app's own screen, with one
   guide line. Nights and dates confirm in the chat, because they rebuild the trip.
7. **Never invent a day.** Days are whole plans. "Add snorkelling" shows days that include it
   and says what else moves.
8. **White ground, cream only on the greeting.** No dark theme, no rainbow orb, no sparkles.
9. **Thinking is shown, condensed, and collapses when done.** 3-5 named steps with a one-line
   result each. About half a second a step.
10. **Counts say what they count.** "9 stays found", not "9".
11. **Real data on every board.** Real cities, nights, prices per person, dates.
12. **No em dashes, no all caps, no subtitles, no couple wording.**

## Two shapes we keep

- **The chat** (Myra, Mindtrip): a sheet with a thread. Cards, options and thinking live
  inside it. Ways in: a persistent ask bar, or a bubble bottom right.
- **The band** (ixigo): no thread. One line, 2-3 chips, the composer, over the live screen.
  The app's real screens do the showing. A chevron opens the transcript.

## Log

- 2026-11-01: created from the 40 screenshots in the user's "AI chatbot competitor
  research" folder and the six web references, for the Annie assistant canvas.
